// WidgetBlueprintGeneratedClass InGameReplayMenu.InGameReplayMenu_C
// Size: 0x298 (Inherited: 0x260)
struct UInGameReplayMenu_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UButton* Button_Exit; // 0x268(0x08)
	struct UButton* Button_Option; // 0x270(0x08)
	struct UButton* Button_ReplayList; // 0x278(0x08)
	struct UImage* Image_5; // 0x280(0x08)
	struct UUIBlurBackground_C* UIBlurBackground; // 0x288(0x08)
	struct ATslHUD* HUD; // 0x290(0x08)

	void SetHUD(struct ATslHUD* inHUD); // Function InGameReplayMenu.InGameReplayMenu_C.SetHUD // Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void GotoReplayList(enum class EPopupButtonID ButtonID); // Function InGameReplayMenu.InGameReplayMenu_C.GotoReplayList // Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void QuitReplay(enum class EPopupButtonID ButtonID); // Function InGameReplayMenu.InGameReplayMenu_C.QuitReplay // Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void BndEvt__Button_ReplayList_K2Node_ComponentBoundEvent_210_OnButtonClickedEvent__DelegateSignature(); // Function InGameReplayMenu.InGameReplayMenu_C.BndEvt__Button_ReplayList_K2Node_ComponentBoundEvent_210_OnButtonClickedEvent__DelegateSignature // BlueprintEvent // @ game+0x33e45c
	void BndEvt__Button_Exit_K2Node_ComponentBoundEvent_228_OnButtonClickedEvent__DelegateSignature(); // Function InGameReplayMenu.InGameReplayMenu_C.BndEvt__Button_Exit_K2Node_ComponentBoundEvent_228_OnButtonClickedEvent__DelegateSignature // BlueprintEvent // @ game+0x33e45c
	void BndEvt__Button_Resume_K2Node_ComponentBoundEvent_247_OnButtonClickedEvent__DelegateSignature(); // Function InGameReplayMenu.InGameReplayMenu_C.BndEvt__Button_Resume_K2Node_ComponentBoundEvent_247_OnButtonClickedEvent__DelegateSignature // BlueprintEvent // @ game+0x33e45c
	void HidePopupWidgetForReplay(); // Function InGameReplayMenu.InGameReplayMenu_C.HidePopupWidgetForReplay // BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void OpenReplayListMap(); // Function InGameReplayMenu.InGameReplayMenu_C.OpenReplayListMap // BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void BndEvt__Button_Option_K2Node_ComponentBoundEvent_68_OnButtonClickedEvent__DelegateSignature(); // Function InGameReplayMenu.InGameReplayMenu_C.BndEvt__Button_Option_K2Node_ComponentBoundEvent_68_OnButtonClickedEvent__DelegateSignature // BlueprintEvent // @ game+0x33e45c
	void ExecuteUbergraph_InGameReplayMenu(int32 EntryPoint); // Function InGameReplayMenu.InGameReplayMenu_C.ExecuteUbergraph_InGameReplayMenu //  // @ game+0x33e45c
};

