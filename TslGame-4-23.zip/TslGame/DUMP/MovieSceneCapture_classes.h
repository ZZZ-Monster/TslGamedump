// Class MovieSceneCapture.MovieSceneCaptureInterface
// Size: 0x38 (Inherited: 0x38)
struct UMovieSceneCaptureInterface : UInterface {
};

// Class MovieSceneCapture.MovieSceneCaptureProtocolSettings
// Size: 0x38 (Inherited: 0x38)
struct UMovieSceneCaptureProtocolSettings : UObject {
};

// Class MovieSceneCapture.MovieSceneCapture
// Size: 0x250 (Inherited: 0x38)
struct UMovieSceneCapture : UObject {
	char pad_38[0x10]; // 0x38(0x10)
	struct FCaptureProtocolID CaptureType; // 0x48(0x08)
	struct UMovieSceneCaptureProtocolSettings* ProtocolSettings; // 0x50(0x08)
	struct FMovieSceneCaptureSettings Settings; // 0x58(0x50)
	bool bUseSeparateProcess; // 0xa8(0x01)
	bool bCloseEditorWhenCaptureStarts; // 0xa9(0x01)
	char pad_AA[0x6]; // 0xaa(0x06)
	struct FString AdditionalCommandLineArguments; // 0xb0(0x10)
	struct FString InheritedCommandLineArguments; // 0xc0(0x10)
	char pad_D0[0x180]; // 0xd0(0x180)
};

// Class MovieSceneCapture.AutomatedLevelSequenceCapture
// Size: 0x250 (Inherited: 0x250)
struct UAutomatedLevelSequenceCapture : UMovieSceneCapture {
};

// Class MovieSceneCapture.LevelCapture
// Size: 0x270 (Inherited: 0x250)
struct ULevelCapture : UMovieSceneCapture {
	bool bAutoStartCapture; // 0x248(0x01)
	char pad_251[0x3]; // 0x251(0x03)
	struct FGuid PrerequisiteActorId; // 0x254(0x10)
	char pad_264[0xc]; // 0x264(0x0c)
};

// Class MovieSceneCapture.MovieSceneCaptureEnvironment
// Size: 0x38 (Inherited: 0x38)
struct UMovieSceneCaptureEnvironment : UObject {

	int32 GetCaptureFrameNumber(); // Function MovieSceneCapture.MovieSceneCaptureEnvironment.GetCaptureFrameNumber // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x54a6f2c
	float GetCaptureElapsedTime(); // Function MovieSceneCapture.MovieSceneCaptureEnvironment.GetCaptureElapsedTime // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x54a6f04
};

// Class MovieSceneCapture.FrameGrabberProtocolSettings
// Size: 0x40 (Inherited: 0x38)
struct UFrameGrabberProtocolSettings : UMovieSceneCaptureProtocolSettings {
	char pad_38[0x8]; // 0x38(0x08)
};

// Class MovieSceneCapture.BmpImageCaptureSettings
// Size: 0x38 (Inherited: 0x38)
struct UBmpImageCaptureSettings : UMovieSceneCaptureProtocolSettings {
};

// Class MovieSceneCapture.ImageCaptureSettings
// Size: 0x48 (Inherited: 0x40)
struct UImageCaptureSettings : UFrameGrabberProtocolSettings {
	int32 CompressionQuality; // 0x40(0x04)
	char pad_44[0x4]; // 0x44(0x04)
};

// Class MovieSceneCapture.CompositionGraphCaptureSettings
// Size: 0x68 (Inherited: 0x38)
struct UCompositionGraphCaptureSettings : UMovieSceneCaptureProtocolSettings {
	struct FCompositionGraphCapturePasses IncludeRenderPasses; // 0x38(0x10)
	bool bCaptureFramesInHDR; // 0x48(0x01)
	char pad_49[0x3]; // 0x49(0x03)
	int32 HDRCompressionQuality; // 0x4c(0x04)
	enum class EHDRCaptureGamut CaptureGamut; // 0x50(0x01)
	char pad_51[0x7]; // 0x51(0x07)
	struct FStringAssetReference PostProcessingMaterial; // 0x58(0x10)
};

// Class MovieSceneCapture.VideoCaptureSettings
// Size: 0x58 (Inherited: 0x40)
struct UVideoCaptureSettings : UFrameGrabberProtocolSettings {
	bool bUseCompression; // 0x40(0x01)
	char pad_41[0x3]; // 0x41(0x03)
	float CompressionQuality; // 0x44(0x04)
	struct FString VideoCodec; // 0x48(0x10)
};

