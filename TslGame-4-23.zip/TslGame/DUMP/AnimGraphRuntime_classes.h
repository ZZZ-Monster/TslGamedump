// Class AnimGraphRuntime.AnimNotify_PlayMontageNotify
// Size: 0x50 (Inherited: 0x48)
struct UAnimNotify_PlayMontageNotify : UAnimNotify {
	struct FName NotifyName; // 0x48(0x08)
};

// Class AnimGraphRuntime.AnimNotify_PlayMontageNotifyWindow
// Size: 0x48 (Inherited: 0x40)
struct UAnimNotify_PlayMontageNotifyWindow : UAnimNotifyState {
	struct FName NotifyName; // 0x40(0x08)
};

// Class AnimGraphRuntime.AnimSequencerInstance
// Size: 0x3a8 (Inherited: 0x3a8)
struct UAnimSequencerInstance : UAnimInstance {
};

// Class AnimGraphRuntime.KismetAnimationLibrary
// Size: 0x38 (Inherited: 0x38)
struct UKismetAnimationLibrary : UBlueprintFunctionLibrary {

	void K2_TwoBoneIK(struct FVector RootPos, struct FVector JointPos, struct FVector EndPos, struct FVector JointTarget, struct FVector Effector, struct FVector OutJointPos, struct FVector OutEndPos, bool bAllowStretching, float StartStretchRatio, float MaxStretchScale); // Function AnimGraphRuntime.KismetAnimationLibrary.K2_TwoBoneIK // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x532e474
	struct FTransform K2_LookAt(struct FTransform CurrentTransform, struct FVector TargetPosition, struct FVector LookAtVector, bool bUseUpVector, struct FVector UpVector, float ClampConeInDegree); // Function AnimGraphRuntime.KismetAnimationLibrary.K2_LookAt // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x532e194
};

// Class AnimGraphRuntime.PlayMontageCallbackProxy
// Size: 0x120 (Inherited: 0x38)
struct UPlayMontageCallbackProxy : UObject {
	struct FMulticastDelegate OnCompleted; // 0x38(0x10)
	struct FMulticastDelegate OnBlendOut; // 0x48(0x10)
	struct FMulticastDelegate OnInterrupted; // 0x58(0x10)
	struct FMulticastDelegate OnNotifyBegin; // 0x68(0x10)
	struct FMulticastDelegate OnNotifyEnd; // 0x78(0x10)
	char pad_88[0x98]; // 0x88(0x98)

	void OnNotifyEndReceived(struct FName NotifyName, struct FBranchingPointNotifyPayload BranchingPointNotifyPayload); // Function AnimGraphRuntime.PlayMontageCallbackProxy.OnNotifyEndReceived // Final|Native|Protected|HasOutParms // @ game+0x532eb14
	void OnNotifyBeginReceived(struct FName NotifyName, struct FBranchingPointNotifyPayload BranchingPointNotifyPayload); // Function AnimGraphRuntime.PlayMontageCallbackProxy.OnNotifyBeginReceived // Final|Native|Protected|HasOutParms // @ game+0x532ea08
	void OnMontageEnded(struct UAnimMontage* Montage, bool bInterrupted); // Function AnimGraphRuntime.PlayMontageCallbackProxy.OnMontageEnded // Final|Native|Protected // @ game+0x532e928
	void OnMontageBlendingOut(struct UAnimMontage* Montage, bool bInterrupted); // Function AnimGraphRuntime.PlayMontageCallbackProxy.OnMontageBlendingOut // Final|Native|Protected // @ game+0x532e848
	struct UPlayMontageCallbackProxy* CreateProxyObjectForPlayMontage(struct USkeletalMeshComponent* InSkeletalMeshComponent, struct UAnimMontage* MontageToPlay, float PlayRate, float StartingPosition, struct FName StartingSection); // Function AnimGraphRuntime.PlayMontageCallbackProxy.CreateProxyObjectForPlayMontage // Final|Native|Static|Public|BlueprintCallable // @ game+0x532dfd8
};

