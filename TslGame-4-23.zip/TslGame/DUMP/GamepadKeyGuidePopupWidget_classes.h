// WidgetBlueprintGeneratedClass GamepadKeyGuidePopupWidget.GamepadKeyGuidePopupWidget_C
// Size: 0x5d0 (Inherited: 0x570)
struct UGamepadKeyGuidePopupWidget_C : UTslGamepadKeyGuideStepperPopupWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x570(0x08)
	struct UWidgetAnimation* PopupEmerging; // 0x578(0x08)
	struct UHorizontalBox* GamepadButtonCancel; // 0x580(0x08)
	struct UBP_GamepadMultipleKeyIconWidget_C* GamepadButtonCancelIcon; // 0x588(0x08)
	struct UHorizontalBox* GamepadButtonOK; // 0x590(0x08)
	struct UBP_GamepadMultipleKeyIconWidget_C* GamepadButtonOKIcon; // 0x598(0x08)
	struct UImage* OptionArrowLeft_Image; // 0x5a0(0x08)
	struct UImage* OptionArrowRight_Image; // 0x5a8(0x08)
	struct UImage* OptionTab_0_Image; // 0x5b0(0x08)
	struct UImage* OptionTab_1_Image; // 0x5b8(0x08)
	struct UImage* OptionTab_2_Image; // 0x5c0(0x08)
	struct UTextBlock* TextTitle; // 0x5c8(0x08)

	void SetPopup(enum class EPopupStyle PopupStyle, struct FText Title, struct FText Message, DelegateProperty PressedDelegate); // Function GamepadKeyGuidePopupWidget.GamepadKeyGuidePopupWidget_C.SetPopup // Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void ExecuteUbergraph_GamepadKeyGuidePopupWidget(int32 EntryPoint); // Function GamepadKeyGuidePopupWidget.GamepadKeyGuidePopupWidget_C.ExecuteUbergraph_GamepadKeyGuidePopupWidget // HasDefaults // @ game+0x33e45c
};

