// Class LightPropagationVolumeRuntime.LightPropagationVolumeBlendable
// Size: 0x88 (Inherited: 0x38)
struct ULightPropagationVolumeBlendable : UObject {
	char pad_38[0x8]; // 0x38(0x08)
	struct FLightPropagationVolumeSettings Settings; // 0x40(0x40)
	float BlendWeight; // 0x80(0x04)
	char pad_84[0x4]; // 0x84(0x04)
};

