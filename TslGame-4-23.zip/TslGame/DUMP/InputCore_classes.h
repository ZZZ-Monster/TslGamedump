// Class InputCore.InputCoreTypes
// Size: 0x38 (Inherited: 0x38)
struct UInputCoreTypes : UObject {
};

