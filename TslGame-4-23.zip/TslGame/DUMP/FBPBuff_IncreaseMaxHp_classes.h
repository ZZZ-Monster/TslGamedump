// BlueprintGeneratedClass FBPBuff_IncreaseMaxHp.FBPBuff_IncreaseMaxHp_C
// Size: 0x4a8 (Inherited: 0x4a0)
struct AFBPBuff_IncreaseMaxHp_C : ATslIncreaseMaxHpBuff {
	struct USceneComponent* DefaultSceneRoot; // 0x4a0(0x08)

	void UserConstructionScript(); // Function FBPBuff_IncreaseMaxHp.FBPBuff_IncreaseMaxHp_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
};

