// BlueprintGeneratedClass P_SwimIdle_Ripples_BP.P_SwimIdle_Ripples_BP_C
// Size: 0x4f0 (Inherited: 0x4f0)
struct AP_SwimIdle_Ripples_BP_C : ATslParticle {
};

