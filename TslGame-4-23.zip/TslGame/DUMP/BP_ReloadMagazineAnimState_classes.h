// BlueprintGeneratedClass BP_ReloadMagazineAnimState.BP_ReloadMagazineAnimState_C
// Size: 0x58 (Inherited: 0x48)
struct UBP_ReloadMagazineAnimState_C : UTslReloadMagazineAnimState {
	enum class Enum_MagazineReloadAnimStateActionType ActionType; // 0x48(0x01)
	char pad_49[0x7]; // 0x49(0x07)
	struct AActor* Gun; // 0x50(0x08)

	void DropMag(struct USkeletalMeshComponent* MeshComp); // Function BP_ReloadMagazineAnimState.BP_ReloadMagazineAnimState_C.DropMag // Public|BlueprintCallable|BlueprintEvent|Const // @ game+0x33e45c
	void AttachMag(struct USkeletalMeshComponent* MeshComp, bool Attach); // Function BP_ReloadMagazineAnimState.BP_ReloadMagazineAnimState_C.AttachMag // Public|BlueprintCallable|BlueprintEvent|Const // @ game+0x33e45c
	void ShowMag(struct USkeletalMeshComponent* MeshComp, bool Show); // Function BP_ReloadMagazineAnimState.BP_ReloadMagazineAnimState_C.ShowMag // Private|BlueprintCallable|BlueprintEvent|Const // @ game+0x33e45c
	bool Received_NotifyEnd(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Function BP_ReloadMagazineAnimState.BP_ReloadMagazineAnimState_C.Received_NotifyEnd // Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const // @ game+0x33e45c
	bool Received_NotifyBegin(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation, float TotalDuration); // Function BP_ReloadMagazineAnimState.BP_ReloadMagazineAnimState_C.Received_NotifyBegin // Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const // @ game+0x33e45c
};

