// BlueprintGeneratedClass Powerup_SuperDrink.Powerup_SuperDrink_C
// Size: 0x448 (Inherited: 0x440)
struct APowerup_SuperDrink_C : APowerup_Base_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x440(0x08)

	void UserConstructionScript(); // Function Powerup_SuperDrink.Powerup_SuperDrink_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void ReceiveBeginPlay(); // Function Powerup_SuperDrink.Powerup_SuperDrink_C.ReceiveBeginPlay // Event|Protected|BlueprintEvent // @ game+0x33e45c
	void ExecuteUbergraph_Powerup_SuperDrink(int32 EntryPoint); // Function Powerup_SuperDrink.Powerup_SuperDrink_C.ExecuteUbergraph_Powerup_SuperDrink //  // @ game+0x33e45c
};

