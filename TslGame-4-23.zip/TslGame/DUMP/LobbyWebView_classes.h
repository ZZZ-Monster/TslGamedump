// WidgetBlueprintGeneratedClass LobbyWebView.LobbyWebView_C
// Size: 0x455 (Inherited: 0x420)
struct ULobbyWebView_C : UBaseLobbyWebView {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x420(0x08)
	struct ULobbyRotationRectWidget_C* RotationRect; // 0x428(0x08)
	struct UCoherentUIGTWidget* WebView_1; // 0x430(0x08)
	struct TArray<struct UCoherentUIGTWidget*> ViewArray; // 0x438(0x10)
	int32 TickForWebViewVisibilityChange; // 0x448(0x04)
	struct FVector2D SaveMosuePosition; // 0x44c(0x08)
	bool bIgnoredLobbyWeb; // 0x454(0x01)

	struct FEventReply OnKeyDown(struct FGeometry MyGeometry, struct FKeyEvent InKeyEvent); // Function LobbyWebView.LobbyWebView_C.OnKeyDown // BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	struct FEventReply OnPreviewMouseButtonDown(struct FGeometry MyGeometry, struct FPointerEvent MouseEvent); // Function LobbyWebView.LobbyWebView_C.OnPreviewMouseButtonDown // BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	struct UCoherentUIGTWidget* GetMainCoherentWidget(); // Function LobbyWebView.LobbyWebView_C.GetMainCoherentWidget // Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const // @ game+0x33e45c
	struct FEventReply OnPreviewKeyDown(struct FGeometry MyGeometry, struct FKeyEvent InKeyEvent); // Function LobbyWebView.LobbyWebView_C.OnPreviewKeyDown // Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void WebViewBroadcast(struct FString EventName, struct FString Parameter); // Function LobbyWebView.LobbyWebView_C.WebViewBroadcast // Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void WebViewUnload(int32 ViewIndex); // Function LobbyWebView.LobbyWebView_C.WebViewUnload // Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void WebViewShow(int32 VeiwIndex, bool visible); // Function LobbyWebView.LobbyWebView_C.WebViewShow // Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void HandleEventFromWeb(struct UCoherentUIGTJSPayload* Payload); // Function LobbyWebView.LobbyWebView_C.HandleEventFromWeb // Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void WebViewInputFocus(int32 ViewIndex); // Function LobbyWebView.LobbyWebView_C.WebViewInputFocus // Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void WebViewLoad(int32 ViewIndex, struct FString URL); // Function LobbyWebView.LobbyWebView_C.WebViewLoad // Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void J_1(struct UCoherentUIGTJSPayload* Payload); // Function LobbyWebView.LobbyWebView_C.J_1 // BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void Construct(); // Function LobbyWebView.LobbyWebView_C.Construct // BlueprintCosmetic|Event|Public|BlueprintEvent // @ game+0x33e45c
	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Function LobbyWebView.LobbyWebView_C.Tick // BlueprintCosmetic|Event|Public|BlueprintEvent // @ game+0x33e45c
	void BndEvt__CoherentUIGTWidget_0_K2Node_ComponentBoundEvent_383_UIGTReadyForBindingsSignature__DelegateSignature(); // Function LobbyWebView.LobbyWebView_C.BndEvt__CoherentUIGTWidget_0_K2Node_ComponentBoundEvent_383_UIGTReadyForBindingsSignature__DelegateSignature // BlueprintEvent // @ game+0x33e45c
	void Destruct(); // Function LobbyWebView.LobbyWebView_C.Destruct // BlueprintCosmetic|Event|Public|BlueprintEvent // @ game+0x33e45c
	void BndEvt__WebView_0_K2Node_ComponentBoundEvent_2_UIGTBindingsReleasedSignature__DelegateSignature(); // Function LobbyWebView.LobbyWebView_C.BndEvt__WebView_0_K2Node_ComponentBoundEvent_2_UIGTBindingsReleasedSignature__DelegateSignature // BlueprintEvent // @ game+0x33e45c
	void CustomEvent_1(float Scale); // Function LobbyWebView.LobbyWebView_C.CustomEvent_1 // BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void CustomEvent_2(); // Function LobbyWebView.LobbyWebView_C.CustomEvent_2 // BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void CustomEvent_3(); // Function LobbyWebView.LobbyWebView_C.CustomEvent_3 // BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void ExecuteUbergraph_LobbyWebView(int32 EntryPoint); // Function LobbyWebView.LobbyWebView_C.ExecuteUbergraph_LobbyWebView // HasDefaults // @ game+0x33e45c
};

