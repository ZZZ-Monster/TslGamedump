// WidgetBlueprintGeneratedClass DetailReportCauseCheckBoxWidget.DetailReportCauseCheckBoxWidget_C
// Size: 0x490 (Inherited: 0x480)
struct UDetailReportCauseCheckBoxWidget_C : UTslDetailReportCauseCheckBox {
	struct UCheckBox* CheckBox; // 0x480(0x08)
	struct UTextBlock* Description; // 0x488(0x08)
};

