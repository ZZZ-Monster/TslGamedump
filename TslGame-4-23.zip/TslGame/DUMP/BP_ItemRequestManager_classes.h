// BlueprintGeneratedClass BP_ItemRequestManager.BP_ItemRequestManager_C
// Size: 0x500 (Inherited: 0x500)
struct UBP_ItemRequestManager_C : UTslItemRequestManager {
};

