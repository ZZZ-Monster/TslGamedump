// WidgetBlueprintGeneratedClass BP_PcOptionCloudSavingCoverWidget.BP_PcOptionCloudSavingCoverWidget_C
// Size: 0x570 (Inherited: 0x570)
struct UBP_PcOptionCloudSavingCoverWidget_C : UTslGameOptionCloudRequestTimeoutCoverWidget {
};

