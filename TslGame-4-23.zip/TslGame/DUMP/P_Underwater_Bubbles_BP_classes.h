// BlueprintGeneratedClass P_Underwater_Bubbles_BP.P_Underwater_Bubbles_BP_C
// Size: 0x4f0 (Inherited: 0x4f0)
struct AP_Underwater_Bubbles_BP_C : ATslParticle {
};

