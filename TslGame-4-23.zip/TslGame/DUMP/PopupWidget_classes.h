// WidgetBlueprintGeneratedClass PopupWidget.PopupWidget_C
// Size: 0x568 (Inherited: 0x538)
struct UPopupWidget_C : UTslPopupBoxWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x538(0x08)
	struct UWidgetAnimation* PopupEmerging; // 0x540(0x08)
	struct UHorizontalBox* GamepadButtonCancel; // 0x548(0x08)
	struct UHorizontalBox* GamepadButtonOK; // 0x550(0x08)
	struct UTslUniversalInputVisibilitySwitcher* TslUniversalInputVisibilitySwitcher_1; // 0x558(0x08)
	struct UImage* WarningImage; // 0x560(0x08)

	void HandleCompetitive(enum class EPopupStyle Style); // Function PopupWidget.PopupWidget_C.HandleCompetitive // Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void SetPopup(enum class EPopupStyle PopupStyle, struct FText Title, struct FText Message, DelegateProperty PressedDelegate); // Function PopupWidget.PopupWidget_C.SetPopup // Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void Construct(); // Function PopupWidget.PopupWidget_C.Construct // BlueprintCosmetic|Event|Public|BlueprintEvent // @ game+0x33e45c
	void Destruct(); // Function PopupWidget.PopupWidget_C.Destruct // BlueprintCosmetic|Event|Public|BlueprintEvent // @ game+0x33e45c
	void ExecuteUbergraph_PopupWidget(int32 EntryPoint); // Function PopupWidget.PopupWidget_C.ExecuteUbergraph_PopupWidget // HasDefaults // @ game+0x33e45c
};

