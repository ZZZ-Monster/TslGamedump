// WidgetBlueprintGeneratedClass BP_PcOptionItemButtonWidget.BP_PcOptionItemButtonWidget_C
// Size: 0x840 (Inherited: 0x840)
struct UBP_PcOptionItemButtonWidget_C : UTslGameOptionItemButtonWidget {
};

