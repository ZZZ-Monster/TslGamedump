// BlueprintGeneratedClass FBRBuff2021_Item_Bolt_ra_lv5.FBRBuff2021_Item_Bolt_ra_lv5_C
// Size: 0x4c8 (Inherited: 0x4c0)
struct AFBRBuff2021_Item_Bolt_ra_lv5_C : ATslFBRItemBuff {
	struct USceneComponent* DefaultSceneRoot; // 0x4c0(0x08)

	void UserConstructionScript(); // Function FBRBuff2021_Item_Bolt_ra_lv5.FBRBuff2021_Item_Bolt_ra_lv5_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
};

