// WidgetBlueprintGeneratedClass DebugInfoCanvasWidget.DebugInfoCanvasWidget_C
// Size: 0x270 (Inherited: 0x260)
struct UDebugInfoCanvasWidget_C : UUserWidget {
	struct UBorder* Border_1; // 0x260(0x08)
	struct UTextBlock* DebugText; // 0x268(0x08)

	void OnPrepass_1(struct UWidget* BoundWidget); // Function DebugInfoCanvasWidget.DebugInfoCanvasWidget_C.OnPrepass_1 // Public|HasDefaults|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	struct FText GetDebugText(); // Function DebugInfoCanvasWidget.DebugInfoCanvasWidget_C.GetDebugText // Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure // @ game+0x33e45c
};

