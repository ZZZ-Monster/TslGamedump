// BlueprintGeneratedClass BP_SandboxManager_Training.BP_SandboxManager_Training_C
// Size: 0x4d0 (Inherited: 0x4d0)
struct UBP_SandboxManager_Training_C : UTslSandboxManager_Training {
};

