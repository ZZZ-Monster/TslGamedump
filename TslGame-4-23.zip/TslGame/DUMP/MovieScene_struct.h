// Enum MovieScene.ESpawnOwnership
enum class ESpawnOwnership : uint8 {
	InnerSequence,
	MasterSequence,
	External,
	ESpawnOwnership_MAX,
};

// Enum MovieScene.EMovieSceneObjectBindingSpace
enum class EMovieSceneObjectBindingSpace : uint8 {
	Local,
	Root,
	EMovieSceneObjectBindingSpace_MAX,
};

// Enum MovieScene.EMovieSceneKeyInterpolation
enum class EMovieSceneKeyInterpolation : uint8 {
	Auto,
	User,
	Break,
	Linear,
	Constant,
	EMovieSceneKeyInterpolation_MAX,
};

// Enum MovieScene.EMovieSceneCompletionMode
enum class EMovieSceneCompletionMode : uint8 {
	KeepState,
	RestoreState,
	EMovieSceneCompletionMode_MAX,
};

// Enum MovieScene.ESectionEvaluationFlags
enum class ESectionEvaluationFlags : uint8 {
	None,
	PreRoll,
	PostRoll,
	ESectionEvaluationFlags_MAX,
};

// Enum MovieScene.EEvaluationMethod
enum class EEvaluationMethod : uint8 {
	Static,
	Swept,
	EEvaluationMethod_MAX,
};

// ScriptStruct MovieScene.MovieSceneSpawnable
// Size: 0x40 (Inherited: 0x00)
struct FMovieSceneSpawnable {
	struct FGuid Guid; // 0x00(0x10)
	struct FString Name; // 0x10(0x10)
	struct UObject* ObjectTemplate; // 0x20(0x08)
	struct TArray<struct FGuid> ChildPossessables; // 0x28(0x10)
	enum class ESpawnOwnership Ownership; // 0x38(0x01)
	char pad_39[0x7]; // 0x39(0x07)
};

// ScriptStruct MovieScene.MovieSceneBinding
// Size: 0x30 (Inherited: 0x00)
struct FMovieSceneBinding {
	struct FGuid ObjectGuid; // 0x00(0x10)
	struct FString BindingName; // 0x10(0x10)
	struct TArray<struct UMovieSceneTrack*> Tracks; // 0x20(0x10)
};

// ScriptStruct MovieScene.MovieScenePossessable
// Size: 0x38 (Inherited: 0x00)
struct FMovieScenePossessable {
	struct FGuid Guid; // 0x00(0x10)
	struct FString Name; // 0x10(0x10)
	struct UClass* PossessedObjectClass; // 0x20(0x08)
	struct FGuid ParentGuid; // 0x28(0x10)
};

// ScriptStruct MovieScene.MovieSceneSequenceID
// Size: 0x04 (Inherited: 0x00)
struct FMovieSceneSequenceID {
	uint32 Value; // 0x00(0x04)
};

// ScriptStruct MovieScene.MovieSceneObjectBindingID
// Size: 0x18 (Inherited: 0x00)
struct FMovieSceneObjectBindingID {
	int32 SequenceID; // 0x00(0x04)
	enum class EMovieSceneObjectBindingSpace Space; // 0x04(0x01)
	char pad_5[0x3]; // 0x05(0x03)
	struct FGuid Guid; // 0x08(0x10)
};

// ScriptStruct MovieScene.MovieSceneTrackLabels
// Size: 0x10 (Inherited: 0x00)
struct FMovieSceneTrackLabels {
	struct TArray<struct FString> Strings; // 0x00(0x10)
};

// ScriptStruct MovieScene.MovieSceneEditorData
// Size: 0x70 (Inherited: 0x00)
struct FMovieSceneEditorData {
	struct TMap<struct FString, struct FMovieSceneExpansionState> ExpansionStates; // 0x00(0x50)
	struct FFloatRange WorkingRange; // 0x50(0x10)
	struct FFloatRange ViewRange; // 0x60(0x10)
};

// ScriptStruct MovieScene.MovieSceneExpansionState
// Size: 0x01 (Inherited: 0x00)
struct FMovieSceneExpansionState {
	bool bExpanded; // 0x00(0x01)
};

// ScriptStruct MovieScene.MovieSceneBindingOverrideData
// Size: 0x24 (Inherited: 0x00)
struct FMovieSceneBindingOverrideData {
	struct FMovieSceneObjectBindingID ObjectBindingId; // 0x00(0x18)
	struct UObject* Object; // 0x18(0x08)
	bool bOverridesDefault; // 0x20(0x01)
	char pad_21[0x3]; // 0x21(0x03)
};

// ScriptStruct MovieScene.MovieSceneSequencePlaybackSettings
// Size: 0x28 (Inherited: 0x00)
struct FMovieSceneSequencePlaybackSettings {
	int32 LoopCount; // 0x00(0x04)
	float PlayRate; // 0x04(0x04)
	bool bRandomStartTime; // 0x08(0x01)
	char pad_9[0x3]; // 0x09(0x03)
	float StartTime; // 0x0c(0x04)
	bool bRestoreState; // 0x10(0x01)
	char pad_11[0x7]; // 0x11(0x07)
	TScriptInterface<struct UMovieSceneBindingOverridesInterface> BindingOverrides; // 0x18(0x10)
};

// ScriptStruct MovieScene.MovieSceneSectionEvalOptions
// Size: 0x02 (Inherited: 0x00)
struct FMovieSceneSectionEvalOptions {
	bool bCanEditCompletionMode; // 0x00(0x01)
	enum class EMovieSceneCompletionMode CompletionMode; // 0x01(0x01)
};

// ScriptStruct MovieScene.MovieSceneTrackEvalOptions
// Size: 0x04 (Inherited: 0x00)
struct FMovieSceneTrackEvalOptions {
	char bCanEvaluateNearestSection : 1; // 0x00(0x01)
	char bEvaluateNearestSection : 1; // 0x00(0x01)
	char bEvaluateInPreroll : 1; // 0x00(0x01)
	char bEvaluateInPostroll : 1; // 0x00(0x01)
	char pad_0_4 : 4; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
};

// ScriptStruct MovieScene.MovieSceneTrackCompilationParams
// Size: 0x02 (Inherited: 0x00)
struct FMovieSceneTrackCompilationParams {
	bool bForEditorPreview; // 0x00(0x01)
	bool bDuringBlueprintCompile; // 0x01(0x01)
};

// ScriptStruct MovieScene.MovieSceneTrackIdentifier
// Size: 0x04 (Inherited: 0x00)
struct FMovieSceneTrackIdentifier {
	uint32 Value; // 0x00(0x04)
};

// ScriptStruct MovieScene.MovieSceneEvaluationField
// Size: 0x30 (Inherited: 0x00)
struct FMovieSceneEvaluationField {
	struct TArray<struct FFloatRange> Ranges; // 0x00(0x10)
	struct TArray<struct FMovieSceneEvaluationGroup> Groups; // 0x10(0x10)
	struct TArray<struct FMovieSceneEvaluationMetaData> MetaData; // 0x20(0x10)
};

// ScriptStruct MovieScene.MovieSceneEvaluationMetaData
// Size: 0x10 (Inherited: 0x00)
struct FMovieSceneEvaluationMetaData {
	struct TArray<struct FMovieSceneSequenceID> ActiveSequences; // 0x00(0x10)
};

// ScriptStruct MovieScene.MovieSceneEvaluationGroup
// Size: 0x20 (Inherited: 0x00)
struct FMovieSceneEvaluationGroup {
	struct TArray<struct FMovieSceneEvaluationGroupLUTIndex> LUTIndices; // 0x00(0x10)
	struct TArray<struct FMovieSceneEvaluationFieldSegmentPtr> SegmentPtrLUT; // 0x10(0x10)
};

// ScriptStruct MovieScene.MovieSceneEvaluationFieldSegmentPtr
// Size: 0x0c (Inherited: 0x08)
struct FMovieSceneEvaluationFieldSegmentPtr : FMovieSceneEvaluationFieldTrackPtr {
	int32 SegmentIndex; // 0x08(0x04)
};

// ScriptStruct MovieScene.MovieSceneEvaluationFieldTrackPtr
// Size: 0x08 (Inherited: 0x00)
struct FMovieSceneEvaluationFieldTrackPtr {
	struct FMovieSceneSequenceID SequenceID; // 0x00(0x04)
	struct FMovieSceneTrackIdentifier TrackIdentifier; // 0x04(0x04)
};

// ScriptStruct MovieScene.MovieSceneEvaluationGroupLUTIndex
// Size: 0x10 (Inherited: 0x00)
struct FMovieSceneEvaluationGroupLUTIndex {
	bool bRequiresImmediateFlush; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	int32 LUTOffset; // 0x04(0x04)
	int32 NumInitPtrs; // 0x08(0x04)
	int32 NumEvalPtrs; // 0x0c(0x04)
};

// ScriptStruct MovieScene.MovieSceneSegment
// Size: 0x50 (Inherited: 0x00)
struct FMovieSceneSegment {
	char pad_0[0x50]; // 0x00(0x50)
};

// ScriptStruct MovieScene.SectionEvaluationData
// Size: 0x0c (Inherited: 0x00)
struct FSectionEvaluationData {
	int32 ImplIndex; // 0x00(0x04)
	float ForcedTime; // 0x04(0x04)
	enum class ESectionEvaluationFlags Flags; // 0x08(0x01)
	char pad_9[0x3]; // 0x09(0x03)
};

// ScriptStruct MovieScene.MovieSceneEvalTemplateBase
// Size: 0x10 (Inherited: 0x00)
struct FMovieSceneEvalTemplateBase {
	char pad_0[0x10]; // 0x00(0x10)
};

// ScriptStruct MovieScene.MovieSceneEmptyStruct
// Size: 0x01 (Inherited: 0x00)
struct FMovieSceneEmptyStruct {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct MovieScene.MovieSceneEvalTemplatePtr
// Size: 0x38 (Inherited: 0x00)
struct FMovieSceneEvalTemplatePtr {
	char pad_0[0x38]; // 0x00(0x38)
};

// ScriptStruct MovieScene.MovieSceneEvalTemplate
// Size: 0x18 (Inherited: 0x10)
struct FMovieSceneEvalTemplate : FMovieSceneEvalTemplateBase {
	enum class EMovieSceneCompletionMode CompletionMode; // 0x10(0x01)
	char pad_11[0x7]; // 0x11(0x07)
};

// ScriptStruct MovieScene.MovieSceneTrackImplementationPtr
// Size: 0x38 (Inherited: 0x00)
struct FMovieSceneTrackImplementationPtr {
	char pad_0[0x38]; // 0x00(0x38)
};

// ScriptStruct MovieScene.MovieSceneTrackImplementation
// Size: 0x10 (Inherited: 0x10)
struct FMovieSceneTrackImplementation : FMovieSceneEvalTemplateBase {
};

// ScriptStruct MovieScene.MovieSceneEvaluationTrack
// Size: 0x80 (Inherited: 0x00)
struct FMovieSceneEvaluationTrack {
	struct FGuid ObjectBindingId; // 0x00(0x10)
	uint16 EvaluationPriority; // 0x10(0x02)
	enum class EEvaluationMethod EvaluationMethod; // 0x12(0x01)
	char pad_13[0x5]; // 0x13(0x05)
	struct TArray<struct FMovieSceneSegment> Segments; // 0x18(0x10)
	struct TArray<struct FMovieSceneEvalTemplatePtr> ChildTemplates; // 0x28(0x10)
	struct FMovieSceneTrackImplementationPtr TrackTemplate; // 0x38(0x38)
	struct FName EvaluationGroup; // 0x70(0x08)
	char bEvaluateInPreroll : 1; // 0x78(0x01)
	char bEvaluateInPostroll : 1; // 0x78(0x01)
	char pad_78_2 : 6; // 0x78(0x01)
	char pad_79[0x7]; // 0x79(0x07)
};

// ScriptStruct MovieScene.MovieSceneSequenceTransform
// Size: 0x08 (Inherited: 0x00)
struct FMovieSceneSequenceTransform {
	float TimeScale; // 0x00(0x04)
	float Offset; // 0x04(0x04)
};

// ScriptStruct MovieScene.MovieSceneSectionParameters
// Size: 0x14 (Inherited: 0x00)
struct FMovieSceneSectionParameters {
	float StartOffset; // 0x00(0x04)
	float TimeScale; // 0x04(0x04)
	int32 HierarchicalBias; // 0x08(0x04)
	float PrerollTime; // 0x0c(0x04)
	float PostrollTime; // 0x10(0x04)
};

// ScriptStruct MovieScene.MovieSceneSequenceHierarchy
// Size: 0xa0 (Inherited: 0x00)
struct FMovieSceneSequenceHierarchy {
	struct TMap<uint32, struct FMovieSceneSubSequenceData> SubSequences; // 0x00(0x50)
	struct TMap<uint32, struct FMovieSceneSequenceHierarchyNode> Hierarchy; // 0x50(0x50)
};

// ScriptStruct MovieScene.MovieSceneSequenceHierarchyNode
// Size: 0x18 (Inherited: 0x00)
struct FMovieSceneSequenceHierarchyNode {
	struct FMovieSceneSequenceID ParentID; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct TArray<struct FMovieSceneSequenceID> Children; // 0x08(0x10)
};

// ScriptStruct MovieScene.MovieSceneSubSequenceData
// Size: 0x50 (Inherited: 0x00)
struct FMovieSceneSubSequenceData {
	struct UMovieSceneSequence* Sequence; // 0x00(0x08)
	struct UObject* SequenceKeyObject; // 0x08(0x08)
	struct FMovieSceneSequenceTransform RootToSequenceTransform; // 0x10(0x08)
	struct FGuid SourceSequenceSignature; // 0x18(0x10)
	struct FMovieSceneSequenceID DeterministicSequenceID; // 0x28(0x04)
	struct FFloatRange PreRollRange; // 0x2c(0x10)
	struct FFloatRange PostRollRange; // 0x3c(0x10)
	int32 HierarchicalBias; // 0x4c(0x04)
};

// ScriptStruct MovieScene.CachedMovieSceneEvaluationTemplate
// Size: 0x220 (Inherited: 0x220)
struct FCachedMovieSceneEvaluationTemplate : FMovieSceneEvaluationTemplate {
};

// ScriptStruct MovieScene.MovieSceneEvaluationTemplate
// Size: 0x220 (Inherited: 0x00)
struct FMovieSceneEvaluationTemplate {
	struct TMap<uint32, struct FMovieSceneEvaluationTrack> Tracks; // 0x00(0x50)
	char pad_50[0x50]; // 0x50(0x50)
	struct FMovieSceneEvaluationField EvaluationField; // 0xa0(0x30)
	struct FMovieSceneSequenceHierarchy Hierarchy; // 0xd0(0xa0)
	struct FMovieSceneTemplateGenerationLedger TemplateLedger; // 0x170(0xa8)
	char bHasLegacyTrackInstances : 1; // 0x218(0x01)
	char bKeepStaleTracks : 1; // 0x218(0x01)
	char pad_218_2 : 6; // 0x218(0x01)
	char pad_219[0x7]; // 0x219(0x07)
};

// ScriptStruct MovieScene.MovieSceneTemplateGenerationLedger
// Size: 0xa8 (Inherited: 0x00)
struct FMovieSceneTemplateGenerationLedger {
	struct FMovieSceneTrackIdentifier LastTrackIdentifier; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct TMap<struct FMovieSceneTrackIdentifier, int32> TrackReferenceCounts; // 0x08(0x50)
	struct TMap<struct FGuid, struct FMovieSceneTrackIdentifiers> TrackSignatureToTrackIdentifier; // 0x58(0x50)
};

// ScriptStruct MovieScene.MovieSceneTrackIdentifiers
// Size: 0x10 (Inherited: 0x00)
struct FMovieSceneTrackIdentifiers {
	struct TArray<struct FMovieSceneTrackIdentifier> Data; // 0x00(0x10)
};

// ScriptStruct MovieScene.MovieSceneSequenceCachedSignature
// Size: 0x18 (Inherited: 0x00)
struct FMovieSceneSequenceCachedSignature {
	struct UMovieSceneSequence* Sequence; // 0x00(0x08)
	struct FGuid CachedSignature; // 0x08(0x10)
};

// ScriptStruct MovieScene.MovieSceneLegacyTrackInstanceTemplate
// Size: 0x20 (Inherited: 0x18)
struct FMovieSceneLegacyTrackInstanceTemplate : FMovieSceneEvalTemplate {
	struct UMovieSceneTrack* Track; // 0x18(0x08)
};

// ScriptStruct MovieScene.MovieScenePropertySectionData
// Size: 0x28 (Inherited: 0x00)
struct FMovieScenePropertySectionData {
	struct FName PropertyName; // 0x00(0x08)
	struct FString PropertyPath; // 0x08(0x10)
	struct FName FunctionName; // 0x18(0x08)
	struct FName NotifyFunctionName; // 0x20(0x08)
};

// ScriptStruct MovieScene.MovieSceneKeyStruct
// Size: 0x08 (Inherited: 0x00)
struct FMovieSceneKeyStruct {
	char pad_0[0x8]; // 0x00(0x08)
};

