// BlueprintGeneratedClass P_Punch_BP.P_Punch_BP_C
// Size: 0x4f0 (Inherited: 0x4f0)
struct AP_Punch_BP_C : ATslParticle {
};

