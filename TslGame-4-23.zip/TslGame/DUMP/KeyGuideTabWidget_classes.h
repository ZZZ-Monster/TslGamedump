// WidgetBlueprintGeneratedClass KeyGuideTabWidget.KeyGuideTabWidget_C
// Size: 0x478 (Inherited: 0x478)
struct UKeyGuideTabWidget_C : UTslTabSelectorWidget {
};

