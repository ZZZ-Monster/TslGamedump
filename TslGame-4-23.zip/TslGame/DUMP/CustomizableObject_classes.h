// Class CustomizableObject.CustomizableSkeletalComponent
// Size: 0x510 (Inherited: 0x4b0)
struct UCustomizableSkeletalComponent : USceneComponent {
	bool bPendingUpdateSkeletalMesh; // 0x4b0(0x01)
	char pad_4B1[0x3]; // 0x4b1(0x03)
	float SkippedLastRenderTime; // 0x4b4(0x04)
	struct UCustomizableObjectInstance* CustomizableObjectInstance; // 0x4b8(0x08)
	char pad_4C0[0x40]; // 0x4c0(0x40)
	struct USkeletalMesh* DeferredSkeletalMeshToSet; // 0x500(0x08)
	char pad_508[0x8]; // 0x508(0x08)

	void UpdateSkeletalMeshAsync(bool bNeverSkipUpdate); // Function CustomizableObject.CustomizableSkeletalComponent.UpdateSkeletalMeshAsync // Final|Native|Public|BlueprintCallable // @ game+0x5ce6294
};

// Class CustomizableObject.CustomizableInstanceLODManagementBase
// Size: 0x38 (Inherited: 0x38)
struct UCustomizableInstanceLODManagementBase : UObject {
};

// Class CustomizableObject.CustomizableInstanceLODManagement
// Size: 0x98 (Inherited: 0x38)
struct UCustomizableInstanceLODManagement : UCustomizableInstanceLODManagementBase {
	char pad_38[0x60]; // 0x38(0x60)
};

// Class CustomizableObject.CustomizableObjectInstance
// Size: 0x210 (Inherited: 0x38)
struct UCustomizableObjectInstance : UObject {
	struct UCustomizableObject* CustomizableObject; // 0x38(0x08)
	struct USkeletalMesh* SkeletalMesh; // 0x40(0x08)
	struct TArray<struct FCustomizableObjectBoolParameterValue> BoolParameters; // 0x48(0x10)
	struct TArray<struct FCustomizableObjectIntParameterValue> IntParameters; // 0x58(0x10)
	struct TArray<struct FCustomizableObjectFloatParameterValue> FloatParameters; // 0x68(0x10)
	struct TArray<struct FCustomizableObjectTextureParameterValue> TextureParameters; // 0x78(0x10)
	struct TArray<struct FCustomizableObjectVectorParameterValue> VectorParameters; // 0x88(0x10)
	struct TArray<struct FCustomizableObjectProjectorParameterValue> ProjectorParameters; // 0x98(0x10)
	bool bBuildParameterDecorations; // 0xa8(0x01)
	char pad_A9[0x7]; // 0xa9(0x07)
	struct FMulticastDelegate UpdatedDelegate; // 0xb0(0x10)
	char pad_C0[0x90]; // 0xc0(0x90)
	struct FString SkeletalMeshStatus; // 0x150(0x10)
	char pad_160[0x80]; // 0x160(0x80)
	struct FGuid COVersionID; // 0x1e0(0x10)
	char pad_1F0[0x8]; // 0x1f0(0x08)
	struct UCustomizableInstancePrivateData* PrivateData; // 0x1f8(0x08)
	char pad_200[0x10]; // 0x200(0x10)

	void UpdateSkeletalMeshAsync(bool bIgnoreCloseDist, bool bForceHighPriority); // Function CustomizableObject.CustomizableObjectInstance.UpdateSkeletalMeshAsync // Final|Native|Public|BlueprintCallable // @ game+0x5ce6198
	void SetVectorParameterSelectedOption(struct FString VectorParamName, struct FLinearColor VectorValue); // Function CustomizableObject.CustomizableObjectInstance.SetVectorParameterSelectedOption // Final|Native|Public|HasDefaults|BlueprintCallable // @ game+0x5ce54e4
	void SetRandomValues(); // Function CustomizableObject.CustomizableObjectInstance.SetRandomValues // Final|Native|Public|BlueprintCallable // @ game+0x5ce60dc
	void SetProjectorValue(struct FString ProjectorParamName, float posX, float posY, float posZ, float dirX, float dirY, float dirZ, float upX, float upY, float upZ, float ScaleX, float ScaleY, float ScaleZ, float Angle, enum class ECustomizableObjectProjectorType ProjectionType, int32 RangeIndex); // Function CustomizableObject.CustomizableObjectInstance.SetProjectorValue // Final|Native|Public|BlueprintCallable // @ game+0x5ce5b44
	void SetProjectorParameterType(struct FString ParamName, int32 RangeIndex, enum class ECustomizableObjectProjectorType Type); // Function CustomizableObject.CustomizableObjectInstance.SetProjectorParameterType // Final|Native|Public|BlueprintCallable // @ game+0x5ce59e8
	void SetIntParameterSelectedOption(struct FString ParamName, struct FString SelectedOptionName, int32 RangeIndex); // Function CustomizableObject.CustomizableObjectInstance.SetIntParameterSelectedOption // Final|Native|Public|BlueprintCallable // @ game+0x5ce5854
	void SetFloatParameterSelectedOption(struct FString FloatParamName, float FloatValue, int32 RangeIndex); // Function CustomizableObject.CustomizableObjectInstance.SetFloatParameterSelectedOption // Final|Native|Public|BlueprintCallable // @ game+0x5ce56f4
	void SetCurrentState(struct FString StateName); // Function CustomizableObject.CustomizableObjectInstance.SetCurrentState // Final|Native|Public|BlueprintCallable // @ game+0x5ce5628
	void SetColorParameterSelectedOption(struct FString ColorParamName, struct FLinearColor ColorValue); // Function CustomizableObject.CustomizableObjectInstance.SetColorParameterSelectedOption // Final|Native|Public|HasDefaults|BlueprintCallable // @ game+0x5ce54e4
	void SetBoolParameterSelectedOption(struct FString BoolParamName, bool boolValue); // Function CustomizableObject.CustomizableObjectInstance.SetBoolParameterSelectedOption // Final|Native|Public|BlueprintCallable // @ game+0x5ce53c4
	bool IsParameterRelevant(struct FString ParamName); // Function CustomizableObject.CustomizableObjectInstance.IsParameterRelevant // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5ce523c
	bool GetProjectorValue(struct FString ProjectorParamName, struct FVector OutPos, struct FVector OutDir, struct FVector OutUp, struct FVector OutScale, float OutAngle, enum class ECustomizableObjectProjectorType OutType, int32 RangeIndex); // Function CustomizableObject.CustomizableObjectInstance.GetProjectorValue // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5ce4810
	struct FVector GetProjectorUp(struct FString ParamName); // Function CustomizableObject.CustomizableObjectInstance.GetProjectorUp // Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5ce46e8
	struct FVector GetProjectorScale(struct FString ParamName); // Function CustomizableObject.CustomizableObjectInstance.GetProjectorScale // Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5ce45c0
	struct FVector GetProjectorPosition(struct FString ParamName); // Function CustomizableObject.CustomizableObjectInstance.GetProjectorPosition // Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5ce4498
	enum class ECustomizableObjectProjectorType GetProjectorParameterType(struct FString ParamName, int32 RangeIndex); // Function CustomizableObject.CustomizableObjectInstance.GetProjectorParameterType // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5ce437c
	struct FVector GetProjectorDirection(struct FString ParamName); // Function CustomizableObject.CustomizableObjectInstance.GetProjectorDirection // Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5ce4254
	float GetProjectorAngle(struct FString ParamName); // Function CustomizableObject.CustomizableObjectInstance.GetProjectorAngle // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5ce4184
	struct UTexture2D* GetParameterDescription(struct FString ParamName, int32 DescIndex); // Function CustomizableObject.CustomizableObjectInstance.GetParameterDescription // Final|Native|Public|BlueprintCallable // @ game+0x5ce3a64
	struct FString GetIntParameterSelectedOption(struct FString ParamName, int32 RangeIndex); // Function CustomizableObject.CustomizableObjectInstance.GetIntParameterSelectedOption // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5ce38f4
	float GetFloatParameterSelectedOption(struct FString FloatParamName, int32 RangeIndex); // Function CustomizableObject.CustomizableObjectInstance.GetFloatParameterSelectedOption // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5ce3620
	struct FString GetCurrentState(); // Function CustomizableObject.CustomizableObjectInstance.GetCurrentState // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5ce3588
	struct FLinearColor GetColorParameterSelectedOption(struct FString ColorParamName); // Function CustomizableObject.CustomizableObjectInstance.GetColorParameterSelectedOption // Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5ce3484
	bool GetBoolParameterSelectedOption(struct FString BoolParamName); // Function CustomizableObject.CustomizableObjectInstance.GetBoolParameterSelectedOption // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5ce338c
	int32 FindVectorParameterNameIndex(struct FString ParamName); // Function CustomizableObject.CustomizableObjectInstance.FindVectorParameterNameIndex // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5ce3294
	int32 FindProjectorParameterNameIndex(struct FString ParamName); // Function CustomizableObject.CustomizableObjectInstance.FindProjectorParameterNameIndex // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5ce31c8
	int32 FindIntParameterNameIndex(struct FString ParamName); // Function CustomizableObject.CustomizableObjectInstance.FindIntParameterNameIndex // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5ce3024
	int32 FindFloatParameterNameIndex(struct FString ParamName); // Function CustomizableObject.CustomizableObjectInstance.FindFloatParameterNameIndex // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5ce2f58
	int32 FindBoolParameterNameIndex(struct FString ParamName); // Function CustomizableObject.CustomizableObjectInstance.FindBoolParameterNameIndex // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5ce2e8c
	struct UCustomizableObjectInstance* Clone(); // Function CustomizableObject.CustomizableObjectInstance.Clone // Final|Native|Public|BlueprintCallable // @ game+0x5ce2e44
};

// Class CustomizableObject.CustomizableInstancePrivateData
// Size: 0x400 (Inherited: 0x38)
struct UCustomizableInstancePrivateData : UObject {
	char pad_38[0x8]; // 0x38(0x08)
	struct TArray<struct FGeneratedMaterial> GeneratedMaterials; // 0x40(0x10)
	struct TArray<struct FGeneratedMesh> GeneratedMeshes; // 0x50(0x10)
	struct TArray<struct FGeneratedTexture> GeneratedTextures; // 0x60(0x10)
	char pad_70[0x88]; // 0x70(0x88)
	struct TArray<struct FParameterDecorations> ParameterDecorations; // 0xf8(0x10)
	char pad_108[0x10]; // 0x108(0x10)
	struct TMap<struct FString, struct UTexture2D*> TextureReuseCache; // 0x118(0x50)
	char pad_168[0x1c8]; // 0x168(0x1c8)
	struct TArray<struct UMaterialInterface*> ReferencedMaterials; // 0x330(0x10)
	char pad_340[0xa0]; // 0x340(0xa0)
	struct TArray<struct UPhysicsAsset*> PhysicsAssetsToMerge; // 0x3e0(0x10)
	char pad_3F0[0x10]; // 0x3f0(0x10)
};

// Class CustomizableObject.CustomizableObjectBuiltData
// Size: 0x38 (Inherited: 0x38)
struct UCustomizableObjectBuiltData : UObject {
};

// Class CustomizableObject.MutableMaskOutCache
// Size: 0xd8 (Inherited: 0x38)
struct UMutableMaskOutCache : UObject {
	struct TMap<struct FString, struct FString> Materials; // 0x38(0x50)
	struct TMap<struct FString, struct FMaskOutTexture> Textures; // 0x88(0x50)
};

// Class CustomizableObject.CustomizableObject
// Size: 0x2d8 (Inherited: 0x38)
struct UCustomizableObject : UObject {
	struct USkeletalMesh* ReferenceSkeletalMesh; // 0x38(0x08)
	struct UStaticMesh* ReferenceStaticMesh; // 0x40(0x08)
	enum class ECustomizableObjectRelevancy Relevancy; // 0x48(0x01)
	bool bDisableTextureLayoutManagement; // 0x49(0x01)
	char pad_4A[0x6]; // 0x4a(0x06)
	struct TArray<struct UMaterialInterface*> ReferencedMaterials; // 0x50(0x10)
	struct TArray<struct FMutableModelImageProperties> ImageProperties; // 0x60(0x10)
	struct TMap<struct FString, struct FCustomizableObjectIdPair> GroupNodeMap; // 0x70(0x50)
	struct TArray<struct UMorphTarget*> ContributingMorphTargets; // 0xc0(0x10)
	struct TArray<struct FMorphTargetVertexIndex> MorphTargetReconstructionInfo; // 0xd0(0x10)
	struct FGuid VersionId; // 0xe0(0x10)
	struct TArray<struct FMutableModelParameterProperties> ParameterProperties; // 0xf0(0x10)
	char pad_100[0xa8]; // 0x100(0xa8)
	struct TMap<struct FString, struct FParameterUIData> ParameterUIDataMap; // 0x1a8(0x50)
	struct TMap<struct FString, struct FParameterUIData> StateUIDataMap; // 0x1f8(0x50)
	struct TMap<struct FString, struct UPhysicsAsset*> PhysicsAssetsMap; // 0x248(0x50)
	struct UMutableMaskOutCache* MaskOutCache; // 0x298(0x20)
	bool bIsChildObject; // 0x2b8(0x01)
	char pad_2B9[0x7]; // 0x2b9(0x07)
	struct UMutableMaskOutCache* MaskOutCache_HardRef; // 0x2c0(0x08)
	char pad_2C8[0x10]; // 0x2c8(0x10)

	void UnloadMaskOutCache(); // Function CustomizableObject.CustomizableObject.UnloadMaskOutCache // Final|Native|Public|BlueprintCallable // @ game+0x5ce6180
	void LoadMaskOutCache(); // Function CustomizableObject.CustomizableObject.LoadMaskOutCache // Final|Native|Public|BlueprintCallable // @ game+0x5ce5324
	bool IsParamMultidimensional(int32 ParamIndex); // Function CustomizableObject.CustomizableObject.IsParamMultidimensional // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5ce5190
	struct FParameterUIData GetStateUIMetadataFromIndex(int32 StateIndex); // Function CustomizableObject.CustomizableObject.GetStateUIMetadataFromIndex // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5ce5028
	struct FParameterUIData GetStateUIMetadata(struct FString StateName); // Function CustomizableObject.CustomizableObject.GetStateUIMetadata // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5ce4f1c
	struct FString GetStateParameterName(struct FString StateName, int32 ParameterIndex); // Function CustomizableObject.CustomizableObject.GetStateParameterName // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5ce4d58
	int32 GetStateParameterCount(struct FString StateName); // Function CustomizableObject.CustomizableObject.GetStateParameterCount // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5ce4c74
	struct FString GetStateName(int32 StateIndex); // Function CustomizableObject.CustomizableObject.GetStateName // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5ce4b84
	int32 GetStateCount(); // Function CustomizableObject.CustomizableObject.GetStateCount // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5ce4b60
	struct FParameterUIData GetParameterUIMetadataFromIndex(int32 ParamIndex); // Function CustomizableObject.CustomizableObject.GetParameterUIMetadataFromIndex // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5ce3ffc
	struct FParameterUIData GetParameterUIMetadata(struct FString ParamName); // Function CustomizableObject.CustomizableObject.GetParameterUIMetadata // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5ce3ef0
	enum class EMutableParameterType GetParameterTypeByName(struct FString Name); // Function CustomizableObject.CustomizableObject.GetParameterTypeByName // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5ce3e24
	enum class EMutableParameterType GetParameterType(int32 ParamIndex); // Function CustomizableObject.CustomizableObject.GetParameterType // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5ce3d68
	struct FString GetParameterName(int32 ParamIndex); // Function CustomizableObject.CustomizableObject.GetParameterName // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5ce3cc0
	int32 GetParameterDescriptionCount(struct FString ParamName); // Function CustomizableObject.CustomizableObject.GetParameterDescriptionCount // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5ce3bd0
	int32 GetParameterCount(); // Function CustomizableObject.CustomizableObject.GetParameterCount // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5ce3a4c
	int32 GetIntParameterNumOptions(int32 ParamIndex); // Function CustomizableObject.CustomizableObject.GetIntParameterNumOptions // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5ce3854
	struct FString GetIntParameterAvailableOption(int32 ParamIndex, int32 K); // Function CustomizableObject.CustomizableObject.GetIntParameterAvailableOption // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5ce3764
	int32 FindParameter(struct FString Name); // Function CustomizableObject.CustomizableObject.FindParameter // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5ce30fc
	struct UCustomizableObjectInstance* CreateInstance(); // Function CustomizableObject.CustomizableObject.CreateInstance // Final|Native|Public|BlueprintCallable // @ game+0x5ce2e68
};

// Class CustomizableObject.CustomizableObjectCookCommandlet
// Size: 0x90 (Inherited: 0x90)
struct UCustomizableObjectCookCommandlet : UCommandlet {
};

// Class CustomizableObject.CustomizableSystemImageProvider
// Size: 0x38 (Inherited: 0x38)
struct UCustomizableSystemImageProvider : UObject {
};

// Class CustomizableObject.CustomizableObjectImageProviderArray
// Size: 0xd0 (Inherited: 0x38)
struct UCustomizableObjectImageProviderArray : UCustomizableSystemImageProvider {
	struct TArray<struct UTexture2D*> Textures; // 0x38(0x10)
	char pad_48[0x88]; // 0x48(0x88)
};

// Class CustomizableObject.CustomizableObjectSystem
// Size: 0x158 (Inherited: 0x38)
struct UCustomizableObjectSystem : UObject {
	struct TArray<struct FPendingReleaseSkeletalMeshInfo> PendingReleaseSkeletalMesh; // 0x38(0x10)
	struct UCustomizableObjectImageProviderArray* PreviewExternalImageProvider; // 0x48(0x08)
	char pad_50[0xd8]; // 0x50(0xd8)
	struct TArray<struct UTexture2D*> ProtectedCachedTextures; // 0x128(0x10)
	char pad_138[0x10]; // 0x138(0x10)
	struct UCustomizableInstanceLODManagementBase* DefaultInstanceLODManagement; // 0x148(0x08)
	struct UCustomizableInstanceLODManagementBase* CurrentInstanceLODManagement; // 0x150(0x08)

	void SetReleaseMutableTexturesImmediately(bool bReleaseTextures); // Function CustomizableObject.CustomizableObjectSystem.SetReleaseMutableTexturesImmediately // Final|Native|Public|BlueprintCallable // @ game+0x5ce60f0
	int32 GetTotalInstances(); // Function CustomizableObject.CustomizableObjectSystem.GetTotalInstances // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5ce5178
	int32 GetTextureMemoryUsed(); // Function CustomizableObject.CustomizableObjectSystem.GetTextureMemoryUsed // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5ce515c
	struct FString GetPluginVersion(); // Function CustomizableObject.CustomizableObjectSystem.GetPluginVersion // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5ce40f0
	int32 GetNumPendingInstances(); // Function CustomizableObject.CustomizableObjectSystem.GetNumPendingInstances // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5ce3a34
	int32 GetNumInstances(); // Function CustomizableObject.CustomizableObjectSystem.GetNumInstances // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5ce3a1c
	struct UCustomizableObjectSystem* GetInstance(); // Function CustomizableObject.CustomizableObjectSystem.GetInstance // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5ce3740
	int32 GetAverageBuildTime(); // Function CustomizableObject.CustomizableObjectSystem.GetAverageBuildTime // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5ce3360
	bool AreEnginePatchesPresent(); // Function CustomizableObject.CustomizableObjectSystem.AreEnginePatchesPresent // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5ce2e10
};

// Class CustomizableObject.CustomizableSkeletalMeshActor
// Size: 0x480 (Inherited: 0x478)
struct ACustomizableSkeletalMeshActor : ASkeletalMeshActor {
	struct UCustomizableSkeletalComponent* CustomizableSkeletalComponent; // 0x478(0x08)
};

