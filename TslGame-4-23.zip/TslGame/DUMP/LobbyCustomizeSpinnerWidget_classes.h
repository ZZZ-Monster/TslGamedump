// WidgetBlueprintGeneratedClass LobbyCustomizeSpinnerWidget.LobbyCustomizeSpinnerWidget_C
// Size: 0x438 (Inherited: 0x430)
struct ULobbyCustomizeSpinnerWidget_C : UTslLoadingSpinnerWidget {
	struct UImage* LoadingSpinnerImage; // 0x430(0x08)
};

