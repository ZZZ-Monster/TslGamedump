// WidgetBlueprintGeneratedClass LobbyNameTagWildCard.LobbyNameTagWildCard_C
// Size: 0x628 (Inherited: 0x5b8)
struct ULobbyNameTagWildCard_C : UTslLobbyNameTagWidget {
	struct UImage* HostImage; // 0x5b8(0x08)
	struct UImage* InAMatchImg; // 0x5c0(0x08)
	struct UImage* LogoutImg; // 0x5c8(0x08)
	struct UTextBlock* NickNameText; // 0x5d0(0x08)
	struct UImage* NotReadyImg; // 0x5d8(0x08)
	struct UImage* QueuingImg; // 0x5e0(0x08)
	struct UBP_RankEmblemWidget_C* RankEmblemWidget; // 0x5e8(0x08)
	struct UImage* ReadyImg; // 0x5f0(0x08)
	struct UWidgetSwitcher* StateSwitcher; // 0x5f8(0x08)
	struct UUserPlatformImageWidget_C* UserPlatformImageWidget; // 0x600(0x08)
	struct UImage* VoiceDetect; // 0x608(0x08)
	struct UImage* VoiceMute; // 0x610(0x08)
	struct UImage* VoiceNormal; // 0x618(0x08)
	struct UWidgetSwitcher* VoiceSwitcher; // 0x620(0x08)
};

