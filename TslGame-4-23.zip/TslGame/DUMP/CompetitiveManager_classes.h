// BlueprintGeneratedClass CompetitiveManager.CompetitiveManager_C
// Size: 0x540 (Inherited: 0x540)
struct ACompetitiveManager_C : ACompetitiveManager {
};

