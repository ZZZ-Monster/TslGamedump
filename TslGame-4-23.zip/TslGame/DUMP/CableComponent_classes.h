// Class CableComponent.CableActor
// Size: 0x3f8 (Inherited: 0x3f0)
struct ACableActor : AActor {
	struct UCableComponent* CableComponent; // 0x3f0(0x08)
};

// Class CableComponent.CableComponent
// Size: 0xb80 (Inherited: 0xae0)
struct UCableComponent : UMeshComponent {
	bool bAttachStart; // 0xad8(0x01)
	bool bAttachEnd; // 0xad9(0x01)
	bool bUseLocalSpace; // 0xada(0x01)
	struct FComponentReference AttachEndTo; // 0xae0(0x18)
	struct FName AttachEndToSocketName; // 0xaf8(0x08)
	struct FName AttachStartToSocketName; // 0xb00(0x08)
	struct FVector EndLocation; // 0xb08(0x0c)
	float CableLength; // 0xb14(0x04)
	int32 NumSegments; // 0xb18(0x04)
	float SubStepTime; // 0xb1c(0x04)
	int32 SolverIterations; // 0xb20(0x04)
	bool bEnableStiffness; // 0xb24(0x01)
	bool bUseSubstepping; // 0xb25(0x01)
	bool bSkipCableUpdateWhenNotVisible; // 0xb26(0x01)
	bool bSkipCableUpdateWhenNotOwnerRecentlyRendered; // 0xb27(0x01)
	bool bEnableCollision; // 0xb28(0x01)
	float CollisionFriction; // 0xb2c(0x04)
	float LinearDrag; // 0xb30(0x04)
	struct FVector CableForce; // 0xb34(0x0c)
	struct TArray<struct FCableCustomSocket> CustomSocketList; // 0xb40(0x10)
	float CableGravityScale; // 0xb50(0x04)
	float CableWidth; // 0xb54(0x04)
	float ExtendBounds; // 0xb58(0x04)
	int32 NumSides; // 0xb5c(0x04)
	float TileMaterial; // 0xb60(0x04)
	char pad_B64[0x1c]; // 0xb64(0x1c)

	void SetAttachEndTo(struct AActor* Actor, struct FName ComponentProperty, struct FName SocketName); // Function CableComponent.CableComponent.SetAttachEndTo // Final|Native|Public|BlueprintCallable // @ game+0x5d670f4
	void GetCableParticleLocations(struct TArray<struct FVector> Locations); // Function CableComponent.CableComponent.GetCableParticleLocations // Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const // @ game+0x5d6702c
	struct USceneComponent* GetAttachedComponent(); // Function CableComponent.CableComponent.GetAttachedComponent // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5d66ff4
	struct AActor* GetAttachedActor(); // Function CableComponent.CableComponent.GetAttachedActor // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5d66fdc
};

