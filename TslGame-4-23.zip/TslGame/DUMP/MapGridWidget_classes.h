// WidgetBlueprintGeneratedClass MapGridWidget.MapGridWidget_C
// Size: 0x16a1 (Inherited: 0x1680)
struct UMapGridWidget_C : UMapGridWidget {
	struct UWidgetAnimation* PulseBlackZoneCircle; // 0x1680(0x08)
	struct FVector2D StartPointUC; // 0x1688(0x08)
	struct FVector2D EndPointUC; // 0x1690(0x08)
	struct FVector2D StandardVector; // 0x1698(0x08)
	bool bShowCoord; // 0x16a0(0x01)

	struct FEventReply OnMouseMove(struct FGeometry MyGeometry, struct FPointerEvent MouseEvent); // Function MapGridWidget.MapGridWidget_C.OnMouseMove // BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	struct FSlateBrush Get_Replayzone_Brush_2(); // Function MapGridWidget.MapGridWidget_C.Get_Replayzone_Brush_2 // Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure // @ game+0x33e45c
	struct FSlateBrush Get_Replayzone_Brush_1(); // Function MapGridWidget.MapGridWidget_C.Get_Replayzone_Brush_1 // Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure // @ game+0x33e45c
};

