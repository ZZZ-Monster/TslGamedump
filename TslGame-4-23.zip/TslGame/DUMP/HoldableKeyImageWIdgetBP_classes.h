// WidgetBlueprintGeneratedClass HoldableKeyImageWIdgetBP.HoldableKeyImageWidgetBP_C
// Size: 0x4d8 (Inherited: 0x4d8)
struct UHoldableKeyImageWidgetBP_C : UTslKeyboardAndMouseHoldableIconWidget {
};

