// BlueprintGeneratedClass PlayerPawn_v2.PlayerPawn_v2_C
// Size: 0x2bd8 (Inherited: 0x2a80)
struct APlayerPawn_v2_C : ATslCharacter {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x2a80(0x08)
	struct UPawnNoiseEmitterComponent* PawnNoiseEmitter; // 0x2a88(0x08)
	struct UCapsuleComponent* Hit_Prone; // 0x2a90(0x08)
	struct UCapsuleComponent* Hit_Stand; // 0x2a98(0x08)
	struct FTimerHandle TestInspectHandle; // 0x2aa0(0x08)
	struct UAnimInstance* BaseAnimInstance; // 0x2aa8(0x08)
	bool AudioListenerIsSet; // 0x2ab0(0x01)
	char pad_2AB1[0x3]; // 0x2ab1(0x03)
	float MinVCut; // 0x2ab4(0x04)
	float MinZVCut; // 0x2ab8(0x04)
	float DmgFactor; // 0x2abc(0x04)
	float VDampingZ; // 0x2ac0(0x04)
	char pad_2AC4[0x4]; // 0x2ac4(0x04)
	struct FTslItemStringClass TestWeaponItemClass; // 0x2ac8(0x08)
	struct FTslItemStringClass TestAmmoItemClass; // 0x2ad0(0x08)
	float MaxJumpZVelocity; // 0x2ad8(0x04)
	float MovementAfterJumpCounter; // 0x2adc(0x04)
	float MinJumpZVelocity; // 0x2ae0(0x04)
	float MovementAfterJumpCounterDecrease; // 0x2ae4(0x04)
	float MaxMovementAfterJumpCounter; // 0x2ae8(0x04)
	char pad_2AEC[0x4]; // 0x2aec(0x04)
	struct UCurveVector* Curve_TPP2FPP; // 0x2af0(0x08)
	struct UCurveVector* Curve_FPP2TPP; // 0x2af8(0x08)
	struct UCurveVector* Curve_TPP2FPP_Pitch; // 0x2b00(0x08)
	struct UCurveVector* Curve_FPP2TPP_Pitch; // 0x2b08(0x08)
	bool bIsWeaponShoulderAttached; // 0x2b10(0x01)
	char pad_2B11[0x3]; // 0x2b11(0x03)
	float ADS_ReadyAngle; // 0x2b14(0x04)
	float SocketOffset_YZ; // 0x2b18(0x04)
	char pad_2B1C[0x4]; // 0x2b1c(0x04)
	struct ATslWeapon_Gun* ActiveGunRef; // 0x2b20(0x08)
	bool bCameraUnderWater; // 0x2b28(0x01)
	char pad_2B29[0x7]; // 0x2b29(0x07)
	struct ABP_CameraMan_C* CameraManRef; // 0x2b30(0x08)
	float YawTarget; // 0x2b38(0x04)
	float YawStep; // 0x2b3c(0x04)
	float GameTime; // 0x2b40(0x04)
	char pad_2B44[0x4]; // 0x2b44(0x04)
	struct UCameraModifier_CameraShake* Shake; // 0x2b48(0x08)
	float WeaponCollisionAlpha; // 0x2b50(0x04)
	char pad_2B54[0x4]; // 0x2b54(0x04)
	struct UW_SprintBar_C* SprintBarWidget; // 0x2b58(0x08)
	struct UStaticMeshComponent* ImpactMeshRef; // 0x2b60(0x08)
	bool HeavyFallStarted; // 0x2b68(0x01)
	bool PhysicalAnimationInitialized; // 0x2b69(0x01)
	char pad_2B6A[0x6]; // 0x2b6a(0x06)
	struct AAudioTestActor_C* AudioActorRef; // 0x2b70(0x08)
	struct UCurveFloat* Curve_EjectDamage; // 0x2b78(0x08)
	struct ABP_BulletCamActor_C* WeaponBulletCamRef; // 0x2b80(0x08)
	struct UW_WeaponMenu_C* WeapMenuRef; // 0x2b88(0x08)
	struct ABP_ActiveRagdollActor_C* RagdollActorRef; // 0x2b90(0x08)
	struct FVector RagdollActorPos; // 0x2b98(0x0c)
	char pad_2BA4[0x4]; // 0x2ba4(0x04)
	struct UW_RecoilDebugMenu_C* RecoilMenuRef; // 0x2ba8(0x08)
	struct TArray<struct FName> DistributedLoadout; // 0x2bb0(0x10)
	struct FTslStringClass AudioTestClassString; // 0x2bc0(0x10)
	struct UW_AIItemMenu_C* aiWeapMenu; // 0x2bd0(0x08)

	void GetAIController(struct TArray<struct ATslNewBotCharacter*> Array, struct ATslNewBotAIController* AsTsl New Bot AIController); // Function PlayerPawn_v2.PlayerPawn_v2_C.GetAIController // Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure // @ game+0x33e45c
	void AIWeaponMenuInit(); // Function PlayerPawn_v2.PlayerPawn_v2_C.AIWeaponMenuInit // Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void DistributeCurrentLoadout(struct TArray<struct FName> InItem); // Function PlayerPawn_v2.PlayerPawn_v2_C.DistributeCurrentLoadout // Public|HasOutParms|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void RecoilDebug_ToggleMouse(); // Function PlayerPawn_v2.PlayerPawn_v2_C.RecoilDebug_ToggleMouse // Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void RecoilDebug_Reset(); // Function PlayerPawn_v2.PlayerPawn_v2_C.RecoilDebug_Reset // Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void RecoilDebug_AddDataRow(); // Function PlayerPawn_v2.PlayerPawn_v2_C.RecoilDebug_AddDataRow // Public|HasDefaults|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void BlurScopeOutside(); // Function PlayerPawn_v2.PlayerPawn_v2_C.BlurScopeOutside // Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void Tick_PhysicalAnimation(); // Function PlayerPawn_v2.PlayerPawn_v2_C.Tick_PhysicalAnimation // Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void TEMP_WeapMenu_InitShow(bool ForceClose); // Function PlayerPawn_v2.PlayerPawn_v2_C.TEMP_WeapMenu_InitShow // Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void FixupThirdPersonCamera(struct USceneComponent* AttachComponent); // Function PlayerPawn_v2.PlayerPawn_v2_C.FixupThirdPersonCamera // Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void InitBulletCam(); // Function PlayerPawn_v2.PlayerPawn_v2_C.InitBulletCam // Public|HasDefaults|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void ProcessMPC(); // Function PlayerPawn_v2.PlayerPawn_v2_C.ProcessMPC // Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void TestInspectObject(); // Function PlayerPawn_v2.PlayerPawn_v2_C.TestInspectObject // Public|HasDefaults|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void TickSimulatePhysicsForAccessories(); // Function PlayerPawn_v2.PlayerPawn_v2_C.TickSimulatePhysicsForAccessories // Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void ProcessPhysicalAnimation(); // Function PlayerPawn_v2.PlayerPawn_v2_C.ProcessPhysicalAnimation // Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void ProcessLocalOnlyFunctions(); // Function PlayerPawn_v2.PlayerPawn_v2_C.ProcessLocalOnlyFunctions // Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void TEMPORARY_ProcessSprintBar(); // Function PlayerPawn_v2.PlayerPawn_v2_C.TEMPORARY_ProcessSprintBar // Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void InitializePhysicsForAccessories(); // Function PlayerPawn_v2.PlayerPawn_v2_C.InitializePhysicsForAccessories // Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void CheckWeaponCollision(); // Function PlayerPawn_v2.PlayerPawn_v2_C.CheckWeaponCollision // Public|HasDefaults|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void HandleMovementParameters(); // Function PlayerPawn_v2.PlayerPawn_v2_C.HandleMovementParameters // Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void CheckCameraUnderwater(); // Function PlayerPawn_v2.PlayerPawn_v2_C.CheckCameraUnderwater // Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void SetInertia(); // Function PlayerPawn_v2.PlayerPawn_v2_C.SetInertia // Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void ScopingSocketOffsetMoving(); // Function PlayerPawn_v2.PlayerPawn_v2_C.ScopingSocketOffsetMoving // Public|HasDefaults|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void AdjustCameraSwitching(); // Function PlayerPawn_v2.PlayerPawn_v2_C.AdjustCameraSwitching // Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void CheckForScoping(); // Function PlayerPawn_v2.PlayerPawn_v2_C.CheckForScoping // Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void push(struct FVector Delta Location); // Function PlayerPawn_v2.PlayerPawn_v2_C.push // Public|HasDefaults|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void UserConstructionScript(); // Function PlayerPawn_v2.PlayerPawn_v2_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void InpActEvt_NumPadZero_K2Node_InputKeyEvent_40(struct FKey Key); // Function PlayerPawn_v2.PlayerPawn_v2_C.InpActEvt_NumPadZero_K2Node_InputKeyEvent_40 // BlueprintEvent // @ game+0x33e45c
	void InpActEvt_Multiply_K2Node_InputKeyEvent_39(struct FKey Key); // Function PlayerPawn_v2.PlayerPawn_v2_C.InpActEvt_Multiply_K2Node_InputKeyEvent_39 // BlueprintEvent // @ game+0x33e45c
	void InpActEvt_NumPadSix_K2Node_InputKeyEvent_38(struct FKey Key); // Function PlayerPawn_v2.PlayerPawn_v2_C.InpActEvt_NumPadSix_K2Node_InputKeyEvent_38 // BlueprintEvent // @ game+0x33e45c
	void InpActEvt_NumPadSix_K2Node_InputKeyEvent_37(struct FKey Key); // Function PlayerPawn_v2.PlayerPawn_v2_C.InpActEvt_NumPadSix_K2Node_InputKeyEvent_37 // BlueprintEvent // @ game+0x33e45c
	void InpActEvt_NumPadFour_K2Node_InputKeyEvent_36(struct FKey Key); // Function PlayerPawn_v2.PlayerPawn_v2_C.InpActEvt_NumPadFour_K2Node_InputKeyEvent_36 // BlueprintEvent // @ game+0x33e45c
	void InpActEvt_NumPadFour_K2Node_InputKeyEvent_35(struct FKey Key); // Function PlayerPawn_v2.PlayerPawn_v2_C.InpActEvt_NumPadFour_K2Node_InputKeyEvent_35 // BlueprintEvent // @ game+0x33e45c
	void InpActEvt_NumPadOne_K2Node_InputKeyEvent_34(struct FKey Key); // Function PlayerPawn_v2.PlayerPawn_v2_C.InpActEvt_NumPadOne_K2Node_InputKeyEvent_34 // BlueprintEvent // @ game+0x33e45c
	void InpActEvt_Add_K2Node_InputKeyEvent_33(struct FKey Key); // Function PlayerPawn_v2.PlayerPawn_v2_C.InpActEvt_Add_K2Node_InputKeyEvent_33 // BlueprintEvent // @ game+0x33e45c
	void InpActEvt_Subtract_K2Node_InputKeyEvent_32(struct FKey Key); // Function PlayerPawn_v2.PlayerPawn_v2_C.InpActEvt_Subtract_K2Node_InputKeyEvent_32 // BlueprintEvent // @ game+0x33e45c
	void InpActEvt_NumPadThree_K2Node_InputKeyEvent_31(struct FKey Key); // Function PlayerPawn_v2.PlayerPawn_v2_C.InpActEvt_NumPadThree_K2Node_InputKeyEvent_31 // BlueprintEvent // @ game+0x33e45c
	void InpActEvt_NumPadSeven_K2Node_InputKeyEvent_30(struct FKey Key); // Function PlayerPawn_v2.PlayerPawn_v2_C.InpActEvt_NumPadSeven_K2Node_InputKeyEvent_30 // BlueprintEvent // @ game+0x33e45c
	void InpActEvt_NumPadNine_K2Node_InputKeyEvent_29(struct FKey Key); // Function PlayerPawn_v2.PlayerPawn_v2_C.InpActEvt_NumPadNine_K2Node_InputKeyEvent_29 // BlueprintEvent // @ game+0x33e45c
	void InpActEvt_NumPadEight_K2Node_InputKeyEvent_28(struct FKey Key); // Function PlayerPawn_v2.PlayerPawn_v2_C.InpActEvt_NumPadEight_K2Node_InputKeyEvent_28 // BlueprintEvent // @ game+0x33e45c
	void InpActEvt_NumPadTwo_K2Node_InputKeyEvent_27(struct FKey Key); // Function PlayerPawn_v2.PlayerPawn_v2_C.InpActEvt_NumPadTwo_K2Node_InputKeyEvent_27 // BlueprintEvent // @ game+0x33e45c
	void InpActEvt_NumPadFive_K2Node_InputKeyEvent_26(struct FKey Key); // Function PlayerPawn_v2.PlayerPawn_v2_C.InpActEvt_NumPadFive_K2Node_InputKeyEvent_26 // BlueprintEvent // @ game+0x33e45c
	void InpActEvt_Decimal_K2Node_InputKeyEvent_25(struct FKey Key); // Function PlayerPawn_v2.PlayerPawn_v2_C.InpActEvt_Decimal_K2Node_InputKeyEvent_25 // BlueprintEvent // @ game+0x33e45c
	void InpActEvt_Divide_K2Node_InputKeyEvent_24(struct FKey Key); // Function PlayerPawn_v2.PlayerPawn_v2_C.InpActEvt_Divide_K2Node_InputKeyEvent_24 // BlueprintEvent // @ game+0x33e45c
	void InpActEvt_Comma_K2Node_InputKeyEvent_23(struct FKey Key); // Function PlayerPawn_v2.PlayerPawn_v2_C.InpActEvt_Comma_K2Node_InputKeyEvent_23 // BlueprintEvent // @ game+0x33e45c
	void InpActEvt_Period_K2Node_InputKeyEvent_22(struct FKey Key); // Function PlayerPawn_v2.PlayerPawn_v2_C.InpActEvt_Period_K2Node_InputKeyEvent_22 // BlueprintEvent // @ game+0x33e45c
	void InpActEvt_Semicolon_K2Node_InputKeyEvent_21(struct FKey Key); // Function PlayerPawn_v2.PlayerPawn_v2_C.InpActEvt_Semicolon_K2Node_InputKeyEvent_21 // BlueprintEvent // @ game+0x33e45c
	void OnInvulnerable(); // Function PlayerPawn_v2.PlayerPawn_v2_C.OnInvulnerable // BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void OnTest_SetupWeapon(); // Function PlayerPawn_v2.PlayerPawn_v2_C.OnTest_SetupWeapon // BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void OnFreeMoveMode(); // Function PlayerPawn_v2.PlayerPawn_v2_C.OnFreeMoveMode // BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void ReceiveBeginPlay(); // Function PlayerPawn_v2.PlayerPawn_v2_C.ReceiveBeginPlay // Event|Protected|BlueprintEvent // @ game+0x33e45c
	void OnDecreaseMaxFlyAccerleration(); // Function PlayerPawn_v2.PlayerPawn_v2_C.OnDecreaseMaxFlyAccerleration // Event|Public|BlueprintEvent // @ game+0x33e45c
	void OnIncreaseMaxFlyAccerleration(); // Function PlayerPawn_v2.PlayerPawn_v2_C.OnIncreaseMaxFlyAccerleration // Event|Public|BlueprintEvent // @ game+0x33e45c
	void SetupWeaponBlueprint(); // Function PlayerPawn_v2.PlayerPawn_v2_C.SetupWeaponBlueprint // Event|Public|BlueprintEvent // @ game+0x33e45c
	void OnTest_InspectObject(); // Function PlayerPawn_v2.PlayerPawn_v2_C.OnTest_InspectObject // Event|Public|BlueprintEvent // @ game+0x33e45c
	void SpawnBulletPassByEffect(struct FVector Location, float BulletVelocity); // Function PlayerPawn_v2.PlayerPawn_v2_C.SpawnBulletPassByEffect // Event|Public|BlueprintEvent // @ game+0x33e45c
	void ServerSetInvulnerability(); // Function PlayerPawn_v2.PlayerPawn_v2_C.ServerSetInvulnerability // Net|NetServer|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void BndEvt__CapsuleComponent_K2Node_ComponentBoundEvent_0_ComponentHitSignature__DelegateSignature(struct UPrimitiveComponent* HitComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, struct FVector NormalImpulse, struct FHitResult Hit); // Function PlayerPawn_v2.PlayerPawn_v2_C.BndEvt__CapsuleComponent_K2Node_ComponentBoundEvent_0_ComponentHitSignature__DelegateSignature // HasOutParms|BlueprintEvent // @ game+0x33e45c
	void NotHaveHealItemNotifyMessage(struct FText ItemName); // Function PlayerPawn_v2.PlayerPawn_v2_C.NotHaveHealItemNotifyMessage // Event|Public|HasOutParms|BlueprintEvent // @ game+0x33e45c
	void NotHaveBoostItemNotifyMessage(); // Function PlayerPawn_v2.PlayerPawn_v2_C.NotHaveBoostItemNotifyMessage // Event|Public|BlueprintEvent // @ game+0x33e45c
	void ActivateADS_Debuff(); // Function PlayerPawn_v2.PlayerPawn_v2_C.ActivateADS_Debuff // Net|NetReliableNetClient|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void Cheat_GiveItem(struct FName ItemRef); // Function PlayerPawn_v2.PlayerPawn_v2_C.Cheat_GiveItem // BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void Cheat_Server_GiveItem(struct FName ItemRef); // Function PlayerPawn_v2.PlayerPawn_v2_C.Cheat_Server_GiveItem // Net|NetServer|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void Cheat_Give_Current_Ammo(); // Function PlayerPawn_v2.PlayerPawn_v2_C.Cheat_Give_Current_Ammo // BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void Cheat_RevivePlayer(); // Function PlayerPawn_v2.PlayerPawn_v2_C.Cheat_RevivePlayer // BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void NotHaveThrowItemNotifyMessage(struct FText ItemName); // Function PlayerPawn_v2.PlayerPawn_v2_C.NotHaveThrowItemNotifyMessage // Event|Public|HasOutParms|BlueprintEvent // @ game+0x33e45c
	void ServerFreeMove(); // Function PlayerPawn_v2.PlayerPawn_v2_C.ServerFreeMove // Net|NetServer|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void Server_SetActiveRagdoll(bool InActivate); // Function PlayerPawn_v2.PlayerPawn_v2_C.Server_SetActiveRagdoll // Net|NetReliableNetServer|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void Client_ResetMesh(); // Function PlayerPawn_v2.PlayerPawn_v2_C.Client_ResetMesh // Net|NetReliableNetMulticast|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void Server_HandleRagdollActor(bool bSpawn); // Function PlayerPawn_v2.PlayerPawn_v2_C.Server_HandleRagdollActor // Net|NetReliableNetMulticast|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void Server_setRagdollActorPos(struct FVector InPos); // Function PlayerPawn_v2.PlayerPawn_v2_C.Server_setRagdollActorPos // Net|NetReliableNetServer|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void HaveNotAnyHealItemNotifyMessage(); // Function PlayerPawn_v2.PlayerPawn_v2_C.HaveNotAnyHealItemNotifyMessage // Event|Public|BlueprintEvent // @ game+0x33e45c
	void ServerSetupWeapon(); // Function PlayerPawn_v2.PlayerPawn_v2_C.ServerSetupWeapon // Net|NetServer|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void Client_AdjustFlySpeed(float MaxSpeed, float MaxAccel, float Deccel); // Function PlayerPawn_v2.PlayerPawn_v2_C.Client_AdjustFlySpeed // Net|NetReliableNetClient|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void ToggleFreeMode(); // Function PlayerPawn_v2.PlayerPawn_v2_C.ToggleFreeMode // Event|Public|BlueprintEvent // @ game+0x33e45c
	void ToggleInvincibility(); // Function PlayerPawn_v2.PlayerPawn_v2_C.ToggleInvincibility // Event|Public|BlueprintEvent // @ game+0x33e45c
	void SimulateHeadShot(struct FTransform SpawnTransform, struct FTransform ImpactTransform); // Function PlayerPawn_v2.PlayerPawn_v2_C.SimulateHeadShot // Event|Protected|HasOutParms|BlueprintEvent // @ game+0x33e45c
	void OnTakeAnyDamage_Event_1(struct AActor* DamagedActor, float Damage, struct UDamageType* DamageType, struct AController* InstigatedBy, struct AActor* DamageCauser); // Function PlayerPawn_v2.PlayerPawn_v2_C.OnTakeAnyDamage_Event_1 // BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void OnLanded(struct FHitResult Hit); // Function PlayerPawn_v2.PlayerPawn_v2_C.OnLanded // Event|Public|HasOutParms|BlueprintEvent // @ game+0x33e45c
	void OnCharacterWeaponRecoil_Event_1(); // Function PlayerPawn_v2.PlayerPawn_v2_C.OnCharacterWeaponRecoil_Event_1 // BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void GiveShieldToPlayer_BP(); // Function PlayerPawn_v2.PlayerPawn_v2_C.GiveShieldToPlayer_BP // Event|Public|BlueprintEvent // @ game+0x33e45c
	void Server_AttachShield(); // Function PlayerPawn_v2.PlayerPawn_v2_C.Server_AttachShield // Net|NetReliableNetServer|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void Cheat_Server_Distribute_Loadout(struct TArray<struct FName> ItemRef); // Function PlayerPawn_v2.PlayerPawn_v2_C.Cheat_Server_Distribute_Loadout // Net|NetServer|HasOutParms|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void Server_GiveAIItem(struct FName ItemID, struct TArray<struct ATslNewBotCharacter*> aiCharacter); // Function PlayerPawn_v2.PlayerPawn_v2_C.Server_GiveAIItem // Net|NetReliableNetServer|HasOutParms|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void Server_UseMedItem(struct TArray<struct ATslNewBotCharacter*> aiCharacter, enum class ECastableItemType ItemType); // Function PlayerPawn_v2.PlayerPawn_v2_C.Server_UseMedItem // Net|NetReliableNetServer|HasOutParms|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void ReceiveTick(float DeltaSeconds); // Function PlayerPawn_v2.PlayerPawn_v2_C.ReceiveTick // Event|Public|BlueprintEvent // @ game+0x33e45c
	void ExecuteUbergraph_PlayerPawn_v2(int32 EntryPoint); // Function PlayerPawn_v2.PlayerPawn_v2_C.ExecuteUbergraph_PlayerPawn_v2 // HasDefaults // @ game+0x33e45c
};

