// WidgetBlueprintGeneratedClass BP_InteractionEmoteCanvasWidget.BP_InteractionEmoteCanvasWidget_C
// Size: 0x4b0 (Inherited: 0x4a8)
struct UBP_InteractionEmoteCanvasWidget_C : UTslInteractionEmoteCanvas {
	struct UWidgetAnimation* Blink; // 0x4a8(0x08)
};

