// WidgetBlueprintGeneratedClass BP_KillLogVictimButton.BP_KillLogVictimButton_C
// Size: 0x6c8 (Inherited: 0x6b8)
struct UBP_KillLogVictimButton_C : UTslKillLogVictimButton {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x6b8(0x08)
	struct UButton* Button_1; // 0x6c0(0x08)

	void BndEvt__Button_0_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature(); // Function BP_KillLogVictimButton.BP_KillLogVictimButton_C.BndEvt__Button_0_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature // BlueprintEvent // @ game+0x33e45c
	void ExecuteUbergraph_BP_KillLogVictimButton(int32 EntryPoint); // Function BP_KillLogVictimButton.BP_KillLogVictimButton_C.ExecuteUbergraph_BP_KillLogVictimButton //  // @ game+0x33e45c
};

