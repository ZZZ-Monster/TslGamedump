// Enum CustomizableObject.ECustomizableObjectProjectorType
enum class ECustomizableObjectProjectorType : uint8 {
	Planar,
	Cylindrical,
	Wrapping,
	ECustomizableObjectProjectorType_MAX,
};

// Enum CustomizableObject.EMutableCompileMeshType
enum class EMutableCompileMeshType : uint8 {
	Full,
	Local,
	LocalAndChildren,
	AddWorkingSetNoChildren,
	AddWorkingSetAndChildren,
	EMutableCompileMeshType_MAX,
};

// Enum CustomizableObject.ECustomizableObjectGroupType
enum class ECustomizableObjectGroupType : uint8 {
	COGT_TOGGLE,
	COGT_ALL,
	COGT_ONE,
	COGT_ONE_OR_NONE,
	COGT_MAX,
};

// Enum CustomizableObject.EMutableParameterType
enum class EMutableParameterType : uint8 {
	None,
	Bool,
	Int,
	Float,
	Color,
	Projector,
	Texture,
	EMutableParameterType_MAX,
};

// Enum CustomizableObject.ECustomizableObjectRelevancy
enum class ECustomizableObjectRelevancy : uint8 {
	All,
	ClientOnly,
	ECustomizableObjectRelevancy_MAX,
};

// ScriptStruct CustomizableObject.CustomizableObjectIdPair
// Size: 0x20 (Inherited: 0x00)
struct FCustomizableObjectIdPair {
	struct FString CustomizableObjectGroupName; // 0x00(0x10)
	struct FString CustomizableObjectName; // 0x10(0x10)
};

// ScriptStruct CustomizableObject.CustomizableObjectIdentifier
// Size: 0x30 (Inherited: 0x00)
struct FCustomizableObjectIdentifier {
	struct FString CustomizableObjectGroupName; // 0x00(0x10)
	struct FString CustomizableObjectName; // 0x10(0x10)
	struct FString Guid; // 0x20(0x10)
};

// ScriptStruct CustomizableObject.CustomizableObjectProjectorParameterValue
// Size: 0x68 (Inherited: 0x00)
struct FCustomizableObjectProjectorParameterValue {
	struct FString ParameterName; // 0x00(0x10)
	struct FCustomizableObjectProjector Value; // 0x10(0x38)
	struct FString Uid; // 0x48(0x10)
	struct TArray<struct FCustomizableObjectProjector> RangeValues; // 0x58(0x10)
};

// ScriptStruct CustomizableObject.CustomizableObjectProjector
// Size: 0x38 (Inherited: 0x00)
struct FCustomizableObjectProjector {
	struct FVector Position; // 0x00(0x0c)
	struct FVector Direction; // 0x0c(0x0c)
	struct FVector Up; // 0x18(0x0c)
	struct FVector Scale; // 0x24(0x0c)
	enum class ECustomizableObjectProjectorType ProjectionType; // 0x30(0x01)
	char pad_31[0x3]; // 0x31(0x03)
	float Angle; // 0x34(0x04)
};

// ScriptStruct CustomizableObject.CustomizableObjectVectorParameterValue
// Size: 0x30 (Inherited: 0x00)
struct FCustomizableObjectVectorParameterValue {
	struct FString ParameterName; // 0x00(0x10)
	struct FLinearColor ParameterValue; // 0x10(0x10)
	struct FString Uid; // 0x20(0x10)
};

// ScriptStruct CustomizableObject.CustomizableObjectTextureParameterValue
// Size: 0x28 (Inherited: 0x00)
struct FCustomizableObjectTextureParameterValue {
	struct FString ParameterName; // 0x00(0x10)
	uint64 ParameterValue; // 0x10(0x08)
	struct FString Uid; // 0x18(0x10)
};

// ScriptStruct CustomizableObject.CustomizableObjectFloatParameterValue
// Size: 0x38 (Inherited: 0x00)
struct FCustomizableObjectFloatParameterValue {
	struct FString ParameterName; // 0x00(0x10)
	float ParameterValue; // 0x10(0x04)
	char pad_14[0x4]; // 0x14(0x04)
	struct FString Uid; // 0x18(0x10)
	struct TArray<float> ParameterRangeValues; // 0x28(0x10)
};

// ScriptStruct CustomizableObject.CustomizableObjectIntParameterValue
// Size: 0x40 (Inherited: 0x00)
struct FCustomizableObjectIntParameterValue {
	struct FString ParameterName; // 0x00(0x10)
	struct FString ParameterValueName; // 0x10(0x10)
	struct FString Uid; // 0x20(0x10)
	struct TArray<struct FString> ParameterRangeValueNames; // 0x30(0x10)
};

// ScriptStruct CustomizableObject.CustomizableObjectBoolParameterValue
// Size: 0x28 (Inherited: 0x00)
struct FCustomizableObjectBoolParameterValue {
	struct FString ParameterName; // 0x00(0x10)
	bool ParameterValue; // 0x10(0x01)
	char pad_11[0x7]; // 0x11(0x07)
	struct FString Uid; // 0x18(0x10)
};

// ScriptStruct CustomizableObject.ParameterUIData
// Size: 0x118 (Inherited: 0x00)
struct FParameterUIData {
	struct FString Name; // 0x00(0x10)
	struct FMutableParamUIMetadata ParamUIMetadata; // 0x10(0xe8)
	enum class EMutableParameterType Type; // 0xf8(0x01)
	char pad_F9[0x7]; // 0xf9(0x07)
	struct TArray<struct FIntegerParameterUIData> ArrayIntegerParameterOption; // 0x100(0x10)
	enum class ECustomizableObjectGroupType IntegerParameterGroupType; // 0x110(0x01)
	bool bDontCompressRuntimeTextures; // 0x111(0x01)
	char pad_112[0x6]; // 0x112(0x06)
};

// ScriptStruct CustomizableObject.IntegerParameterUIData
// Size: 0xf8 (Inherited: 0x00)
struct FIntegerParameterUIData {
	struct FString Name; // 0x00(0x10)
	struct FMutableParamUIMetadata ParamUIMetadata; // 0x10(0xe8)
};

// ScriptStruct CustomizableObject.MutableParamUIMetadata
// Size: 0xe8 (Inherited: 0x00)
struct FMutableParamUIMetadata {
	struct FString ObjectFriendlyName; // 0x00(0x10)
	struct FString UISectionName; // 0x10(0x10)
	int32 UIOrder; // 0x20(0x04)
	char pad_24[0x4]; // 0x24(0x04)
	struct UTexture2D* UIThumbnail; // 0x28(0x20)
	struct TMap<struct FString, struct FString> ExtraInformation; // 0x48(0x50)
	struct TMap<struct FString, struct UObject*> ExtraAssets; // 0x98(0x50)
};

// ScriptStruct CustomizableObject.CustomizedMaterialTexture2D
// Size: 0x10 (Inherited: 0x00)
struct FCustomizedMaterialTexture2D {
	struct FName Name; // 0x00(0x08)
	struct UTexture2D* Texture; // 0x08(0x08)
};

// ScriptStruct CustomizableObject.ParameterDecorations
// Size: 0x10 (Inherited: 0x00)
struct FParameterDecorations {
	struct TArray<struct UTexture2D*> Images; // 0x00(0x10)
};

// ScriptStruct CustomizableObject.GeneratedMaterial
// Size: 0x10 (Inherited: 0x00)
struct FGeneratedMaterial {
	struct TArray<struct FGeneratedTexture> Textures; // 0x00(0x10)
};

// ScriptStruct CustomizableObject.GeneratedTexture
// Size: 0x20 (Inherited: 0x00)
struct FGeneratedTexture {
	int32 ID; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct FString Name; // 0x08(0x10)
	struct UTexture2D* Texture; // 0x18(0x08)
};

// ScriptStruct CustomizableObject.GeneratedMesh
// Size: 0x10 (Inherited: 0x00)
struct FGeneratedMesh {
	int32 ID; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct UStaticMesh* Mesh; // 0x08(0x08)
};

// ScriptStruct CustomizableObject.MutableBuiltData
// Size: 0x14 (Inherited: 0x00)
struct FMutableBuiltData {
	struct FGuid CompilationId; // 0x00(0x10)
	int32 SupportedVersion; // 0x10(0x04)
};

// ScriptStruct CustomizableObject.WorkingSet
// Size: 0x30 (Inherited: 0x00)
struct FWorkingSet {
	struct FString CObjectPath; // 0x00(0x10)
	struct UCustomizableObject* CObject; // 0x10(0x20)
};

// ScriptStruct CustomizableObject.MorphTargetVertexIndex
// Size: 0x08 (Inherited: 0x00)
struct FMorphTargetVertexIndex {
	int32 MorphIndex; // 0x00(0x04)
	int32 VertexIndex; // 0x04(0x04)
};

// ScriptStruct CustomizableObject.MaskOutTexture
// Size: 0x18 (Inherited: 0x00)
struct FMaskOutTexture {
	int32 SizeX; // 0x00(0x04)
	int32 SizeY; // 0x04(0x04)
	struct TArray<uint32> Data; // 0x08(0x10)
};

// ScriptStruct CustomizableObject.MutableModelParameterProperties
// Size: 0x118 (Inherited: 0x00)
struct FMutableModelParameterProperties {
	struct FString Name; // 0x00(0x10)
	enum class EMutableParameterType Type; // 0x10(0x01)
	char pad_11[0x3]; // 0x11(0x03)
	int32 ImageDescriptionCount; // 0x14(0x04)
	struct TArray<struct FMutableModelParameterValue> PossibleValues; // 0x18(0x10)
	struct FMutableParamUIMetadata ParamUIMetadata; // 0x28(0xe8)
	bool bIsParamMultidimensional; // 0x110(0x01)
	char pad_111[0x7]; // 0x111(0x07)
};

// ScriptStruct CustomizableObject.MutableModelParameterValue
// Size: 0x18 (Inherited: 0x00)
struct FMutableModelParameterValue {
	struct FString Name; // 0x00(0x10)
	int32 Value; // 0x10(0x04)
	char pad_14[0x4]; // 0x14(0x04)
};

// ScriptStruct CustomizableObject.MutableModelImageProperties
// Size: 0x20 (Inherited: 0x00)
struct FMutableModelImageProperties {
	struct FString TextureParameterName; // 0x00(0x10)
	enum class TextureFilter Filter; // 0x10(0x01)
	char pad_11[0x3]; // 0x11(0x03)
	char SRGB : 1; // 0x14(0x01)
	char pad_14_1 : 7; // 0x14(0x01)
	char pad_15[0x3]; // 0x15(0x03)
	int32 LODBias; // 0x18(0x04)
	enum class TextureAddress AddressX; // 0x1c(0x01)
	enum class TextureAddress AddressY; // 0x1d(0x01)
	enum class TextureGroup LODGroup; // 0x1e(0x01)
	char pad_1F[0x1]; // 0x1f(0x01)
};

// ScriptStruct CustomizableObject.CustomizableObjectExportOptions
// Size: 0x18 (Inherited: 0x00)
struct FCustomizableObjectExportOptions {
	bool bTextureCompression; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct FString TargetPlatform; // 0x08(0x10)
};

// ScriptStruct CustomizableObject.CompilationOptions
// Size: 0x20 (Inherited: 0x00)
struct FCompilationOptions {
	bool bTextureCompression; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	int32 OptimizationLevel; // 0x04(0x04)
	bool bUseParallelCompilation; // 0x08(0x01)
	bool bUseDiskCompilation; // 0x09(0x01)
	char pad_A[0x16]; // 0x0a(0x16)
};

// ScriptStruct CustomizableObject.ProfileParameterDat
// Size: 0x70 (Inherited: 0x00)
struct FProfileParameterDat {
	struct FString ProfileName; // 0x00(0x10)
	struct TArray<struct FCustomizableObjectBoolParameterValue> BoolParameters; // 0x10(0x10)
	struct TArray<struct FCustomizableObjectIntParameterValue> IntParameters; // 0x20(0x10)
	struct TArray<struct FCustomizableObjectFloatParameterValue> FloatParameters; // 0x30(0x10)
	struct TArray<struct FCustomizableObjectTextureParameterValue> TextureParameters; // 0x40(0x10)
	struct TArray<struct FCustomizableObjectVectorParameterValue> VectorParameters; // 0x50(0x10)
	struct TArray<struct FCustomizableObjectProjectorParameterValue> ProjectorParameters; // 0x60(0x10)
};

// ScriptStruct CustomizableObject.PendingReleaseSkeletalMeshInfo
// Size: 0x20 (Inherited: 0x00)
struct FPendingReleaseSkeletalMeshInfo {
	struct USkeletalMesh* SkeletalMesh; // 0x00(0x08)
	struct TArray<struct USkinnedMeshComponent*> Components; // 0x08(0x10)
	double Timestamp; // 0x18(0x08)
};

