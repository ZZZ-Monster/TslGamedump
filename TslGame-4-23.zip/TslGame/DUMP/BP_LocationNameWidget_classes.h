// WidgetBlueprintGeneratedClass BP_LocationNameWidget.BP_LocationNameWidget_C
// Size: 0x4b0 (Inherited: 0x4a8)
struct UBP_LocationNameWidget_C : ULocationNameWidget {
	struct UImage* Image_3; // 0x4a8(0x08)
};

