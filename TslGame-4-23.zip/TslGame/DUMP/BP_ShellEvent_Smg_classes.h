// BlueprintGeneratedClass BP_ShellEvent_Smg.BP_ShellEvent_SMG_C
// Size: 0x98 (Inherited: 0x98)
struct UBP_ShellEvent_SMG_C : UTslParticleModuleEventSendToGame {
};

