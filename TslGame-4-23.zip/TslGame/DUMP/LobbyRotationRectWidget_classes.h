// WidgetBlueprintGeneratedClass LobbyRotationRectWidget.LobbyRotationRectWidget_C
// Size: 0x430 (Inherited: 0x428)
struct ULobbyRotationRectWidget_C : UBaseLobbyRotationRectWidget {
	struct UImage* RotationRect; // 0x428(0x08)
};

