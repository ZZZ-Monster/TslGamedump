// BlueprintGeneratedClass FBRBuff_item_super_wa_lv4.FBRBuff_item_super_wa_lv4_C
// Size: 0x4c8 (Inherited: 0x4c0)
struct AFBRBuff_item_super_wa_lv4_C : ATslFBRItemBuff {
	struct USceneComponent* DefaultSceneRoot; // 0x4c0(0x08)

	void UserConstructionScript(); // Function FBRBuff_item_super_wa_lv4.FBRBuff_item_super_wa_lv4_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
};

