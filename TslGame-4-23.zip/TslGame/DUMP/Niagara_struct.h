// Enum Niagara.ENiagaraNumericOutputTypeSelectionMode
enum class ENiagaraNumericOutputTypeSelectionMode : uint8 {
	None,
	Largest,
	Smallest,
	Scalar,
	ENiagaraNumericOutputTypeSelectionMode_MAX,
};

// Enum Niagara.ENiagaraScriptCompileStatus
enum class ENiagaraScriptCompileStatus : uint8 {
	NCS_Unknown,
	NCS_Dirty,
	NCS_Error,
	NCS_UpToDate,
	NCS_BeingCreated,
	NCS_UpToDateWithWarnings,
	NCS_MAX,
};

// Enum Niagara.ENiagaraInputNodeUsage
enum class ENiagaraInputNodeUsage : uint8 {
	Undefined,
	Parameter,
	Attribute,
	SystemConstant,
	ENiagaraInputNodeUsage_MAX,
};

// Enum Niagara.ENiagaraDataSetType
enum class ENiagaraDataSetType : uint8 {
	ParticleData,
	Shared,
	Event,
	ENiagaraDataSetType_MAX,
};

// Enum Niagara.ENiagaraSpriteFacingMode
enum class ENiagaraSpriteFacingMode : uint8 {
	FaceCamera,
	FaceCameraPlane,
	CustomFacingVector,
	ENiagaraSpriteFacingMode_MAX,
};

// Enum Niagara.ENiagaraSpriteAlignment
enum class ENiagaraSpriteAlignment : uint8 {
	Unaligned,
	VelocityAligned,
	CustomAlignment,
	ENiagaraSpriteAlignment_MAX,
};

// Enum Niagara.ENiagaraSortMode
enum class ENiagaraSortMode : uint8 {
	SortNone,
	SortViewDepth,
	SortViewDistance,
	ENiagaraSortMode_MAX,
};

// Enum Niagara.ENiagaraScriptUsage
enum class ENiagaraScriptUsage : uint8 {
	Function,
	Module,
	SpawnScript,
	SpawnScriptInterpolated,
	UpdateScript,
	EffectScript,
	ENiagaraScriptUsage_MAX,
};

// Enum Niagara.EUnusedAttributeBehaviour
enum class EUnusedAttributeBehaviour : uint8 {
	Copy,
	Zero,
	None,
	MarkInvalid,
	PassThrough,
	EUnusedAttributeBehaviour_MAX,
};

// Enum Niagara.ENiagaraCollisionMode
enum class ENiagaraCollisionMode : uint8 {
	None,
	SceneGeometry,
	DepthBuffer,
	DistanceField,
	ENiagaraCollisionMode_MAX,
};

// Enum Niagara.EScriptCompileIndices
enum class EScriptCompileIndices : uint8 {
	SpawnScript,
	UpdateScript,
	EventScript,
	EScriptCompileIndices_MAX,
};

// Enum Niagara.EScriptExecutionMode
enum class EScriptExecutionMode : uint8 {
	EveryParticle,
	SpawnedParticles,
	SingleParticle,
	EScriptExecutionMode_MAX,
};

// ScriptStruct Niagara.NiagaraVariable
// Size: 0x30 (Inherited: 0x00)
struct FNiagaraVariable {
	struct FGuid ID; // 0x00(0x10)
	struct FName Name; // 0x10(0x08)
	struct FNiagaraTypeDefinition TypeDef; // 0x18(0x08)
	struct TArray<bool> VarData; // 0x20(0x10)
};

// ScriptStruct Niagara.NiagaraTypeDefinition
// Size: 0x08 (Inherited: 0x00)
struct FNiagaraTypeDefinition {
	struct UStruct* Struct; // 0x00(0x08)
};

// ScriptStruct Niagara.NiagaraMatrix
// Size: 0x40 (Inherited: 0x00)
struct FNiagaraMatrix {
	struct FVector4 Row0; // 0x00(0x10)
	struct FVector4 Row1; // 0x10(0x10)
	struct FVector4 Row2; // 0x20(0x10)
	struct FVector4 Row3; // 0x30(0x10)
};

// ScriptStruct Niagara.NiagaraTestStruct
// Size: 0x48 (Inherited: 0x00)
struct FNiagaraTestStruct {
	struct FVector Vector1; // 0x00(0x0c)
	struct FVector Vector2; // 0x0c(0x0c)
	struct FNiagaraTestStructInner InnerStruct1; // 0x18(0x18)
	struct FNiagaraTestStructInner InnerStruct2; // 0x30(0x18)
};

// ScriptStruct Niagara.NiagaraTestStructInner
// Size: 0x18 (Inherited: 0x00)
struct FNiagaraTestStructInner {
	struct FVector InnerVector1; // 0x00(0x0c)
	struct FVector InnerVector2; // 0x0c(0x0c)
};

// ScriptStruct Niagara.NiagaraNumeric
// Size: 0x01 (Inherited: 0x00)
struct FNiagaraNumeric {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct Niagara.NiagaraBool
// Size: 0x04 (Inherited: 0x00)
struct FNiagaraBool {
	int32 Value; // 0x00(0x04)
};

// ScriptStruct Niagara.NiagaraInt32
// Size: 0x04 (Inherited: 0x00)
struct FNiagaraInt32 {
	int32 Value; // 0x00(0x04)
};

// ScriptStruct Niagara.NiagaraFloat
// Size: 0x04 (Inherited: 0x00)
struct FNiagaraFloat {
	float Value; // 0x00(0x04)
};

// ScriptStruct Niagara.VMExternalFunctionBindingInfo
// Size: 0x30 (Inherited: 0x00)
struct FVMExternalFunctionBindingInfo {
	struct FName Name; // 0x00(0x08)
	struct FGuid OwnerId; // 0x08(0x10)
	struct TArray<bool> InputParamLocations; // 0x18(0x10)
	int32 NumOutputs; // 0x28(0x04)
	char pad_2C[0x4]; // 0x2c(0x04)
};

// ScriptStruct Niagara.NiagaraStatScope
// Size: 0x20 (Inherited: 0x00)
struct FNiagaraStatScope {
	char pad_0[0x20]; // 0x00(0x20)
};

// ScriptStruct Niagara.NiagaraScriptDataInterfaceInfo
// Size: 0x20 (Inherited: 0x00)
struct FNiagaraScriptDataInterfaceInfo {
	struct UNiagaraDataInterface* DataInterface; // 0x00(0x08)
	struct FGuid ID; // 0x08(0x10)
	struct FName Name; // 0x18(0x08)
};

// ScriptStruct Niagara.NiagaraFunctionSignature
// Size: 0x40 (Inherited: 0x00)
struct FNiagaraFunctionSignature {
	struct FName Name; // 0x00(0x08)
	struct TArray<struct FNiagaraVariable> Inputs; // 0x08(0x10)
	struct TArray<struct FNiagaraVariable> Outputs; // 0x18(0x10)
	struct FGuid OwnerId; // 0x28(0x10)
	bool bRequiresContext; // 0x38(0x01)
	bool bMemberFunction; // 0x39(0x01)
	char pad_3A[0x6]; // 0x3a(0x06)
};

// ScriptStruct Niagara.NiagaraScriptDataUsageInfo
// Size: 0x01 (Inherited: 0x00)
struct FNiagaraScriptDataUsageInfo {
	bool bReadsAttriubteData; // 0x00(0x01)
};

// ScriptStruct Niagara.NiagaraDataSetProperties
// Size: 0x20 (Inherited: 0x00)
struct FNiagaraDataSetProperties {
	struct FNiagaraDataSetID ID; // 0x00(0x10)
	struct TArray<struct FNiagaraVariable> Variables; // 0x10(0x10)
};

// ScriptStruct Niagara.NiagaraDataSetID
// Size: 0x10 (Inherited: 0x00)
struct FNiagaraDataSetID {
	struct FName Name; // 0x00(0x08)
	enum class ENiagaraDataSetType Type; // 0x08(0x01)
	char pad_9[0x7]; // 0x09(0x07)
};

// ScriptStruct Niagara.NDIStaticMeshSectionFilter
// Size: 0x68 (Inherited: 0x00)
struct FNDIStaticMeshSectionFilter {
	struct TArray<int32> AllowedMaterialSlots; // 0x00(0x10)
	char pad_10[0x58]; // 0x10(0x58)
};

// ScriptStruct Niagara.MeshTriCoordinate
// Size: 0x10 (Inherited: 0x00)
struct FMeshTriCoordinate {
	int32 Tri; // 0x00(0x04)
	struct FVector BaryCoord; // 0x04(0x0c)
};

// ScriptStruct Niagara.NiagaraEmitterHandle
// Size: 0x30 (Inherited: 0x00)
struct FNiagaraEmitterHandle {
	struct FGuid ID; // 0x00(0x10)
	struct FName IdName; // 0x10(0x08)
	bool bIsEnabled; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
	struct FName Name; // 0x20(0x08)
	struct UNiagaraEmitterProperties* Instance; // 0x28(0x08)
};

// ScriptStruct Niagara.NiagaraEmitterInternalVariableBinding
// Size: 0x30 (Inherited: 0x00)
struct FNiagaraEmitterInternalVariableBinding {
	struct FGuid SourceParameterId; // 0x00(0x10)
	struct FGuid DestinationEmitterId; // 0x10(0x10)
	struct FString DestinationEmitterVariableName; // 0x20(0x10)
};

// ScriptStruct Niagara.NiagaraParameterBinding
// Size: 0x30 (Inherited: 0x00)
struct FNiagaraParameterBinding {
	struct FGuid SourceParameterId; // 0x00(0x10)
	struct FGuid DestinationEmitterId; // 0x10(0x10)
	struct FGuid DestinationParameterId; // 0x20(0x10)
};

// ScriptStruct Niagara.NiagaraParameters
// Size: 0x10 (Inherited: 0x00)
struct FNiagaraParameters {
	struct TArray<struct FNiagaraVariable> Parameters; // 0x00(0x10)
};

// ScriptStruct Niagara.NiagaraCollisionEventPayload
// Size: 0x2c (Inherited: 0x00)
struct FNiagaraCollisionEventPayload {
	struct FVector CollisionPos; // 0x00(0x0c)
	struct FVector CollisionNormal; // 0x0c(0x0c)
	int32 PhysicalMaterialIndex; // 0x18(0x04)
	struct FVector CollisionVelocity; // 0x1c(0x0c)
	int32 ParticleIndex; // 0x28(0x04)
};

// ScriptStruct Niagara.NiagaraEmitterBurst
// Size: 0x10 (Inherited: 0x00)
struct FNiagaraEmitterBurst {
	float Time; // 0x00(0x04)
	float TimeRange; // 0x04(0x04)
	uint32 SpawnMinimum; // 0x08(0x04)
	uint32 SpawnMaximum; // 0x0c(0x04)
};

// ScriptStruct Niagara.NiagaraEventScriptProperties
// Size: 0x50 (Inherited: 0x28)
struct FNiagaraEventScriptProperties : FNiagaraEmitterScriptProperties {
	enum class EScriptExecutionMode ExecutionMode; // 0x28(0x01)
	char pad_29[0x3]; // 0x29(0x03)
	uint32 SpawnNumber; // 0x2c(0x04)
	uint32 MaxEventsPerFrame; // 0x30(0x04)
	struct FGuid SourceEmitterID; // 0x34(0x10)
	char pad_44[0x4]; // 0x44(0x04)
	struct FName SourceEventName; // 0x48(0x08)
};

// ScriptStruct Niagara.NiagaraEmitterScriptProperties
// Size: 0x28 (Inherited: 0x00)
struct FNiagaraEmitterScriptProperties {
	struct UNiagaraScript* Script; // 0x00(0x08)
	struct TArray<struct FNiagaraEventReceiverProperties> EventReceivers; // 0x08(0x10)
	struct TArray<struct FNiagaraEventGeneratorProperties> EventGenerators; // 0x18(0x10)
};

// ScriptStruct Niagara.NiagaraEventGeneratorProperties
// Size: 0x38 (Inherited: 0x00)
struct FNiagaraEventGeneratorProperties {
	int32 MaxEventsPerFrame; // 0x00(0x04)
	char pad_4[0x14]; // 0x04(0x14)
	struct FNiagaraDataSetProperties SetProps; // 0x18(0x20)
};

// ScriptStruct Niagara.NiagaraEventReceiverProperties
// Size: 0x28 (Inherited: 0x00)
struct FNiagaraEventReceiverProperties {
	struct FName Name; // 0x00(0x08)
	struct FName SourceEventGenerator; // 0x08(0x08)
	struct FName SourceEmitter; // 0x10(0x08)
	struct TArray<struct UNiagaraEventReceiverEmitterAction*> EmitterActions; // 0x18(0x10)
};

