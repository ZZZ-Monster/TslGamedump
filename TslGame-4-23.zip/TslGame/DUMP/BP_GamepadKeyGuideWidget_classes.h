// WidgetBlueprintGeneratedClass BP_GamepadKeyGuideWidget.BP_GamepadKeyGuideWidget_C
// Size: 0x708 (Inherited: 0x698)
struct UBP_GamepadKeyGuideWidget_C : UTslGamepadKeyGuideWidget {
	struct UBP_GamepadKeyGuideTabSelectorCombo_C* BP_GamepadKeyGuideTabSelectorCombo; // 0x698(0x08)
	struct UBP_GamepadMultipleKeyIconWidget_C* BP_GamepadMultipleKeyIconWidget; // 0x6a0(0x08)
	struct UBP_GamepadMultipleKeyIconWidget_C* BP_GamepadMultipleKeyIconWidget_3; // 0x6a8(0x08)
	struct UBP_GamepadMultipleKeyIconWidget_C* BP_GamepadMultipleKeyIconWidget_4; // 0x6b0(0x08)
	struct UBP_GamepadMultipleKeyIconWidget_C* BP_GamepadMultipleKeyIconWidget_5; // 0x6b8(0x08)
	struct UBP_GamepadMultipleKeyIconWidget_C* CombinationKeyIconWidget; // 0x6c0(0x08)
	struct UInvalidationBox* InvalidationBox_5; // 0x6c8(0x08)
	struct UBP_GamepadKeyGuideKeyContents_C* KeyGuide; // 0x6d0(0x08)
	struct UBP_GamepadMultipleKeyIconWidget_C* NormalKeyIconWidget; // 0x6d8(0x08)
	struct USafeZone* SafeZone_1; // 0x6e0(0x08)
	struct UBP_GamepadKeyGuideTabSelectorWidget_C* TabSelector; // 0x6e8(0x08)
	struct UTextBlock* Title_Text; // 0x6f0(0x08)
	struct UWidgetSwitcher* WidgetSwitcher_1; // 0x6f8(0x08)
	struct UWidgetSwitcher* WidgetSwitcher_2; // 0x700(0x08)
};

