// WidgetBlueprintGeneratedClass BP_MapWayPointWidget.BP_MapWayPointWidget_C
// Size: 0x4a8 (Inherited: 0x480)
struct UBP_MapWayPointWidget_C : UMapWayPointBaseWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x480(0x08)
	struct UWidgetAnimation* WayPointEmerging; // 0x488(0x08)
	struct UImage* Circle; // 0x490(0x08)
	struct USizeBox* MapWayPointSizeBox; // 0x498(0x08)
	struct UWidgetSwitcher* TacticalSwitcher; // 0x4a0(0x08)

	void PreConstruct(bool IsDesignTime); // Function BP_MapWayPointWidget.BP_MapWayPointWidget_C.PreConstruct // BlueprintCosmetic|Event|Public|BlueprintEvent // @ game+0x33e45c
	void ExecuteUbergraph_BP_MapWayPointWidget(int32 EntryPoint); // Function BP_MapWayPointWidget.BP_MapWayPointWidget_C.ExecuteUbergraph_BP_MapWayPointWidget //  // @ game+0x33e45c
};

