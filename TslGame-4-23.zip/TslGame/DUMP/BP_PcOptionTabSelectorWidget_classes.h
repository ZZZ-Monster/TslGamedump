// WidgetBlueprintGeneratedClass BP_PcOptionTabSelectorWidget.BP_PcOptionTabSelectorWidget_C
// Size: 0x480 (Inherited: 0x458)
struct UBP_PcOptionTabSelectorWidget_C : UTslGameOptionTabSelectorWidget {
	struct UBP_GamepadKeyIconWidget_C* BP_GamepadKeyIconWidget; // 0x458(0x08)
	struct UBP_GamepadKeyIconWidget_C* BP_GamepadKeyIconWidget_1; // 0x460(0x08)
	struct UTslUniversalInputVisibilitySwitcher* GamepadLB; // 0x468(0x08)
	struct UTslUniversalInputVisibilitySwitcher* GamepadRB; // 0x470(0x08)
	struct UInvalidationBox* InvalidationBox_6; // 0x478(0x08)
};

