// Class ClothingSystemRuntimeInterface.ClothingAssetBase
// Size: 0x58 (Inherited: 0x38)
struct UClothingAssetBase : UObject {
	struct FString ImportedFilePath; // 0x38(0x10)
	struct FGuid AssetGuid; // 0x48(0x10)
};

// Class ClothingSystemRuntimeInterface.ClothingSimulationFactory
// Size: 0x38 (Inherited: 0x38)
struct UClothingSimulationFactory : UObject {
};

