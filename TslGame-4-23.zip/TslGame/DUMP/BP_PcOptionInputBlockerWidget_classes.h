// WidgetBlueprintGeneratedClass BP_PcOptionInputBlockerWidget.BP_PcOptionInputBlockerWidget_C
// Size: 0x478 (Inherited: 0x478)
struct UBP_PcOptionInputBlockerWidget_C : UTslGameOptionInputBlockerWidget {
};

