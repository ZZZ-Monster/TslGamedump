// WidgetBlueprintGeneratedClass BP_CompassPingWidget.BP_CompassPingWidget_C
// Size: 0x448 (Inherited: 0x448)
struct UBP_CompassPingWidget_C : UTslCompassMarkerWidget {
};

