// WidgetBlueprintGeneratedClass HitNotifyWidget.HitNotifyWidget_C
// Size: 0x514 (Inherited: 0x4d8)
struct UHitNotifyWidget_C : UTslHitNotifyWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4d8(0x08)
	struct UWidgetAnimation* FadeOut; // 0x4e0(0x08)
	struct UCanvasPanel* CanvasPanel; // 0x4e8(0x08)
	struct UImage* Image; // 0x4f0(0x08)
	struct UMaterialInstanceDynamic* MaskMaterialInstance; // 0x4f8(0x08)
	struct UAkAudioEvent* HitNotifyManSoundAk; // 0x500(0x08)
	struct UAkAudioEvent* HitNotifyWomanSoundAk; // 0x508(0x08)
	int32 BloodSpotCurrentIndex; // 0x510(0x04)

	void GetBloodSpotWidget(struct UUserWidget* Widget); // Function HitNotifyWidget.HitNotifyWidget_C.GetBloodSpotWidget // Public|HasOutParms|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void InitializeBloodSpotWidgets(); // Function HitNotifyWidget.HitNotifyWidget_C.InitializeBloodSpotWidgets // Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void InitializeKoreanRating(); // Function HitNotifyWidget.HitNotifyWidget_C.InitializeKoreanRating // Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void InitializeChineseLicensing(); // Function HitNotifyWidget.HitNotifyWidget_C.InitializeChineseLicensing // Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void DamagedPercentToDamage(float DamagedPercent, float Damage); // Function HitNotifyWidget.HitNotifyWidget_C.DamagedPercentToDamage // Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const // @ game+0x33e45c
	void GetPlayerHealthPercent(float HealthPercent); // Function HitNotifyWidget.HitNotifyWidget_C.GetPlayerHealthPercent // Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const // @ game+0x33e45c
	void PostAkEvent(struct UAkAudioEvent* AkEvent); // Function HitNotifyWidget.HitNotifyWidget_C.PostAkEvent // Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void SetRTPCValue(struct FString RTPC, float Value); // Function HitNotifyWidget.HitNotifyWidget_C.SetRTPCValue // Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void DamagedPercentToDamagePercent(float DamagedPercent, float DamagePercent); // Function HitNotifyWidget.HitNotifyWidget_C.DamagedPercentToDamagePercent // Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const // @ game+0x33e45c
	void PlayHitNotifySound(); // Function HitNotifyWidget.HitNotifyWidget_C.PlayHitNotifySound // Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void GetRandomScale(struct FVector2D Scale); // Function HitNotifyWidget.HitNotifyWidget_C.GetRandomScale // Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const // @ game+0x33e45c
	void GetRandomTranslation(struct FVector2D Translation); // Function HitNotifyWidget.HitNotifyWidget_C.GetRandomTranslation // Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const // @ game+0x33e45c
	void OnHitNotify_Temp(float DamagePercent, enum class EDamageTypeCategory DamageTypeCategory); // Function HitNotifyWidget.HitNotifyWidget_C.OnHitNotify_Temp // Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void Construct(); // Function HitNotifyWidget.HitNotifyWidget_C.Construct // BlueprintCosmetic|Event|Public|BlueprintEvent // @ game+0x33e45c
	void OnPlayBloodSpot(struct UUserWidget* Widget); // Function HitNotifyWidget.HitNotifyWidget_C.OnPlayBloodSpot // Event|Public|BlueprintEvent // @ game+0x33e45c
	void ExecuteUbergraph_HitNotifyWidget(int32 EntryPoint); // Function HitNotifyWidget.HitNotifyWidget_C.ExecuteUbergraph_HitNotifyWidget //  // @ game+0x33e45c
};

