// BlueprintGeneratedClass P_Footprint_Lava_BP.P_Footprint_Lava_BP_C
// Size: 0x4f0 (Inherited: 0x4f0)
struct AP_Footprint_Lava_BP_C : ATslParticle {
};

