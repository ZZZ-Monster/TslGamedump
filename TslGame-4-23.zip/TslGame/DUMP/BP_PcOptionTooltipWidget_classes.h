// WidgetBlueprintGeneratedClass BP_PcOptionTooltipWidget.BP_PcOptionTooltipWidget_C
// Size: 0x440 (Inherited: 0x440)
struct UBP_PcOptionTooltipWidget_C : UTslGameOptionTooltipWidget {
};

