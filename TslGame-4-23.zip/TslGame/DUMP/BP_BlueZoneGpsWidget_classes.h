// WidgetBlueprintGeneratedClass BP_BlueZoneGpsWidget.BP_BlueZoneGpsWidget_C
// Size: 0x6b8 (Inherited: 0x698)
struct UBP_BlueZoneGpsWidget_C : UBluezoneGpsBaseWidget {
	struct UWidgetAnimation* MovingAnimation; // 0x698(0x08)
	struct UWidgetAnimation* WidgetVanishing; // 0x6a0(0x08)
	struct UWidgetAnimation* WidgetEmerging; // 0x6a8(0x08)
	struct UInvalidationBox* InvalidationBox_Gauge; // 0x6b0(0x08)
};

