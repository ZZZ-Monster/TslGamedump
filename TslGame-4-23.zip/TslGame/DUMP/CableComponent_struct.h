// ScriptStruct CableComponent.CableCustomSocket
// Size: 0x10 (Inherited: 0x00)
struct FCableCustomSocket {
	int32 ParticleIndex; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct FName SocketName; // 0x08(0x08)
};

