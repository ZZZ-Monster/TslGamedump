// BlueprintGeneratedClass CameraShake_GrenadeDamage_Right.CameraShake_GrenadeDamage_Right_C
// Size: 0x170 (Inherited: 0x170)
struct UCameraShake_GrenadeDamage_Right_C : UCameraShake {
};

