// BlueprintGeneratedClass DmgType_Gun.DmgType_Gun_C
// Size: 0x100 (Inherited: 0x100)
struct UDmgType_Gun_C : UTslDamageType {
};

