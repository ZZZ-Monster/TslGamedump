// WidgetBlueprintGeneratedClass CarePackageInteractionWidget.CarePackageInteractionWidget_C
// Size: 0x4d0 (Inherited: 0x4c0)
struct UCarePackageInteractionWidget_C : UCarePackageInteractionWidget {
	struct UTextBlock* AdditionalMessage; // 0x4c0(0x08)
	struct UBP_GamepadKeyIconWidget_C* XHoldKeyIcon; // 0x4c8(0x08)

	void ShowCarePackageInteractionWidget(bool IsShow); // Function CarePackageInteractionWidget.CarePackageInteractionWidget_C.ShowCarePackageInteractionWidget // Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
};

