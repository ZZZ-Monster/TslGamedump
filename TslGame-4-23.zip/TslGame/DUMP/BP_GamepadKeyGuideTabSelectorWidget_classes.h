// WidgetBlueprintGeneratedClass BP_GamepadKeyGuideTabSelectorWidget.BP_GamepadKeyGuideTabSelectorWidget_C
// Size: 0x4b0 (Inherited: 0x478)
struct UBP_GamepadKeyGuideTabSelectorWidget_C : UTslTabSelectorWidget {
	struct UBP_GamepadKeyIconWidget_C* BP_GamepadKeyIconWidget; // 0x478(0x08)
	struct UBP_GamepadKeyIconWidget_C* BP_GamepadKeyIconWidget_1; // 0x480(0x08)
	struct UBP_GamepadOptionTabWidget_C* Tab0; // 0x488(0x08)
	struct UBP_GamepadOptionTabWidget_C* Tab1; // 0x490(0x08)
	struct UBP_GamepadOptionTabWidget_C* Tab2; // 0x498(0x08)
	struct UBP_GamepadOptionTabWidget_C* Tab3; // 0x4a0(0x08)
	struct UHorizontalBox* TabHorizontalBox; // 0x4a8(0x08)
};

