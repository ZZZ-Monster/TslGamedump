// Class MaterialShaderQualitySettings.MaterialShaderQualitySettings
// Size: 0x88 (Inherited: 0x38)
struct UMaterialShaderQualitySettings : UObject {
	struct TMap<struct FName, struct UShaderPlatformQualitySettings*> ForwardSettingMap; // 0x38(0x50)
};

// Class MaterialShaderQualitySettings.ShaderPlatformQualitySettings
// Size: 0x50 (Inherited: 0x38)
struct UShaderPlatformQualitySettings : UObject {
	struct FMaterialQualityOverrides QualityOverrides[0x03]; // 0x38(0x12)
	char pad_4A[0x6]; // 0x4a(0x06)
};

