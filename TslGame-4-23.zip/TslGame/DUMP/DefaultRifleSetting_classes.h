// BlueprintGeneratedClass DefaultRifleSetting.DefaultRifleSetting_C
// Size: 0x1080 (Inherited: 0x1080)
struct ADefaultRifleSetting_C : ATslWeapon_Trajectory {
};

