// WidgetBlueprintGeneratedClass KeyGuideContentBP.KeyGuideContentBP_C
// Size: 0x4a8 (Inherited: 0x488)
struct UKeyGuideContentBP_C : UTslKeyGuideContentWidget {
	struct UKeyImageWIdgetBP_C* KeyImageWIdgetBP_1; // 0x488(0x08)
	struct UKeyImageWIdgetBP_C* KeyImageWIdgetBP_2; // 0x490(0x08)
	struct UKeyImageWIdgetBP_C* KeyImageWIdgetBP_3; // 0x498(0x08)
	struct UKeyImageWIdgetBP_C* KeyImageWIdgetBP_4; // 0x4a0(0x08)
};

