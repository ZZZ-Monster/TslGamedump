// BlueprintGeneratedClass GunImpact_Med.GunImpact_Med_C
// Size: 0x11e8 (Inherited: 0x11e0)
struct AGunImpact_Med_C : ATslGunImpact {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x11e0(0x08)

	void UserConstructionScript(); // Function GunImpact_Med.GunImpact_Med_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void ExecuteUbergraph_GunImpact_Med(int32 EntryPoint); // Function GunImpact_Med.GunImpact_Med_C.ExecuteUbergraph_GunImpact_Med //  // @ game+0x33e45c
};

