// Class CoreUObject.Object
// Size: 0x38 (Inherited: 0x00)
struct UObject {
	char pad_0[0x38]; // 0x00(0x38)

	void ExecuteUbergraph(int32 EntryPoint); // Function CoreUObject.Object.ExecuteUbergraph // Event|Public|BlueprintEvent // @ game+0x33e45c
};

// Class CoreUObject.Interface
// Size: 0x38 (Inherited: 0x38)
struct UInterface : UObject {
};

// Class CoreUObject.GCObjectReferencer
// Size: 0x70 (Inherited: 0x38)
struct UGCObjectReferencer : UObject {
	char pad_38[0x38]; // 0x38(0x38)
};

// Class CoreUObject.TextBuffer
// Size: 0x60 (Inherited: 0x38)
struct UTextBuffer : UObject {
	char pad_38[0x28]; // 0x38(0x28)
};

// Class CoreUObject.Field
// Size: 0x40 (Inherited: 0x38)
struct UField : UObject {
	char pad_38[0x8]; // 0x38(0x08)
};

// Class CoreUObject.Struct
// Size: 0x110 (Inherited: 0x40)
struct UStruct : UField {
	char pad_40[0xd0]; // 0x40(0xd0)
};

// Class CoreUObject.ScriptStruct
// Size: 0x120 (Inherited: 0x110)
struct UScriptStruct : UStruct {
	char pad_110[0x10]; // 0x110(0x10)
};

// Class CoreUObject.Package
// Size: 0x160 (Inherited: 0x38)
struct UPackage : UObject {
	char pad_38[0x128]; // 0x38(0x128)
};

// Class CoreUObject.Class
// Size: 0x2e8 (Inherited: 0x110)
struct UClass : UStruct {
	char pad_110[0x1d8]; // 0x110(0x1d8)
};

// Class CoreUObject.Function
// Size: 0x160 (Inherited: 0x110)
struct UFunction : UStruct {
	char pad_110[0x50]; // 0x110(0x50)
};

// Class CoreUObject.DelegateFunction
// Size: 0x160 (Inherited: 0x160)
struct UDelegateFunction : UFunction {
};

// Class CoreUObject.DynamicClass
// Size: 0x350 (Inherited: 0x2e8)
struct UDynamicClass : UClass {
	char pad_2E8[0x68]; // 0x2e8(0x68)
};

// Class CoreUObject.PackageMap
// Size: 0xf0 (Inherited: 0x38)
struct UPackageMap : UObject {
	char pad_38[0xb8]; // 0x38(0xb8)
};

// Class CoreUObject.Enum
// Size: 0x80 (Inherited: 0x40)
struct UEnum : UField {
	char pad_40[0x40]; // 0x40(0x40)
};

// Class CoreUObject.Property
// Size: 0x88 (Inherited: 0x40)
struct UProperty : UField {
	char pad_40[0x48]; // 0x40(0x48)
};

// Class CoreUObject.EnumProperty
// Size: 0x98 (Inherited: 0x88)
struct UEnumProperty : UProperty {
	char pad_88[0x10]; // 0x88(0x10)
};

// Class CoreUObject.LinkerPlaceholderClass
// Size: 0x488 (Inherited: 0x2e8)
struct ULinkerPlaceholderClass : UClass {
	char pad_2E8[0x1a0]; // 0x2e8(0x1a0)
};

// Class CoreUObject.LinkerPlaceholderExportObject
// Size: 0xe8 (Inherited: 0x38)
struct ULinkerPlaceholderExportObject : UObject {
	char pad_38[0xb0]; // 0x38(0xb0)
};

// Class CoreUObject.LinkerPlaceholderFunction
// Size: 0x300 (Inherited: 0x160)
struct ULinkerPlaceholderFunction : UFunction {
	char pad_160[0x1a0]; // 0x160(0x1a0)
};

// Class CoreUObject.MetaData
// Size: 0xd8 (Inherited: 0x38)
struct UMetaData : UObject {
	char pad_38[0xa0]; // 0x38(0xa0)
};

// Class CoreUObject.ObjectRedirector
// Size: 0x40 (Inherited: 0x38)
struct UObjectRedirector : UObject {
	char pad_38[0x8]; // 0x38(0x08)
};

// Class CoreUObject.ArrayProperty
// Size: 0x90 (Inherited: 0x88)
struct UArrayProperty : UProperty {
	char pad_88[0x8]; // 0x88(0x08)
};

// Class CoreUObject.ObjectPropertyBase
// Size: 0x90 (Inherited: 0x88)
struct UObjectPropertyBase : UProperty {
	char pad_88[0x8]; // 0x88(0x08)
};

// Class CoreUObject.AssetObjectProperty
// Size: 0x90 (Inherited: 0x90)
struct UAssetObjectProperty : UObjectPropertyBase {
};

// Class CoreUObject.AssetClassProperty
// Size: 0x98 (Inherited: 0x90)
struct UAssetClassProperty : UAssetObjectProperty {
	char pad_90[0x8]; // 0x90(0x08)
};

// Class CoreUObject.BoolProperty
// Size: 0x90 (Inherited: 0x88)
struct UBoolProperty : UProperty {
	char pad_88[0x8]; // 0x88(0x08)
};

// Class CoreUObject.NumericProperty
// Size: 0x88 (Inherited: 0x88)
struct UNumericProperty : UProperty {
};

// Class CoreUObject.ByteProperty
// Size: 0x90 (Inherited: 0x88)
struct UByteProperty : UNumericProperty {
	char pad_88[0x8]; // 0x88(0x08)
};

// Class CoreUObject.ObjectProperty
// Size: 0x90 (Inherited: 0x90)
struct UObjectProperty : UObjectPropertyBase {
};

// Class CoreUObject.ClassProperty
// Size: 0x98 (Inherited: 0x90)
struct UClassProperty : UObjectProperty {
	char pad_90[0x8]; // 0x90(0x08)
};

// Class CoreUObject.DelegateProperty
// Size: 0x90 (Inherited: 0x88)
struct UDelegateProperty : UProperty {
	char pad_88[0x8]; // 0x88(0x08)
};

// Class CoreUObject.DoubleProperty
// Size: 0x88 (Inherited: 0x88)
struct UDoubleProperty : UNumericProperty {
};

// Class CoreUObject.FloatProperty
// Size: 0x88 (Inherited: 0x88)
struct UFloatProperty : UNumericProperty {
};

// Class CoreUObject.IntProperty
// Size: 0x88 (Inherited: 0x88)
struct UIntProperty : UNumericProperty {
};

// Class CoreUObject.Int16Property
// Size: 0x88 (Inherited: 0x88)
struct UInt16Property : UNumericProperty {
};

// Class CoreUObject.Int64Property
// Size: 0x88 (Inherited: 0x88)
struct UInt64Property : UNumericProperty {
};

// Class CoreUObject.Int8Property
// Size: 0x88 (Inherited: 0x88)
struct UInt8Property : UNumericProperty {
};

// Class CoreUObject.InterfaceProperty
// Size: 0x90 (Inherited: 0x88)
struct UInterfaceProperty : UProperty {
	char pad_88[0x8]; // 0x88(0x08)
};

// Class CoreUObject.LazyObjectProperty
// Size: 0x90 (Inherited: 0x90)
struct ULazyObjectProperty : UObjectPropertyBase {
};

// Class CoreUObject.MapProperty
// Size: 0xc0 (Inherited: 0x88)
struct UMapProperty : UProperty {
	char pad_88[0x38]; // 0x88(0x38)
};

// Class CoreUObject.MulticastDelegateProperty
// Size: 0x90 (Inherited: 0x88)
struct UMulticastDelegateProperty : UProperty {
	char pad_88[0x8]; // 0x88(0x08)
};

// Class CoreUObject.NameProperty
// Size: 0x88 (Inherited: 0x88)
struct UNameProperty : UProperty {
};

// Class CoreUObject.EncryptedObjectProperty
// Size: 0x90 (Inherited: 0x90)
struct UEncryptedObjectProperty : UObjectPropertyBase {
};

// Class CoreUObject.SetProperty
// Size: 0xb0 (Inherited: 0x88)
struct USetProperty : UProperty {
	char pad_88[0x28]; // 0x88(0x28)
};

// Class CoreUObject.StrProperty
// Size: 0x88 (Inherited: 0x88)
struct UStrProperty : UProperty {
};

// Class CoreUObject.StructProperty
// Size: 0x90 (Inherited: 0x88)
struct UStructProperty : UProperty {
	char pad_88[0x8]; // 0x88(0x08)
};

// Class CoreUObject.UInt16Property
// Size: 0x88 (Inherited: 0x88)
struct UUInt16Property : UNumericProperty {
};

// Class CoreUObject.UInt32Property
// Size: 0x88 (Inherited: 0x88)
struct UUInt32Property : UNumericProperty {
};

// Class CoreUObject.UInt64Property
// Size: 0x88 (Inherited: 0x88)
struct UUInt64Property : UNumericProperty {
};

// Class CoreUObject.WeakObjectProperty
// Size: 0x90 (Inherited: 0x90)
struct UWeakObjectProperty : UObjectPropertyBase {
};

// Class CoreUObject.TextProperty
// Size: 0x88 (Inherited: 0x88)
struct UTextProperty : UProperty {
};

