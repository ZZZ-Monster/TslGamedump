// BlueprintGeneratedClass BP_UnderwaterBulletTrailEffectShort.BP_UnderwaterBulletTrailEffectShort_C
// Size: 0x510 (Inherited: 0x510)
struct ABP_UnderwaterBulletTrailEffectShort_C : ATslParticleBulletTrail {
};

