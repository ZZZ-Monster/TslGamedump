// Class CoherentRenderingPlugin.CoherentRenderingSettings
// Size: 0x50 (Inherited: 0x38)
struct UCoherentRenderingSettings : UObject {
	enum class ECoherentRenderingSettingsSeverity RenderingLogSeverity; // 0x38(0x01)
	bool ShowWarningsOnScreen; // 0x39(0x01)
	char pad_3A[0x6]; // 0x3a(0x06)
	struct FString DeveloperOptions; // 0x40(0x10)
};

// Class CoherentRenderingPlugin.CohTextureUserWrapData
// Size: 0x88 (Inherited: 0x38)
struct UCohTextureUserWrapData : UObject {
	char pad_38[0x48]; // 0x38(0x48)
	struct UTexture* Texture; // 0x80(0x08)
};

