// WidgetBlueprintGeneratedClass BP_RankEmblemWidget.BP_RankEmblemWidget_C
// Size: 0x4f8 (Inherited: 0x4f0)
struct UBP_RankEmblemWidget_C : UTslRankEmblemWidget {
	struct UImage* EmblemImage; // 0x4f0(0x08)
};

