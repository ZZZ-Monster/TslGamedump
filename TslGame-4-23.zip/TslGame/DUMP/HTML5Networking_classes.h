// Class HTML5Networking.WebSocketConnection
// Size: 0x65858 (Inherited: 0x65848)
struct UWebSocketConnection : UNetConnection {
	char pad_65848[0x10]; // 0x65848(0x10)
};

// Class HTML5Networking.WebSocketNetDriver
// Size: 0x4e0 (Inherited: 0x4d0)
struct UWebSocketNetDriver : UNetDriver {
	int32 WebSocketPort; // 0x4d0(0x04)
	char pad_4D4[0xc]; // 0x4d4(0x0c)
};

