// BlueprintGeneratedClass LobbyHUD_Default.LobbyHUD_Default_C
// Size: 0x18e8 (Inherited: 0x1890)
struct ALobbyHUD_Default_C : ALobbyHUD {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x1890(0x08)
	struct ABP_MasteryPose_C* PoseActor; // 0x1898(0x08)
	struct UDataTable* MasteryPoseData; // 0x18a0(0x08)
	struct FString DefaultPose; // 0x18a8(0x10)
	struct FString CurrentPose; // 0x18b8(0x10)
	struct FString InputPose; // 0x18c8(0x10)
	float PoseDelayTime; // 0x18d8(0x04)
	char pad_18DC[0x4]; // 0x18dc(0x04)
	struct ALobbyCharacter* CurrentCharacter; // 0x18e0(0x08)

	void ChangeScene(struct FString PoseId); // Function LobbyHUD_Default.LobbyHUD_Default_C.ChangeScene // Public|HasDefaults|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void ShowPoseActor(struct FString SourceString, struct TArray<struct FString> SkinIDs); // Function LobbyHUD_Default.LobbyHUD_Default_C.ShowPoseActor // Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void DestroyPoseActor(); // Function LobbyHUD_Default.LobbyHUD_Default_C.DestroyPoseActor // Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void UserConstructionScript(); // Function LobbyHUD_Default.LobbyHUD_Default_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void HideMasteryPose(); // Function LobbyHUD_Default.LobbyHUD_Default_C.HideMasteryPose // Event|Public|BlueprintEvent // @ game+0x33e45c
	void ShowMasteryPose(struct FString PoseId, struct TArray<struct FString> ItemIds); // Function LobbyHUD_Default.LobbyHUD_Default_C.ShowMasteryPose // Event|Public|HasOutParms|BlueprintEvent // @ game+0x33e45c
	void ReceivePostBeginPlay(); // Function LobbyHUD_Default.LobbyHUD_Default_C.ReceivePostBeginPlay // Event|Public|BlueprintEvent // @ game+0x33e45c
	void ExecuteUbergraph_LobbyHUD_Default(int32 EntryPoint); // Function LobbyHUD_Default.LobbyHUD_Default_C.ExecuteUbergraph_LobbyHUD_Default //  // @ game+0x33e45c
};

