// BlueprintGeneratedClass LobbyCharacterMale_v2.LobbyCharacterMale_v2_C
// Size: 0xbd0 (Inherited: 0xbd0)
struct ALobbyCharacterMale_v2_C : ALobbyCharacterBase_v2_C {
};

