// WidgetBlueprintGeneratedClass DetailReportCauseManagerWidget.DetailReportCauseManagerWidget_C
// Size: 0x478 (Inherited: 0x470)
struct UDetailReportCauseManagerWidget_C : UTslDetailReportCauseMgrWidget {
	struct UVerticalBox* ListBorder; // 0x470(0x08)
};

