// BlueprintGeneratedClass BP_ShellEvent_DMR.BP_ShellEvent_DMR_C
// Size: 0x98 (Inherited: 0x98)
struct UBP_ShellEvent_DMR_C : UTslParticleModuleEventSendToGame {
};

