// BlueprintGeneratedClass P_BreathStaying_BP.P_BreathStaying_BP_C
// Size: 0x4f0 (Inherited: 0x4f0)
struct AP_BreathStaying_BP_C : ATslParticle {
};

