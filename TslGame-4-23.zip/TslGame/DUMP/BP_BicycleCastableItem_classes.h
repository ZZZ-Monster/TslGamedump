// BlueprintGeneratedClass BP_BicycleCastableItem.BP_BicycleCastableItem_C
// Size: 0xa8 (Inherited: 0xa8)
struct UBP_BicycleCastableItem_C : UBicycleCastableItemImplement {
};

