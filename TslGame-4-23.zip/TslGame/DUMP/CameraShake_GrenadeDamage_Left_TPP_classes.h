// BlueprintGeneratedClass CameraShake_GrenadeDamage_Left_TPP.CameraShake_GrenadeDamage_Left_TPP_C
// Size: 0x170 (Inherited: 0x170)
struct UCameraShake_GrenadeDamage_Left_TPP_C : UCameraShake {
};

