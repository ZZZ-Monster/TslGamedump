// Class GameplayTasks.GameplayTasksComponent
// Size: 0x270 (Inherited: 0x200)
struct UGameplayTasksComponent : UActorComponent {
	char pad_200[0x8]; // 0x200(0x08)
	struct TArray<struct UGameplayTask*> SimulatedTasks; // 0x208(0x10)
	struct TArray<struct UGameplayTask*> TaskPriorityQueue; // 0x218(0x10)
	char pad_228[0x10]; // 0x228(0x10)
	struct TArray<struct UGameplayTask*> TickingTasks; // 0x238(0x10)
	char pad_248[0x8]; // 0x248(0x08)
	struct FMulticastDelegate OnClaimedResourcesChange; // 0x250(0x10)
	char pad_260[0x10]; // 0x260(0x10)

	void OnRep_SimulatedTasks(); // Function GameplayTasks.GameplayTasksComponent.OnRep_SimulatedTasks // Final|Native|Public // @ game+0x541541c
	enum class EGameplayTaskRunResult K2_RunGameplayTask(TScriptInterface<struct UGameplayTaskOwnerInterface> TaskOwner, struct UGameplayTask* Task, bool Priority, struct TArray<struct UClass*> AdditionalRequiredResources, struct TArray<struct UClass*> AdditionalClaimedResources); // Function GameplayTasks.GameplayTasksComponent.K2_RunGameplayTask // Final|Native|Static|Public|BlueprintCallable // @ game+0x5415160
};

// Class GameplayTasks.GameplayTask
// Size: 0x78 (Inherited: 0x38)
struct UGameplayTask : UObject {
	char pad_38[0x8]; // 0x38(0x08)
	struct FName InstanceName; // 0x40(0x08)
	char pad_48[0x2]; // 0x48(0x02)
	enum class ETaskResourceOverlapPolicy ResourceOverlapPolicy; // 0x4a(0x01)
	char pad_4B[0x25]; // 0x4b(0x25)
	struct UGameplayTask* ChildTask; // 0x70(0x08)

	void ReadyForActivation(); // Function GameplayTasks.GameplayTask.ReadyForActivation // Final|Native|Public|BlueprintCallable // @ game+0x5415430
	void GenericGameplayTaskDelegate__DelegateSignature(); // DelegateFunction GameplayTasks.GameplayTask.GenericGameplayTaskDelegate__DelegateSignature // MulticastDelegate|Public|Delegate // @ game+0x33e45c
	void EndTask(); // Function GameplayTasks.GameplayTask.EndTask // Final|Native|Public|BlueprintCallable // @ game+0x541506c
};

// Class GameplayTasks.GameplayTaskOwnerInterface
// Size: 0x38 (Inherited: 0x38)
struct UGameplayTaskOwnerInterface : UInterface {
};

// Class GameplayTasks.GameplayTaskResource
// Size: 0x48 (Inherited: 0x38)
struct UGameplayTaskResource : UObject {
	int32 ManualResourceID; // 0x38(0x04)
	int8 AutoResourceID; // 0x3c(0x01)
	char pad_3D[0x3]; // 0x3d(0x03)
	char bManuallySetID : 1; // 0x40(0x01)
	char pad_40_1 : 7; // 0x40(0x01)
	char pad_41[0x7]; // 0x41(0x07)
};

// Class GameplayTasks.GameplayTask_ClaimResource
// Size: 0x78 (Inherited: 0x78)
struct UGameplayTask_ClaimResource : UGameplayTask {

	struct UGameplayTask_ClaimResource* ClaimResources(TScriptInterface<struct UGameplayTaskOwnerInterface> InTaskOwner, struct TArray<struct UClass*> ResourceClasses, bool Priority, struct FName TaskInstanceName); // Function GameplayTasks.GameplayTask_ClaimResource.ClaimResources // Final|Native|Static|Public|BlueprintCallable // @ game+0x5414e20
	struct UGameplayTask_ClaimResource* ClaimResource(TScriptInterface<struct UGameplayTaskOwnerInterface> InTaskOwner, struct UClass* ResourceClass, bool Priority, struct FName TaskInstanceName); // Function GameplayTasks.GameplayTask_ClaimResource.ClaimResource // Final|Native|Static|Public|BlueprintCallable // @ game+0x5414c84
};

// Class GameplayTasks.GameplayTask_SpawnActor
// Size: 0xb8 (Inherited: 0x78)
struct UGameplayTask_SpawnActor : UGameplayTask {
	struct FMulticastDelegate SUCCESS; // 0x78(0x10)
	struct FMulticastDelegate DidNotSpawn; // 0x88(0x10)
	char pad_98[0x18]; // 0x98(0x18)
	struct UClass* ClassToSpawn; // 0xb0(0x08)

	struct UGameplayTask_SpawnActor* SpawnActor(TScriptInterface<struct UGameplayTaskOwnerInterface> TaskOwner, struct FVector SpawnLocation, struct FRotator SpawnRotation, struct UClass* Class, bool bSpawnOnlyOnAuthority); // Function GameplayTasks.GameplayTask_SpawnActor.SpawnActor // Final|Native|Static|Public|HasDefaults|BlueprintCallable // @ game+0x5415444
	void FinishSpawningActor(struct UObject* WorldContextObject, struct AActor* SpawnedActor); // Function GameplayTasks.GameplayTask_SpawnActor.FinishSpawningActor // Native|Public|BlueprintCallable // @ game+0x5415080
	bool BeginSpawningActor(struct UObject* WorldContextObject, struct AActor* SpawnedActor); // Function GameplayTasks.GameplayTask_SpawnActor.BeginSpawningActor // Native|Public|HasOutParms|BlueprintCallable // @ game+0x5414b88
};

// Class GameplayTasks.GameplayTask_TimeLimitedExecution
// Size: 0xa8 (Inherited: 0x78)
struct UGameplayTask_TimeLimitedExecution : UGameplayTask {
	struct FMulticastDelegate OnFinished; // 0x78(0x10)
	struct FMulticastDelegate OnTimeExpired; // 0x88(0x10)
	char pad_98[0x10]; // 0x98(0x10)

	void TaskFinishDelegate__DelegateSignature(); // DelegateFunction GameplayTasks.GameplayTask_TimeLimitedExecution.TaskFinishDelegate__DelegateSignature // MulticastDelegate|Public|Delegate // @ game+0x33e45c
};

// Class GameplayTasks.GameplayTask_WaitDelay
// Size: 0x90 (Inherited: 0x78)
struct UGameplayTask_WaitDelay : UGameplayTask {
	struct FMulticastDelegate OnFinish; // 0x78(0x10)
	char pad_88[0x8]; // 0x88(0x08)

	struct UGameplayTask_WaitDelay* TaskWaitDelay(TScriptInterface<struct UGameplayTaskOwnerInterface> TaskOwner, float Time, bool Priority); // Function GameplayTasks.GameplayTask_WaitDelay.TaskWaitDelay // Final|Native|Static|Public|BlueprintCallable // @ game+0x5415644
	void TaskDelayDelegate__DelegateSignature(); // DelegateFunction GameplayTasks.GameplayTask_WaitDelay.TaskDelayDelegate__DelegateSignature // MulticastDelegate|Public|Delegate // @ game+0x33e45c
};

