// WidgetBlueprintGeneratedClass CarePackgeItemListWidget.CarePackgeItemListWidget_C
// Size: 0x518 (Inherited: 0x510)
struct UCarePackgeItemListWidget_C : UCarePackageItemListWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x510(0x08)

	void Construct(); // Function CarePackgeItemListWidget.CarePackgeItemListWidget_C.Construct // BlueprintCosmetic|Event|Public|BlueprintEvent // @ game+0x33e45c
	void ExecuteUbergraph_CarePackgeItemListWidget(int32 EntryPoint); // Function CarePackgeItemListWidget.CarePackgeItemListWidget_C.ExecuteUbergraph_CarePackgeItemListWidget //  // @ game+0x33e45c
};

