// BlueprintGeneratedClass CS_AntiLeanLeft.CS_AntiLeanLeft_C
// Size: 0x170 (Inherited: 0x170)
struct UCS_AntiLeanLeft_C : UCameraShake {
};

