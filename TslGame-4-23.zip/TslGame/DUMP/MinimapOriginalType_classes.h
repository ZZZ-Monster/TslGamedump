// WidgetBlueprintGeneratedClass MinimapOriginalType.MinimapOriginalType_C
// Size: 0x600 (Inherited: 0x5d8)
struct UMinimapOriginalType_C : UMinimapCanvasWidget {
	struct UWidgetSwitcher* BluezoneInfoSwitcher; // 0x5d8(0x08)
	struct UBP_FlaregunUiWidget_C* BP_FlaregunUiWidget; // 0x5e0(0x08)
	struct UBP_MiniMapWidget_C* Minimap; // 0x5e8(0x08)
	struct URetainerBox* Minimap_RetainerBox; // 0x5f0(0x08)
	struct USafeZone* SafeZone_1; // 0x5f8(0x08)
};

