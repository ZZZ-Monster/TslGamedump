// Class GeometryCache.GeometryCache
// Size: 0x70 (Inherited: 0x38)
struct UGeometryCache : UObject {
	char pad_38[0x8]; // 0x38(0x08)
	struct TArray<struct UMaterialInterface*> Materials; // 0x40(0x10)
	struct TArray<struct UGeometryCacheTrack*> Tracks; // 0x50(0x10)
	char pad_60[0x10]; // 0x60(0x10)
};

// Class GeometryCache.GeometryCacheActor
// Size: 0x3f8 (Inherited: 0x3f0)
struct AGeometryCacheActor : AActor {
	struct UGeometryCacheComponent* GeometryCacheComponent; // 0x3f0(0x08)

	struct UGeometryCacheComponent* GetGeometryCacheComponent(); // Function GeometryCache.GeometryCacheActor.GetGeometryCacheComponent // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x4d8dc30
};

// Class GeometryCache.GeometryCacheComponent
// Size: 0xb50 (Inherited: 0xae0)
struct UGeometryCacheComponent : UMeshComponent {
	struct UGeometryCache* GeometryCache; // 0xad8(0x08)
	bool bRunning; // 0xae0(0x01)
	bool bLooping; // 0xae1(0x01)
	float StartTimeOffset; // 0xae4(0x04)
	float PlaybackSpeed; // 0xae8(0x04)
	int32 NumTracks; // 0xaec(0x04)
	float ElapsedTime; // 0xaf0(0x04)
	char pad_AFA[0x56]; // 0xafa(0x56)

	void Stop(); // Function GeometryCache.GeometryCacheComponent.Stop // Final|Native|Public|BlueprintCallable // @ game+0x549ad5c
	void SetStartTimeOffset(float NewStartTimeOffset); // Function GeometryCache.GeometryCacheComponent.SetStartTimeOffset // Final|Native|Public|BlueprintCallable // @ game+0x549acc4
	void SetPlaybackSpeed(float NewPlaybackSpeed); // Function GeometryCache.GeometryCacheComponent.SetPlaybackSpeed // Final|Native|Public|BlueprintCallable // @ game+0x549ac14
	void SetLooping(bool bNewLooping); // Function GeometryCache.GeometryCacheComponent.SetLooping // Final|Native|Public|BlueprintCallable // @ game+0x549aa90
	bool SetGeometryCache(struct UGeometryCache* NewGeomCache); // Function GeometryCache.GeometryCacheComponent.SetGeometryCache // Native|Public|BlueprintCallable // @ game+0x549a9e8
	void PlayReversedFromEnd(); // Function GeometryCache.GeometryCacheComponent.PlayReversedFromEnd // Final|Native|Public|BlueprintCallable // @ game+0x549a9bc
	void PlayReversed(); // Function GeometryCache.GeometryCacheComponent.PlayReversed // Final|Native|Public|BlueprintCallable // @ game+0x549a99c
	void PlayFromStart(); // Function GeometryCache.GeometryCacheComponent.PlayFromStart // Final|Native|Public|BlueprintCallable // @ game+0x549a974
	void Play(); // Function GeometryCache.GeometryCacheComponent.Play // Final|Native|Public|BlueprintCallable // @ game+0x549a954
	void Pause(); // Function GeometryCache.GeometryCacheComponent.Pause // Final|Native|Public|BlueprintCallable // @ game+0x549a934
	bool IsPlayingReversed(); // Function GeometryCache.GeometryCacheComponent.IsPlayingReversed // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x549a900
	bool IsPlaying(); // Function GeometryCache.GeometryCacheComponent.IsPlaying // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x549a8e8
	bool IsLooping(); // Function GeometryCache.GeometryCacheComponent.IsLooping // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x549a8d0
	float GetStartTimeOffset(); // Function GeometryCache.GeometryCacheComponent.GetStartTimeOffset // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x549a8b8
	float GetPlaybackSpeed(); // Function GeometryCache.GeometryCacheComponent.GetPlaybackSpeed // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x549a884
};

// Class GeometryCache.GeometryCacheTrack
// Size: 0x60 (Inherited: 0x38)
struct UGeometryCacheTrack : UObject {
	char pad_38[0x28]; // 0x38(0x28)
};

// Class GeometryCache.GeometryCacheTrack_FlipbookAnimation
// Size: 0x88 (Inherited: 0x60)
struct UGeometryCacheTrack_FlipbookAnimation : UGeometryCacheTrack {
	uint32 NumMeshSamples; // 0x60(0x04)
	char pad_64[0x24]; // 0x64(0x24)

	void AddMeshSample(struct FGeometryCacheMeshData MeshData, float SampleTime); // Function GeometryCache.GeometryCacheTrack_FlipbookAnimation.AddMeshSample // Final|Native|Public|HasOutParms // @ game+0x549a748
};

// Class GeometryCache.GeometryCacheTrack_TransformAnimation
// Size: 0xb0 (Inherited: 0x60)
struct UGeometryCacheTrack_TransformAnimation : UGeometryCacheTrack {
	char pad_60[0x50]; // 0x60(0x50)

	void SetMesh(struct FGeometryCacheMeshData NewMeshData); // Function GeometryCache.GeometryCacheTrack_TransformAnimation.SetMesh // Final|Native|Public|HasOutParms // @ game+0x549ab20
};

// Class GeometryCache.GeometryCacheTrack_TransformGroupAnimation
// Size: 0xb0 (Inherited: 0x60)
struct UGeometryCacheTrack_TransformGroupAnimation : UGeometryCacheTrack {
	char pad_60[0x50]; // 0x60(0x50)

	void SetMesh(struct FGeometryCacheMeshData NewMeshData); // Function GeometryCache.GeometryCacheTrack_TransformGroupAnimation.SetMesh // Final|Native|Public|HasOutParms // @ game+0x549ab20
};

