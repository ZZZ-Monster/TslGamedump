// WidgetBlueprintGeneratedClass BP_PcOptionKeyBinderSlotWidget.BP_PcOptionKeyBinderSlotWidget_C
// Size: 0x548 (Inherited: 0x548)
struct UBP_PcOptionKeyBinderSlotWidget_C : UTslGameOptionItemKeyBinderSlotWidget {
};

