// WidgetBlueprintGeneratedClass MapPlayerStartWidgetBP.MapPlayerStartWidgetBP_C
// Size: 0x638 (Inherited: 0x638)
struct UMapPlayerStartWidgetBP_C : UMapPlayerStartWidget {
};

