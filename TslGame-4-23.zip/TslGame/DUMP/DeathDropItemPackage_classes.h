// BlueprintGeneratedClass DeathDropItemPackage.DeathDropItemPackage_C
// Size: 0x600 (Inherited: 0x5f8)
struct ADeathDropItemPackage_C : AFloorSnapItemPackage {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x5f8(0x08)

	struct FText GetCategory(); // Function DeathDropItemPackage.DeathDropItemPackage_C.GetCategory // Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void UserConstructionScript(); // Function DeathDropItemPackage.DeathDropItemPackage_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void ReceiveBeginPlay(); // Function DeathDropItemPackage.DeathDropItemPackage_C.ReceiveBeginPlay // Event|Protected|BlueprintEvent // @ game+0x33e45c
	void ExecuteUbergraph_DeathDropItemPackage(int32 EntryPoint); // Function DeathDropItemPackage.DeathDropItemPackage_C.ExecuteUbergraph_DeathDropItemPackage // HasDefaults // @ game+0x33e45c
};

