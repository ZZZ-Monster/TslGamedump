// WidgetBlueprintGeneratedClass BP_GamepadReportStepperBigWidget.BP_GamepadReportStepperBigWidget_C
// Size: 0x6c8 (Inherited: 0x690)
struct UBP_GamepadReportStepperBigWidget_C : UTslGamepadStepperWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x690(0x08)
	struct UBorder* Border_5; // 0x698(0x08)
	struct UButton* LeftArrow; // 0x6a0(0x08)
	struct UButton* RightArrow; // 0x6a8(0x08)
	struct UBP_StepperCounterWidget_C* StepperCounter; // 0x6b0(0x08)
	struct UTextBlock* StepperTextBox; // 0x6b8(0x08)
	struct UTextBlock* TitleTextBox; // 0x6c0(0x08)

	void UpdateDesign_Normal(); // Function BP_GamepadReportStepperBigWidget.BP_GamepadReportStepperBigWidget_C.UpdateDesign_Normal // Event|Public|BlueprintEvent // @ game+0x33e45c
	void UpdateDesign_Focused(); // Function BP_GamepadReportStepperBigWidget.BP_GamepadReportStepperBigWidget_C.UpdateDesign_Focused // Event|Public|BlueprintEvent // @ game+0x33e45c
	void ExecuteUbergraph_BP_GamepadReportStepperBigWidget(int32 EntryPoint); // Function BP_GamepadReportStepperBigWidget.BP_GamepadReportStepperBigWidget_C.ExecuteUbergraph_BP_GamepadReportStepperBigWidget // HasDefaults // @ game+0x33e45c
};

