// WidgetBlueprintGeneratedClass MapCaptureAreaWidgetBP.MapCaptureAreaWidgetBP_C
// Size: 0x6f8 (Inherited: 0x6f0)
struct UMapCaptureAreaWidgetBP_C : UMapCaptureAreaWidget {
	struct UImage* CircleImage; // 0x6f0(0x08)
};

