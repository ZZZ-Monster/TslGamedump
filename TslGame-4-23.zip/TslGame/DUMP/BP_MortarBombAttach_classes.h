// BlueprintGeneratedClass BP_MortarBombAttach.BP_MortarBombAttach_C
// Size: 0x448 (Inherited: 0x440)
struct ABP_MortarBombAttach_C : APowerup_Base_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x440(0x08)

	void UserConstructionScript(); // Function BP_MortarBombAttach.BP_MortarBombAttach_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void MortarBomb_Attach(); // Function BP_MortarBombAttach.BP_MortarBombAttach_C.MortarBomb_Attach // BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void ExecuteUbergraph_BP_MortarBombAttach(int32 EntryPoint); // Function BP_MortarBombAttach.BP_MortarBombAttach_C.ExecuteUbergraph_BP_MortarBombAttach //  // @ game+0x33e45c
};

