// BlueprintGeneratedClass BP_DroneItem.BP_DroneItem_C
// Size: 0x370 (Inherited: 0x370)
struct UBP_DroneItem_C : UDroneItem {
};

