// Class ActorSequence.ActorSequence
// Size: 0x370 (Inherited: 0x340)
struct UActorSequence : UMovieSceneSequence {
	struct UMovieScene* MovieScene; // 0x340(0x08)
	struct FActorSequenceObjectReferenceMap ObjectReferences; // 0x348(0x20)
	char pad_368[0x8]; // 0x368(0x08)
};

// Class ActorSequence.ActorSequenceComponent
// Size: 0x240 (Inherited: 0x200)
struct UActorSequenceComponent : UActorComponent {
	struct FMovieSceneSequencePlaybackSettings PlaybackSettings; // 0x200(0x28)
	struct UActorSequence* Sequence; // 0x228(0x08)
	struct UActorSequencePlayer* SequencePlayer; // 0x230(0x08)
	bool bAutoPlay; // 0x238(0x01)
	char pad_239[0x7]; // 0x239(0x07)
};

// Class ActorSequence.ActorSequencePlayer
// Size: 0x710 (Inherited: 0x710)
struct UActorSequencePlayer : UMovieSceneSequencePlayer {
};

