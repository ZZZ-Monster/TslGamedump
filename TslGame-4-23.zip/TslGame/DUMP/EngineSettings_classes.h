// Class EngineSettings.ConsoleSettings
// Size: 0x80 (Inherited: 0x38)
struct UConsoleSettings : UObject {
	int32 MaxScrollbackSize; // 0x38(0x04)
	char pad_3C[0x4]; // 0x3c(0x04)
	struct TArray<struct FAutoCompleteCommand> ManualAutoCompleteList; // 0x40(0x10)
	struct TArray<struct FString> AutoCompleteMapPaths; // 0x50(0x10)
	float BackgroundOpacityPercentage; // 0x60(0x04)
	bool bOrderTopToBottom; // 0x64(0x01)
	char pad_65[0x3]; // 0x65(0x03)
	struct FColor InputColor; // 0x68(0x04)
	struct FColor HistoryColor; // 0x6c(0x04)
	struct FColor AutoCompleteCommandColor; // 0x70(0x04)
	struct FColor AutoCompleteCVarColor; // 0x74(0x04)
	struct FColor AutoCompleteFadedColor; // 0x78(0x04)
	char pad_7C[0x4]; // 0x7c(0x04)
};

// Class EngineSettings.GameMapsSettings
// Size: 0xe0 (Inherited: 0x38)
struct UGameMapsSettings : UObject {
	struct FStringAssetReference EditorStartupMap; // 0x38(0x10)
	struct FString LocalMapOptions; // 0x48(0x10)
	struct FStringAssetReference TransitionMap; // 0x58(0x10)
	bool bUseSplitscreen; // 0x68(0x01)
	enum class ETwoPlayerSplitScreenType TwoPlayerSplitscreenLayout; // 0x69(0x01)
	enum class EThreePlayerSplitScreenType ThreePlayerSplitscreenLayout; // 0x6a(0x01)
	bool bOffsetPlayerGamepadIds; // 0x6b(0x01)
	char pad_6C[0x4]; // 0x6c(0x04)
	struct FStringClassReference GameInstanceClass; // 0x70(0x10)
	struct FStringAssetReference GameDefaultMap; // 0x80(0x10)
	struct FStringAssetReference ServerDefaultMap; // 0x90(0x10)
	struct FStringClassReference GlobalDefaultGameMode; // 0xa0(0x10)
	struct FStringClassReference GlobalDefaultServerGameMode; // 0xb0(0x10)
	struct TArray<struct FGameModeName> GameModeMapPrefixes; // 0xc0(0x10)
	struct TArray<struct FGameModeName> GameModeClassAliases; // 0xd0(0x10)
};

// Class EngineSettings.GameNetworkManagerSettings
// Size: 0x68 (Inherited: 0x38)
struct UGameNetworkManagerSettings : UObject {
	int32 MinDynamicBandwidth; // 0x38(0x04)
	int32 MaxDynamicBandwidth; // 0x3c(0x04)
	int32 TotalNetBandwidth; // 0x40(0x04)
	int32 BadPingThreshold; // 0x44(0x04)
	char bIsStandbyCheckingEnabled : 1; // 0x48(0x01)
	char pad_48_1 : 7; // 0x48(0x01)
	char pad_49[0x3]; // 0x49(0x03)
	float StandbyRxCheatTime; // 0x4c(0x04)
	float StandbyTxCheatTime; // 0x50(0x04)
	float PercentMissingForRxStandby; // 0x54(0x04)
	float PercentMissingForTxStandby; // 0x58(0x04)
	float PercentForBadPing; // 0x5c(0x04)
	float JoinInProgressStandbyWaitTime; // 0x60(0x04)
	char pad_64[0x4]; // 0x64(0x04)
};

// Class EngineSettings.GameSessionSettings
// Size: 0x48 (Inherited: 0x38)
struct UGameSessionSettings : UObject {
	int32 MaxSpectators; // 0x38(0x04)
	int32 MaxPlayers; // 0x3c(0x04)
	char bRequiresPushToTalk : 1; // 0x40(0x01)
	char pad_40_1 : 7; // 0x40(0x01)
	char pad_41[0x7]; // 0x41(0x07)
};

// Class EngineSettings.GeneralEngineSettings
// Size: 0x38 (Inherited: 0x38)
struct UGeneralEngineSettings : UObject {
};

// Class EngineSettings.GeneralProjectSettings
// Size: 0x120 (Inherited: 0x38)
struct UGeneralProjectSettings : UObject {
	struct FString CompanyName; // 0x38(0x10)
	struct FString CompanyDistinguishedName; // 0x48(0x10)
	struct FString CopyrightNotice; // 0x58(0x10)
	struct FString Description; // 0x68(0x10)
	struct FString Homepage; // 0x78(0x10)
	struct FString LicensingTerms; // 0x88(0x10)
	struct FString PrivacyPolicy; // 0x98(0x10)
	struct FGuid ProjectID; // 0xa8(0x10)
	struct FString ProjectName; // 0xb8(0x10)
	struct FString ProjectVersion; // 0xc8(0x10)
	struct FString SupportContact; // 0xd8(0x10)
	struct FText ProjectDisplayedTitle; // 0xe8(0x18)
	struct FText ProjectDebugTitleInfo; // 0x100(0x18)
	bool bShouldWindowPreserveAspectRatio; // 0x118(0x01)
	bool bUseBorderlessWindow; // 0x119(0x01)
	bool bStartInVR; // 0x11a(0x01)
	bool bAllowWindowResize; // 0x11b(0x01)
	bool bAllowClose; // 0x11c(0x01)
	bool bAllowMaximize; // 0x11d(0x01)
	bool bAllowMinimize; // 0x11e(0x01)
	char pad_11F[0x1]; // 0x11f(0x01)
};

// Class EngineSettings.HudSettings
// Size: 0x50 (Inherited: 0x38)
struct UHudSettings : UObject {
	char bShowHUD : 1; // 0x38(0x01)
	char pad_38_1 : 7; // 0x38(0x01)
	char pad_39[0x7]; // 0x39(0x07)
	struct TArray<struct FName> DebugDisplay; // 0x40(0x10)
};

