// BlueprintGeneratedClass LobbyCharacterBase_v2.LobbyCharacterBase_v2_C
// Size: 0xbd0 (Inherited: 0xbd0)
struct ALobbyCharacterBase_v2_C : ALobbyCharacter {
};

