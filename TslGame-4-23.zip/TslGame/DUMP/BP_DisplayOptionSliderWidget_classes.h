// WidgetBlueprintGeneratedClass BP_DisplayOptionSliderWidget.BP_DisplayOptionSliderWidget_C
// Size: 0x868 (Inherited: 0x840)
struct UBP_DisplayOptionSliderWidget_C : UTslGameOptionItemSliderWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x840(0x08)
	struct UProgressBar* BrightnessProgressBar; // 0x848(0x08)
	struct USlider* BrightnessSlider; // 0x850(0x08)
	struct UEditableText* BrightnessText; // 0x858(0x08)
	struct UProgressBar* NewVar_1; // 0x860(0x08)

	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Function BP_DisplayOptionSliderWidget.BP_DisplayOptionSliderWidget_C.Tick // BlueprintCosmetic|Event|Public|BlueprintEvent // @ game+0x33e45c
	void ExecuteUbergraph_BP_DisplayOptionSliderWidget(int32 EntryPoint); // Function BP_DisplayOptionSliderWidget.BP_DisplayOptionSliderWidget_C.ExecuteUbergraph_BP_DisplayOptionSliderWidget // HasDefaults // @ game+0x33e45c
};

