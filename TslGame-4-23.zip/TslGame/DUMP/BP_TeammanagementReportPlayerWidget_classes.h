// WidgetBlueprintGeneratedClass BP_TeammanagementReportPlayerWidget.BP_TeammanagementReportPlayerWidget_C
// Size: 0x3b8 (Inherited: 0x3a0)
struct UBP_TeammanagementReportPlayerWidget_C : UTslTeamManagementReportPlayerWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x3a0(0x08)
	struct UUI_TeamManagementAndMissionList_C* NewTeamAndMissionList; // 0x3a8(0x08)
	struct UBP_PcSystemMenuWidget_C* SystemMenu; // 0x3b0(0x08)

	void SetPopup(enum class EPopupStyle PopupStyle, struct FText Title, struct FText Message, DelegateProperty PressedDelegate); // Function BP_TeammanagementReportPlayerWidget.BP_TeammanagementReportPlayerWidget_C.SetPopup // Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void SetStyleNormal(); // Function BP_TeammanagementReportPlayerWidget.BP_TeammanagementReportPlayerWidget_C.SetStyleNormal // Event|Public|BlueprintEvent // @ game+0x33e45c
	void ExecuteUbergraph_BP_TeammanagementReportPlayerWidget(int32 EntryPoint); // Function BP_TeammanagementReportPlayerWidget.BP_TeammanagementReportPlayerWidget_C.ExecuteUbergraph_BP_TeammanagementReportPlayerWidget // HasDefaults // @ game+0x33e45c
};

