// ScriptStruct LevelSequence.LevelSequenceObject
// Size: 0x38 (Inherited: 0x00)
struct FLevelSequenceObject {
	struct UObject* ObjectOrOwner; // 0x00(0x1c)
	char pad_1C[0x4]; // 0x1c(0x04)
	struct FString ComponentName; // 0x20(0x10)
	struct UObject* CachedComponent; // 0x30(0x08)
};

// ScriptStruct LevelSequence.LevelSequenceBindingReferences
// Size: 0x50 (Inherited: 0x00)
struct FLevelSequenceBindingReferences {
	struct TMap<struct FGuid, struct FLevelSequenceBindingReferenceArray> BindingIdToReferences; // 0x00(0x50)
};

// ScriptStruct LevelSequence.LevelSequenceBindingReferenceArray
// Size: 0x10 (Inherited: 0x00)
struct FLevelSequenceBindingReferenceArray {
	struct TArray<struct FLevelSequenceBindingReference> References; // 0x00(0x10)
};

// ScriptStruct LevelSequence.LevelSequenceBindingReference
// Size: 0x20 (Inherited: 0x00)
struct FLevelSequenceBindingReference {
	struct FString PackageName; // 0x00(0x10)
	struct FString ObjectPath; // 0x10(0x10)
};

// ScriptStruct LevelSequence.LevelSequenceObjectReferenceMap
// Size: 0x50 (Inherited: 0x00)
struct FLevelSequenceObjectReferenceMap {
	char pad_0[0x50]; // 0x00(0x50)
};

// ScriptStruct LevelSequence.LevelSequenceLegacyObjectReference
// Size: 0x20 (Inherited: 0x00)
struct FLevelSequenceLegacyObjectReference {
	char pad_0[0x20]; // 0x00(0x20)
};

// ScriptStruct LevelSequence.LevelSequencePlayerSnapshot
// Size: 0x50 (Inherited: 0x00)
struct FLevelSequencePlayerSnapshot {
	struct FText MasterName; // 0x00(0x18)
	float MasterTime; // 0x18(0x04)
	char pad_1C[0x4]; // 0x1c(0x04)
	struct FText CurrentShotName; // 0x20(0x18)
	float CurrentShotLocalTime; // 0x38(0x04)
	char pad_3C[0x4]; // 0x3c(0x04)
	struct UCameraComponent* CameraComponent; // 0x40(0x08)
	struct FLevelSequenceSnapshotSettings Settings; // 0x48(0x08)
};

// ScriptStruct LevelSequence.LevelSequenceSnapshotSettings
// Size: 0x08 (Inherited: 0x00)
struct FLevelSequenceSnapshotSettings {
	bool ZeroPadAmount; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	float FrameRate; // 0x04(0x04)
};

// ScriptStruct LevelSequence.BoundActorProxy
// Size: 0x01 (Inherited: 0x00)
struct FBoundActorProxy {
	char pad_0[0x1]; // 0x00(0x01)
};

