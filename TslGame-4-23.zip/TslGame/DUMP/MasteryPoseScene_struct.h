// UserDefinedStruct MasteryPoseScene.MasteryPoseScene
// Size: 0x90 (Inherited: 0x00)
struct FMasteryPoseScene {
	struct UAnimSequence* PlayerPose_14_680F16F24620F93F5BE08482E4B331B7; // 0x00(0x08)
	char pad_8[0x8]; // 0x08(0x08)
	struct FTransform SurvivalPageTransform_28_E1AEFE1A4C1AF0311D9296932584D6CD; // 0x10(0x30)
	struct FString SurvivalPageScene_32_2ABD8C7C4E1D741795EAF682098530DC; // 0x40(0x10)
	struct UClass* PoseAsset_39_39BCBF6D4675AACDF881B18FB8699A6A; // 0x50(0x08)
	char pad_58[0x8]; // 0x58(0x08)
	struct FTransform PlayerCardTransform_29_2E4AAD5846444AF931B52F8BEF3C7786; // 0x60(0x30)
};

