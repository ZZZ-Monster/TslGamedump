// WidgetBlueprintGeneratedClass BP_MiniMapWidget.BP_MiniMapWidget_C
// Size: 0x4c0 (Inherited: 0x4a8)
struct UBP_MiniMapWidget_C : UMiniMapBaseWidget {
	struct UBluezoneHudMinimizeWidget_C* BluezoneHudMinimizeWidget; // 0x4a8(0x08)
	struct UMapGridWidget_C* MapGridWidget; // 0x4b0(0x08)
	struct ATslCharacter* Character; // 0x4b8(0x08)

	void OnPrepass_1(struct UWidget* BoundWidget); // Function BP_MiniMapWidget.BP_MiniMapWidget_C.OnPrepass_1 // Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
};

