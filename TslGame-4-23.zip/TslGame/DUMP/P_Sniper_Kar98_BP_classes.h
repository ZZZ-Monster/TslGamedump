// BlueprintGeneratedClass P_Sniper_Kar98_BP.P_Sniper_Kar98_BP_C
// Size: 0x4f0 (Inherited: 0x4f0)
struct AP_Sniper_Kar98_BP_C : ATslParticle {
};

