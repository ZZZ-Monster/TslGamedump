// BlueprintGeneratedClass BP_LobbyCharacterPivot.BP_LobbyCharacterPivot_C
// Size: 0x418 (Inherited: 0x410)
struct ABP_LobbyCharacterPivot_C : ALobbyCharacterPivot {
	struct USceneComponent* DefaultSceneRoot; // 0x410(0x08)

	void UserConstructionScript(); // Function BP_LobbyCharacterPivot.BP_LobbyCharacterPivot_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
};

