// WidgetBlueprintGeneratedClass BP_GamepadKeyGuideWidgetPop.BP_GamepadKeyGuideWidgetPop_C
// Size: 0x6e0 (Inherited: 0x6a0)
struct UBP_GamepadKeyGuideWidgetPop_C : UTslGamepadKeyBindingWidget {
	struct UWidgetAnimation* PopupEmerging; // 0x6a0(0x08)
	struct UBP_GamepadMultipleKeyIconWidget_C* CloseMultipleKeyIconWidget; // 0x6a8(0x08)
	struct UBP_GamepadMultipleKeyIconWidget_C* DefaultMultipleKeyIconWidget; // 0x6b0(0x08)
	struct UBP_GamepadMultipleKeyIconWidget_C* EmptyMultipleKeyIconWidget; // 0x6b8(0x08)
	struct UBP_GamepadKeyGuideKeyActionList_C* KeyBindPopScrollTop; // 0x6c0(0x08)
	struct UImage* KeyBindPopTooltipIcon; // 0x6c8(0x08)
	struct UImage* Line1_Image; // 0x6d0(0x08)
	struct UBP_GamepadMultipleKeyIconWidget_C* SelectKeyIconWidget; // 0x6d8(0x08)
};

