// Enum MovieSceneTracks.MovieScene3DPathSection_Axis
enum class MovieScene3DPathSection_Axis : uint8 {
	X,
	Y,
	Z,
	NEG_X,
	NEG_Y,
	NEG_Z,
	MovieScene3DPathSection_MAX,
};

// Enum MovieSceneTracks.EShow3DTrajectory
enum class EShow3DTrajectory : uint8 {
	EST_OnlyWhenSelected,
	EST_Always,
	EST_Never,
	EST_MAX,
};

// Enum MovieSceneTracks.EFireEventsAtPosition
enum class EFireEventsAtPosition : uint8 {
	AtStartOfEvaluation,
	AtEndOfEvaluation,
	AfterSpawn,
	EFireEventsAtPosition_MAX,
};

// Enum MovieSceneTracks.ELevelVisibility
enum class ELevelVisibility : uint8 {
	Visible,
	Hidden,
	ELevelVisibility_MAX,
};

// Enum MovieSceneTracks.EParticleKey
enum class EParticleKey : uint8 {
	Activate,
	Deactivate,
	Trigger,
	EParticleKey_MAX,
};

// ScriptStruct MovieSceneTracks.MovieScene3DTransformKeyStruct
// Size: 0x78 (Inherited: 0x08)
struct FMovieScene3DTransformKeyStruct : FMovieSceneKeyStruct {
	struct FVector Location; // 0x08(0x0c)
	struct FRotator Rotation; // 0x14(0x0c)
	struct FVector Scale; // 0x20(0x0c)
	char pad_2C[0x4c]; // 0x2c(0x4c)
};

// ScriptStruct MovieSceneTracks.MovieScene3DScaleKeyStruct
// Size: 0x30 (Inherited: 0x08)
struct FMovieScene3DScaleKeyStruct : FMovieSceneKeyStruct {
	struct FVector Scale; // 0x08(0x0c)
	char pad_14[0x1c]; // 0x14(0x1c)
};

// ScriptStruct MovieSceneTracks.MovieScene3DRotationKeyStruct
// Size: 0x30 (Inherited: 0x08)
struct FMovieScene3DRotationKeyStruct : FMovieSceneKeyStruct {
	struct FRotator Rotation; // 0x08(0x0c)
	char pad_14[0x1c]; // 0x14(0x1c)
};

// ScriptStruct MovieSceneTracks.MovieScene3DLocationKeyStruct
// Size: 0x30 (Inherited: 0x08)
struct FMovieScene3DLocationKeyStruct : FMovieSceneKeyStruct {
	struct FVector Location; // 0x08(0x0c)
	char pad_14[0x1c]; // 0x14(0x1c)
};

// ScriptStruct MovieSceneTracks.MovieSceneCameraAnimSectionData
// Size: 0x20 (Inherited: 0x00)
struct FMovieSceneCameraAnimSectionData {
	struct UCameraAnim* CameraAnim; // 0x00(0x08)
	float PlayRate; // 0x08(0x04)
	float PlayScale; // 0x0c(0x04)
	float BlendInTime; // 0x10(0x04)
	float BlendOutTime; // 0x14(0x04)
	bool bLooping; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
};

// ScriptStruct MovieSceneTracks.MovieSceneCameraShakeSectionData
// Size: 0x20 (Inherited: 0x00)
struct FMovieSceneCameraShakeSectionData {
	struct UClass* ShakeClass; // 0x00(0x08)
	float PlayScale; // 0x08(0x04)
	enum class ECameraAnimPlaySpace PlaySpace; // 0x0c(0x01)
	char pad_D[0x3]; // 0x0d(0x03)
	struct FRotator UserDefinedPlaySpace; // 0x10(0x0c)
	char pad_1C[0x4]; // 0x1c(0x04)
};

// ScriptStruct MovieSceneTracks.MovieSceneColorKeyStruct
// Size: 0x58 (Inherited: 0x08)
struct FMovieSceneColorKeyStruct : FMovieSceneKeyStruct {
	struct FLinearColor Color; // 0x08(0x10)
	char pad_18[0x40]; // 0x18(0x40)
};

// ScriptStruct MovieSceneTracks.MovieSceneEventSectionData
// Size: 0x20 (Inherited: 0x00)
struct FMovieSceneEventSectionData {
	struct TArray<float> KeyTimes; // 0x00(0x10)
	struct TArray<struct FEventPayload> KeyValues; // 0x10(0x10)
};

// ScriptStruct MovieSceneTracks.EventPayload
// Size: 0x28 (Inherited: 0x00)
struct FEventPayload {
	struct FName EventName; // 0x00(0x08)
	struct FMovieSceneEventParameters Parameters; // 0x08(0x20)
};

// ScriptStruct MovieSceneTracks.MovieSceneEventParameters
// Size: 0x20 (Inherited: 0x00)
struct FMovieSceneEventParameters {
	char pad_0[0x20]; // 0x00(0x20)
};

// ScriptStruct MovieSceneTracks.ColorParameterNameAndCurves
// Size: 0x1d0 (Inherited: 0x00)
struct FColorParameterNameAndCurves {
	struct FName ParameterName; // 0x00(0x08)
	int32 Index; // 0x08(0x04)
	char pad_C[0x4]; // 0x0c(0x04)
	struct FRichCurve RedCurve; // 0x10(0x70)
	struct FRichCurve GreenCurve; // 0x80(0x70)
	struct FRichCurve BlueCurve; // 0xf0(0x70)
	struct FRichCurve AlphaCurve; // 0x160(0x70)
};

// ScriptStruct MovieSceneTracks.VectorParameterNameAndCurves
// Size: 0x160 (Inherited: 0x00)
struct FVectorParameterNameAndCurves {
	struct FName ParameterName; // 0x00(0x08)
	int32 Index; // 0x08(0x04)
	char pad_C[0x4]; // 0x0c(0x04)
	struct FRichCurve XCurve; // 0x10(0x70)
	struct FRichCurve YCurve; // 0x80(0x70)
	struct FRichCurve ZCurve; // 0xf0(0x70)
};

// ScriptStruct MovieSceneTracks.ScalarParameterNameAndCurve
// Size: 0x80 (Inherited: 0x00)
struct FScalarParameterNameAndCurve {
	struct FName ParameterName; // 0x00(0x08)
	int32 Index; // 0x08(0x04)
	char pad_C[0x4]; // 0x0c(0x04)
	struct FRichCurve ParameterCurve; // 0x10(0x70)
};

// ScriptStruct MovieSceneTracks.MovieSceneSkeletalAnimationParams
// Size: 0x90 (Inherited: 0x00)
struct FMovieSceneSkeletalAnimationParams {
	struct UAnimSequenceBase* Animation; // 0x00(0x08)
	float StartOffset; // 0x08(0x04)
	float EndOffset; // 0x0c(0x04)
	float PlayRate; // 0x10(0x04)
	char bReverse : 1; // 0x14(0x01)
	char pad_14_1 : 7; // 0x14(0x01)
	char pad_15[0x3]; // 0x15(0x03)
	struct FName SlotName; // 0x18(0x08)
	struct FRichCurve weight; // 0x20(0x70)
};

// ScriptStruct MovieSceneTracks.MovieSceneVector4KeyStruct
// Size: 0x60 (Inherited: 0x48)
struct FMovieSceneVector4KeyStruct : FMovieSceneVectorKeyStructBase {
	char pad_48[0x8]; // 0x48(0x08)
	struct FVector4 Vector; // 0x50(0x10)
};

// ScriptStruct MovieSceneTracks.MovieSceneVectorKeyStructBase
// Size: 0x48 (Inherited: 0x08)
struct FMovieSceneVectorKeyStructBase : FMovieSceneKeyStruct {
	char pad_8[0x40]; // 0x08(0x40)
};

// ScriptStruct MovieSceneTracks.MovieSceneVectorKeyStruct
// Size: 0x58 (Inherited: 0x48)
struct FMovieSceneVectorKeyStruct : FMovieSceneVectorKeyStructBase {
	struct FVector Vector; // 0x48(0x0c)
	char pad_54[0x4]; // 0x54(0x04)
};

// ScriptStruct MovieSceneTracks.MovieSceneVector2DKeyStruct
// Size: 0x50 (Inherited: 0x48)
struct FMovieSceneVector2DKeyStruct : FMovieSceneVectorKeyStructBase {
	struct FVector2D Vector; // 0x48(0x08)
};

// ScriptStruct MovieSceneTracks.MovieSceneComponentMaterialSectionTemplate
// Size: 0x50 (Inherited: 0x48)
struct FMovieSceneComponentMaterialSectionTemplate : FMovieSceneParameterSectionTemplate {
	int32 MaterialIndex; // 0x48(0x04)
	char pad_4C[0x4]; // 0x4c(0x04)
};

// ScriptStruct MovieSceneTracks.MovieSceneParameterSectionTemplate
// Size: 0x48 (Inherited: 0x18)
struct FMovieSceneParameterSectionTemplate : FMovieSceneEvalTemplate {
	struct TArray<struct FScalarParameterNameAndCurve> Scalars; // 0x18(0x10)
	struct TArray<struct FVectorParameterNameAndCurves> Vectors; // 0x28(0x10)
	struct TArray<struct FColorParameterNameAndCurves> Colors; // 0x38(0x10)
};

// ScriptStruct MovieSceneTracks.MovieSceneSpawnSectionTemplate
// Size: 0x88 (Inherited: 0x18)
struct FMovieSceneSpawnSectionTemplate : FMovieSceneEvalTemplate {
	struct FIntegralCurve Curve; // 0x18(0x70)
};

// ScriptStruct MovieSceneTracks.MovieScene3DAttachSectionTemplate
// Size: 0x38 (Inherited: 0x18)
struct FMovieScene3DAttachSectionTemplate : FMovieSceneEvalTemplate {
	struct FGuid AttachGuid; // 0x18(0x10)
	struct FName AttachSocketName; // 0x28(0x08)
	struct FName AttachComponentName; // 0x30(0x08)
};

// ScriptStruct MovieSceneTracks.MovieScene3DPathSectionTemplate
// Size: 0xa0 (Inherited: 0x18)
struct FMovieScene3DPathSectionTemplate : FMovieSceneEvalTemplate {
	struct FGuid PathGuid; // 0x18(0x10)
	struct FRichCurve TimingCurve; // 0x28(0x70)
	enum class MovieScene3DPathSection_Axis FrontAxisEnum; // 0x98(0x01)
	enum class MovieScene3DPathSection_Axis UpAxisEnum; // 0x99(0x01)
	char pad_9A[0x2]; // 0x9a(0x02)
	char bFollow : 1; // 0x9c(0x01)
	char bReverse : 1; // 0x9c(0x01)
	char bForceUpright : 1; // 0x9c(0x01)
	char pad_9C_3 : 5; // 0x9c(0x01)
	char pad_9D[0x3]; // 0x9d(0x03)
};

// ScriptStruct MovieSceneTracks.MovieScene3DTransformSectionTemplate
// Size: 0x408 (Inherited: 0x18)
struct FMovieScene3DTransformSectionTemplate : FMovieSceneEvalTemplate {
	struct FRichCurve TranslationCurve[0x03]; // 0x18(0x150)
	struct FRichCurve RotationCurve[0x03]; // 0x168(0x150)
	struct FRichCurve ScaleCurve[0x03]; // 0x2b8(0x150)
};

// ScriptStruct MovieSceneTracks.MovieSceneActorReferenceSectionTemplate
// Size: 0xc0 (Inherited: 0x18)
struct FMovieSceneActorReferenceSectionTemplate : FMovieSceneEvalTemplate {
	struct FMovieScenePropertySectionData PropertyData; // 0x18(0x28)
	struct FIntegralCurve ActorGuidIndexCurve; // 0x40(0x70)
	struct TArray<struct FGuid> ActorGuids; // 0xb0(0x10)
};

// ScriptStruct MovieSceneTracks.MovieSceneAudioSectionTemplate
// Size: 0x150 (Inherited: 0x18)
struct FMovieSceneAudioSectionTemplate : FMovieSceneEvalTemplate {
	struct FMovieSceneAudioSectionTemplateData AudioData; // 0x18(0x138)
};

// ScriptStruct MovieSceneTracks.MovieSceneAudioSectionTemplateData
// Size: 0x138 (Inherited: 0x00)
struct FMovieSceneAudioSectionTemplateData {
	struct USoundBase* Sound; // 0x00(0x08)
	float AudioStartOffset; // 0x08(0x04)
	struct FFloatRange AudioRange; // 0x0c(0x10)
	char pad_1C[0x4]; // 0x1c(0x04)
	struct FRichCurve AudioPitchMultiplierCurve; // 0x20(0x70)
	struct FRichCurve AudioVolumeCurve; // 0x90(0x70)
	int32 RowIndex; // 0x100(0x04)
	char pad_104[0x4]; // 0x104(0x04)
	DelegateProperty OnQueueSubtitles; // 0x108(0x10)
	struct FMulticastDelegate OnAudioFinished; // 0x118(0x10)
	struct FMulticastDelegate OnAudioPlaybackPercent; // 0x128(0x10)
};

// ScriptStruct MovieSceneTracks.MovieSceneAdditiveCameraAnimationTrackTemplate
// Size: 0x18 (Inherited: 0x18)
struct FMovieSceneAdditiveCameraAnimationTrackTemplate : FMovieSceneEvalTemplate {
};

// ScriptStruct MovieSceneTracks.MovieSceneCameraShakeSectionTemplate
// Size: 0x40 (Inherited: 0x18)
struct FMovieSceneCameraShakeSectionTemplate : FMovieSceneAdditiveCameraAnimationTemplate {
	struct FMovieSceneCameraShakeSectionData SourceData; // 0x18(0x20)
	float SectionStartTime; // 0x38(0x04)
	char pad_3C[0x4]; // 0x3c(0x04)
};

// ScriptStruct MovieSceneTracks.MovieSceneAdditiveCameraAnimationTemplate
// Size: 0x18 (Inherited: 0x18)
struct FMovieSceneAdditiveCameraAnimationTemplate : FMovieSceneEvalTemplate {
};

// ScriptStruct MovieSceneTracks.MovieSceneCameraAnimSectionTemplate
// Size: 0x40 (Inherited: 0x18)
struct FMovieSceneCameraAnimSectionTemplate : FMovieSceneAdditiveCameraAnimationTemplate {
	struct FMovieSceneCameraAnimSectionData SourceData; // 0x18(0x20)
	float SectionStartTime; // 0x38(0x04)
	char pad_3C[0x4]; // 0x3c(0x04)
};

// ScriptStruct MovieSceneTracks.MovieSceneCameraCutSectionTemplate
// Size: 0x70 (Inherited: 0x18)
struct FMovieSceneCameraCutSectionTemplate : FMovieSceneEvalTemplate {
	struct FGuid CameraGuid; // 0x18(0x10)
	char pad_28[0x8]; // 0x28(0x08)
	struct FTransform CutTransform; // 0x30(0x30)
	bool bHasCutTransform; // 0x60(0x01)
	char pad_61[0xf]; // 0x61(0x0f)
};

// ScriptStruct MovieSceneTracks.MovieSceneColorSectionTemplate
// Size: 0x1f0 (Inherited: 0x18)
struct FMovieSceneColorSectionTemplate : FMovieSceneEvalTemplate {
	struct FName PropertyName; // 0x18(0x08)
	struct FString PropertyPath; // 0x20(0x10)
	struct FRichCurve Curves[0x04]; // 0x30(0x1c0)
};

// ScriptStruct MovieSceneTracks.MovieSceneEventSectionTemplate
// Size: 0x50 (Inherited: 0x18)
struct FMovieSceneEventSectionTemplate : FMovieSceneEvalTemplate {
	struct FMovieSceneEventSectionData EventData; // 0x18(0x20)
	struct TArray<struct FMovieSceneObjectBindingID> EventReceivers; // 0x38(0x10)
	char bFireEventsWhenForwards : 1; // 0x48(0x01)
	char bFireEventsWhenBackwards : 1; // 0x48(0x01)
	char pad_48_2 : 6; // 0x48(0x01)
	char pad_49[0x7]; // 0x49(0x07)
};

// ScriptStruct MovieSceneTracks.MovieSceneFadeSectionTemplate
// Size: 0xa0 (Inherited: 0x18)
struct FMovieSceneFadeSectionTemplate : FMovieSceneEvalTemplate {
	struct FRichCurve FadeCurve; // 0x18(0x70)
	struct FLinearColor FadeColor; // 0x88(0x10)
	char bFadeAudio : 1; // 0x98(0x01)
	char pad_98_1 : 7; // 0x98(0x01)
	char pad_99[0x7]; // 0x99(0x07)
};

// ScriptStruct MovieSceneTracks.MovieSceneLevelVisibilitySectionTemplate
// Size: 0x30 (Inherited: 0x18)
struct FMovieSceneLevelVisibilitySectionTemplate : FMovieSceneEvalTemplate {
	enum class ELevelVisibility Visibility; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
	struct TArray<struct FName> LevelNames; // 0x20(0x10)
};

// ScriptStruct MovieSceneTracks.MovieSceneMaterialParameterCollectionTemplate
// Size: 0x50 (Inherited: 0x48)
struct FMovieSceneMaterialParameterCollectionTemplate : FMovieSceneParameterSectionTemplate {
	struct UMaterialParameterCollection* MPC; // 0x48(0x08)
};

// ScriptStruct MovieSceneTracks.MovieSceneParticleParameterSectionTemplate
// Size: 0x48 (Inherited: 0x48)
struct FMovieSceneParticleParameterSectionTemplate : FMovieSceneParameterSectionTemplate {
};

// ScriptStruct MovieSceneTracks.MovieSceneParticleSectionTemplate
// Size: 0x88 (Inherited: 0x18)
struct FMovieSceneParticleSectionTemplate : FMovieSceneEvalTemplate {
	struct FIntegralCurve ParticleKeys; // 0x18(0x70)
};

// ScriptStruct MovieSceneTracks.MovieSceneTransformPropertySectionTemplate
// Size: 0x430 (Inherited: 0x18)
struct FMovieSceneTransformPropertySectionTemplate : FMovieSceneEvalTemplate {
	struct FMovieScenePropertySectionData PropertyData; // 0x18(0x28)
	struct FRichCurve TranslationCurve[0x03]; // 0x40(0x150)
	struct FRichCurve RotationCurve[0x03]; // 0x190(0x150)
	struct FRichCurve ScaleCurve[0x03]; // 0x2e0(0x150)
};

// ScriptStruct MovieSceneTracks.MovieSceneVectorPropertySectionTemplate
// Size: 0x208 (Inherited: 0x18)
struct FMovieSceneVectorPropertySectionTemplate : FMovieSceneEvalTemplate {
	struct FMovieScenePropertySectionData PropertyData; // 0x18(0x28)
	struct FRichCurve ComponentCurves[0x04]; // 0x40(0x1c0)
	int32 NumChannelsUsed; // 0x200(0x04)
	char pad_204[0x4]; // 0x204(0x04)
};

// ScriptStruct MovieSceneTracks.MovieSceneStringPropertySectionTemplate
// Size: 0xb8 (Inherited: 0x18)
struct FMovieSceneStringPropertySectionTemplate : FMovieSceneEvalTemplate {
	struct FMovieScenePropertySectionData PropertyData; // 0x18(0x28)
	struct FStringCurve StringCurve; // 0x40(0x78)
};

// ScriptStruct MovieSceneTracks.MovieSceneIntegerPropertySectionTemplate
// Size: 0xb0 (Inherited: 0x18)
struct FMovieSceneIntegerPropertySectionTemplate : FMovieSceneEvalTemplate {
	struct FMovieScenePropertySectionData PropertyData; // 0x18(0x28)
	struct FIntegralCurve IntegerCurve; // 0x40(0x70)
};

// ScriptStruct MovieSceneTracks.MovieSceneEnumPropertySectionTemplate
// Size: 0xb0 (Inherited: 0x18)
struct FMovieSceneEnumPropertySectionTemplate : FMovieSceneEvalTemplate {
	struct FMovieScenePropertySectionData PropertyData; // 0x18(0x28)
	struct FIntegralCurve EnumCurve; // 0x40(0x70)
};

// ScriptStruct MovieSceneTracks.MovieSceneBytePropertySectionTemplate
// Size: 0xb0 (Inherited: 0x18)
struct FMovieSceneBytePropertySectionTemplate : FMovieSceneEvalTemplate {
	struct FMovieScenePropertySectionData PropertyData; // 0x18(0x28)
	struct FIntegralCurve ByteCurve; // 0x40(0x70)
};

// ScriptStruct MovieSceneTracks.MovieSceneFloatPropertySectionTemplate
// Size: 0xb0 (Inherited: 0x18)
struct FMovieSceneFloatPropertySectionTemplate : FMovieSceneEvalTemplate {
	struct FMovieScenePropertySectionData PropertyData; // 0x18(0x28)
	struct FRichCurve FloatCurve; // 0x40(0x70)
};

// ScriptStruct MovieSceneTracks.MovieSceneBoolPropertySectionTemplate
// Size: 0xb0 (Inherited: 0x18)
struct FMovieSceneBoolPropertySectionTemplate : FMovieSceneEvalTemplate {
	struct FMovieScenePropertySectionData PropertyData; // 0x18(0x28)
	struct FIntegralCurve BoolCurve; // 0x40(0x70)
};

// ScriptStruct MovieSceneTracks.MovieSceneSkeletalAnimationSharedTrack
// Size: 0x18 (Inherited: 0x18)
struct FMovieSceneSkeletalAnimationSharedTrack : FMovieSceneEvalTemplate {
};

// ScriptStruct MovieSceneTracks.MovieSceneSkeletalAnimationSectionTemplate
// Size: 0xb0 (Inherited: 0x18)
struct FMovieSceneSkeletalAnimationSectionTemplate : FMovieSceneEvalTemplate {
	struct FMovieSceneSkeletalAnimationSectionTemplateParameters Params; // 0x18(0x98)
};

// ScriptStruct MovieSceneTracks.MovieSceneSkeletalAnimationSectionTemplateParameters
// Size: 0x98 (Inherited: 0x90)
struct FMovieSceneSkeletalAnimationSectionTemplateParameters : FMovieSceneSkeletalAnimationParams {
	float SectionStartTime; // 0x90(0x04)
	float SectionEndTime; // 0x94(0x04)
};

// ScriptStruct MovieSceneTracks.MovieSceneSlomoSectionTemplate
// Size: 0x88 (Inherited: 0x18)
struct FMovieSceneSlomoSectionTemplate : FMovieSceneEvalTemplate {
	struct FRichCurve SlomoCurve; // 0x18(0x70)
};

// ScriptStruct MovieSceneTracks.MovieSceneVisibilitySectionTemplate
// Size: 0xb8 (Inherited: 0xb0)
struct FMovieSceneVisibilitySectionTemplate : FMovieSceneBoolPropertySectionTemplate {
	bool bTemporarilyHiddenInGame; // 0xb0(0x01)
	char pad_B1[0x7]; // 0xb1(0x07)
};

