// WidgetBlueprintGeneratedClass BP_PcSystemMenuButtonWidget.BP_PcSystemMenuButtonWidget_C
// Size: 0x4f0 (Inherited: 0x4d0)
struct UBP_PcSystemMenuButtonWidget_C : UTslSystemMenuButton {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4d0(0x08)
	struct UTextBlock* ButtonText; // 0x4d8(0x08)
	struct FMulticastDelegate OnClicked; // 0x4e0(0x10)

	void PreConstruct(bool IsDesignTime); // Function BP_PcSystemMenuButtonWidget.BP_PcSystemMenuButtonWidget_C.PreConstruct // BlueprintCosmetic|Event|Public|BlueprintEvent // @ game+0x33e45c
	void BndEvt__Button_Internal_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature(); // Function BP_PcSystemMenuButtonWidget.BP_PcSystemMenuButtonWidget_C.BndEvt__Button_Internal_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature // BlueprintEvent // @ game+0x33e45c
	void ExecuteUbergraph_BP_PcSystemMenuButtonWidget(int32 EntryPoint); // Function BP_PcSystemMenuButtonWidget.BP_PcSystemMenuButtonWidget_C.ExecuteUbergraph_BP_PcSystemMenuButtonWidget //  // @ game+0x33e45c
	void OnClicked__DelegateSignature(); // Function BP_PcSystemMenuButtonWidget.BP_PcSystemMenuButtonWidget_C.OnClicked__DelegateSignature // Public|Delegate|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
};

