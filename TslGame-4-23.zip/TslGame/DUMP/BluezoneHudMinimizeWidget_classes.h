// WidgetBlueprintGeneratedClass BluezoneHudMinimizeWidget.BluezoneHudMinimizeWidget_C
// Size: 0x518 (Inherited: 0x4f8)
struct UBluezoneHudMinimizeWidget_C : UObserverBluezoneTimeWidget {
	struct UImage* DividerImage; // 0x4f8(0x08)
	struct UImage* Image_1; // 0x500(0x08)
	struct UInvalidationBox* InvalidationBox_1; // 0x508(0x08)
	struct UInvalidationBox* InvalidationBox_2; // 0x510(0x08)
};

