// BlueprintGeneratedClass BP_JerryCan_CastableImplement.BP_JerryCan_CastableImplement_C
// Size: 0x150 (Inherited: 0x150)
struct UBP_JerryCan_CastableImplement_C : UCastableItemImplement_JerryCan {
};

