// BlueprintGeneratedClass CS_Hit.CS_Hit_C
// Size: 0x170 (Inherited: 0x170)
struct UCS_Hit_C : UCameraShake {
};

