// WidgetBlueprintGeneratedClass BP_MapCharacterIconWidget.BP_MapCharacterIconWidget_C
// Size: 0xad8 (Inherited: 0xa78)
struct UBP_MapCharacterIconWidget_C : UMapCharacterIconBaseWidget {
	struct UWidgetAnimation* OnEngage; // 0xa78(0x08)
	struct UWidgetAnimation* FadeOut; // 0xa80(0x08)
	struct UWidgetAnimation* GroggyWarning; // 0xa88(0x08)
	struct UWidgetAnimation* Hitted; // 0xa90(0x08)
	struct UWidgetAnimation* Attacked; // 0xa98(0x08)
	struct UImage* EngageHintImage; // 0xaa0(0x08)
	struct UImage* HitEffectImage; // 0xaa8(0x08)
	struct UBorder* NameBorder; // 0xab0(0x08)
	struct UImage* NameTagColorImg; // 0xab8(0x08)
	struct UBP_ObserverPlayerIconMuzzleFlash_C* ObserverPlayerIconMuzzleFlash; // 0xac0(0x08)
	struct UImage* SpectatedIcon; // 0xac8(0x08)
	struct UUserPlatformImageWidget_C* UserPlatformImage; // 0xad0(0x08)
};

