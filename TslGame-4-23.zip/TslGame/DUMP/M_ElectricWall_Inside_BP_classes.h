// BlueprintGeneratedClass M_ElectricWall_Inside_BP.M_ElectricWall_Inside_BP_C
// Size: 0x498 (Inherited: 0x478)
struct AM_ElectricWall_Inside_BP_C : ATslPostProcessEffect {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x478(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x480(0x08)
	float _____0______0_F1196C2844F052526643A091F7753F02; // 0x488(0x04)
	enum class ETimelineDirection _____0__Direction_F1196C2844F052526643A091F7753F02; // 0x48c(0x01)
	char pad_48D[0x3]; // 0x48d(0x03)
	struct UTimelineComponent* �Є�|�x�_1; // 0x490(0x08)

	void UserConstructionScript(); // Function M_ElectricWall_Inside_BP.M_ElectricWall_Inside_BP_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void �Є�|�x�_(); // Function M_ElectricWall_Inside_BP.M_ElectricWall_Inside_BP_C.�Є�|�x�_ // BlueprintEvent // @ game+0x33e45c
	void �Є�|�x�_(); // Function M_ElectricWall_Inside_BP.M_ElectricWall_Inside_BP_C.�Є�|�x�_ // BlueprintEvent // @ game+0x33e45c
	void ReceiveBeginPlay(); // Function M_ElectricWall_Inside_BP.M_ElectricWall_Inside_BP_C.ReceiveBeginPlay // Event|Protected|BlueprintEvent // @ game+0x33e45c
	void Custom Event_1(); // Function M_ElectricWall_Inside_BP.M_ElectricWall_Inside_BP_C.Custom Event_1 // BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void OnSetEffectParameter(struct FString ParameterName, float Value); // Function M_ElectricWall_Inside_BP.M_ElectricWall_Inside_BP_C.OnSetEffectParameter // BlueprintCosmetic|Event|Public|BlueprintEvent // @ game+0x33e45c
	void ExecuteUbergraph_M_ElectricWall_Inside_BP(int32 EntryPoint); // Function M_ElectricWall_Inside_BP.M_ElectricWall_Inside_BP_C.ExecuteUbergraph_M_ElectricWall_Inside_BP // HasDefaults // @ game+0x33e45c
};

