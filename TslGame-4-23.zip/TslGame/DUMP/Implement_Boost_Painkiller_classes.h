// BlueprintGeneratedClass Implement_Boost_Painkiller.Implement_Boost_Painkiller_C
// Size: 0x40 (Inherited: 0x40)
struct UImplement_Boost_Painkiller_C : UCastableItemImplement_Boost {
};

