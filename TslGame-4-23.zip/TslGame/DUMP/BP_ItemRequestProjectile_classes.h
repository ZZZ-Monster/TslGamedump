// BlueprintGeneratedClass BP_ItemRequestProjectile.BP_ItemRequestProjectile_C
// Size: 0x680 (Inherited: 0x680)
struct ABP_ItemRequestProjectile_C : ATslItemRequestProjectile {
};

