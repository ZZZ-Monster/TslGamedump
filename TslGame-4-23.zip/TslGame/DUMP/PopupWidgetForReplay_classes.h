// WidgetBlueprintGeneratedClass PopupWidgetForReplay.PopupWidgetForReplay_C
// Size: 0x2d8 (Inherited: 0x260)
struct UPopupWidgetForReplay_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UWidgetAnimation* PopupEmerging; // 0x268(0x08)
	struct UTslCommonButton* ButtonCancel; // 0x270(0x08)
	struct UTslCommonButton* ButtonOK; // 0x278(0x08)
	struct UTextBlock* TextBlock_172; // 0x280(0x08)
	struct UTextBlock* TextCancel; // 0x288(0x08)
	struct UTextBlock* TextOK; // 0x290(0x08)
	struct UBorder* Waiting; // 0x298(0x08)
	struct FText Message; // 0x2a0(0x18)
	struct FMulticastDelegate ButtonClickDispatcher; // 0x2b8(0x10)
	struct FMulticastDelegate HideMyself; // 0x2c8(0x10)

	struct FText Get_TextCancel_Text_1(); // Function PopupWidgetForReplay.PopupWidgetForReplay_C.Get_TextCancel_Text_1 // Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure // @ game+0x33e45c
	void SetPopup(enum class EPopupStyle PopupStyle, struct FText Title, struct FText Message, DelegateProperty PressedDelegate); // Function PopupWidgetForReplay.PopupWidgetForReplay_C.SetPopup // Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void Construct(); // Function PopupWidgetForReplay.PopupWidgetForReplay_C.Construct // BlueprintCosmetic|Event|Public|BlueprintEvent // @ game+0x33e45c
	void Custom Event_1(); // Function PopupWidgetForReplay.PopupWidgetForReplay_C.Custom Event_1 // BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void Destruct(); // Function PopupWidgetForReplay.PopupWidgetForReplay_C.Destruct // BlueprintCosmetic|Event|Public|BlueprintEvent // @ game+0x33e45c
	void XBoxOneOk(); // Function PopupWidgetForReplay.PopupWidgetForReplay_C.XBoxOneOk // BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void BndEvt__TslCommonButton_0_K2Node_ComponentBoundEvent_102_OnButtonClickedEvent__DelegateSignature(); // Function PopupWidgetForReplay.PopupWidgetForReplay_C.BndEvt__TslCommonButton_0_K2Node_ComponentBoundEvent_102_OnButtonClickedEvent__DelegateSignature // BlueprintEvent // @ game+0x33e45c
	void BndEvt__TslCommonButton_1_K2Node_ComponentBoundEvent_155_OnButtonClickedEvent__DelegateSignature(); // Function PopupWidgetForReplay.PopupWidgetForReplay_C.BndEvt__TslCommonButton_1_K2Node_ComponentBoundEvent_155_OnButtonClickedEvent__DelegateSignature // BlueprintEvent // @ game+0x33e45c
	void ExecuteUbergraph_PopupWidgetForReplay(int32 EntryPoint); // Function PopupWidgetForReplay.PopupWidgetForReplay_C.ExecuteUbergraph_PopupWidgetForReplay // HasDefaults // @ game+0x33e45c
	void HideMyself__DelegateSignature(); // Function PopupWidgetForReplay.PopupWidgetForReplay_C.HideMyself__DelegateSignature // Public|Delegate|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void ButtonClickDispatcher__DelegateSignature(enum class EPopupButtonID NewParam); // Function PopupWidgetForReplay.PopupWidgetForReplay_C.ButtonClickDispatcher__DelegateSignature // Public|Delegate|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
};

