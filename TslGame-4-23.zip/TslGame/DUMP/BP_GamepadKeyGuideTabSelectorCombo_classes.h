// WidgetBlueprintGeneratedClass BP_GamepadKeyGuideTabSelectorCombo.BP_GamepadKeyGuideTabSelectorCombo_C
// Size: 0x4a8 (Inherited: 0x478)
struct UBP_GamepadKeyGuideTabSelectorCombo_C : UTslTabSelectorWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x478(0x08)
	struct UBP_GamepadKeyIconWidget_C* BP_GamepadKeyIconWidget; // 0x480(0x08)
	struct UBP_GamepadKeyIconWidget_C* BP_GamepadKeyIconWidget_1; // 0x488(0x08)
	struct UBP_GamepadOptionTabWidget_C* Tab0; // 0x490(0x08)
	struct UBP_GamepadOptionTabWidget_C* Tab1; // 0x498(0x08)
	struct UHorizontalBox* TabHorizontalBox; // 0x4a0(0x08)

	void Construct(); // Function BP_GamepadKeyGuideTabSelectorCombo.BP_GamepadKeyGuideTabSelectorCombo_C.Construct // BlueprintCosmetic|Event|Public|BlueprintEvent // @ game+0x33e45c
	void ExecuteUbergraph_BP_GamepadKeyGuideTabSelectorCombo(int32 EntryPoint); // Function BP_GamepadKeyGuideTabSelectorCombo.BP_GamepadKeyGuideTabSelectorCombo_C.ExecuteUbergraph_BP_GamepadKeyGuideTabSelectorCombo // HasDefaults // @ game+0x33e45c
};

