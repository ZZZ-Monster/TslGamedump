// BlueprintGeneratedClass BP_SandboxManager.BP_SandboxManager_C
// Size: 0x4ec (Inherited: 0x4d0)
struct UBP_SandboxManager_C : UTslSandboxManager {
	struct UCurveFloat* Flying_Threshold; // 0x4d0(0x08)
	float OldWeight; // 0x4d8(0x04)
	float CurWeight; // 0x4dc(0x04)
	struct UParticleSystemComponent* LocPSC; // 0x4e0(0x08)
	float LocDeltaSeconds; // 0x4e8(0x04)
};

