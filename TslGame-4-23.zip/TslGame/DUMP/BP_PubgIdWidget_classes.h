// WidgetBlueprintGeneratedClass BP_PubgIdWidget.BP_PubgIdWidget_C
// Size: 0x590 (Inherited: 0x588)
struct UBP_PubgIdWidget_C : UTslPubgIdWidget {
	struct UTextBlock* PlayerNameText; // 0x588(0x08)
};

