// Class GameplayTags.EditableGameplayTagQuery
// Size: 0xa8 (Inherited: 0x38)
struct UEditableGameplayTagQuery : UObject {
	struct FString UserDescription; // 0x38(0x10)
	char pad_48[0x10]; // 0x48(0x10)
	struct UEditableGameplayTagQueryExpression* RootExpression; // 0x58(0x08)
	struct FGameplayTagQuery TagQueryExportText_Helper; // 0x60(0x48)
};

// Class GameplayTags.EditableGameplayTagQueryExpression
// Size: 0x38 (Inherited: 0x38)
struct UEditableGameplayTagQueryExpression : UObject {
};

// Class GameplayTags.EditableGameplayTagQueryExpression_AnyTagsMatch
// Size: 0x58 (Inherited: 0x38)
struct UEditableGameplayTagQueryExpression_AnyTagsMatch : UEditableGameplayTagQueryExpression {
	struct FGameplayTagContainer Tags; // 0x38(0x20)
};

// Class GameplayTags.EditableGameplayTagQueryExpression_AllTagsMatch
// Size: 0x58 (Inherited: 0x38)
struct UEditableGameplayTagQueryExpression_AllTagsMatch : UEditableGameplayTagQueryExpression {
	struct FGameplayTagContainer Tags; // 0x38(0x20)
};

// Class GameplayTags.EditableGameplayTagQueryExpression_NoTagsMatch
// Size: 0x58 (Inherited: 0x38)
struct UEditableGameplayTagQueryExpression_NoTagsMatch : UEditableGameplayTagQueryExpression {
	struct FGameplayTagContainer Tags; // 0x38(0x20)
};

// Class GameplayTags.EditableGameplayTagQueryExpression_AnyExprMatch
// Size: 0x48 (Inherited: 0x38)
struct UEditableGameplayTagQueryExpression_AnyExprMatch : UEditableGameplayTagQueryExpression {
	struct TArray<struct UEditableGameplayTagQueryExpression*> Expressions; // 0x38(0x10)
};

// Class GameplayTags.EditableGameplayTagQueryExpression_AllExprMatch
// Size: 0x48 (Inherited: 0x38)
struct UEditableGameplayTagQueryExpression_AllExprMatch : UEditableGameplayTagQueryExpression {
	struct TArray<struct UEditableGameplayTagQueryExpression*> Expressions; // 0x38(0x10)
};

// Class GameplayTags.EditableGameplayTagQueryExpression_NoExprMatch
// Size: 0x48 (Inherited: 0x38)
struct UEditableGameplayTagQueryExpression_NoExprMatch : UEditableGameplayTagQueryExpression {
	struct TArray<struct UEditableGameplayTagQueryExpression*> Expressions; // 0x38(0x10)
};

// Class GameplayTags.GameplayTagAssetInterface
// Size: 0x38 (Inherited: 0x38)
struct UGameplayTagAssetInterface : UInterface {

	bool HasMatchingGameplayTag(struct FGameplayTag TagToCheck); // Function GameplayTags.GameplayTagAssetInterface.HasMatchingGameplayTag // Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x540fb54
	bool HasAnyMatchingGameplayTags(struct FGameplayTagContainer TagContainer); // Function GameplayTags.GameplayTagAssetInterface.HasAnyMatchingGameplayTags // Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const // @ game+0x540f81c
	bool HasAllMatchingGameplayTags(struct FGameplayTagContainer TagContainer); // Function GameplayTags.GameplayTagAssetInterface.HasAllMatchingGameplayTags // Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const // @ game+0x540f38c
	void GetOwnedGameplayTags(struct FGameplayTagContainer TagContainer); // Function GameplayTags.GameplayTagAssetInterface.GetOwnedGameplayTags // Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const // @ game+0x540f20c
};

// Class GameplayTags.BlueprintGameplayTagLibrary
// Size: 0x38 (Inherited: 0x38)
struct UBlueprintGameplayTagLibrary : UBlueprintFunctionLibrary {

	bool RemoveGameplayTag(struct FGameplayTagContainer TagContainer, struct FGameplayTag Tag); // Function GameplayTags.BlueprintGameplayTagLibrary.RemoveGameplayTag // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x5410c6c
	bool NotEqual_TagTag(struct FGameplayTag A, struct FString B); // Function GameplayTags.BlueprintGameplayTagLibrary.NotEqual_TagTag // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5410b24
	bool NotEqual_TagContainerTagContainer(struct FGameplayTagContainer A, struct FString B); // Function GameplayTags.BlueprintGameplayTagLibrary.NotEqual_TagContainerTagContainer // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5410984
	bool NotEqual_GameplayTagContainer(struct FGameplayTagContainer A, struct FGameplayTagContainer B); // Function GameplayTags.BlueprintGameplayTagLibrary.NotEqual_GameplayTagContainer // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x54107fc
	bool NotEqual_GameplayTag(struct FGameplayTag A, struct FGameplayTag B); // Function GameplayTags.BlueprintGameplayTagLibrary.NotEqual_GameplayTag // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5410724
	bool MatchesTag(struct FGameplayTag TagOne, struct FGameplayTag TagTwo, bool bExactMatch); // Function GameplayTags.BlueprintGameplayTagLibrary.MatchesTag // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x54105dc
	bool MatchesAnyTags(struct FGameplayTag TagOne, struct FGameplayTagContainer OtherContainer, bool bExactMatch); // Function GameplayTags.BlueprintGameplayTagLibrary.MatchesAnyTags // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x5410434
	struct FGameplayTagContainer MakeLiteralGameplayTagContainer(struct FGameplayTagContainer Value); // Function GameplayTags.BlueprintGameplayTagLibrary.MakeLiteralGameplayTagContainer // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x54102b4
	struct FGameplayTag MakeLiteralGameplayTag(struct FGameplayTag Value); // Function GameplayTags.BlueprintGameplayTagLibrary.MakeLiteralGameplayTag // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x541022c
	struct FGameplayTagQuery MakeGameplayTagQuery(struct FGameplayTagQuery TagQuery); // Function GameplayTags.BlueprintGameplayTagLibrary.MakeGameplayTagQuery // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x541008c
	struct FGameplayTagContainer MakeGameplayTagContainerFromTag(struct FGameplayTag SingleTag); // Function GameplayTags.BlueprintGameplayTagLibrary.MakeGameplayTagContainerFromTag // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x540ffb0
	struct FGameplayTagContainer MakeGameplayTagContainerFromArray(struct TArray<struct FGameplayTag> GameplayTags); // Function GameplayTags.BlueprintGameplayTagLibrary.MakeGameplayTagContainerFromArray // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x540fe5c
	bool IsGameplayTagValid(struct FGameplayTag GameplayTag); // Function GameplayTags.BlueprintGameplayTagLibrary.IsGameplayTagValid // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x540fdc4
	bool HasTag(struct FGameplayTagContainer TagContainer, struct FGameplayTag Tag, bool bExactMatch); // Function GameplayTags.BlueprintGameplayTagLibrary.HasTag // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x540fbf8
	bool HasAnyTags(struct FGameplayTagContainer TagContainer, struct FGameplayTagContainer OtherContainer, bool bExactMatch); // Function GameplayTags.BlueprintGameplayTagLibrary.HasAnyTags // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x540f90c
	bool HasAllTags(struct FGameplayTagContainer TagContainer, struct FGameplayTagContainer OtherContainer, bool bExactMatch); // Function GameplayTags.BlueprintGameplayTagLibrary.HasAllTags // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x540f5d4
	bool HasAllMatchingGameplayTags(TScriptInterface<struct UGameplayTagAssetInterface> TagContainerInterface, struct FGameplayTagContainer OtherContainer); // Function GameplayTags.BlueprintGameplayTagLibrary.HasAllMatchingGameplayTags // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x540f47c
	struct FName GetTagName(struct FGameplayTag GameplayTag); // Function GameplayTags.BlueprintGameplayTagLibrary.GetTagName // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x540f2f0
	int32 GetNumGameplayTagsInContainer(struct FGameplayTagContainer TagContainer); // Function GameplayTags.BlueprintGameplayTagLibrary.GetNumGameplayTagsInContainer // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x540f12c
	struct FString GetDebugStringFromGameplayTagContainer(struct FGameplayTagContainer TagContainer); // Function GameplayTags.BlueprintGameplayTagLibrary.GetDebugStringFromGameplayTagContainer // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x540eff0
	struct FString GetDebugStringFromGameplayTag(struct FGameplayTag GameplayTag); // Function GameplayTags.BlueprintGameplayTagLibrary.GetDebugStringFromGameplayTag // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x540eef8
	void GetAllActorsOfClassMatchingTagQuery(struct UObject* WorldContextObject, struct UClass* ActorClass, struct FGameplayTagQuery GameplayTagQuery, struct TArray<struct AActor*> OutActors); // Function GameplayTags.BlueprintGameplayTagLibrary.GetAllActorsOfClassMatchingTagQuery // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x540ecfc
	bool EqualEqual_GameplayTagContainer(struct FGameplayTagContainer A, struct FGameplayTagContainer B); // Function GameplayTags.BlueprintGameplayTagLibrary.EqualEqual_GameplayTagContainer // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x540eb78
	bool EqualEqual_GameplayTag(struct FGameplayTag A, struct FGameplayTag B); // Function GameplayTags.BlueprintGameplayTagLibrary.EqualEqual_GameplayTag // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x540eaa0
	bool DoesTagAssetInterfaceHaveTag(TScriptInterface<struct UGameplayTagAssetInterface> TagContainerInterface, struct FGameplayTag Tag); // Function GameplayTags.BlueprintGameplayTagLibrary.DoesTagAssetInterfaceHaveTag // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x540e9a4
	bool DoesContainerMatchTagQuery(struct FGameplayTagContainer TagContainer, struct FGameplayTagQuery TagQuery); // Function GameplayTags.BlueprintGameplayTagLibrary.DoesContainerMatchTagQuery // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x540e818
	void BreakGameplayTagContainer(struct FGameplayTagContainer GameplayTagContainer, struct TArray<struct FGameplayTag> GameplayTags); // Function GameplayTags.BlueprintGameplayTagLibrary.BreakGameplayTagContainer // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x540e6b0
	void AppendGameplayTagContainers(struct FGameplayTagContainer InOutTagContainer, struct FGameplayTagContainer InTagContainer); // Function GameplayTags.BlueprintGameplayTagLibrary.AppendGameplayTagContainers // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x540e530
	void AddGameplayTag(struct FGameplayTagContainer TagContainer, struct FGameplayTag Tag); // Function GameplayTags.BlueprintGameplayTagLibrary.AddGameplayTag // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x540e3f4
};

// Class GameplayTags.GameplayTagsManager
// Size: 0x190 (Inherited: 0x38)
struct UGameplayTagsManager : UObject {
	char pad_38[0x80]; // 0x38(0x80)
	struct TArray<struct FGameplayTagSource> TagSources; // 0xb8(0x10)
	char pad_C8[0x68]; // 0xc8(0x68)
	struct TArray<struct UDataTable*> GameplayTagTables; // 0x130(0x10)
	char pad_140[0x50]; // 0x140(0x50)
};

// Class GameplayTags.GameplayTagsList
// Size: 0x58 (Inherited: 0x38)
struct UGameplayTagsList : UObject {
	struct FString ConfigFileName; // 0x38(0x10)
	struct TArray<struct FGameplayTagTableRow> GameplayTagList; // 0x48(0x10)
};

// Class GameplayTags.GameplayTagsSettings
// Size: 0xb0 (Inherited: 0x58)
struct UGameplayTagsSettings : UGameplayTagsList {
	bool ImportTagsFromConfig; // 0x58(0x01)
	bool WarnOnInvalidTags; // 0x59(0x01)
	char pad_5A[0x6]; // 0x5a(0x06)
	struct TArray<struct FGameplayTagCategoryRemap> CategoryRemapping; // 0x60(0x10)
	bool FastReplication; // 0x70(0x01)
	char pad_71[0x7]; // 0x71(0x07)
	struct TArray<struct FStringAssetReference> GameplayTagTableList; // 0x78(0x10)
	struct TArray<struct FGameplayTagRedirect> GameplayTagRedirects; // 0x88(0x10)
	struct TArray<struct FName> CommonlyReplicatedTags; // 0x98(0x10)
	int32 NumBitsForContainerSize; // 0xa8(0x04)
	int32 NetIndexFirstBitSegment; // 0xac(0x04)
};

// Class GameplayTags.GameplayTagsDeveloperSettings
// Size: 0x48 (Inherited: 0x38)
struct UGameplayTagsDeveloperSettings : UObject {
	struct FString DeveloperConfigName; // 0x38(0x10)
};

