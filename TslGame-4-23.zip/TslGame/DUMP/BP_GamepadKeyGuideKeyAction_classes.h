// WidgetBlueprintGeneratedClass BP_GamepadKeyGuideKeyAction.BP_GamepadKeyGuideKeyAction_C
// Size: 0x538 (Inherited: 0x4d8)
struct UBP_GamepadKeyGuideKeyAction_C : UTslGamepadKeyGuideActionWidget {
	struct UImage* CombinationIcon1; // 0x4d8(0x08)
	struct UImage* CombinationIcon2; // 0x4e0(0x08)
	struct UBP_GamepadKeyTapIconWidget_C* FirstKeyIcon; // 0x4e8(0x08)
	struct UBP_GamepadKeyIconWidget_C* SecondKeyIcon; // 0x4f0(0x08)
	struct UBP_GamepadKeyIconWidget_C* ThirdKeyIcon; // 0x4f8(0x08)
	int32 FirstKeyIndex; // 0x500(0x04)
	char pad_504[0x4]; // 0x504(0x04)
	struct FKey SecondKey; // 0x508(0x18)
	struct FKey ThirdKey; // 0x520(0x18)
};

