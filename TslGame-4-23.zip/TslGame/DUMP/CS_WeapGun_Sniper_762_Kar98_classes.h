// BlueprintGeneratedClass CS_WeapGun_Sniper_762_Kar98.CS_WeapGun_Sniper_762_Kar98_C
// Size: 0x170 (Inherited: 0x170)
struct UCS_WeapGun_Sniper_762_Kar98_C : UCameraShake {
};

