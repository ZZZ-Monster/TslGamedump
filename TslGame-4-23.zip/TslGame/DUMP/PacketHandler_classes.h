// Class PacketHandler.HandlerComponentFactory
// Size: 0x38 (Inherited: 0x38)
struct UHandlerComponentFactory : UObject {
};

