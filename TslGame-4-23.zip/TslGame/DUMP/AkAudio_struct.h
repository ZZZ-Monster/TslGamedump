// Enum AkAudio.EOcclusionCalculationMode
enum class EOcclusionCalculationMode : uint8 {
	SingleRaycast,
	MultiRaycast,
	EOcclusionCalculationMode_MAX,
};

// Enum AkAudio.EOcclusionMode
enum class EOcclusionMode : uint8 {
	NoOcclusion,
	OnPostEventWithRefresh,
	OnPostEvent,
	OnlyRefresh,
	EOcclusionMode_MAX,
};

// Enum AkAudio.ESoundVolumeShape
enum class ESoundVolumeShape : uint8 {
	Box,
	Sphere,
	Capsule,
	ESoundVolumeShape_MAX,
};

// Enum AkAudio.EAkIgnoreRolloffDirection
enum class EAkIgnoreRolloffDirection : uint8 {
	None,
	Left,
	Right,
	Front,
	Back,
	LeftAndRight,
	LeftAndFront,
	LeftAndBack,
	RightAndFront,
	RightAndBack,
	BackAndFront,
	EAkIgnoreRolloffDirection_MAX,
};

// ScriptStruct AkAudio.AkOcclusionSettings
// Size: 0x10 (Inherited: 0x00)
struct FAkOcclusionSettings {
	enum class EOcclusionMode Mode; // 0x00(0x01)
	enum class EOcclusionCalculationMode CalculationMode; // 0x01(0x01)
	char pad_2[0x2]; // 0x02(0x02)
	float RefreshInterval; // 0x04(0x04)
	float MinOcclusionDistance; // 0x08(0x04)
	float MaxOcclusionDistance; // 0x0c(0x04)
};

// ScriptStruct AkAudio.AkSoundVolumeBase
// Size: 0x80 (Inherited: 0x00)
struct FAkSoundVolumeBase {
	char pad_0[0x8]; // 0x00(0x08)
	struct FRotator Rotation; // 0x08(0x0c)
	struct FVector Location; // 0x14(0x0c)
	char pad_20[0x9]; // 0x20(0x09)
	enum class ESoundVolumeShape Shape; // 0x29(0x01)
	char pad_2A[0x2]; // 0x2a(0x02)
	struct FVector BoxExtents; // 0x2c(0x0c)
	float Radius; // 0x38(0x04)
	float CapsuleHalfHeight; // 0x3c(0x04)
	char pad_40[0x40]; // 0x40(0x40)
};

// ScriptStruct AkAudio.AkReverbSoundVolume
// Size: 0x158 (Inherited: 0x80)
struct FAkReverbSoundVolume : FAkSoundVolumeBase {
	struct TMap<struct UAkAuxBus*, float> ReverbSends; // 0x80(0x50)
	struct UAkSoundVolumeRTPCs* RTPCs; // 0xd0(0x08)
	int32 Priority; // 0xd8(0x04)
	float RolloffDistance; // 0xdc(0x04)
	bool bNoVerticalRolloff; // 0xe0(0x01)
	char pad_E1[0x3]; // 0xe1(0x03)
	float IndoorsAmount; // 0xe4(0x04)
	enum class EAkIgnoreRolloffDirection IgnoreRolloffDir; // 0xe8(0x01)
	char pad_E9[0x6f]; // 0xe9(0x6f)
};

// ScriptStruct AkAudio.AkReverbSoundVolumePortal
// Size: 0xf0 (Inherited: 0x80)
struct FAkReverbSoundVolumePortal : FAkSoundVolumeBase {
	float Openness; // 0x80(0x04)
	float MinOpenness; // 0x84(0x04)
	float RolloffDistance; // 0x88(0x04)
	float Directionality; // 0x8c(0x04)
	char pad_90[0x60]; // 0x90(0x60)
};

// ScriptStruct AkAudio.AkVolumesData
// Size: 0x20 (Inherited: 0x00)
struct FAkVolumesData {
	struct TArray<struct FAkReverbSoundVolume> Volumes; // 0x00(0x10)
	struct TArray<struct FAkReverbSoundVolumePortal> Portals; // 0x10(0x10)
};

// ScriptStruct AkAudio.AkSoundVolumeRTPC
// Size: 0x18 (Inherited: 0x00)
struct FAkSoundVolumeRTPC {
	struct FString Name; // 0x00(0x10)
	float Value; // 0x10(0x04)
	char pad_14[0x4]; // 0x14(0x04)
};

// ScriptStruct AkAudio.AkReverbSoundPortalsBakedData
// Size: 0x08 (Inherited: 0x00)
struct FAkReverbSoundPortalsBakedData {
	int32 FrontSideVolume; // 0x00(0x04)
	int32 BackSideVolume; // 0x04(0x04)
};

// ScriptStruct AkAudio.AkReverbSoundVolumeBakedData
// Size: 0x18 (Inherited: 0x00)
struct FAkReverbSoundVolumeBakedData {
	struct TArray<int32> OverlappingVolumes; // 0x00(0x10)
	bool AreConnectedPortalsBaked; // 0x10(0x01)
	char pad_11[0x7]; // 0x11(0x07)
};

// ScriptStruct AkAudio.AkAudioEventTrackKey
// Size: 0x20 (Inherited: 0x00)
struct FAkAudioEventTrackKey {
	float Time; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct UAkAudioEvent* AkAudioEvent; // 0x08(0x08)
	struct FString EventName; // 0x10(0x10)
};

// ScriptStruct AkAudio.MovieSceneAkAudioEventTemplate
// Size: 0x20 (Inherited: 0x00)
struct FMovieSceneAkAudioEventTemplate {
	char pad_0[0x18]; // 0x00(0x18)
	struct UMovieSceneAkAudioEventSection* Section; // 0x18(0x08)
};

// ScriptStruct AkAudio.MovieSceneAkAudioRTPCTemplate
// Size: 0x20 (Inherited: 0x00)
struct FMovieSceneAkAudioRTPCTemplate {
	char pad_0[0x18]; // 0x00(0x18)
	struct UMovieSceneAkAudioRTPCSection* Section; // 0x18(0x08)
};

// ScriptStruct AkAudio.MovieSceneAkAudioRTPCSectionData
// Size: 0x80 (Inherited: 0x00)
struct FMovieSceneAkAudioRTPCSectionData {
	struct FString RTPCName; // 0x00(0x10)
	struct FRichCurve RTPCCurve; // 0x10(0x70)
};

