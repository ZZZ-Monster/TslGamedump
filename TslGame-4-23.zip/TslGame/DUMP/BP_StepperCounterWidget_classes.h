// WidgetBlueprintGeneratedClass BP_StepperCounterWidget.BP_StepperCounterWidget_C
// Size: 0x480 (Inherited: 0x468)
struct UBP_StepperCounterWidget_C : UTslStepperCounterWidget {
	struct UBP_StepperCounterContentWidget_C* BP_StepperCounterContentWidget; // 0x468(0x08)
	struct UBP_StepperCounterContentWidget_C* BP_StepperCounterContentWidget_1; // 0x470(0x08)
	struct UHorizontalBox* ContentsHorizontalBox; // 0x478(0x08)
};

