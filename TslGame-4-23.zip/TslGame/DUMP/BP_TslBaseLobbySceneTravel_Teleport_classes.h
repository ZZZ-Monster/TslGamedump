// BlueprintGeneratedClass BP_TslBaseLobbySceneTravel_Teleport.BP_TslBaseLobbySceneTravel_Teleport_C
// Size: 0x490 (Inherited: 0x480)
struct ABP_TslBaseLobbySceneTravel_Teleport_C : ATslBaseLobbySceneTravel {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x480(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x488(0x08)

	void UserConstructionScript(); // Function BP_TslBaseLobbySceneTravel_Teleport.BP_TslBaseLobbySceneTravel_Teleport_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void OnStartTravel(); // Function BP_TslBaseLobbySceneTravel_Teleport.BP_TslBaseLobbySceneTravel_Teleport_C.OnStartTravel // Event|Public|BlueprintEvent // @ game+0x33e45c
	void ExecuteUbergraph_BP_TslBaseLobbySceneTravel_Teleport(int32 EntryPoint); // Function BP_TslBaseLobbySceneTravel_Teleport.BP_TslBaseLobbySceneTravel_Teleport_C.ExecuteUbergraph_BP_TslBaseLobbySceneTravel_Teleport //  // @ game+0x33e45c
};

