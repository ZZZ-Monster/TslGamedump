// WidgetBlueprintGeneratedClass InteractInfoTextWidget.InteractInfoTextWidget_C
// Size: 0x5c8 (Inherited: 0x590)
struct UInteractInfoTextWidget_C : UTslInteractInfoTextWidget {
	struct UWidgetAnimation* Blinking; // 0x590(0x08)
	struct UHorizontalBox* InteractInfoCancelMsgBox; // 0x598(0x08)
	struct UBorder* InteractInfoCancelMsgLayer; // 0x5a0(0x08)
	struct UTextBlock* InteractInfoText; // 0x5a8(0x08)
	struct UBorder* InteractInfoTextBox; // 0x5b0(0x08)
	struct UWidgetSwitcher* InteractKeySwitcher; // 0x5b8(0x08)
	struct UTextBlock* InteractText; // 0x5c0(0x08)
};

