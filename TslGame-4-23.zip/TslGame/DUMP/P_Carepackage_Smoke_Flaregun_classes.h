// BlueprintGeneratedClass P_Carepackage_Smoke_Flaregun.P_Carepackage_Smoke_Flaregun_C
// Size: 0x4f0 (Inherited: 0x4f0)
struct AP_Carepackage_Smoke_Flaregun_C : AP_Carepackage_Smoke_C {
};

