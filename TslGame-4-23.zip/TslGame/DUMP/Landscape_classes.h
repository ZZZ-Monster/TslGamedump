// Class Landscape.ControlPointMeshComponent
// Size: 0xb80 (Inherited: 0xb80)
struct UControlPointMeshComponent : UStaticMeshComponent {
};

// Class Landscape.LandscapeComponent
// Size: 0xb40 (Inherited: 0x9d0)
struct ULandscapeComponent : UPrimitiveComponent {
	int32 SectionBaseX; // 0x9d0(0x04)
	int32 SectionBaseY; // 0x9d4(0x04)
	int32 ComponentSizeQuads; // 0x9d8(0x04)
	int32 SubsectionSizeQuads; // 0x9dc(0x04)
	int32 NumSubsections; // 0x9e0(0x04)
	char pad_9E4[0x4]; // 0x9e4(0x04)
	struct UMaterialInterface* OverrideMaterial; // 0x9e8(0x08)
	struct UMaterialInterface* OverrideHoleMaterial; // 0x9f0(0x08)
	struct TArray<struct UMaterialInstanceConstant*> MaterialInstances; // 0x9f8(0x10)
	struct TArray<struct FWeightmapLayerAllocationInfo> WeightmapLayerAllocations; // 0xa08(0x10)
	struct TArray<struct UTexture2D*> WeightmapTextures; // 0xa18(0x10)
	struct UTexture2D* XYOffsetmapTexture; // 0xa28(0x08)
	struct FIntPoint HeightmapOffset; // 0xa30(0x08)
	char pad_A38[0x8]; // 0xa38(0x08)
	struct FVector4 WeightmapScaleBias; // 0xa40(0x10)
	float WeightmapSubsectionOffset; // 0xa50(0x04)
	char pad_A54[0x4]; // 0xa54(0x04)
	struct UTexture2D* HeightmapTexture; // 0xa58(0x08)
	struct UTexture2D* NormalmapTexture; // 0xa60(0x08)
	struct FBox CachedLocalBox; // 0xa68(0x1c)
	struct ULandscapeHeightfieldCollisionComponent* CollisionComponent; // 0xa84(0x1c)
	struct FGuid MapBuildDataId; // 0xaa0(0x10)
	struct TArray<struct FGuid> IrrelevantLights; // 0xab0(0x10)
	int32 CollisionMipLevel; // 0xac0(0x04)
	int32 SimpleCollisionMipLevel; // 0xac4(0x04)
	float NegativeZBoundsExtension; // 0xac8(0x04)
	float PositiveZBoundsExtension; // 0xacc(0x04)
	float StaticLightingResolution; // 0xad0(0x04)
	int32 ForcedLOD; // 0xad4(0x04)
	int32 LODBias; // 0xad8(0x04)
	struct FGuid StateId; // 0xadc(0x10)
	struct FGuid BakedTextureMaterialGuid; // 0xaec(0x10)
	char pad_AFC[0x4]; // 0xafc(0x04)
	struct UTexture2D* GIBakedBaseColorTexture; // 0xb00(0x08)
	bool bRemoveGrass; // 0xb08(0x01)
	bool MobileBlendableLayerMask; // 0xb09(0x01)
	char pad_B0A[0x6]; // 0xb0a(0x06)
	struct UMaterialInterface* MobileMaterialInterface; // 0xb10(0x08)
	struct UTexture2D* MobileWeightNormalmapTexture; // 0xb18(0x08)
	char pad_B20[0x20]; // 0xb20(0x20)
};

// Class Landscape.LandscapeGizmoActor
// Size: 0x3f0 (Inherited: 0x3f0)
struct ALandscapeGizmoActor : AActor {
};

// Class Landscape.LandscapeGizmoActiveActor
// Size: 0x440 (Inherited: 0x3f0)
struct ALandscapeGizmoActiveActor : ALandscapeGizmoActor {
	char pad_3F0[0x50]; // 0x3f0(0x50)
};

// Class Landscape.LandscapeGizmoRenderComponent
// Size: 0x9d0 (Inherited: 0x9d0)
struct ULandscapeGizmoRenderComponent : UPrimitiveComponent {
};

// Class Landscape.LandscapeGrassType
// Size: 0x68 (Inherited: 0x38)
struct ULandscapeGrassType : UObject {
	struct TArray<struct FGrassVariety> GrassVarieties; // 0x38(0x10)
	struct UStaticMesh* GrassMesh; // 0x48(0x08)
	float GrassDensity; // 0x50(0x04)
	float PlacementJitter; // 0x54(0x04)
	int32 StartCullDistance; // 0x58(0x04)
	int32 EndCullDistance; // 0x5c(0x04)
	bool RandomRotation; // 0x60(0x01)
	bool AlignToSurface; // 0x61(0x01)
	char pad_62[0x6]; // 0x62(0x06)
};

// Class Landscape.LandscapeHeightfieldCollisionComponent
// Size: 0xb40 (Inherited: 0x9d0)
struct ULandscapeHeightfieldCollisionComponent : UPrimitiveComponent {
	struct TArray<struct ULandscapeLayerInfoObject*> ComponentLayerInfos; // 0x9d0(0x10)
	int32 SectionBaseX; // 0x9e0(0x04)
	int32 SectionBaseY; // 0x9e4(0x04)
	int32 CollisionSizeQuads; // 0x9e8(0x04)
	float CollisionScale; // 0x9ec(0x04)
	int32 SimpleCollisionSizeQuads; // 0x9f0(0x04)
	int32 CollisionLODSizeQuads; // 0x9f4(0x04)
	struct TArray<bool> CollisionQuadFlags; // 0x9f8(0x10)
	struct FGuid HeightfieldGuid; // 0xa08(0x10)
	struct FBox CachedLocalBox; // 0xa18(0x1c)
	struct ULandscapeComponent* RenderComponent; // 0xa34(0x1c)
	char pad_A50[0x80]; // 0xa50(0x80)
	struct TArray<struct UPhysicalMaterial*> CookedPhysicalMaterials; // 0xad0(0x10)
	char pad_AE0[0x60]; // 0xae0(0x60)
};

// Class Landscape.LandscapeMeshCollisionComponent
// Size: 0xb50 (Inherited: 0xb40)
struct ULandscapeMeshCollisionComponent : ULandscapeHeightfieldCollisionComponent {
	struct FGuid MeshGuid; // 0xb38(0x10)
};

// Class Landscape.LandscapeInfo
// Size: 0x210 (Inherited: 0x38)
struct ULandscapeInfo : UObject {
	struct ALandscape* LandscapeActor; // 0x38(0x1c)
	struct FGuid LandscapeGuid; // 0x54(0x10)
	int32 ComponentSizeQuads; // 0x64(0x04)
	int32 SubsectionSizeQuads; // 0x68(0x04)
	int32 ComponentNumSubsections; // 0x6c(0x04)
	struct FVector DrawScale; // 0x70(0x0c)
	char pad_7C[0x54]; // 0x7c(0x54)
	SetProperty Proxies; // 0xd0(0x50)
	char pad_120[0xf0]; // 0x120(0xf0)
};

// Class Landscape.LandscapeInfoMap
// Size: 0x88 (Inherited: 0x38)
struct ULandscapeInfoMap : UObject {
	char pad_38[0x50]; // 0x38(0x50)
};

// Class Landscape.LandscapeLayerInfoObject
// Size: 0x60 (Inherited: 0x38)
struct ULandscapeLayerInfoObject : UObject {
	struct FName LayerName; // 0x38(0x08)
	struct UPhysicalMaterial* PhysMaterial; // 0x40(0x08)
	float Hardness; // 0x48(0x04)
	struct FLinearColor LayerUsageDebugColor; // 0x4c(0x10)
	char pad_5C[0x4]; // 0x5c(0x04)
};

// Class Landscape.LandscapeMaterialInstanceConstant
// Size: 0x1f8 (Inherited: 0x1f0)
struct ULandscapeMaterialInstanceConstant : UMaterialInstanceConstant {
	char bIsLayerThumbnail : 1; // 0x1f0(0x01)
	char bDisableTessellation : 1; // 0x1f0(0x01)
	char pad_1F0_2 : 6; // 0x1f0(0x01)
	char pad_1F1[0x7]; // 0x1f1(0x07)
};

// Class Landscape.LandscapeMaterialInstanceDynamic
// Size: 0x248 (Inherited: 0x1f8)
struct ULandscapeMaterialInstanceDynamic : ULandscapeMaterialInstanceConstant {
	char pad_1F8[0x50]; // 0x1f8(0x50)
};

// Class Landscape.LandscapeMeshProxyActor
// Size: 0x3f8 (Inherited: 0x3f0)
struct ALandscapeMeshProxyActor : AActor {
	struct ULandscapeMeshProxyComponent* LandscapeMeshProxyComponent; // 0x3f0(0x08)
};

// Class Landscape.LandscapeMeshProxyComponent
// Size: 0xba0 (Inherited: 0xb80)
struct ULandscapeMeshProxyComponent : UStaticMeshComponent {
	struct FGuid LandscapeGuid; // 0xb78(0x10)
	struct TArray<struct FIntPoint> ProxyComponentBases; // 0xb88(0x10)
	int8 ProxyLOD; // 0xb98(0x01)
};

// Class Landscape.LandscapeProxy
// Size: 0x830 (Inherited: 0x3f0)
struct ALandscapeProxy : AActor {
	struct FGuid LandscapeGuid; // 0x3f0(0x10)
	struct ULandscapeSplinesComponent* SplineComponent; // 0x400(0x08)
	int32 ComponentSizeQuads; // 0x408(0x04)
	int32 SubsectionSizeQuads; // 0x40c(0x04)
	int32 NumSubsections; // 0x410(0x04)
	struct FIntPoint LandscapeSectionOffset; // 0x414(0x08)
	int32 MaxLODLevel; // 0x41c(0x04)
	float LODDistanceFactor; // 0x420(0x04)
	enum class ELandscapeLODFalloff LODFalloff; // 0x424(0x01)
	char pad_425[0x3]; // 0x425(0x03)
	int32 StaticLightingLOD; // 0x428(0x04)
	char pad_42C[0x4]; // 0x42c(0x04)
	struct UPhysicalMaterial* DefaultPhysMaterial; // 0x430(0x08)
	float StreamingDistanceMultiplier; // 0x438(0x04)
	char pad_43C[0x4]; // 0x43c(0x04)
	struct UMaterialInterface* LandscapeMaterial; // 0x440(0x08)
	struct UMaterialInterface* LandscapeHoleMaterial; // 0x448(0x08)
	float NegativeZBoundsExtension; // 0x450(0x04)
	float PositiveZBoundsExtension; // 0x454(0x04)
	struct TArray<struct ULandscapeComponent*> LandscapeComponents; // 0x458(0x10)
	struct TArray<struct ULandscapeHeightfieldCollisionComponent*> CollisionComponents; // 0x468(0x10)
	struct TArray<struct UHierarchicalInstancedStaticMeshComponent*> FoliageComponents; // 0x478(0x10)
	char pad_488[0x60]; // 0x488(0x60)
	char bHasLandscapeGrass : 1; // 0x4e8(0x01)
	char bCastStaticShadow : 1; // 0x4e8(0x01)
	char bCastShadowAsTwoSided : 1; // 0x4e8(0x01)
	char bCastFarShadow : 1; // 0x4e8(0x01)
	char bUseMaterialPositionOffsetInStaticLighting : 1; // 0x4e8(0x01)
	char bRenderCustomDepth : 1; // 0x4e8(0x01)
	char bGenerateOverlapEvents : 1; // 0x4e8(0x01)
	char bBakeMaterialPositionOffsetIntoCollision : 1; // 0x4e8(0x01)
	char bUseLandscapeForCullingInvisibleHLODVertices : 1; // 0x4e9(0x01)
	char bUsedForNavigation : 1; // 0x4e9(0x01)
	char pad_4E9_2 : 6; // 0x4e9(0x01)
	char pad_4EA[0x2]; // 0x4ea(0x02)
	float StaticLightingResolution; // 0x4ec(0x04)
	struct FLightingChannels LightingChannels; // 0x4f0(0x03)
	char pad_4F3[0x1]; // 0x4f3(0x01)
	int32 CustomDepthStencilValue; // 0x4f4(0x04)
	struct FLightmassPrimitiveSettings LightmassSettings; // 0x4f8(0x18)
	int32 CollisionMipLevel; // 0x510(0x04)
	int32 SimpleCollisionMipLevel; // 0x514(0x04)
	float CollisionThickness; // 0x518(0x04)
	char pad_51C[0x4]; // 0x51c(0x04)
	struct FBodyInstance BodyInstance; // 0x520(0x230)
	enum class ENavDataGatheringMode NavigationGeometryGatheringMode; // 0x750(0x01)
	char pad_751[0xdf]; // 0x751(0xdf)

	void EditorApplySpline(struct USplineComponent* InSplineComponent, float StartWidth, float EndWidth, float StartSideFalloff, float EndSideFalloff, float StartRoll, float EndRoll, int32 NumSubdivisions, bool bRaiseHeights, bool bLowerHeights, struct ULandscapeLayerInfoObject* PaintLayer); // Function Landscape.LandscapeProxy.EditorApplySpline // Final|Native|Public|BlueprintCallable // @ game+0x52f1bac
	void ChangeLODDistanceFactor(float InLODDistanceFactor); // Function Landscape.LandscapeProxy.ChangeLODDistanceFactor // Native|Public|BlueprintCallable // @ game+0x4d6574c
};

// Class Landscape.Landscape
// Size: 0x830 (Inherited: 0x830)
struct ALandscape : ALandscapeProxy {
};

// Class Landscape.LandscapeStreamingProxy
// Size: 0x850 (Inherited: 0x830)
struct ALandscapeStreamingProxy : ALandscapeProxy {
	struct ALandscape* LandscapeActor; // 0x830(0x1c)
	char pad_84C[0x4]; // 0x84c(0x04)
};

// Class Landscape.LandscapeSplinesComponent
// Size: 0xa00 (Inherited: 0x9d0)
struct ULandscapeSplinesComponent : UPrimitiveComponent {
	struct TArray<struct ULandscapeSplineControlPoint*> ControlPoints; // 0x9d0(0x10)
	struct TArray<struct ULandscapeSplineSegment*> Segments; // 0x9e0(0x10)
	struct TArray<struct UMeshComponent*> CookedForeignMeshComponents; // 0x9f0(0x10)
};

// Class Landscape.LandscapeSplineSegment
// Size: 0xc0 (Inherited: 0x38)
struct ULandscapeSplineSegment : UObject {
	struct FLandscapeSplineSegmentConnection Connections[0x02]; // 0x38(0x30)
	struct FInterpCurveVector SplineInfo; // 0x68(0x18)
	struct TArray<struct FLandscapeSplineInterpPoint> Points; // 0x80(0x10)
	struct FBox Bounds; // 0x90(0x1c)
	char pad_AC[0x4]; // 0xac(0x04)
	struct TArray<struct USplineMeshComponent*> LocalMeshComponents; // 0xb0(0x10)
};

// Class Landscape.LandscapeSplineControlPoint
// Size: 0xa8 (Inherited: 0x38)
struct ULandscapeSplineControlPoint : UObject {
	struct FVector Location; // 0x38(0x0c)
	struct FRotator Rotation; // 0x44(0x0c)
	float Width; // 0x50(0x04)
	float SideFalloff; // 0x54(0x04)
	float EndFalloff; // 0x58(0x04)
	char pad_5C[0x4]; // 0x5c(0x04)
	struct TArray<struct FLandscapeSplineConnection> ConnectedSegments; // 0x60(0x10)
	struct TArray<struct FLandscapeSplineInterpPoint> Points; // 0x70(0x10)
	struct FBox Bounds; // 0x80(0x1c)
	char pad_9C[0x4]; // 0x9c(0x04)
	struct UControlPointMeshComponent* LocalMeshComponent; // 0xa0(0x08)
};

// Class Landscape.MaterialExpressionLandscapeBlendTA
// Size: 0x1c0 (Inherited: 0x70)
struct UMaterialExpressionLandscapeBlendTA : UMaterialExpressionTerrainBlendBase {
	struct FExpressionInput UV; // 0x70(0x38)
	struct FExpressionInput DiffuseTexture; // 0xa8(0x38)
	struct FExpressionInput NormalTexture; // 0xe0(0x38)
	struct FExpressionInput HeightTexture; // 0x118(0x38)
	struct FExpressionInput RoughnessTexture; // 0x150(0x38)
	struct TArray<struct FTerrainLayerTA> Layers; // 0x188(0x10)
	uint32 ConstCoordinate; // 0x198(0x04)
	struct FGuid ExpressionGUID; // 0x19c(0x10)
	char pad_1AC[0x14]; // 0x1ac(0x14)
};

// Class Landscape.MaterialExpressionLandscapeGrassOutput
// Size: 0x80 (Inherited: 0x70)
struct UMaterialExpressionLandscapeGrassOutput : UMaterialExpressionCustomOutput {
	struct TArray<struct FGrassInput> GrassTypes; // 0x70(0x10)
};

// Class Landscape.MaterialExpressionLandscapeLayerBlend
// Size: 0x90 (Inherited: 0x70)
struct UMaterialExpressionLandscapeLayerBlend : UMaterialExpression {
	struct TArray<struct FLayerBlendInput> Layers; // 0x70(0x10)
	struct FGuid ExpressionGUID; // 0x80(0x10)
};

// Class Landscape.MaterialExpressionLandscapeLayerCoords
// Size: 0x88 (Inherited: 0x70)
struct UMaterialExpressionLandscapeLayerCoords : UMaterialExpression {
	enum class ETerrainCoordMappingType MappingType; // 0x70(0x01)
	enum class ELandscapeCustomizedCoordType CustomUVType; // 0x71(0x01)
	char pad_72[0x2]; // 0x72(0x02)
	float MappingScale; // 0x74(0x04)
	float MappingRotation; // 0x78(0x04)
	float MappingPanU; // 0x7c(0x04)
	float MappingPanV; // 0x80(0x04)
	char pad_84[0x4]; // 0x84(0x04)
};

// Class Landscape.MaterialExpressionLandscapeLayerSample
// Size: 0x90 (Inherited: 0x70)
struct UMaterialExpressionLandscapeLayerSample : UMaterialExpression {
	struct FName ParameterName; // 0x70(0x08)
	float PreviewWeight; // 0x78(0x04)
	struct FGuid ExpressionGUID; // 0x7c(0x10)
	char pad_8C[0x4]; // 0x8c(0x04)
};

// Class Landscape.MaterialExpressionLandscapeLayerSwitch
// Size: 0x100 (Inherited: 0x70)
struct UMaterialExpressionLandscapeLayerSwitch : UMaterialExpression {
	struct FExpressionInput LayerUsed; // 0x70(0x38)
	struct FExpressionInput LayerNotUsed; // 0xa8(0x38)
	struct FName ParameterName; // 0xe0(0x08)
	char PreviewUsed : 1; // 0xe8(0x01)
	char pad_E8_1 : 7; // 0xe8(0x01)
	char pad_E9[0x3]; // 0xe9(0x03)
	struct FGuid ExpressionGUID; // 0xec(0x10)
	char pad_FC[0x4]; // 0xfc(0x04)
};

// Class Landscape.MaterialExpressionLandscapeLayerWeight
// Size: 0x108 (Inherited: 0x70)
struct UMaterialExpressionLandscapeLayerWeight : UMaterialExpression {
	struct FExpressionInput Base; // 0x70(0x38)
	struct FExpressionInput Layer; // 0xa8(0x38)
	struct FName ParameterName; // 0xe0(0x08)
	float PreviewWeight; // 0xe8(0x04)
	struct FVector ConstBase; // 0xec(0x0c)
	struct FGuid ExpressionGUID; // 0xf8(0x10)
};

// Class Landscape.MaterialExpressionLandscapeVisibilityMask
// Size: 0x80 (Inherited: 0x70)
struct UMaterialExpressionLandscapeVisibilityMask : UMaterialExpression {
	struct FGuid ExpressionGUID; // 0x70(0x10)
};

