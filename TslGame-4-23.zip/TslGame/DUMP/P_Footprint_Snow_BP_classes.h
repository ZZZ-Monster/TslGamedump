// BlueprintGeneratedClass P_Footprint_Snow_BP.P_Footprint_Snow_BP_C
// Size: 0x4f0 (Inherited: 0x4f0)
struct AP_Footprint_Snow_BP_C : ATslParticle {
};

