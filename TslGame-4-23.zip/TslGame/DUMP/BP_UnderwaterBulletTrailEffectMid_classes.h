// BlueprintGeneratedClass BP_UnderwaterBulletTrailEffectMid.BP_UnderwaterBulletTrailEffectMid_C
// Size: 0x510 (Inherited: 0x510)
struct ABP_UnderwaterBulletTrailEffectMid_C : ATslParticleBulletTrail {
};

