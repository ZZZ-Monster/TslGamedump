// BlueprintGeneratedClass Powerup_BandageOnHand.Powerup_BandageOnHand_C
// Size: 0x440 (Inherited: 0x440)
struct APowerup_BandageOnHand_C : APowerup_Base_C {
};

