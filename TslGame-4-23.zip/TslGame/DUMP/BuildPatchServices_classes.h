// Class BuildPatchServices.BuildPatchManifest
// Size: 0xe0 (Inherited: 0x38)
struct UBuildPatchManifest : UObject {
	bool ManifestFileVersion; // 0x38(0x01)
	bool bIsFileData; // 0x39(0x01)
	char pad_3A[0x2]; // 0x3a(0x02)
	uint32 AppID; // 0x3c(0x04)
	struct FString AppName; // 0x40(0x10)
	struct FString BuildVersion; // 0x50(0x10)
	struct FString LaunchExe; // 0x60(0x10)
	struct FString LaunchCommand; // 0x70(0x10)
	struct FString PrereqName; // 0x80(0x10)
	struct FString PrereqPath; // 0x90(0x10)
	struct FString PrereqArgs; // 0xa0(0x10)
	struct TArray<struct FFileManifestData> FileManifestList; // 0xb0(0x10)
	struct TArray<struct FChunkInfoData> ChunkList; // 0xc0(0x10)
	struct TArray<struct FCustomFieldData> CustomFields; // 0xd0(0x10)
};

