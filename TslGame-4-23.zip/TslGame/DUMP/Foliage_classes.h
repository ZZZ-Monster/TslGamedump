// Class Foliage.FoliageInstancedStaticMeshComponent
// Size: 0xda0 (Inherited: 0xd80)
struct UFoliageInstancedStaticMeshComponent : UHierarchicalInstancedStaticMeshComponent {
	struct FMulticastDelegate OnInstanceTakePointDamage; // 0xd80(0x10)
	struct FMulticastDelegate OnInstanceTakeRadialDamage; // 0xd90(0x10)
};

// Class Foliage.FoliageStatistics
// Size: 0x38 (Inherited: 0x38)
struct UFoliageStatistics : UBlueprintFunctionLibrary {

	int32 FoliageOverlappingSphereCount(struct UObject* WorldContextObject, struct UStaticMesh* StaticMesh, struct FVector CenterPosition, float Radius); // Function Foliage.FoliageStatistics.FoliageOverlappingSphereCount // Final|Native|Static|Public|HasDefaults|BlueprintCallable // @ game+0x52e1ff8
	int32 FoliageOverlappingBoxCount(struct UObject* WorldContextObject, struct UStaticMesh* StaticMesh, struct FBox Box); // Function Foliage.FoliageStatistics.FoliageOverlappingBoxCount // Final|Native|Static|Public|HasDefaults|BlueprintCallable // @ game+0x52e1eb4
};

// Class Foliage.FoliageType
// Size: 0x450 (Inherited: 0x38)
struct UFoliageType : UObject {
	struct FGuid UpdateGuid; // 0x38(0x10)
	float Density; // 0x48(0x04)
	float DensityAdjustmentFactor; // 0x4c(0x04)
	float Radius; // 0x50(0x04)
	enum class EFoliageScaling Scaling; // 0x54(0x01)
	char pad_55[0x3]; // 0x55(0x03)
	struct FFloatInterval ScaleX; // 0x58(0x08)
	struct FFloatInterval ScaleY; // 0x60(0x08)
	struct FFloatInterval ScaleZ; // 0x68(0x08)
	struct FFoliageVertexColorChannelMask VertexColorMaskByChannel[0x04]; // 0x70(0x30)
	enum class FoliageVertexColorMask VertexColorMask; // 0xa0(0x01)
	char pad_A1[0x3]; // 0xa1(0x03)
	float VertexColorMaskThreshold; // 0xa4(0x04)
	char VertexColorMaskInvert : 1; // 0xa8(0x01)
	char pad_A8_1 : 7; // 0xa8(0x01)
	char pad_A9[0x3]; // 0xa9(0x03)
	struct FFloatInterval ZOffset; // 0xac(0x08)
	char AlignToNormal : 1; // 0xb4(0x01)
	char pad_B4_1 : 7; // 0xb4(0x01)
	char pad_B5[0x3]; // 0xb5(0x03)
	float AlignMaxAngle; // 0xb8(0x04)
	char RandomYaw : 1; // 0xbc(0x01)
	char pad_BC_1 : 7; // 0xbc(0x01)
	char pad_BD[0x3]; // 0xbd(0x03)
	float RandomPitchAngle; // 0xc0(0x04)
	struct FFloatInterval GroundSlopeAngle; // 0xc4(0x08)
	struct FFloatInterval Height; // 0xcc(0x08)
	char pad_D4[0x4]; // 0xd4(0x04)
	struct TArray<struct FName> LandscapeLayers; // 0xd8(0x10)
	struct FName LandscapeLayer; // 0xe8(0x08)
	char CollisionWithWorld : 1; // 0xf0(0x01)
	char pad_F0_1 : 7; // 0xf0(0x01)
	char pad_F1[0x3]; // 0xf1(0x03)
	struct FVector CollisionScale; // 0xf4(0x0c)
	float MinimumLayerWeight; // 0x100(0x04)
	struct FBoxSphereBounds MeshBounds; // 0x104(0x1c)
	struct FVector LowBoundOriginRadius; // 0x120(0x0c)
	enum class EComponentMobility Mobility; // 0x12c(0x01)
	char pad_12D[0x3]; // 0x12d(0x03)
	struct FInt32Interval CullDistance; // 0x130(0x08)
	char bEnableStaticLighting : 1; // 0x138(0x01)
	char CastShadow : 1; // 0x138(0x01)
	char bAffectDynamicIndirectLighting : 1; // 0x138(0x01)
	char bAffectDistanceFieldLighting : 1; // 0x138(0x01)
	char bCastDynamicShadow : 1; // 0x138(0x01)
	char bCastStaticShadow : 1; // 0x138(0x01)
	char bCastShadowAsTwoSided : 1; // 0x138(0x01)
	char bOverrideLightMapRes : 1; // 0x138(0x01)
	char pad_139[0x3]; // 0x139(0x03)
	int32 OverriddenLightMapRes; // 0x13c(0x04)
	char bUseAsOccluder : 1; // 0x140(0x01)
	char bTreatAsGrass : 1; // 0x140(0x01)
	char bRenderCustomDepth : 1; // 0x140(0x01)
	char pad_140_3 : 5; // 0x140(0x01)
	char pad_141[0x3]; // 0x141(0x03)
	int32 CustomDepthStencilValue; // 0x144(0x04)
	char bReceivesDecals : 1; // 0x148(0x01)
	char bReceivesDecalsEx : 1; // 0x148(0x01)
	char bDecalChannelValid : 1; // 0x148(0x01)
	char pad_148_3 : 5; // 0x148(0x01)
	char pad_149[0x3]; // 0x149(0x03)
	enum class EDecalChannel DecalChannel; // 0x14c(0x01)
	enum class EHasCustomNavigableGeometry CustomNavigableGeometry; // 0x14d(0x01)
	struct FLightingChannels LightingChannels; // 0x14e(0x03)
	char pad_151[0xf]; // 0x151(0x0f)
	struct FBodyInstance BodyInstance; // 0x160(0x230)
	float CollisionRadius; // 0x390(0x04)
	float ShadeRadius; // 0x394(0x04)
	int32 NumSteps; // 0x398(0x04)
	float InitialSeedDensity; // 0x39c(0x04)
	float AverageSpreadDistance; // 0x3a0(0x04)
	float SpreadVariance; // 0x3a4(0x04)
	int32 SeedsPerStep; // 0x3a8(0x04)
	int32 DistributionSeed; // 0x3ac(0x04)
	float MaxInitialSeedOffset; // 0x3b0(0x04)
	bool bCanGrowInShade; // 0x3b4(0x01)
	bool bSpawnsInShade; // 0x3b5(0x01)
	char pad_3B6[0x2]; // 0x3b6(0x02)
	float MaxInitialAge; // 0x3b8(0x04)
	float MaxAge; // 0x3bc(0x04)
	float OverlapPriority; // 0x3c0(0x04)
	struct FFloatInterval ProceduralScale; // 0x3c4(0x08)
	char pad_3CC[0x4]; // 0x3cc(0x04)
	struct FRuntimeFloatCurve ScaleCurve; // 0x3d0(0x78)
	int32 ChangeCount; // 0x448(0x04)
	char ReapplyDensity : 1; // 0x44c(0x01)
	char ReapplyRadius : 1; // 0x44c(0x01)
	char ReapplyAlignToNormal : 1; // 0x44c(0x01)
	char ReapplyRandomYaw : 1; // 0x44c(0x01)
	char ReapplyScaling : 1; // 0x44c(0x01)
	char ReapplyScaleX : 1; // 0x44c(0x01)
	char ReapplyScaleY : 1; // 0x44c(0x01)
	char ReapplyScaleZ : 1; // 0x44c(0x01)
	char ReapplyRandomPitchAngle : 1; // 0x44d(0x01)
	char ReapplyGroundSlope : 1; // 0x44d(0x01)
	char ReapplyHeight : 1; // 0x44d(0x01)
	char ReapplyLandscapeLayers : 1; // 0x44d(0x01)
	char ReapplyZOffset : 1; // 0x44d(0x01)
	char ReapplyCollisionWithWorld : 1; // 0x44d(0x01)
	char ReapplyVertexColorMask : 1; // 0x44d(0x01)
	char bEnableDensityScaling : 1; // 0x44d(0x01)
	char pad_44E[0x2]; // 0x44e(0x02)
};

// Class Foliage.FoliageType_InstancedStaticMesh
// Size: 0x470 (Inherited: 0x450)
struct UFoliageType_InstancedStaticMesh : UFoliageType {
	struct UStaticMesh* Mesh; // 0x450(0x08)
	struct TArray<struct UMaterialInterface*> OverrideMaterials; // 0x458(0x10)
	struct UClass* ComponentClass; // 0x468(0x08)
};

// Class Foliage.InstancedFoliageActor
// Size: 0x440 (Inherited: 0x3f0)
struct AInstancedFoliageActor : AActor {
	char pad_3F0[0x50]; // 0x3f0(0x50)
};

// Class Foliage.InteractiveFoliageActor
// Size: 0x460 (Inherited: 0x400)
struct AInteractiveFoliageActor : AStaticMeshActor {
	struct UCapsuleComponent* CapsuleComponent; // 0x400(0x08)
	struct FVector TouchingActorEntryPosition; // 0x408(0x0c)
	struct FVector FoliageVelocity; // 0x414(0x0c)
	struct FVector FoliageForce; // 0x420(0x0c)
	struct FVector FoliagePosition; // 0x42c(0x0c)
	float FoliageDamageImpulseScale; // 0x438(0x04)
	float FoliageTouchImpulseScale; // 0x43c(0x04)
	float FoliageStiffness; // 0x440(0x04)
	float FoliageStiffnessQuadratic; // 0x444(0x04)
	float FoliageDamping; // 0x448(0x04)
	float MaxDamageImpulse; // 0x44c(0x04)
	float MaxTouchImpulse; // 0x450(0x04)
	float MaxForce; // 0x454(0x04)
	float Mass; // 0x458(0x04)
	char pad_45C[0x4]; // 0x45c(0x04)

	void CapsuleTouched(struct UPrimitiveComponent* OverlappedComp, struct AActor* Other, struct UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, struct FHitResult OverlapInfo); // Function Foliage.InteractiveFoliageActor.CapsuleTouched // Final|Native|Protected|HasOutParms // @ game+0x52e1c64
};

// Class Foliage.InteractiveFoliageComponent
// Size: 0xb80 (Inherited: 0xb80)
struct UInteractiveFoliageComponent : UStaticMeshComponent {
};

// Class Foliage.ProceduralFoliageBlockingVolume
// Size: 0x430 (Inherited: 0x428)
struct AProceduralFoliageBlockingVolume : AVolume {
	struct AProceduralFoliageVolume* ProceduralFoliageVolume; // 0x428(0x08)
};

// Class Foliage.ProceduralFoliageComponent
// Size: 0x230 (Inherited: 0x200)
struct UProceduralFoliageComponent : UActorComponent {
	struct UProceduralFoliageSpawner* FoliageSpawner; // 0x200(0x08)
	float TileOverlap; // 0x208(0x04)
	char pad_20C[0x4]; // 0x20c(0x04)
	struct AVolume* SpawningVolume; // 0x210(0x08)
	struct FGuid ProceduralGuid; // 0x218(0x10)
	char pad_228[0x8]; // 0x228(0x08)
};

// Class Foliage.ProceduralFoliageSpawner
// Size: 0x80 (Inherited: 0x38)
struct UProceduralFoliageSpawner : UObject {
	int32 RandomSeed; // 0x38(0x04)
	float TileSize; // 0x3c(0x04)
	int32 NumUniqueTiles; // 0x40(0x04)
	float MinimumQuadTreeSize; // 0x44(0x04)
	char pad_48[0x8]; // 0x48(0x08)
	struct TArray<struct FFoliageTypeObject> FoliageTypes; // 0x50(0x10)
	bool bNeedsSimulation; // 0x60(0x01)
	char pad_61[0x1f]; // 0x61(0x1f)

	void Simulate(int32 NumSteps); // Function Foliage.ProceduralFoliageSpawner.Simulate // Final|Native|Public|BlueprintCallable // @ game+0x52e2174
};

// Class Foliage.ProceduralFoliageTile
// Size: 0x168 (Inherited: 0x38)
struct UProceduralFoliageTile : UObject {
	struct UProceduralFoliageSpawner* FoliageSpawner; // 0x38(0x08)
	char pad_40[0xa0]; // 0x40(0xa0)
	struct TArray<struct FProceduralFoliageInstance> InstancesArray; // 0xe0(0x10)
	char pad_F0[0x78]; // 0xf0(0x78)
};

// Class Foliage.ProceduralFoliageVolume
// Size: 0x430 (Inherited: 0x428)
struct AProceduralFoliageVolume : AVolume {
	struct UProceduralFoliageComponent* ProceduralComponent; // 0x428(0x08)
};

