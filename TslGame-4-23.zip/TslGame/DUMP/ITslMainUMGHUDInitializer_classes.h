// BlueprintGeneratedClass ITslMainUMGHUDInitializer.ITslMainUMGHUDInitializer_C
// Size: 0x38 (Inherited: 0x38)
struct UITslMainUMGHUDInitializer_C : UInterface {

	void InitializeMainUMGHUD(); // Function ITslMainUMGHUDInitializer.ITslMainUMGHUDInitializer_C.InitializeMainUMGHUD // Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
};

