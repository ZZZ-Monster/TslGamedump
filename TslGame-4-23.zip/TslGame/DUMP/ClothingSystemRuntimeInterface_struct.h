// ScriptStruct ClothingSystemRuntimeInterface.ClothCollisionData
// Size: 0x30 (Inherited: 0x00)
struct FClothCollisionData {
	struct TArray<struct FClothCollisionPrim_Sphere> Spheres; // 0x00(0x10)
	struct TArray<struct FClothCollisionPrim_SphereConnection> SphereConnections; // 0x10(0x10)
	struct TArray<struct FClothCollisionPrim_Convex> Convexes; // 0x20(0x10)
};

// ScriptStruct ClothingSystemRuntimeInterface.ClothCollisionPrim_Convex
// Size: 0x18 (Inherited: 0x00)
struct FClothCollisionPrim_Convex {
	struct TArray<struct FPlane> Planes; // 0x00(0x10)
	int32 BoneIndex; // 0x10(0x04)
	char pad_14[0x4]; // 0x14(0x04)
};

// ScriptStruct ClothingSystemRuntimeInterface.ClothCollisionPrim_SphereConnection
// Size: 0x08 (Inherited: 0x00)
struct FClothCollisionPrim_SphereConnection {
	int32 SphereIndices[0x02]; // 0x00(0x08)
};

// ScriptStruct ClothingSystemRuntimeInterface.ClothCollisionPrim_Sphere
// Size: 0x14 (Inherited: 0x00)
struct FClothCollisionPrim_Sphere {
	int32 BoneIndex; // 0x00(0x04)
	float Radius; // 0x04(0x04)
	struct FVector LocalPosition; // 0x08(0x0c)
};

