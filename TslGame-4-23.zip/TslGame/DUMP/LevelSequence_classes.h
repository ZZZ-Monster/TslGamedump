// Class LevelSequence.LevelSequence
// Size: 0x440 (Inherited: 0x340)
struct ULevelSequence : UMovieSceneSequence {
	struct UMovieScene* MovieScene; // 0x340(0x08)
	struct FLevelSequenceObjectReferenceMap ObjectReferences; // 0x348(0x50)
	struct FLevelSequenceBindingReferences BindingReferences; // 0x398(0x50)
	struct TMap<struct FString, struct FLevelSequenceObject> PossessedObjects; // 0x3e8(0x50)
	char pad_438[0x8]; // 0x438(0x08)
};

// Class LevelSequence.LevelSequencePlayer
// Size: 0x790 (Inherited: 0x710)
struct ULevelSequencePlayer : UMovieSceneSequencePlayer {
	char pad_710[0x20]; // 0x710(0x20)
	struct TArray<struct UObject*> AdditionalEventReceivers; // 0x730(0x10)
	char pad_740[0x50]; // 0x740(0x50)

	struct ULevelSequencePlayer* CreateLevelSequencePlayer(struct UObject* WorldContextObject, struct ULevelSequence* LevelSequence, struct FMovieSceneSequencePlaybackSettings Settings); // Function LevelSequence.LevelSequencePlayer.CreateLevelSequencePlayer // Final|Native|Static|Public|BlueprintCallable // @ game+0x54a0b20
};

// Class LevelSequence.LevelSequenceBurnInInitSettings
// Size: 0x38 (Inherited: 0x38)
struct ULevelSequenceBurnInInitSettings : UObject {
};

// Class LevelSequence.LevelSequenceBurnInOptions
// Size: 0x58 (Inherited: 0x38)
struct ULevelSequenceBurnInOptions : UObject {
	bool bUseBurnIn; // 0x38(0x01)
	char pad_39[0x7]; // 0x39(0x07)
	struct FStringClassReference BurnInClass; // 0x40(0x10)
	struct ULevelSequenceBurnInInitSettings* Settings; // 0x50(0x08)
};

// Class LevelSequence.LevelSequenceActor
// Size: 0x468 (Inherited: 0x3f0)
struct ALevelSequenceActor : AActor {
	char pad_3F0[0x8]; // 0x3f0(0x08)
	bool bAutoPlay; // 0x3f8(0x01)
	char pad_3F9[0x7]; // 0x3f9(0x07)
	struct FMovieSceneSequencePlaybackSettings PlaybackSettings; // 0x400(0x28)
	struct ULevelSequencePlayer* SequencePlayer; // 0x428(0x08)
	struct FStringAssetReference LevelSequence; // 0x430(0x10)
	struct TArray<struct AActor*> AdditionalEventReceivers; // 0x440(0x10)
	struct ULevelSequenceBurnInOptions* BurnInOptions; // 0x450(0x08)
	struct UMovieSceneBindingOverrides* BindingOverrides; // 0x458(0x08)
	struct ULevelSequenceBurnIn* BurnInInstance; // 0x460(0x08)

	void SetSequence(struct ULevelSequence* InSequence); // Function LevelSequence.LevelSequenceActor.SetSequence // Final|Native|Public|BlueprintCallable // @ game+0x54a1260
	void SetEventReceivers(struct TArray<struct AActor*> AdditionalReceivers); // Function LevelSequence.LevelSequenceActor.SetEventReceivers // Final|Native|Public|BlueprintCallable // @ game+0x54a1170
	void SetBinding(struct FMovieSceneObjectBindingID Binding, struct TArray<struct AActor*> Actors, bool bAllowBindingsFromAsset); // Function LevelSequence.LevelSequenceActor.SetBinding // Final|Native|Public|HasOutParms|BlueprintCallable // @ game+0x54a0fd0
	void ResetBindings(); // Function LevelSequence.LevelSequenceActor.ResetBindings // Final|Native|Public|BlueprintCallable // @ game+0x54a0f90
	void ResetBinding(struct FMovieSceneObjectBindingID Binding); // Function LevelSequence.LevelSequenceActor.ResetBinding // Final|Native|Public|BlueprintCallable // @ game+0x54a0ea0
	void RemoveBinding(struct FMovieSceneObjectBindingID Binding, struct AActor* Actor); // Function LevelSequence.LevelSequenceActor.RemoveBinding // Final|Native|Public|BlueprintCallable // @ game+0x54a0d54
	struct ULevelSequence* GetSequence(bool Load); // Function LevelSequence.LevelSequenceActor.GetSequence // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x54a0cb0
	void AddBinding(struct FMovieSceneObjectBindingID Binding, struct AActor* Actor, bool bAllowBindingsFromAsset); // Function LevelSequence.LevelSequenceActor.AddBinding // Final|Native|Public|BlueprintCallable // @ game+0x54a099c
};

// Class LevelSequence.LevelSequenceBurnIn
// Size: 0x2b8 (Inherited: 0x260)
struct ULevelSequenceBurnIn : UUserWidget {
	struct FLevelSequencePlayerSnapshot FrameInformation; // 0x260(0x50)
	struct ALevelSequenceActor* LevelSequenceActor; // 0x2b0(0x08)

	void SetSettings(struct UObject* InSettings); // Function LevelSequence.LevelSequenceBurnIn.SetSettings // Event|Public|BlueprintEvent // @ game+0x33e45c
	struct UClass* GetSettingsClass(); // Function LevelSequence.LevelSequenceBurnIn.GetSettingsClass // Native|Event|Public|BlueprintEvent|Const // @ game+0x4d60a28
};

