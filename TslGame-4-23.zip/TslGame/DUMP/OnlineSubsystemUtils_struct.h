// Enum OnlineSubsystemUtils.EBeaconConnectionState
enum class EBeaconConnectionState : uint8 {
	Invalid,
	Closed,
	Pending,
	Open,
	EBeaconConnectionState_MAX,
};

// Enum OnlineSubsystemUtils.EPartyReservationResult
enum class EPartyReservationResult : uint8 {
	NoResult,
	RequestPending,
	GeneralError,
	PartyLimitReached,
	IncorrectPlayerCount,
	RequestTimedOut,
	ReservationDuplicate,
	ReservationNotFound,
	ReservationAccepted,
	ReservationDenied,
	ReservationDenied_Banned,
	ReservationRequestCanceled,
	ReservationInvalid,
	BadSessionId,
	EPartyReservationResult_MAX,
};

// Enum OnlineSubsystemUtils.EClientRequestType
enum class EClientRequestType : uint8 {
	NonePending,
	ExistingSessionReservation,
	ReservationUpdate,
	EmptyServerReservation,
	Reconnect,
	Abandon,
	EClientRequestType_MAX,
};

// ScriptStruct OnlineSubsystemUtils.BlueprintSessionResult
// Size: 0xb8 (Inherited: 0x00)
struct FBlueprintSessionResult {
	char pad_0[0xb8]; // 0x00(0xb8)
};

// ScriptStruct OnlineSubsystemUtils.PartyReservation
// Size: 0x30 (Inherited: 0x00)
struct FPartyReservation {
	int32 TeamNum; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct FUniqueNetIdRepl PartyLeader; // 0x08(0x18)
	struct TArray<struct FPlayerReservation> PartyMembers; // 0x20(0x10)
};

// ScriptStruct OnlineSubsystemUtils.PlayerReservation
// Size: 0x30 (Inherited: 0x00)
struct FPlayerReservation {
	struct FUniqueNetIdRepl UniqueId; // 0x00(0x18)
	struct FString ValidationStr; // 0x18(0x10)
	float ElapsedTime; // 0x28(0x04)
	char pad_2C[0x4]; // 0x2c(0x04)
};

// ScriptStruct OnlineSubsystemUtils.PIELoginSettingsInternal
// Size: 0x40 (Inherited: 0x00)
struct FPIELoginSettingsInternal {
	struct FString ID; // 0x00(0x10)
	struct FString Token; // 0x10(0x10)
	struct FString Type; // 0x20(0x10)
	struct TArray<bool> TokenBytes; // 0x30(0x10)
};

