// Class EasyAntiCheatCommon.EasyAntiCheatNetComponent
// Size: 0x210 (Inherited: 0x200)
struct UEasyAntiCheatNetComponent : UActorComponent {
	char pad_200[0x10]; // 0x200(0x10)

	void ServerMessage(struct TArray<bool> Message); // Function EasyAntiCheatCommon.EasyAntiCheatNetComponent.ServerMessage // Net|NetReliableNative|Event|Public|NetServer|NetValidate // @ game+0x5c47eec
	void ClientMessage(struct TArray<bool> Message); // Function EasyAntiCheatCommon.EasyAntiCheatNetComponent.ClientMessage // Net|NetReliableNative|Event|Public|NetClient // @ game+0x5c47e30
};

