// WidgetBlueprintGeneratedClass BP_BlueZonePhaseWidget.BP_BlueZonePhaseWidget_C
// Size: 0x490 (Inherited: 0x438)
struct UBP_BlueZonePhaseWidget_C : UBluezonePhaseWidget {
	struct UWidgetAnimation* ReleasingText_Tritanopia; // 0x438(0x08)
	struct UWidgetAnimation* ReleasingText_Protanopia; // 0x440(0x08)
	struct UWidgetAnimation* ReleasingText_Deuteranopia; // 0x448(0x08)
	struct UWidgetAnimation* Warning_Tritanopia; // 0x450(0x08)
	struct UWidgetAnimation* Warning_Protanopia; // 0x458(0x08)
	struct UWidgetAnimation* Warning_Deuteranopia; // 0x460(0x08)
	struct UWidgetAnimation* WidgetVanishing; // 0x468(0x08)
	struct UWidgetAnimation* WidgetEmerging; // 0x470(0x08)
	struct UWidgetAnimation* WaitingText; // 0x478(0x08)
	struct UWidgetAnimation* ReleasingText_Normal; // 0x480(0x08)
	struct UInvalidationBox* InvalidationBox; // 0x488(0x08)
};

