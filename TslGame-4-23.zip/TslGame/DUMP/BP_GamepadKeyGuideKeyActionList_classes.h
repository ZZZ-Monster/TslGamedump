// WidgetBlueprintGeneratedClass BP_GamepadKeyGuideKeyActionList.BP_GamepadKeyGuideKeyActionList_C
// Size: 0x800 (Inherited: 0x770)
struct UBP_GamepadKeyGuideKeyActionList_C : UTslGamepadKeyGuideActionListWidget {
	struct UWidgetAnimation* Anim_FocusBlink; // 0x770(0x08)
	struct UWidgetAnimation* Anim_ChangeLoop; // 0x778(0x08)
	struct UWidgetAnimation* Anim_EmptyLoop; // 0x780(0x08)
	struct UBP_GamepadKeyGuideKeyAction_C* Action_2; // 0x788(0x08)
	struct UBP_GamepadKeyGuideKeyAction_C* Action_3; // 0x790(0x08)
	struct UBP_GamepadKeyGuideKeyAction_C* Action_4; // 0x798(0x08)
	struct UImage* ActionBg_2; // 0x7a0(0x08)
	struct UImage* ActionBg_3; // 0x7a8(0x08)
	struct UImage* ActionBg_4; // 0x7b0(0x08)
	struct UImage* Image_4; // 0x7b8(0x08)
	struct UImage* KeyActionListFocus_Image; // 0x7c0(0x08)
	struct UImage* KeyActionListFocusSmall_Image; // 0x7c8(0x08)
	struct UBP_GamepadKeyIconWidget_C* KeyIcon; // 0x7d0(0x08)
	struct UBP_GamepadKeyIconWidget_C* KeyIconAdd; // 0x7d8(0x08)
	struct UImage* KeyIconAdd_Image; // 0x7e0(0x08)
	struct UImage* KeyIconAddBg_Image; // 0x7e8(0x08)
	struct UImage* KeyIconBg_Image; // 0x7f0(0x08)
	struct UWidgetSwitcher* WidgetSwitcher_2; // 0x7f8(0x08)
};

