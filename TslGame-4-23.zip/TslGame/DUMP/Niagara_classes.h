// Class Niagara.NiagaraActor
// Size: 0x3f8 (Inherited: 0x3f0)
struct ANiagaraActor : AActor {
	struct UNiagaraComponent* NiagaraComponent; // 0x3f0(0x08)
};

// Class Niagara.NiagaraComponent
// Size: 0xa20 (Inherited: 0x9d0)
struct UNiagaraComponent : UPrimitiveComponent {
	struct UNiagaraEffect* Asset; // 0x9d0(0x08)
	char pad_9D8[0x10]; // 0x9d8(0x10)
	struct TArray<struct FNiagaraVariable> EffectParameterLocalOverrides; // 0x9e8(0x10)
	struct TArray<struct FNiagaraScriptDataInterfaceInfo> EffectDataInterfaceLocalOverrides; // 0x9f8(0x10)
	struct TArray<struct UNiagaraDataInterface*> InstanceDataInterfaces; // 0xa08(0x10)
	bool bRenderingEnabled; // 0xa18(0x01)
	char pad_A19[0x7]; // 0xa19(0x07)

	void SetRenderingEnabled(bool bInRenderingEnabled); // Function Niagara.NiagaraComponent.SetRenderingEnabled // Final|Native|Public|BlueprintCallable // @ game+0x5554c38
	void SetNiagaraVariableVec4(struct FString InVariableName, struct FVector4 InValue); // Function Niagara.NiagaraComponent.SetNiagaraVariableVec4 // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5554b04
	void SetNiagaraVariableVec3(struct FString InVariableName, struct FVector InValue); // Function Niagara.NiagaraComponent.SetNiagaraVariableVec3 // Final|Native|Public|HasDefaults|BlueprintCallable // @ game+0x55549ac
	void SetNiagaraVariableVec2(struct FString InVariableName, struct FVector2D InValue); // Function Niagara.NiagaraComponent.SetNiagaraVariableVec2 // Final|Native|Public|HasDefaults|BlueprintCallable // @ game+0x555484c
	void SetNiagaraVariableFloat(struct FString InVariableName, float InValue); // Function Niagara.NiagaraComponent.SetNiagaraVariableFloat // Final|Native|Public|BlueprintCallable // @ game+0x555472c
	void SetNiagaraVariableBool(struct FString InVariableName, bool InValue); // Function Niagara.NiagaraComponent.SetNiagaraVariableBool // Final|Native|Public|BlueprintCallable // @ game+0x55545d8
	void SetNiagaraStaticMeshDataInterfaceActor(struct FString InVariableName, struct AActor* InSource); // Function Niagara.NiagaraComponent.SetNiagaraStaticMeshDataInterfaceActor // Final|Native|Public|BlueprintCallable // @ game+0x55544bc
	void SetNiagaraEmitterSpawnRate(struct FString InEmitterName, float InValue); // Function Niagara.NiagaraComponent.SetNiagaraEmitterSpawnRate // Final|Native|Public|BlueprintCallable // @ game+0x555439c
	void ResetEffect(); // Function Niagara.NiagaraComponent.ResetEffect // Final|Native|Public|BlueprintCallable // @ game+0x555435c
	void ReinitializeEffect(); // Function Niagara.NiagaraComponent.ReinitializeEffect // Final|Native|Public|BlueprintCallable // @ game+0x555431c
};

// Class Niagara.NiagaraDataInterface
// Size: 0x38 (Inherited: 0x38)
struct UNiagaraDataInterface : UObject {
};

// Class Niagara.NiagaraDataInterfaceCurveBase
// Size: 0x38 (Inherited: 0x38)
struct UNiagaraDataInterfaceCurveBase : UNiagaraDataInterface {
};

// Class Niagara.NiagaraDataInterfaceCurve
// Size: 0xa8 (Inherited: 0x38)
struct UNiagaraDataInterfaceCurve : UNiagaraDataInterfaceCurveBase {
	struct FRichCurve Curve; // 0x38(0x70)
};

// Class Niagara.NiagaraDataInterfaceVectorCurve
// Size: 0x188 (Inherited: 0x38)
struct UNiagaraDataInterfaceVectorCurve : UNiagaraDataInterfaceCurveBase {
	struct FRichCurve XCurve; // 0x38(0x70)
	struct FRichCurve YCurve; // 0xa8(0x70)
	struct FRichCurve ZCurve; // 0x118(0x70)
};

// Class Niagara.NiagaraDataInterfaceColorCurve
// Size: 0x1f8 (Inherited: 0x38)
struct UNiagaraDataInterfaceColorCurve : UNiagaraDataInterfaceCurveBase {
	struct FRichCurve RedCurve; // 0x38(0x70)
	struct FRichCurve GreenCurve; // 0xa8(0x70)
	struct FRichCurve BlueCurve; // 0x118(0x70)
	struct FRichCurve AlphaCurve; // 0x188(0x70)
};

// Class Niagara.NiagaraDataInterfaceCurlNoise
// Size: 0x38 (Inherited: 0x38)
struct UNiagaraDataInterfaceCurlNoise : UNiagaraDataInterface {
};

// Class Niagara.NiagaraDataInterfaceSpline
// Size: 0xd0 (Inherited: 0x38)
struct UNiagaraDataInterfaceSpline : UNiagaraDataInterface {
	struct AActor* Source; // 0x38(0x08)
	char pad_40[0x90]; // 0x40(0x90)
};

// Class Niagara.NiagaraDataInterfaceStaticMesh
// Size: 0x200 (Inherited: 0x38)
struct UNiagaraDataInterfaceStaticMesh : UNiagaraDataInterface {
	struct UStaticMesh* DefaultMesh; // 0x38(0x08)
	struct AActor* Source; // 0x40(0x08)
	struct FNDIStaticMeshSectionFilter SectionFilter; // 0x48(0x68)
	bool bEnableVertexColorRangeSorting; // 0xb0(0x01)
	char pad_B1[0x14f]; // 0xb1(0x14f)
};

// Class Niagara.NiagaraEffect
// Size: 0x80 (Inherited: 0x38)
struct UNiagaraEffect : UObject {
	struct TArray<struct FNiagaraEmitterHandle> EmitterHandles; // 0x38(0x10)
	struct UNiagaraScript* EffectScript; // 0x48(0x08)
	struct TArray<struct FNiagaraParameterBinding> ParameterBindings; // 0x50(0x10)
	struct TArray<struct FNiagaraParameterBinding> DataInterfaceBindings; // 0x60(0x10)
	struct TArray<struct FNiagaraEmitterInternalVariableBinding> InternalEmitterVariableBindings; // 0x70(0x10)
};

// Class Niagara.NiagaraEffectRendererProperties
// Size: 0x38 (Inherited: 0x38)
struct UNiagaraEffectRendererProperties : UObject {
};

// Class Niagara.NiagaraLightRendererProperties
// Size: 0x48 (Inherited: 0x38)
struct UNiagaraLightRendererProperties : UNiagaraEffectRendererProperties {
	float RadiusScale; // 0x38(0x04)
	struct FVector ColorAdd; // 0x3c(0x0c)
};

// Class Niagara.NiagaraMeshRendererProperties
// Size: 0x40 (Inherited: 0x38)
struct UNiagaraMeshRendererProperties : UNiagaraEffectRendererProperties {
	struct UStaticMesh* ParticleMesh; // 0x38(0x08)
};

// Class Niagara.NiagaraRibbonRendererProperties
// Size: 0x38 (Inherited: 0x38)
struct UNiagaraRibbonRendererProperties : UNiagaraEffectRendererProperties {
};

// Class Niagara.NiagaraSpriteRendererProperties
// Size: 0x58 (Inherited: 0x38)
struct UNiagaraSpriteRendererProperties : UNiagaraEffectRendererProperties {
	struct FVector2D SubImageSize; // 0x38(0x08)
	enum class ENiagaraSpriteAlignment Alignment; // 0x40(0x01)
	enum class ENiagaraSpriteFacingMode FacingMode; // 0x41(0x01)
	char pad_42[0x2]; // 0x42(0x02)
	struct FVector CustomFacingVectorMask; // 0x44(0x0c)
	enum class ENiagaraSortMode SortMode; // 0x50(0x01)
	char pad_51[0x7]; // 0x51(0x07)
};

// Class Niagara.NiagaraScript
// Size: 0xf8 (Inherited: 0x38)
struct UNiagaraScript : UObject {
	struct TArray<bool> ByteCode; // 0x38(0x10)
	struct FNiagaraParameters Parameters; // 0x48(0x10)
	struct FNiagaraParameters InternalParameters; // 0x58(0x10)
	struct TArray<struct FNiagaraVariable> Attributes; // 0x68(0x10)
	struct TArray<struct FNiagaraDataSetProperties> EventReceivers; // 0x78(0x10)
	struct TArray<struct FNiagaraDataSetProperties> EventGenerators; // 0x88(0x10)
	struct FNiagaraScriptDataUsageInfo DataUsage; // 0x98(0x01)
	enum class ENiagaraScriptUsage Usage; // 0x99(0x01)
	char pad_9A[0x6]; // 0x9a(0x06)
	struct TArray<struct FNiagaraScriptDataInterfaceInfo> DataInterfaceInfo; // 0xa0(0x10)
	struct TArray<struct FVMExternalFunctionBindingInfo> CalledVMExternalFunctions; // 0xb0(0x10)
	enum class ENiagaraNumericOutputTypeSelectionMode NumericOutputTypeSelectionMode; // 0xc0(0x01)
	char pad_C1[0x27]; // 0xc1(0x27)
	struct TArray<struct FNiagaraStatScope> StatScopes; // 0xe8(0x10)
};

// Class Niagara.NiagaraEventReceiverEmitterAction
// Size: 0x38 (Inherited: 0x38)
struct UNiagaraEventReceiverEmitterAction : UObject {
};

// Class Niagara.NiagaraEventReceiverEmitterAction_SpawnParticles
// Size: 0x40 (Inherited: 0x38)
struct UNiagaraEventReceiverEmitterAction_SpawnParticles : UNiagaraEventReceiverEmitterAction {
	uint32 NumParticles; // 0x38(0x04)
	char pad_3C[0x4]; // 0x3c(0x04)
};

// Class Niagara.NiagaraEmitterProperties
// Size: 0x118 (Inherited: 0x38)
struct UNiagaraEmitterProperties : UObject {
	float SpawnRate; // 0x38(0x04)
	bool bLocalSpace; // 0x3c(0x01)
	char pad_3D[0x3]; // 0x3d(0x03)
	struct UMaterial* Material; // 0x40(0x08)
	float StartTime; // 0x48(0x04)
	float EndTime; // 0x4c(0x04)
	int32 NumLoops; // 0x50(0x04)
	enum class ENiagaraCollisionMode CollisionMode; // 0x54(0x01)
	char pad_55[0x3]; // 0x55(0x03)
	struct UNiagaraEffectRendererProperties* RendererProperties; // 0x58(0x08)
	struct FNiagaraEmitterScriptProperties UpdateScriptProps; // 0x60(0x28)
	struct FNiagaraEmitterScriptProperties SpawnScriptProps; // 0x88(0x28)
	struct FNiagaraEventScriptProperties EventHandlerScriptProps; // 0xb0(0x50)
	struct TArray<struct FNiagaraEmitterBurst> Bursts; // 0x100(0x10)
	char bInterpolatedSpawning : 1; // 0x110(0x01)
	char pad_110_1 : 7; // 0x110(0x01)
	char pad_111[0x7]; // 0x111(0x07)
};

// Class Niagara.NiagaraFunctionLibrary
// Size: 0x38 (Inherited: 0x38)
struct UNiagaraFunctionLibrary : UBlueprintFunctionLibrary {

	struct UNiagaraComponent* SpawnEffectAttached(struct UNiagaraEffect* EffectTemplate, struct USceneComponent* AttachToComponent, struct FName AttachPointName, struct FVector Location, struct FRotator Rotation, enum class EAttachLocation LocationType, bool bAutoDestroy); // Function Niagara.NiagaraFunctionLibrary.SpawnEffectAttached // Final|Native|Static|Public|HasDefaults|BlueprintCallable // @ game+0x5554e90
	struct UNiagaraComponent* SpawnEffectAtLocation(struct UObject* WorldContextObject, struct UNiagaraEffect* EffectTemplate, struct FVector Location, struct FRotator Rotation, bool bAutoDestroy); // Function Niagara.NiagaraFunctionLibrary.SpawnEffectAtLocation // Final|Native|Static|Public|HasDefaults|BlueprintCallable // @ game+0x5554cc8
};

// Class Niagara.NiagaraScriptSourceBase
// Size: 0x58 (Inherited: 0x38)
struct UNiagaraScriptSourceBase : UObject {
	char pad_38[0x20]; // 0x38(0x20)
};

// Class Niagara.NiagaraSettings
// Size: 0x98 (Inherited: 0x48)
struct UNiagaraSettings : UDeveloperSettings {
	struct FStringAssetReference DefaultEffect; // 0x48(0x10)
	struct FStringAssetReference DefaultEmitter; // 0x58(0x10)
	struct FStringAssetReference DefaultScript; // 0x68(0x10)
	struct TArray<struct FStringAssetReference> AdditionalParameterTypes; // 0x78(0x10)
	struct TArray<struct FStringAssetReference> AdditionalPayloadTypes; // 0x88(0x10)
};

