// WidgetBlueprintGeneratedClass BloodSpotWidget.BloodSpotWidget_C
// Size: 0x29c (Inherited: 0x260)
struct UBloodSpotWidget_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UWidgetAnimation* FadOut2; // 0x268(0x08)
	struct UImage* BloodSpotImage; // 0x270(0x08)
	struct UMaterialInstanceDynamic* MatBloodSpot; // 0x278(0x08)
	float SaveRandomValue; // 0x280(0x04)
	struct FVector OriginalColor; // 0x284(0x0c)
	struct FVector OriginalColorShadow; // 0x290(0x0c)

	void Start(); // Function BloodSpotWidget.BloodSpotWidget_C.Start // Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void Construct(); // Function BloodSpotWidget.BloodSpotWidget_C.Construct // BlueprintCosmetic|Event|Public|BlueprintEvent // @ game+0x33e45c
	void OnAnimationFinished(struct UWidgetAnimation* Animation); // Function BloodSpotWidget.BloodSpotWidget_C.OnAnimationFinished // BlueprintCosmetic|Event|Public|BlueprintEvent // @ game+0x33e45c
	void OnAnimationStarted(struct UWidgetAnimation* Animation); // Function BloodSpotWidget.BloodSpotWidget_C.OnAnimationStarted // BlueprintCosmetic|Event|Public|BlueprintEvent // @ game+0x33e45c
	void ExecuteUbergraph_BloodSpotWidget(int32 EntryPoint); // Function BloodSpotWidget.BloodSpotWidget_C.ExecuteUbergraph_BloodSpotWidget //  // @ game+0x33e45c
};

