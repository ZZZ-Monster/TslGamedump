// Enum HoudiniEngineRuntime.EHoudiniToolSelectionType
enum class EHoudiniToolSelectionType : uint8 {
	HTOOL_SELECTION_ALL,
	HTOOL_SELECTION_WORLD_ONLY,
	HTOOL_SELECTION_CB_ONLY,
	HTOOL_SELECTION_MAX,
};

// Enum HoudiniEngineRuntime.EHoudiniToolType
enum class EHoudiniToolType : uint8 {
	HTOOLTYPE_GENERATOR,
	HTOOLTYPE_OPERATOR_SINGLE,
	HTOOLTYPE_OPERATOR_MULTI,
	HTOOLTYPE_OPERATOR_BATCH,
	HTOOLTYPE_MAX,
};

// Enum HoudiniEngineRuntime.EHoudiniRuntimeSettingsAxisImport
enum class EHoudiniRuntimeSettingsAxisImport : uint8 {
	HRSAI_Unreal,
	HRSAI_Houdini,
	HRSAI_MAX,
};

// Enum HoudiniEngineRuntime.EHoudiniRuntimeSettingsRecomputeFlag
enum class EHoudiniRuntimeSettingsRecomputeFlag : uint8 {
	HRSRF_Always,
	HRSRF_OnlyIfMissing,
	HRSRF_Nothing,
	HRSRF_MAX,
};

// Enum HoudiniEngineRuntime.EHoudiniRuntimeSettingsSessionType
enum class EHoudiniRuntimeSettingsSessionType : uint8 {
	HRSST_InProcess,
	HRSST_Socket,
	HRSST_NamedPipe,
	HRSST_MAX,
};

// Enum HoudiniEngineRuntime.EHoudiniVertexAttributeDataType
enum class EHoudiniVertexAttributeDataType : uint8 {
	VADT_Float,
	VADT_Int32,
	VADT_Bool,
	VADT_MAX,
};

// Enum HoudiniEngineRuntime.EHoudiniHandleType
enum class EHoudiniHandleType : uint8 {
	Xform,
	Bounder,
	Unsupported,
	EHoudiniHandleType_MAX,
};

// ScriptStruct HoudiniEngineRuntime.HoudiniToolDirectory
// Size: 0x30 (Inherited: 0x00)
struct FHoudiniToolDirectory {
	struct FString Name; // 0x00(0x10)
	struct FDirectoryPath path; // 0x10(0x10)
	struct FString ContentDirID; // 0x20(0x10)
};

