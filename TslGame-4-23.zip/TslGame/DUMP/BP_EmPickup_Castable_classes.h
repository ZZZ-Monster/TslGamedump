// BlueprintGeneratedClass BP_EmPickup_Castable.BP_EmPickup_Castable_C
// Size: 0xa0 (Inherited: 0xa0)
struct UBP_EmPickup_Castable_C : UEmPickupCastableItemImplement {
};

