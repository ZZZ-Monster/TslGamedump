// BlueprintGeneratedClass LootTruckItemSpawnProcessor_Savage_UniqueGunBag.LootTruckItemSpawnProcessor_Savage_UniqueGunBag_C
// Size: 0x140 (Inherited: 0x140)
struct ULootTruckItemSpawnProcessor_Savage_UniqueGunBag_C : UModePresetItemSpawner {
};

