// WidgetBlueprintGeneratedClass BP_BlueZoneTimeWidget.BP_BlueZoneTimeWidget_C
// Size: 0x518 (Inherited: 0x4e0)
struct UBP_BlueZoneTimeWidget_C : UBluezoneTimeWidget {
	struct UWidgetAnimation* Warning_Tritanopia; // 0x4e0(0x08)
	struct UWidgetAnimation* Warning_Protanopia; // 0x4e8(0x08)
	struct UWidgetAnimation* Warning_Deuteranopia; // 0x4f0(0x08)
	struct UWidgetAnimation* WidgetVanishing; // 0x4f8(0x08)
	struct UWidgetAnimation* WidgetEmerging; // 0x500(0x08)
	struct UWidgetAnimation* WaitingText; // 0x508(0x08)
	struct USizeBox* SizeBoxforCautionImg; // 0x510(0x08)
};

