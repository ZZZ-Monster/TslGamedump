// BlueprintGeneratedClass P_Carepackage_Smoke_DeuteranopiaTest.P_Carepackage_Smoke_DeuteranopiaTest_C
// Size: 0x4f0 (Inherited: 0x4f0)
struct AP_Carepackage_Smoke_DeuteranopiaTest_C : ATslParticle {
};

