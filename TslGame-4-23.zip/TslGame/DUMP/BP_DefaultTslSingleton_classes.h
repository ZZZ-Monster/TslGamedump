// BlueprintGeneratedClass BP_DefaultTslSingleton.BP_DefaultTslSingleton_C
// Size: 0xe70 (Inherited: 0xe70)
struct UBP_DefaultTslSingleton_C : UTslSingleton {
};

