// WidgetBlueprintGeneratedClass BP_MapCarePackageItemIconWidget.BP_MapCarePackageItemIconWidget_C
// Size: 0x4b0 (Inherited: 0x4a0)
struct UBP_MapCarePackageItemIconWidget_C : UMapCarePackageItemIconBaseWidget {
	struct UWidgetAnimation* Hitted; // 0x4a0(0x08)
	struct UWidgetAnimation* Attacked; // 0x4a8(0x08)
};

