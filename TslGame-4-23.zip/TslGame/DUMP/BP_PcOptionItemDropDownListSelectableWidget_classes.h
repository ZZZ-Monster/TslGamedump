// WidgetBlueprintGeneratedClass BP_PcOptionItemDropDownListSelectableWidget.BP_PcOptionItemDropDownListSelectableWidget_C
// Size: 0x4b8 (Inherited: 0x4b8)
struct UBP_PcOptionItemDropDownListSelectableWidget_C : UTslGameOptionItemDropDownListSelectableWidget {
};

