// BlueprintGeneratedClass BP_ShellEvent_Rifle.BP_ShellEvent_Rifle_C
// Size: 0x98 (Inherited: 0x98)
struct UBP_ShellEvent_Rifle_C : UTslParticleModuleEventSendToGame {
};

