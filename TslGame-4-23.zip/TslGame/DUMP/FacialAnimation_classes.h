// Class FacialAnimation.AudioCurveSourceComponent
// Size: 0x7c0 (Inherited: 0x780)
struct UAudioCurveSourceComponent : UAudioComponent {
	char pad_780[0x8]; // 0x780(0x08)
	struct FName CurveSourceBindingName; // 0x788(0x08)
	float CurveSyncOffset; // 0x790(0x04)
	char pad_794[0x2c]; // 0x794(0x2c)
};

