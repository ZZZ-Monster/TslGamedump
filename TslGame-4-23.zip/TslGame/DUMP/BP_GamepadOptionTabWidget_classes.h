// WidgetBlueprintGeneratedClass BP_GamepadOptionTabWidget.BP_GamepadOptionTabWidget_C
// Size: 0x520 (Inherited: 0x510)
struct UBP_GamepadOptionTabWidget_C : UTslTabSelectorContentsWidget {
	struct UImage* Dot_Image; // 0x510(0x08)
	struct UWidgetSwitcher* StateSwitcher; // 0x518(0x08)
};

