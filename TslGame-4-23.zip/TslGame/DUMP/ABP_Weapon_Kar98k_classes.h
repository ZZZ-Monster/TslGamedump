// AnimBlueprintGeneratedClass ABP_Weapon_Kar98k.ABP_Weapon_Kar98k_C
// Size: 0xe5c (Inherited: 0x498)
struct UABP_Weapon_Kar98k_C : UTslGunAnimInstance {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x498(0x08)
	struct FAnimNode_Root AnimGraphNode_Root_54202F4D4356180788A09FB6755FC87D; // 0x4a0(0x48)
	struct FAnimNode_Slot AnimGraphNode_Slot_71D460D54075C36AA5C2019A71AA4D40; // 0x4e8(0x70)
	struct FAnimNode_Slot AnimGraphNode_Slot_62AF327940874CF70C37908CEEB9A299; // 0x558(0x70)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_535B35864D6D73BE83E3B0B9F7682E1B; // 0x5c8(0x140)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace_3E2088744337103ED0574AB818B09483; // 0x708(0x48)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace_51E3C84E43C0E8972AFE0B973181BE94; // 0x750(0x48)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_F04618AC46C758D4557155A3D6C5281B; // 0x798(0x140)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_21737C5C46F8C2B4D22D6AA0A7564D0C; // 0x8d8(0x70)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_291D982749D2C15B5A42458E533D3353; // 0x948(0x140)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_43A4B63640B00C90EE186E9BCF655F5A; // 0xa88(0x140)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_18C910A44F9008AC742A4E9E701EA7F8; // 0xbc8(0x140)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_033A2398482A3043781C368D6E04B471; // 0xd08(0x140)
	float ClipShowAlpha; // 0xe48(0x04)
	float MagRootAlpha; // 0xe4c(0x04)
	struct ATslWeapon_Gun* GunRef; // 0xe50(0x08)
	float BoltActionAlpha; // 0xe58(0x04)

	void Handle_ReloadByOne_Stop(); // Function ABP_Weapon_Kar98k.ABP_Weapon_Kar98k_C.Handle_ReloadByOne_Stop // Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void Handle_ReloadByOne_Single(); // Function ABP_Weapon_Kar98k.ABP_Weapon_Kar98k_C.Handle_ReloadByOne_Single // Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void Handle_ReloadByOne_Start(); // Function ABP_Weapon_Kar98k.ABP_Weapon_Kar98k_C.Handle_ReloadByOne_Start // Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void Handle_FireCycle(); // Function ABP_Weapon_Kar98k.ABP_Weapon_Kar98k_C.Handle_FireCycle // Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Weapon_Kar98k_AnimGraphNode_ModifyBone_18C910A44F9008AC742A4E9E701EA7F8(); // Function ABP_Weapon_Kar98k.ABP_Weapon_Kar98k_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Weapon_Kar98k_AnimGraphNode_ModifyBone_18C910A44F9008AC742A4E9E701EA7F8 // BlueprintEvent // @ game+0x33e45c
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Weapon_Kar98k_AnimGraphNode_ModifyBone_033A2398482A3043781C368D6E04B471(); // Function ABP_Weapon_Kar98k.ABP_Weapon_Kar98k_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Weapon_Kar98k_AnimGraphNode_ModifyBone_033A2398482A3043781C368D6E04B471 // BlueprintEvent // @ game+0x33e45c
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Weapon_Kar98k_AnimGraphNode_ModifyBone_43A4B63640B00C90EE186E9BCF655F5A(); // Function ABP_Weapon_Kar98k.ABP_Weapon_Kar98k_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Weapon_Kar98k_AnimGraphNode_ModifyBone_43A4B63640B00C90EE186E9BCF655F5A // BlueprintEvent // @ game+0x33e45c
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Weapon_Kar98k_AnimGraphNode_ModifyBone_291D982749D2C15B5A42458E533D3353(); // Function ABP_Weapon_Kar98k.ABP_Weapon_Kar98k_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Weapon_Kar98k_AnimGraphNode_ModifyBone_291D982749D2C15B5A42458E533D3353 // BlueprintEvent // @ game+0x33e45c
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Weapon_Kar98k_AnimGraphNode_ModifyBone_F04618AC46C758D4557155A3D6C5281B(); // Function ABP_Weapon_Kar98k.ABP_Weapon_Kar98k_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Weapon_Kar98k_AnimGraphNode_ModifyBone_F04618AC46C758D4557155A3D6C5281B // BlueprintEvent // @ game+0x33e45c
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Weapon_Kar98k_AnimGraphNode_ModifyBone_535B35864D6D73BE83E3B0B9F7682E1B(); // Function ABP_Weapon_Kar98k.ABP_Weapon_Kar98k_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Weapon_Kar98k_AnimGraphNode_ModifyBone_535B35864D6D73BE83E3B0B9F7682E1B // BlueprintEvent // @ game+0x33e45c
	void BlueprintUpdateAnimation(float DeltaTimeX); // Function ABP_Weapon_Kar98k.ABP_Weapon_Kar98k_C.BlueprintUpdateAnimation // Event|Public|BlueprintEvent // @ game+0x33e45c
	void BlueprintInitializeAnimation(); // Function ABP_Weapon_Kar98k.ABP_Weapon_Kar98k_C.BlueprintInitializeAnimation // Event|Public|BlueprintEvent // @ game+0x33e45c
	void WeaponFireCycle_Event_1(); // Function ABP_Weapon_Kar98k.ABP_Weapon_Kar98k_C.WeaponFireCycle_Event_1 // BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void AnimNotify_ClipShow(); // Function ABP_Weapon_Kar98k.ABP_Weapon_Kar98k_C.AnimNotify_ClipShow // BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void AnimNotify_ClipHide(); // Function ABP_Weapon_Kar98k.ABP_Weapon_Kar98k_C.AnimNotify_ClipHide // BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void Reload2_Event_1(); // Function ABP_Weapon_Kar98k.ABP_Weapon_Kar98k_C.Reload2_Event_1 // BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void ReloadByOneStart_Event_1(int32 AmmoToReload); // Function ABP_Weapon_Kar98k.ABP_Weapon_Kar98k_C.ReloadByOneStart_Event_1 // BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void ReloadByOneSingle_Event_1(); // Function ABP_Weapon_Kar98k.ABP_Weapon_Kar98k_C.ReloadByOneSingle_Event_1 // BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void ReloadByOneEnd_Event_1(); // Function ABP_Weapon_Kar98k.ABP_Weapon_Kar98k_C.ReloadByOneEnd_Event_1 // BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void AnimNotify_ShellEject(); // Function ABP_Weapon_Kar98k.ABP_Weapon_Kar98k_C.AnimNotify_ShellEject // BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void CancelReload_Event_1(); // Function ABP_Weapon_Kar98k.ABP_Weapon_Kar98k_C.CancelReload_Event_1 // BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void ExecuteUbergraph_ABP_Weapon_Kar98k(int32 EntryPoint); // Function ABP_Weapon_Kar98k.ABP_Weapon_Kar98k_C.ExecuteUbergraph_ABP_Weapon_Kar98k // HasDefaults // @ game+0x33e45c
};

