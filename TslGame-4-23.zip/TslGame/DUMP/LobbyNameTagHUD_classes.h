// WidgetBlueprintGeneratedClass LobbyNameTagHUD.LobbyNameTagHUD_C
// Size: 0x468 (Inherited: 0x468)
struct ULobbyNameTagHUD_C : UTslLobbyNameTagHudWidget {

	void CleanUpNameTagWidget(int32 SlotIndex); // Function LobbyNameTagHUD.LobbyNameTagHUD_C.CleanUpNameTagWidget // Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void SetupNameTagWidget(int32 SlotIndex); // Function LobbyNameTagHUD.LobbyNameTagHUD_C.SetupNameTagWidget // Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void GetNameTagWidget(int32 SlotIndex, struct UTslLobbyNameTagWidget* Widget); // Function LobbyNameTagHUD.LobbyNameTagHUD_C.GetNameTagWidget // Public|HasOutParms|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
};

