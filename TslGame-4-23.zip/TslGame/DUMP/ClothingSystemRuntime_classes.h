// Class ClothingSystemRuntime.ClothingAssetCustomData
// Size: 0x38 (Inherited: 0x38)
struct UClothingAssetCustomData : UObject {
};

// Class ClothingSystemRuntime.ClothingAsset
// Size: 0x168 (Inherited: 0x58)
struct UClothingAsset : UClothingAssetBase {
	struct FClothConfig ClothConfig; // 0x58(0xbc)
	char pad_114[0x4]; // 0x114(0x04)
	struct TArray<struct FClothLODData> LODData; // 0x118(0x10)
	struct TArray<int32> LodMap; // 0x128(0x10)
	struct TArray<struct FName> UsedBoneNames; // 0x138(0x10)
	struct TArray<int32> UsedBoneIndices; // 0x148(0x10)
	int32 ReferenceBoneIndex; // 0x158(0x04)
	char pad_15C[0x4]; // 0x15c(0x04)
	struct UClothingAssetCustomData* CustomData; // 0x160(0x08)
};

// Class ClothingSystemRuntime.ClothingSimulationFactoryNv
// Size: 0x38 (Inherited: 0x38)
struct UClothingSimulationFactoryNv : UClothingSimulationFactory {
};

