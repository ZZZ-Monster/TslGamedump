// WidgetBlueprintGeneratedClass BP_CompassMarkerWidget.BP_CompassMarkerWidget_C
// Size: 0x448 (Inherited: 0x448)
struct UBP_CompassMarkerWidget_C : UTslCompassMarkerWidget {
};

