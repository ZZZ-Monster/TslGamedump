// WidgetBlueprintGeneratedClass NewWorldMapWidget_BP.NewWorldMapWidget_BP_C
// Size: 0x708 (Inherited: 0x690)
struct UNewWorldMapWidget_BP_C : UTslNewWorldMapWidget {
	struct UWidgetAnimation* MapFadeOut; // 0x690(0x08)
	struct UWidgetAnimation* MapFadeIn; // 0x698(0x08)
	struct UBP_WorldMapTrainingInfo_C* BP_WorldMapTrainingInfo; // 0x6a0(0x08)
	struct UCanvasPanel* CanvasPanel_3; // 0x6a8(0x08)
	struct UScaleBox* FlaregunScaleBox; // 0x6b0(0x08)
	struct UBP_FlaregunUiWidget_C* FlaregunWidget; // 0x6b8(0x08)
	struct UMapGridWidget_C* MapWidget; // 0x6c0(0x08)
	struct UImage* Normal; // 0x6c8(0x08)
	struct UWidgetSwitcher* PadGuideSwitcher; // 0x6d0(0x08)
	struct USafeZone* SafeZone_1; // 0x6d8(0x08)
	struct USafeZone* SafeZone_6; // 0x6e0(0x08)
	struct USizeBox* SizeBoxForSelectableSpawnKit; // 0x6e8(0x08)
	struct UImage* TrainingInfoBgImage; // 0x6f0(0x08)
	struct UUIBlurBackground_C* UIBlurBackground_C_1; // 0x6f8(0x08)
	struct UImage* WayPoint; // 0x700(0x08)
};

