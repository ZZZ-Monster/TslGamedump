// BlueprintGeneratedClass FBRBuff_ReduceMeleeDamageRatio.FBRBuff_ReduceMeleeDamageRatio_C
// Size: 0x4a8 (Inherited: 0x4a0)
struct AFBRBuff_ReduceMeleeDamageRatio_C : ATslFBRBuff {
	struct USceneComponent* DefaultSceneRoot; // 0x4a0(0x08)

	void UserConstructionScript(); // Function FBRBuff_ReduceMeleeDamageRatio.FBRBuff_ReduceMeleeDamageRatio_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
};

