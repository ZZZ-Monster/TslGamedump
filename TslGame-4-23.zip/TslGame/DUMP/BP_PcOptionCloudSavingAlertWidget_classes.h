// WidgetBlueprintGeneratedClass BP_PcOptionCloudSavingAlertWidget.BP_PcOptionCloudSavingAlertWidget_C
// Size: 0x498 (Inherited: 0x498)
struct UBP_PcOptionCloudSavingAlertWidget_C : UTslGameOptionCloudPopupWidget {
};

