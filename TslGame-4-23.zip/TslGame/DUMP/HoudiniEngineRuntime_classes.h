// Class HoudiniEngineRuntime.HoudiniAsset
// Size: 0x68 (Inherited: 0x38)
struct UHoudiniAsset : UObject {
	struct FString AssetFileName; // 0x38(0x10)
	struct UThumbnailInfo* ThumbnailInfo; // 0x48(0x08)
	char pad_50[0x18]; // 0x50(0x18)
};

// Class HoudiniEngineRuntime.HoudiniAssetActor
// Size: 0x400 (Inherited: 0x3f0)
struct AHoudiniAssetActor : AActor {
	struct UHoudiniAssetComponent* HoudiniAssetComponent; // 0x3f0(0x08)
	char pad_3F8[0x8]; // 0x3f8(0x08)
};

// Class HoudiniEngineRuntime.HoudiniRuntimeSettings
// Size: 0x4b0 (Inherited: 0x38)
struct UHoudiniRuntimeSettings : UObject {
	enum class EHoudiniRuntimeSettingsSessionType SessionType; // 0x38(0x01)
	char pad_39[0x7]; // 0x39(0x07)
	struct FString ServerHost; // 0x40(0x10)
	int32 ServerPort; // 0x50(0x04)
	char pad_54[0x4]; // 0x54(0x04)
	struct FString ServerPipeName; // 0x58(0x10)
	bool bStartAutomaticServer; // 0x68(0x01)
	char pad_69[0x3]; // 0x69(0x03)
	float AutomaticServerTimeout; // 0x6c(0x04)
	bool bShowMultiAssetDialog; // 0x70(0x01)
	bool bPauseCookingOnStart; // 0x71(0x01)
	bool bEnableCooking; // 0x72(0x01)
	bool bUploadTransformsToHoudiniEngine; // 0x73(0x01)
	bool bTransformChangeTriggersCooks; // 0x74(0x01)
	bool bDisplaySlateCookingNotifications; // 0x75(0x01)
	bool bCookCurvesOnMouseRelease; // 0x76(0x01)
	char pad_77[0x1]; // 0x77(0x01)
	struct FText TemporaryCookFolder; // 0x78(0x18)
	bool bTreatRampParametersAsMultiparms; // 0x90(0x01)
	char pad_91[0x7]; // 0x91(0x07)
	struct FString CollisionGroupNamePrefix; // 0x98(0x10)
	struct FString RenderedCollisionGroupNamePrefix; // 0xa8(0x10)
	struct FString UCXCollisionGroupNamePrefix; // 0xb8(0x10)
	struct FString UCXRenderedCollisionGroupNamePrefix; // 0xc8(0x10)
	struct FString SimpleCollisionGroupNamePrefix; // 0xd8(0x10)
	struct FString SimpleRenderedCollisionGroupNamePrefix; // 0xe8(0x10)
	struct FString MarshallingAttributeMaterial; // 0xf8(0x10)
	struct FString MarshallingAttributeMaterialHole; // 0x108(0x10)
	struct FString MarshallingAttributeInstanceOverride; // 0x118(0x10)
	struct FString MarshallingAttributeFaceSmoothingMask; // 0x128(0x10)
	struct FString MarshallingAttributeLightmapResolution; // 0x138(0x10)
	struct FString MarshallingAttributeGeneratedMeshName; // 0x148(0x10)
	struct FString MarshallingAttributeInputMeshName; // 0x158(0x10)
	struct FString MarshallingAttributeInputSourceFile; // 0x168(0x10)
	float MarshallingSplineResolution; // 0x178(0x04)
	bool MarshallingLandscapesUseDefaultUnrealScaling; // 0x17c(0x01)
	bool MarshallingLandscapesUseFullResolution; // 0x17d(0x01)
	bool MarshallingLandscapesForceMinMaxValues; // 0x17e(0x01)
	char pad_17F[0x1]; // 0x17f(0x01)
	float MarshallingLandscapesForcedMinValue; // 0x180(0x04)
	float MarshallingLandscapesForcedMaxValue; // 0x184(0x04)
	float GeneratedGeometryScaleFactor; // 0x188(0x04)
	float TransformScaleFactor; // 0x18c(0x04)
	enum class EHoudiniRuntimeSettingsAxisImport ImportAxis; // 0x190(0x01)
	char pad_191[0x3]; // 0x191(0x03)
	char bDoubleSidedGeometry : 1; // 0x194(0x01)
	char pad_194_1 : 7; // 0x194(0x01)
	char pad_195[0x3]; // 0x195(0x03)
	struct UPhysicalMaterial* PhysMaterial; // 0x198(0x08)
	struct FBodyInstance DefaultBodyInstance; // 0x1a0(0x230)
	enum class ECollisionTraceFlag CollisionTraceFlag; // 0x3d0(0x01)
	char pad_3D1[0x3]; // 0x3d1(0x03)
	int32 LightMapResolution; // 0x3d4(0x04)
	float LpvBiasMultiplier; // 0x3d8(0x04)
	float GeneratedDistanceFieldResolutionScale; // 0x3dc(0x04)
	struct FWalkableSlopeOverride WalkableSlopeOverride; // 0x3e0(0x10)
	int32 LightMapCoordinateIndex; // 0x3f0(0x04)
	char bUseMaximumStreamingTexelRatio : 1; // 0x3f4(0x01)
	char pad_3F4_1 : 7; // 0x3f4(0x01)
	char pad_3F5[0x3]; // 0x3f5(0x03)
	float StreamingDistanceMultiplier; // 0x3f8(0x04)
	char pad_3FC[0x4]; // 0x3fc(0x04)
	struct UFoliageType_InstancedStaticMesh* FoliageDefaultSettings; // 0x400(0x08)
	struct TArray<struct UAssetUserData*> AssetUserData; // 0x408(0x10)
	bool bUseFullPrecisionUVs; // 0x418(0x01)
	char pad_419[0x3]; // 0x419(0x03)
	int32 SrcLightmapIndex; // 0x41c(0x04)
	int32 DstLightmapIndex; // 0x420(0x04)
	int32 MinLightmapResolution; // 0x424(0x04)
	bool bRemoveDegenerates; // 0x428(0x01)
	enum class EHoudiniRuntimeSettingsRecomputeFlag GenerateLightmapUVsFlag; // 0x429(0x01)
	enum class EHoudiniRuntimeSettingsRecomputeFlag RecomputeNormalsFlag; // 0x42a(0x01)
	enum class EHoudiniRuntimeSettingsRecomputeFlag RecomputeTangentsFlag; // 0x42b(0x01)
	bool bUseMikkTSpace; // 0x42c(0x01)
	bool bBuildAdjacencyBuffer; // 0x42d(0x01)
	bool bUseCustomHoudiniLocation; // 0x42e(0x01)
	char pad_42F[0x1]; // 0x42f(0x01)
	struct FDirectoryPath CustomHoudiniLocation; // 0x430(0x10)
	bool bHidePlacementModeHoudiniTools; // 0x440(0x01)
	char pad_441[0x7]; // 0x441(0x07)
	struct TArray<struct FHoudiniToolDirectory> CustomHoudiniToolsLocation; // 0x448(0x10)
	int32 CookingThreadStackSize; // 0x458(0x04)
	char pad_45C[0x4]; // 0x45c(0x04)
	struct FString HoudiniEnvironmentFiles; // 0x460(0x10)
	struct FString OtlSearchPath; // 0x470(0x10)
	struct FString DsoSearchPath; // 0x480(0x10)
	struct FString ImageDsoSearchPath; // 0x490(0x10)
	struct FString AudioDsoSearchPath; // 0x4a0(0x10)
};

// Class HoudiniEngineRuntime.HoudiniAssetComponent
// Size: 0x12b0 (Inherited: 0x9d0)
struct UHoudiniAssetComponent : UPrimitiveComponent {
	char pad_9D0[0x8]; // 0x9d0(0x08)
	char bGeneratedDoubleSidedGeometry : 1; // 0x9d8(0x01)
	char pad_9D8_1 : 7; // 0x9d8(0x01)
	char pad_9D9[0x7]; // 0x9d9(0x07)
	struct UPhysicalMaterial* GeneratedPhysMaterial; // 0x9e0(0x08)
	char pad_9E8[0x8]; // 0x9e8(0x08)
	struct FBodyInstance DefaultBodyInstance; // 0x9f0(0x230)
	enum class ECollisionTraceFlag GeneratedCollisionTraceFlag; // 0xc20(0x01)
	char pad_C21[0x3]; // 0xc21(0x03)
	int32 GeneratedLightMapResolution; // 0xc24(0x04)
	float GeneratedLpvBiasMultiplier; // 0xc28(0x04)
	float GeneratedDistanceFieldResolutionScale; // 0xc2c(0x04)
	struct FWalkableSlopeOverride GeneratedWalkableSlopeOverride; // 0xc30(0x10)
	int32 GeneratedLightMapCoordinateIndex; // 0xc40(0x04)
	char bGeneratedUseMaximumStreamingTexelRatio : 1; // 0xc44(0x01)
	char pad_C44_1 : 7; // 0xc44(0x01)
	char pad_C45[0x3]; // 0xc45(0x03)
	float GeneratedStreamingDistanceMultiplier; // 0xc48(0x04)
	char pad_C4C[0x4]; // 0xc4c(0x04)
	struct UFoliageType_InstancedStaticMesh* GeneratedFoliageDefaultSettings; // 0xc50(0x08)
	struct TArray<struct UAssetUserData*> GeneratedAssetUserData; // 0xc58(0x10)
	char pad_C68[0x478]; // 0xc68(0x478)
	struct FText BakeFolder; // 0x10e0(0x18)
	struct FText TempCookFolder; // 0x10f8(0x18)
	char pad_1110[0x1a0]; // 0x1110(0x1a0)

	int32 GetAssetId(); // Function HoudiniEngineRuntime.HoudiniAssetComponent.GetAssetId // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5e16c20
};

// Class HoudiniEngineRuntime.HoudiniAssetComponentMaterials
// Size: 0xe0 (Inherited: 0x38)
struct UHoudiniAssetComponentMaterials : UObject {
	char pad_38[0xa8]; // 0x38(0xa8)
};

// Class HoudiniEngineRuntime.HoudiniAssetParameter
// Size: 0xb0 (Inherited: 0x38)
struct UHoudiniAssetParameter : UObject {
	char pad_38[0x78]; // 0x38(0x78)
};

// Class HoudiniEngineRuntime.HoudiniAssetInstanceInput
// Size: 0x190 (Inherited: 0xb0)
struct UHoudiniAssetInstanceInput : UHoudiniAssetParameter {
	char pad_B0[0xe0]; // 0xb0(0xe0)
};

// Class HoudiniEngineRuntime.HoudiniAssetInstanceInputField
// Size: 0x1b0 (Inherited: 0x38)
struct UHoudiniAssetInstanceInputField : UObject {
	char pad_38[0x178]; // 0x38(0x178)
};

// Class HoudiniEngineRuntime.HoudiniAssetInput
// Size: 0x240 (Inherited: 0xb0)
struct UHoudiniAssetInput : UHoudiniAssetParameter {
	char pad_B0[0x190]; // 0xb0(0x190)
};

// Class HoudiniEngineRuntime.HoudiniAssetParameterButton
// Size: 0xb0 (Inherited: 0xb0)
struct UHoudiniAssetParameterButton : UHoudiniAssetParameter {
};

// Class HoudiniEngineRuntime.HoudiniAssetParameterChoice
// Size: 0xe8 (Inherited: 0xb0)
struct UHoudiniAssetParameterChoice : UHoudiniAssetParameter {
	char pad_B0[0x38]; // 0xb0(0x38)
};

// Class HoudiniEngineRuntime.HoudiniAssetParameterColor
// Size: 0xc0 (Inherited: 0xb0)
struct UHoudiniAssetParameterColor : UHoudiniAssetParameter {
	char pad_B0[0x10]; // 0xb0(0x10)
};

// Class HoudiniEngineRuntime.HoudiniAssetParameterFile
// Size: 0xd8 (Inherited: 0xb0)
struct UHoudiniAssetParameterFile : UHoudiniAssetParameter {
	char pad_B0[0x28]; // 0xb0(0x28)
};

// Class HoudiniEngineRuntime.HoudiniAssetParameterFloat
// Size: 0xe8 (Inherited: 0xb0)
struct UHoudiniAssetParameterFloat : UHoudiniAssetParameter {
	char pad_B0[0x38]; // 0xb0(0x38)
};

// Class HoudiniEngineRuntime.HoudiniAssetParameterFolder
// Size: 0xb0 (Inherited: 0xb0)
struct UHoudiniAssetParameterFolder : UHoudiniAssetParameter {
};

// Class HoudiniEngineRuntime.HoudiniAssetParameterFolderList
// Size: 0xb0 (Inherited: 0xb0)
struct UHoudiniAssetParameterFolderList : UHoudiniAssetParameter {
};

// Class HoudiniEngineRuntime.HoudiniAssetParameterInt
// Size: 0xe0 (Inherited: 0xb0)
struct UHoudiniAssetParameterInt : UHoudiniAssetParameter {
	char pad_B0[0x30]; // 0xb0(0x30)
};

// Class HoudiniEngineRuntime.HoudiniAssetParameterLabel
// Size: 0xb0 (Inherited: 0xb0)
struct UHoudiniAssetParameterLabel : UHoudiniAssetParameter {
};

// Class HoudiniEngineRuntime.HoudiniAssetParameterMultiparm
// Size: 0xc0 (Inherited: 0xb0)
struct UHoudiniAssetParameterMultiparm : UHoudiniAssetParameter {
	char pad_B0[0x10]; // 0xb0(0x10)
};

// Class HoudiniEngineRuntime.HoudiniAssetParameterRampCurveFloat
// Size: 0xc0 (Inherited: 0xb8)
struct UHoudiniAssetParameterRampCurveFloat : UCurveFloat {
	char pad_B8[0x8]; // 0xb8(0x08)
};

// Class HoudiniEngineRuntime.HoudiniAssetParameterRampCurveColor
// Size: 0x218 (Inherited: 0x200)
struct UHoudiniAssetParameterRampCurveColor : UCurveLinearColor {
	char pad_200[0x18]; // 0x200(0x18)
};

// Class HoudiniEngineRuntime.HoudiniAssetParameterRamp
// Size: 0xd8 (Inherited: 0xc0)
struct UHoudiniAssetParameterRamp : UHoudiniAssetParameterMultiparm {
	char pad_C0[0x18]; // 0xc0(0x18)
};

// Class HoudiniEngineRuntime.HoudiniAssetParameterSeparator
// Size: 0xb0 (Inherited: 0xb0)
struct UHoudiniAssetParameterSeparator : UHoudiniAssetParameter {
};

// Class HoudiniEngineRuntime.HoudiniAssetParameterString
// Size: 0xc0 (Inherited: 0xb0)
struct UHoudiniAssetParameterString : UHoudiniAssetParameter {
	char pad_B0[0x10]; // 0xb0(0x10)
};

// Class HoudiniEngineRuntime.HoudiniAssetParameterToggle
// Size: 0xc0 (Inherited: 0xb0)
struct UHoudiniAssetParameterToggle : UHoudiniAssetParameter {
	char pad_B0[0x10]; // 0xb0(0x10)
};

// Class HoudiniEngineRuntime.HoudiniAttributeDataComponent
// Size: 0x210 (Inherited: 0x200)
struct UHoudiniAttributeDataComponent : UActorComponent {
	char pad_200[0x10]; // 0x200(0x10)
};

// Class HoudiniEngineRuntime.HoudiniEngineConvertBgeoCommandlet
// Size: 0x90 (Inherited: 0x90)
struct UHoudiniEngineConvertBgeoCommandlet : UCommandlet {
};

// Class HoudiniEngineRuntime.HoudiniEngineConvertBgeoDirCommandlet
// Size: 0x90 (Inherited: 0x90)
struct UHoudiniEngineConvertBgeoDirCommandlet : UCommandlet {
};

// Class HoudiniEngineRuntime.HoudiniHandleComponent
// Size: 0x570 (Inherited: 0x4b0)
struct UHoudiniHandleComponent : USceneComponent {
	char pad_4B0[0xb0]; // 0x4b0(0xb0)
	enum class EHoudiniHandleType HandleType; // 0x560(0x01)
	char pad_561[0xf]; // 0x561(0x0f)
};

// Class HoudiniEngineRuntime.HoudiniInstancedActorComponent
// Size: 0x4d0 (Inherited: 0x4b0)
struct UHoudiniInstancedActorComponent : USceneComponent {
	struct UObject* InstancedAsset; // 0x4b0(0x08)
	struct TArray<struct AActor*> Instances; // 0x4b8(0x10)
	char pad_4C8[0x8]; // 0x4c8(0x08)
};

// Class HoudiniEngineRuntime.HoudiniMeshSplitInstancerComponent
// Size: 0x4d0 (Inherited: 0x4b0)
struct UHoudiniMeshSplitInstancerComponent : USceneComponent {
	struct TArray<struct UStaticMeshComponent*> Instances; // 0x4b0(0x10)
	struct UMaterialInterface* OverrideMaterial; // 0x4c0(0x08)
	struct UStaticMesh* InstancedMesh; // 0x4c8(0x08)
};

// Class HoudiniEngineRuntime.HoudiniSplineComponent
// Size: 0x5b0 (Inherited: 0x4b0)
struct UHoudiniSplineComponent : USceneComponent {
	char pad_4B0[0x100]; // 0x4b0(0x100)
};

// Class HoudiniEngineRuntime.TestHoudiniParameterBuilder
// Size: 0xd8 (Inherited: 0x38)
struct UTestHoudiniParameterBuilder : UObject {
	char pad_38[0xa0]; // 0x38(0xa0)
};

