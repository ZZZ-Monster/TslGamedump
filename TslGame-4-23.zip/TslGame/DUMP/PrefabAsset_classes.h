// Class PrefabAsset.PrefabActor
// Size: 0x420 (Inherited: 0x3f0)
struct APrefabActor : AActor {
	struct UPrefabComponent* PrefabComponent; // 0x3f0(0x08)
	struct FText BackupPrefabCopyData; // 0x3f8(0x18)
	bool bKeepMaterialOverrides; // 0x410(0x01)
	bool bKeepTslOverrides; // 0x411(0x01)
	char pad_412[0x6]; // 0x412(0x06)
	struct ULODParentComponent* BuildingHLOD; // 0x418(0x08)

	void SetPrefab(struct UPrefabAsset* NewPrefab, bool bForceRevertEvenDisconnected); // Function PrefabAsset.PrefabActor.SetPrefab // Final|Native|Public|BlueprintCallable // @ game+0x5c5d7e4
	void SetMobility(enum class EComponentMobility InMobility); // Function PrefabAsset.PrefabActor.SetMobility // Final|Native|Public|BlueprintCallable // @ game+0x5c5d750
	struct UPrefabAsset* GetPrefab(); // Function PrefabAsset.PrefabActor.GetPrefab // Final|Native|Public|BlueprintCallable // @ game+0x5c5d730
	void DestroyPrefabActor(bool bDestroyAttachedChildren); // Function PrefabAsset.PrefabActor.DestroyPrefabActor // Final|Native|Public|BlueprintCallable // @ game+0x4d09aac
};

// Class PrefabAsset.PrefabActorHolder
// Size: 0x3f0 (Inherited: 0x3f0)
struct APrefabActorHolder : AActor {
};

// Class PrefabAsset.PrefabLODHolder
// Size: 0x400 (Inherited: 0x3f0)
struct APrefabLODHolder : APrefabActorHolder {
	struct ULODParentComponent* HLODParentComponent; // 0x3f0(0x08)
	struct UStaticMesh* LevelLODMesh; // 0x3f8(0x08)
};

// Class PrefabAsset.PrefabAsset
// Size: 0x140 (Inherited: 0x38)
struct UPrefabAsset : UObject {
	struct FGuid PrefabId; // 0x38(0x10)
	struct FText PrefabContent; // 0x48(0x18)
	struct FVector PrefabPivot; // 0x60(0x0c)
	char pad_6C[0x4]; // 0x6c(0x04)
	struct FString PrefabHash; // 0x70(0x10)
	struct TMap<struct FString, struct FStringAssetReference> AssetReferences; // 0x80(0x50)
	int32 NumActors; // 0xd0(0x04)
	char pad_D4[0x4]; // 0xd4(0x04)
	struct FStringAssetReference GeneratedBlueprintAssetReference; // 0xd8(0x10)
	struct TMap<struct FString, struct FPrefabOverride> AssetPrefabOverrideMap; // 0xe8(0x50)
	bool bIsBaseBuilding; // 0x138(0x01)
	bool bIsDestroyedPrefab; // 0x139(0x01)
	bool RemoveFromLevelLOD; // 0x13a(0x01)
	char pad_13B[0x5]; // 0x13b(0x05)
};

// Class PrefabAsset.PrefabBuildingCreator
// Size: 0x458 (Inherited: 0x3f0)
struct APrefabBuildingCreator : AActor {
	char pad_3F0[0x8]; // 0x3f0(0x08)
	bool bSpawnInOrder; // 0x3f8(0x01)
	bool bLockConfiguration; // 0x3f9(0x01)
	char pad_3FA[0x6]; // 0x3fa(0x06)
	struct TArray<struct UPrefabAsset*> PrefabAssetList; // 0x400(0x10)
	struct TArray<struct UPrefabAsset*> PrefabOverrides; // 0x410(0x10)
	bool bUseRoofPrefab; // 0x420(0x01)
	char pad_421[0x7]; // 0x421(0x07)
	struct UPrefabAsset* RoofPrefab; // 0x428(0x08)
	struct AActor* SpawnedRoofPrefab; // 0x430(0x08)
	struct TArray<struct AActor*> SpawnedPrefabActors; // 0x438(0x10)
	float FloorHeight; // 0x448(0x04)
	float BaseOffset; // 0x44c(0x04)
	int32 NumberOfFloors; // 0x450(0x04)
	char pad_454[0x4]; // 0x454(0x04)
};

// Class PrefabAsset.PrefabComponent
// Size: 0xac0 (Inherited: 0x9d0)
struct UPrefabComponent : UPrimitiveComponent {
	char bConnected : 1; // 0x9d0(0x01)
	char bLightingChannelA : 1; // 0x9d0(0x01)
	char bLightingChannelB : 1; // 0x9d0(0x01)
	char pad_9D0_3 : 5; // 0x9d0(0x01)
	char pad_9D1[0x7]; // 0x9d1(0x07)
	struct TMap<struct FString, struct FPrefabOverride> ComponentPrefabOverrideMap; // 0x9d8(0x50)
	struct FVector BoxSelectionScale; // 0xa28(0x0c)
	struct FVector SelectionBoxOffset; // 0xa34(0x0c)
	char bLockSelection : 1; // 0xa40(0x01)
	char pad_A40_1 : 7; // 0xa40(0x01)
	char pad_A41[0x7]; // 0xa41(0x07)
	struct UBlueprint* GeneratedBlueprint; // 0xa48(0x08)
	struct UPrefabAsset* Prefab; // 0xa50(0x08)
	struct TMap<struct FName, struct AActor*> PrefabInstancesMap; // 0xa58(0x50)
	char bTransient : 1; // 0xaa8(0x01)
	char pad_AA8_1 : 7; // 0xaa8(0x01)
	char pad_AA9[0x3]; // 0xaa9(0x03)
	bool bIsBaseBuilding; // 0xaac(0x01)
	char pad_AAD[0x3]; // 0xaad(0x03)
	uint32 HouseID; // 0xab0(0x04)
	bool bIsDestroyedPrefab; // 0xab4(0x01)
	char pad_AB5[0x1]; // 0xab5(0x01)
	bool bWasDisconnectedBeforeBake; // 0xab6(0x01)
	char pad_AB7[0x9]; // 0xab7(0x09)
};

// Class PrefabAsset.PrefabToolSettings
// Size: 0xc8 (Inherited: 0x38)
struct UPrefabToolSettings : UObject {
	bool bReplaceActorsWithCreatedPrefab; // 0x38(0x01)
	char pad_39[0x1]; // 0x39(0x01)
	bool bCheckPrefabChangeBeforeUpdateAllPrefabActorsWhenOpenMap; // 0x3a(0x01)
	bool bShouldLockAllPrefabsOnMapOpen; // 0x3b(0x01)
	bool bUpdatePrefabThumbnailOnSave; // 0x3c(0x01)
	char pad_3D[0x4]; // 0x3d(0x04)
	bool bIsolateWhenEnteringPrefab; // 0x41(0x01)
	bool bExpandComponentDestroyAndConvert; // 0x42(0x01)
	bool bExpandComponentPivotAndSnap; // 0x43(0x01)
	bool bExpandComponentCollapse; // 0x44(0x01)
	bool bExpandComponentTSLSettings; // 0x45(0x01)
	bool bExpandComponentSelectionSettings; // 0x46(0x01)
	bool bExpandComponentDestruction; // 0x47(0x01)
	bool bExpandComponentGeneratedBP; // 0x48(0x01)
	bool bEnablePrefabComponentVisualizer; // 0x49(0x01)
	enum class EPrefabVisualizerType PrefabComponentVisualizerType; // 0x4a(0x01)
	bool bDisplayPrefabComponentVisualizerEvenNotSelected; // 0x4b(0x01)
	struct FColor PrefabViewVisualizerColor; // 0x4c(0x04)
	struct FColor PrefabViewVisualizerColorBaseBuilding; // 0x50(0x04)
	struct FColor PrefabViewVisualizerColorDesignItems; // 0x54(0x04)
	struct FColor TargetActorColor; // 0x58(0x04)
	struct FColor UnLockedConnectedColor; // 0x5c(0x04)
	struct FColor LockedConnectedColor; // 0x60(0x04)
	struct FColor UnLockedDisConnectedColor; // 0x64(0x04)
	struct FColor LockedDisConnectedColor; // 0x68(0x04)
	struct FColor UnLockedNoPrefabAssignedColor; // 0x6c(0x04)
	struct FColor LockedNoPrefabAssignedColor; // 0x70(0x04)
	char pad_74[0x4]; // 0x74(0x04)
	struct FStringAssetReference PrefabMaterialPath; // 0x78(0x10)
	struct UMaterial* PrefabMaterial; // 0x88(0x08)
	char pad_90[0x1]; // 0x90(0x01)
	bool bDisableLockPrefabSelectionFeature; // 0x91(0x01)
	char pad_92[0x30]; // 0x92(0x30)
	bool bLockPrefabChildSelection; // 0xc2(0x01)
	bool bDebugMode; // 0xc3(0x01)
	bool bTransparentvisualizer; // 0xc4(0x01)
	char pad_C5[0x3]; // 0xc5(0x03)
};

