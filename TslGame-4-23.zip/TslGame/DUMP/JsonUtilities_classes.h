// Class JsonUtilities.JsonUtilitiesDummyObject
// Size: 0x38 (Inherited: 0x38)
struct UJsonUtilitiesDummyObject : UObject {
};

