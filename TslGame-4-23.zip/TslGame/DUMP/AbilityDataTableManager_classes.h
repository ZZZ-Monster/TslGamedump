// BlueprintGeneratedClass AbilityDataTableManager.AbilityDataTableManager_C
// Size: 0x138 (Inherited: 0x138)
struct UAbilityDataTableManager_C : UTslAbilityDataTableManager {
};

