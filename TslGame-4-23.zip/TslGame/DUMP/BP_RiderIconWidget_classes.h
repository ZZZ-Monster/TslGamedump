// WidgetBlueprintGeneratedClass BP_RiderIconWidget.BP_RiderIconWidget_C
// Size: 0x448 (Inherited: 0x448)
struct UBP_RiderIconWidget_C : URiderIconWidget {
};

