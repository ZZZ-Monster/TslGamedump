// WidgetBlueprintGeneratedClass BP_KillLogViewWidget.BP_KillLogViewWidget_C
// Size: 0x460 (Inherited: 0x448)
struct UBP_KillLogViewWidget_C : UTslKillLogViewWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x448(0x08)
	struct UButton* Button_1; // 0x450(0x08)
	struct UImage* DebugCrosshair; // 0x458(0x08)

	void BndEvt__Button_0_K2Node_ComponentBoundEvent_116_OnButtonClickedEvent__DelegateSignature(); // Function BP_KillLogViewWidget.BP_KillLogViewWidget_C.BndEvt__Button_0_K2Node_ComponentBoundEvent_116_OnButtonClickedEvent__DelegateSignature // BlueprintEvent // @ game+0x33e45c
	void ExecuteUbergraph_BP_KillLogViewWidget(int32 EntryPoint); // Function BP_KillLogViewWidget.BP_KillLogViewWidget_C.ExecuteUbergraph_BP_KillLogViewWidget //  // @ game+0x33e45c
};

