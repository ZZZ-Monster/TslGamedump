// Class MovieSceneTracks.MovieScene3DConstraintSection
// Size: 0xf0 (Inherited: 0xe0)
struct UMovieScene3DConstraintSection : UMovieSceneSection {
	struct FGuid ConstraintId; // 0xe0(0x10)
};

// Class MovieSceneTracks.MovieScene3DAttachSection
// Size: 0x110 (Inherited: 0xf0)
struct UMovieScene3DAttachSection : UMovieScene3DConstraintSection {
	struct FName AttachSocketName; // 0xf0(0x08)
	struct FName AttachComponentName; // 0xf8(0x08)
	char bConstrainTx : 1; // 0x100(0x01)
	char bConstrainTy : 1; // 0x100(0x01)
	char bConstrainTz : 1; // 0x100(0x01)
	char bConstrainRx : 1; // 0x100(0x01)
	char bConstrainRy : 1; // 0x100(0x01)
	char bConstrainRz : 1; // 0x100(0x01)
	char pad_100_6 : 2; // 0x100(0x01)
	char pad_101[0xf]; // 0x101(0x0f)
};

// Class MovieSceneTracks.MovieScene3DPathSection
// Size: 0x170 (Inherited: 0xf0)
struct UMovieScene3DPathSection : UMovieScene3DConstraintSection {
	struct FRichCurve TimingCurve; // 0xf0(0x70)
	enum class MovieScene3DPathSection_Axis FrontAxisEnum; // 0x160(0x01)
	enum class MovieScene3DPathSection_Axis UpAxisEnum; // 0x161(0x01)
	char pad_162[0x2]; // 0x162(0x02)
	char bFollow : 1; // 0x164(0x01)
	char bReverse : 1; // 0x164(0x01)
	char bForceUpright : 1; // 0x164(0x01)
	char pad_164_3 : 5; // 0x164(0x01)
	char pad_165[0xb]; // 0x165(0x0b)
};

// Class MovieSceneTracks.MovieScene3DConstraintTrack
// Size: 0xe0 (Inherited: 0xd0)
struct UMovieScene3DConstraintTrack : UMovieSceneTrack {
	struct TArray<struct UMovieSceneSection*> ConstraintSections; // 0xc8(0x10)
};

// Class MovieSceneTracks.MovieScene3DAttachTrack
// Size: 0xe0 (Inherited: 0xe0)
struct UMovieScene3DAttachTrack : UMovieScene3DConstraintTrack {
};

// Class MovieSceneTracks.MovieScene3DPathTrack
// Size: 0xe0 (Inherited: 0xe0)
struct UMovieScene3DPathTrack : UMovieScene3DConstraintTrack {
};

// Class MovieSceneTracks.MovieScene3DTransformSection
// Size: 0x4e0 (Inherited: 0xe0)
struct UMovieScene3DTransformSection : UMovieSceneSection {
	char pad_E0[0x8]; // 0xe0(0x08)
	struct FRichCurve Translation[0x03]; // 0xe8(0x150)
	struct FRichCurve Rotation[0x03]; // 0x238(0x150)
	struct FRichCurve Scale[0x03]; // 0x388(0x150)
	char pad_4D8[0x8]; // 0x4d8(0x08)
};

// Class MovieSceneTracks.MovieSceneActorReferenceSection
// Size: 0x180 (Inherited: 0xe0)
struct UMovieSceneActorReferenceSection : UMovieSceneSection {
	char pad_E0[0x8]; // 0xe0(0x08)
	struct FIntegralCurve ActorGuidIndexCurve; // 0xe8(0x70)
	char pad_158[0x10]; // 0x158(0x10)
	struct TArray<struct FString> ActorGuidStrings; // 0x168(0x10)
	char pad_178[0x8]; // 0x178(0x08)
};

// Class MovieSceneTracks.MovieSceneAudioSection
// Size: 0x210 (Inherited: 0xe0)
struct UMovieSceneAudioSection : UMovieSceneSection {
	struct USoundBase* Sound; // 0xe0(0x08)
	float StartOffset; // 0xe8(0x04)
	float AudioStartTime; // 0xec(0x04)
	float AudioDilationFactor; // 0xf0(0x04)
	float AudioVolume; // 0xf4(0x04)
	struct FRichCurve SoundVolume; // 0xf8(0x70)
	struct FRichCurve PitchMultiplier; // 0x168(0x70)
	bool bSuppressSubtitles; // 0x1d8(0x01)
	char pad_1D9[0x7]; // 0x1d9(0x07)
	DelegateProperty OnQueueSubtitles; // 0x1e0(0x10)
	struct FMulticastDelegate OnAudioFinished; // 0x1f0(0x10)
	struct FMulticastDelegate OnAudioPlaybackPercent; // 0x200(0x10)
};

// Class MovieSceneTracks.MovieSceneAudioTrack
// Size: 0xe0 (Inherited: 0xd0)
struct UMovieSceneAudioTrack : UMovieSceneNameableTrack {
	struct TArray<struct UMovieSceneSection*> AudioSections; // 0xc8(0x10)
};

// Class MovieSceneTracks.MovieSceneBoolSection
// Size: 0x160 (Inherited: 0xe0)
struct UMovieSceneBoolSection : UMovieSceneSection {
	char pad_E0[0x8]; // 0xe0(0x08)
	bool DefaultValue; // 0xe8(0x01)
	char pad_E9[0x7]; // 0xe9(0x07)
	struct FIntegralCurve BoolCurve; // 0xf0(0x70)
};

// Class MovieSceneTracks.MovieSceneSpawnSection
// Size: 0x160 (Inherited: 0x160)
struct UMovieSceneSpawnSection : UMovieSceneBoolSection {
};

// Class MovieSceneTracks.MovieSceneByteSection
// Size: 0x160 (Inherited: 0xe0)
struct UMovieSceneByteSection : UMovieSceneSection {
	char pad_E0[0x8]; // 0xe0(0x08)
	struct FIntegralCurve ByteCurve; // 0xe8(0x70)
	char pad_158[0x8]; // 0x158(0x08)
};

// Class MovieSceneTracks.MovieSceneCameraAnimSection
// Size: 0x120 (Inherited: 0xe0)
struct UMovieSceneCameraAnimSection : UMovieSceneSection {
	struct FMovieSceneCameraAnimSectionData AnimData; // 0xe0(0x20)
	struct UCameraAnim* CameraAnim; // 0x100(0x08)
	float PlayRate; // 0x108(0x04)
	float PlayScale; // 0x10c(0x04)
	float BlendInTime; // 0x110(0x04)
	float BlendOutTime; // 0x114(0x04)
	bool bLooping; // 0x118(0x01)
	char pad_119[0x7]; // 0x119(0x07)
};

// Class MovieSceneTracks.MovieSceneCameraAnimTrack
// Size: 0xe0 (Inherited: 0xd0)
struct UMovieSceneCameraAnimTrack : UMovieSceneNameableTrack {
	struct TArray<struct UMovieSceneSection*> CameraAnimSections; // 0xc8(0x10)
};

// Class MovieSceneTracks.MovieSceneCameraCutSection
// Size: 0xf0 (Inherited: 0xe0)
struct UMovieSceneCameraCutSection : UMovieSceneSection {
	struct FGuid CameraGuid; // 0xe0(0x10)
};

// Class MovieSceneTracks.MovieSceneCameraCutTrack
// Size: 0xe0 (Inherited: 0xd0)
struct UMovieSceneCameraCutTrack : UMovieSceneNameableTrack {
	struct TArray<struct UMovieSceneSection*> Sections; // 0xc8(0x10)
};

// Class MovieSceneTracks.MovieSceneCameraShakeSection
// Size: 0x120 (Inherited: 0xe0)
struct UMovieSceneCameraShakeSection : UMovieSceneSection {
	struct FMovieSceneCameraShakeSectionData ShakeData; // 0xe0(0x20)
	struct UClass* ShakeClass; // 0x100(0x08)
	float PlayScale; // 0x108(0x04)
	enum class ECameraAnimPlaySpace PlaySpace; // 0x10c(0x01)
	char pad_10D[0x3]; // 0x10d(0x03)
	struct FRotator UserDefinedPlaySpace; // 0x110(0x0c)
	char pad_11C[0x4]; // 0x11c(0x04)
};

// Class MovieSceneTracks.MovieSceneCameraShakeTrack
// Size: 0xe0 (Inherited: 0xd0)
struct UMovieSceneCameraShakeTrack : UMovieSceneNameableTrack {
	struct TArray<struct UMovieSceneSection*> CameraShakeSections; // 0xc8(0x10)
};

// Class MovieSceneTracks.MovieSceneColorSection
// Size: 0x2b0 (Inherited: 0xe0)
struct UMovieSceneColorSection : UMovieSceneSection {
	char pad_E0[0x8]; // 0xe0(0x08)
	struct FRichCurve RedCurve; // 0xe8(0x70)
	struct FRichCurve GreenCurve; // 0x158(0x70)
	struct FRichCurve BlueCurve; // 0x1c8(0x70)
	struct FRichCurve AlphaCurve; // 0x238(0x70)
	char pad_2A8[0x8]; // 0x2a8(0x08)
};

// Class MovieSceneTracks.MovieSceneEnumSection
// Size: 0x160 (Inherited: 0xe0)
struct UMovieSceneEnumSection : UMovieSceneSection {
	char pad_E0[0x8]; // 0xe0(0x08)
	struct FIntegralCurve EnumCurve; // 0xe8(0x70)
	char pad_158[0x8]; // 0x158(0x08)
};

// Class MovieSceneTracks.MovieSceneEventSection
// Size: 0x1f0 (Inherited: 0xe0)
struct UMovieSceneEventSection : UMovieSceneSection {
	struct FNameCurve Events; // 0xe0(0x68)
	struct FMovieSceneEventSectionData EventData; // 0x148(0x20)
	char pad_168[0x88]; // 0x168(0x88)
};

// Class MovieSceneTracks.MovieSceneSpawnTrack
// Size: 0xf0 (Inherited: 0xd0)
struct UMovieSceneSpawnTrack : UMovieSceneTrack {
	struct TArray<struct UMovieSceneSection*> Sections; // 0xc8(0x10)
	struct FGuid ObjectGuid; // 0xd8(0x10)
};

// Class MovieSceneTracks.MovieSceneEventTrack
// Size: 0xf0 (Inherited: 0xd0)
struct UMovieSceneEventTrack : UMovieSceneNameableTrack {
	char bFireEventsWhenForwards : 1; // 0xc8(0x01)
	char bFireEventsWhenBackwards : 1; // 0xc8(0x01)
	enum class EFireEventsAtPosition EventPosition; // 0xcc(0x01)
	struct TArray<struct FMovieSceneObjectBindingID> EventReceivers; // 0xd0(0x10)
	struct TArray<struct UMovieSceneSection*> Sections; // 0xe0(0x10)
};

// Class MovieSceneTracks.MovieSceneFloatSection
// Size: 0x160 (Inherited: 0xe0)
struct UMovieSceneFloatSection : UMovieSceneSection {
	char pad_E0[0x8]; // 0xe0(0x08)
	struct FRichCurve FloatCurve; // 0xe8(0x70)
	char pad_158[0x8]; // 0x158(0x08)
};

// Class MovieSceneTracks.MovieSceneFadeSection
// Size: 0x170 (Inherited: 0x160)
struct UMovieSceneFadeSection : UMovieSceneFloatSection {
	struct FLinearColor FadeColor; // 0x158(0x10)
	char bFadeAudio : 1; // 0x168(0x01)
};

// Class MovieSceneTracks.MovieSceneSlomoSection
// Size: 0x160 (Inherited: 0x160)
struct UMovieSceneSlomoSection : UMovieSceneFloatSection {
};

// Class MovieSceneTracks.MovieSceneIntegerSection
// Size: 0x160 (Inherited: 0xe0)
struct UMovieSceneIntegerSection : UMovieSceneSection {
	char pad_E0[0x8]; // 0xe0(0x08)
	struct FIntegralCurve IntegerCurve; // 0xe8(0x70)
	char pad_158[0x8]; // 0x158(0x08)
};

// Class MovieSceneTracks.MovieSceneLevelVisibilitySection
// Size: 0x100 (Inherited: 0xe0)
struct UMovieSceneLevelVisibilitySection : UMovieSceneSection {
	enum class ELevelVisibility Visibility; // 0xe0(0x01)
	char pad_E1[0x7]; // 0xe1(0x07)
	struct TArray<struct FName> LevelNames; // 0xe8(0x10)
	char pad_F8[0x8]; // 0xf8(0x08)
};

// Class MovieSceneTracks.MovieScenePropertyTrack
// Size: 0xf0 (Inherited: 0xd0)
struct UMovieScenePropertyTrack : UMovieSceneNameableTrack {
	struct FName PropertyName; // 0xc8(0x08)
	struct FString PropertyPath; // 0xd0(0x10)
	struct TArray<struct UMovieSceneSection*> Sections; // 0xe0(0x10)
};

// Class MovieSceneTracks.MovieSceneLevelVisibilityTrack
// Size: 0xe0 (Inherited: 0xd0)
struct UMovieSceneLevelVisibilityTrack : UMovieSceneNameableTrack {
	struct TArray<struct UMovieSceneSection*> Sections; // 0xc8(0x10)
};

// Class MovieSceneTracks.MovieSceneParameterSection
// Size: 0x110 (Inherited: 0xe0)
struct UMovieSceneParameterSection : UMovieSceneSection {
	struct TArray<struct FScalarParameterNameAndCurve> ScalarParameterNamesAndCurves; // 0xe0(0x10)
	struct TArray<struct FVectorParameterNameAndCurves> VectorParameterNamesAndCurves; // 0xf0(0x10)
	struct TArray<struct FColorParameterNameAndCurves> ColorParameterNamesAndCurves; // 0x100(0x10)
};

// Class MovieSceneTracks.MovieSceneMaterialTrack
// Size: 0xe0 (Inherited: 0xd0)
struct UMovieSceneMaterialTrack : UMovieSceneNameableTrack {
	struct TArray<struct UMovieSceneSection*> Sections; // 0xc8(0x10)
};

// Class MovieSceneTracks.MovieSceneComponentMaterialTrack
// Size: 0xe0 (Inherited: 0xe0)
struct UMovieSceneComponentMaterialTrack : UMovieSceneMaterialTrack {
	int32 MaterialIndex; // 0xd8(0x04)
};

// Class MovieSceneTracks.MovieSceneMaterialParameterCollectionTrack
// Size: 0xe0 (Inherited: 0xe0)
struct UMovieSceneMaterialParameterCollectionTrack : UMovieSceneMaterialTrack {
	struct UMaterialParameterCollection* MPC; // 0xd8(0x08)
};

// Class MovieSceneTracks.MovieSceneParticleParameterTrack
// Size: 0xe0 (Inherited: 0xd0)
struct UMovieSceneParticleParameterTrack : UMovieSceneNameableTrack {
	struct TArray<struct UMovieSceneSection*> Sections; // 0xc8(0x10)
};

// Class MovieSceneTracks.MovieSceneParticleSection
// Size: 0x150 (Inherited: 0xe0)
struct UMovieSceneParticleSection : UMovieSceneSection {
	struct FIntegralCurve ParticleKeys; // 0xe0(0x70)
};

// Class MovieSceneTracks.MovieSceneParticleTrack
// Size: 0xe0 (Inherited: 0xd0)
struct UMovieSceneParticleTrack : UMovieSceneNameableTrack {
	struct TArray<struct UMovieSceneSection*> ParticleSections; // 0xc8(0x10)
};

// Class MovieSceneTracks.MovieScene3DTransformTrack
// Size: 0xf0 (Inherited: 0xf0)
struct UMovieScene3DTransformTrack : UMovieScenePropertyTrack {
};

// Class MovieSceneTracks.MovieSceneActorReferenceTrack
// Size: 0xf0 (Inherited: 0xf0)
struct UMovieSceneActorReferenceTrack : UMovieScenePropertyTrack {
};

// Class MovieSceneTracks.MovieSceneBoolTrack
// Size: 0xf0 (Inherited: 0xf0)
struct UMovieSceneBoolTrack : UMovieScenePropertyTrack {
};

// Class MovieSceneTracks.MovieSceneVisibilityTrack
// Size: 0xf0 (Inherited: 0xf0)
struct UMovieSceneVisibilityTrack : UMovieSceneBoolTrack {
};

// Class MovieSceneTracks.MovieSceneByteTrack
// Size: 0x100 (Inherited: 0xf0)
struct UMovieSceneByteTrack : UMovieScenePropertyTrack {
	struct UEnum* Enum; // 0xf0(0x08)
	char pad_F8[0x8]; // 0xf8(0x08)
};

// Class MovieSceneTracks.MovieSceneColorTrack
// Size: 0x100 (Inherited: 0xf0)
struct UMovieSceneColorTrack : UMovieScenePropertyTrack {
	bool bIsSlateColor; // 0xf0(0x01)
	char pad_F1[0xf]; // 0xf1(0x0f)
};

// Class MovieSceneTracks.MovieSceneEnumTrack
// Size: 0x100 (Inherited: 0xf0)
struct UMovieSceneEnumTrack : UMovieScenePropertyTrack {
	struct UEnum* Enum; // 0xf0(0x08)
	char pad_F8[0x8]; // 0xf8(0x08)
};

// Class MovieSceneTracks.MovieSceneFloatTrack
// Size: 0xf0 (Inherited: 0xf0)
struct UMovieSceneFloatTrack : UMovieScenePropertyTrack {
};

// Class MovieSceneTracks.MovieSceneFadeTrack
// Size: 0xf0 (Inherited: 0xf0)
struct UMovieSceneFadeTrack : UMovieSceneFloatTrack {
};

// Class MovieSceneTracks.MovieSceneSlomoTrack
// Size: 0xf0 (Inherited: 0xf0)
struct UMovieSceneSlomoTrack : UMovieSceneFloatTrack {
};

// Class MovieSceneTracks.MovieSceneIntegerTrack
// Size: 0xf0 (Inherited: 0xf0)
struct UMovieSceneIntegerTrack : UMovieScenePropertyTrack {
};

// Class MovieSceneTracks.MovieSceneStringTrack
// Size: 0xf0 (Inherited: 0xf0)
struct UMovieSceneStringTrack : UMovieScenePropertyTrack {
};

// Class MovieSceneTracks.MovieSceneTransformTrack
// Size: 0xf0 (Inherited: 0xf0)
struct UMovieSceneTransformTrack : UMovieScenePropertyTrack {
};

// Class MovieSceneTracks.MovieSceneVectorTrack
// Size: 0x100 (Inherited: 0xf0)
struct UMovieSceneVectorTrack : UMovieScenePropertyTrack {
	int32 NumChannelsUsed; // 0xf0(0x04)
	char pad_F4[0xc]; // 0xf4(0x0c)
};

// Class MovieSceneTracks.MovieSceneSkeletalAnimationSection
// Size: 0x1a0 (Inherited: 0xe0)
struct UMovieSceneSkeletalAnimationSection : UMovieSceneSection {
	struct FMovieSceneSkeletalAnimationParams Params; // 0xe0(0x90)
	struct UAnimSequence* AnimSequence; // 0x170(0x08)
	struct UAnimSequenceBase* Animation; // 0x178(0x08)
	float StartOffset; // 0x180(0x04)
	float EndOffset; // 0x184(0x04)
	float PlayRate; // 0x188(0x04)
	char bReverse : 1; // 0x18c(0x01)
	char pad_18C_1 : 7; // 0x18c(0x01)
	char pad_18D[0x3]; // 0x18d(0x03)
	struct FName SlotName; // 0x190(0x08)
	char pad_198[0x8]; // 0x198(0x08)
};

// Class MovieSceneTracks.MovieSceneSkeletalAnimationTrack
// Size: 0xe0 (Inherited: 0xd0)
struct UMovieSceneSkeletalAnimationTrack : UMovieSceneNameableTrack {
	struct TArray<struct UMovieSceneSection*> AnimationSections; // 0xc8(0x10)
};

// Class MovieSceneTracks.MovieSceneStringSection
// Size: 0x160 (Inherited: 0xe0)
struct UMovieSceneStringSection : UMovieSceneSection {
	char pad_E0[0x8]; // 0xe0(0x08)
	struct FStringCurve StringCurve; // 0xe8(0x78)
};

// Class MovieSceneTracks.MovieSceneSubSection
// Size: 0x150 (Inherited: 0xe0)
struct UMovieSceneSubSection : UMovieSceneSection {
	struct FMovieSceneSectionParameters Parameters; // 0xe0(0x14)
	float StartOffset; // 0xf4(0x04)
	float TimeScale; // 0xf8(0x04)
	float PrerollTime; // 0xfc(0x04)
	struct UMovieSceneSequence* SubSequence; // 0x100(0x08)
	struct AActor* ActorToRecord; // 0x108(0x1c)
	char pad_124[0x4]; // 0x124(0x04)
	struct FString TargetSequenceName; // 0x128(0x10)
	struct FDirectoryPath TargetPathToRecordTo; // 0x138(0x10)
	char pad_148[0x8]; // 0x148(0x08)
};

// Class MovieSceneTracks.MovieSceneCinematicShotSection
// Size: 0x160 (Inherited: 0x150)
struct UMovieSceneCinematicShotSection : UMovieSceneSubSection {
	struct FText DisplayName; // 0x148(0x18)
};

// Class MovieSceneTracks.MovieSceneSubTrack
// Size: 0xe0 (Inherited: 0xd0)
struct UMovieSceneSubTrack : UMovieSceneNameableTrack {
	struct TArray<struct UMovieSceneSection*> Sections; // 0xc8(0x10)
};

// Class MovieSceneTracks.MovieSceneCinematicShotTrack
// Size: 0xe0 (Inherited: 0xe0)
struct UMovieSceneCinematicShotTrack : UMovieSceneSubTrack {
};

// Class MovieSceneTracks.MovieSceneVectorSection
// Size: 0x2b0 (Inherited: 0xe0)
struct UMovieSceneVectorSection : UMovieSceneSection {
	char pad_E0[0x8]; // 0xe0(0x08)
	struct FRichCurve Curves[0x04]; // 0xe8(0x1c0)
	int32 ChannelsUsed; // 0x2a8(0x04)
	char pad_2AC[0x4]; // 0x2ac(0x04)
};

