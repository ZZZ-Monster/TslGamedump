// WidgetBlueprintGeneratedClass PlatoonFireSupportAreaIndicator.PlatoonFireSupportAreaIndicator_C
// Size: 0x260 (Inherited: 0x260)
struct UPlatoonFireSupportAreaIndicator_C : UUserWidget {
};

