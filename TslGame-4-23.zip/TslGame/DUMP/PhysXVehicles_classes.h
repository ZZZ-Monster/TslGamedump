// Class PhysXVehicles.VehicleWheel
// Size: 0x138 (Inherited: 0x38)
struct UVehicleWheel : UObject {
	struct UStaticMesh* CollisionMesh; // 0x38(0x08)
	bool bDontCreateShape; // 0x40(0x01)
	bool bAutoAdjustCollisionSize; // 0x41(0x01)
	char pad_42[0x2]; // 0x42(0x02)
	struct FVector Offset; // 0x44(0x0c)
	float ShapeRadius; // 0x50(0x04)
	float ShapeWidth; // 0x54(0x04)
	float Mass; // 0x58(0x04)
	float DampingRate; // 0x5c(0x04)
	float SteerAngle; // 0x60(0x04)
	bool bAffectedByHandbrake; // 0x64(0x01)
	char pad_65[0x3]; // 0x65(0x03)
	struct UTireType* TireType; // 0x68(0x08)
	struct UTireConfig* TireConfig; // 0x70(0x08)
	float LatStiffMaxLoad; // 0x78(0x04)
	float LatStiffValue; // 0x7c(0x04)
	float LongStiffValue; // 0x80(0x04)
	float SuspensionForceOffset; // 0x84(0x04)
	float SuspensionForceOffsetX; // 0x88(0x04)
	struct FVector SuspensionTravelDir; // 0x8c(0x0c)
	struct FVector TireForceOffset; // 0x98(0x0c)
	float SuspensionMaxRaise; // 0xa4(0x04)
	float SuspensionMaxDrop; // 0xa8(0x04)
	float SuspensionNaturalFrequency; // 0xac(0x04)
	float SuspensionDampingRatio; // 0xb0(0x04)
	float DampenerBoundScale; // 0xb4(0x04)
	float DampenerReboundScale; // 0xb8(0x04)
	float SuspensionLimitVelocityScalar; // 0xbc(0x04)
	struct FWheelDetailedConfig WheelDetailedConfig; // 0xc0(0x14)
	float MaxBrakeTorque; // 0xd4(0x04)
	float MaxHandBrakeTorque; // 0xd8(0x04)
	enum class ECollisionChannel QueryChannel; // 0xdc(0x01)
	char pad_DD[0x3]; // 0xdd(0x03)
	struct UWheeledVehicleMovementComponent* VehicleSim; // 0xe0(0x08)
	int32 WheelIndex; // 0xe8(0x04)
	float DebugLongSlip; // 0xec(0x04)
	float DebugLatSlip; // 0xf0(0x04)
	float DebugNormalizedTireLoad; // 0xf4(0x04)
	char pad_F8[0x4]; // 0xf8(0x04)
	float DebugWheelTorque; // 0xfc(0x04)
	float DebugLongForce; // 0x100(0x04)
	float DebugLatForce; // 0x104(0x04)
	struct FVector Location; // 0x108(0x0c)
	struct FVector OldLocation; // 0x114(0x0c)
	struct FVector Velocity; // 0x120(0x0c)
	float RealWheelRotationSpeed; // 0x12c(0x04)
	char pad_130[0x8]; // 0x130(0x08)

	bool IsInAir(); // Function PhysXVehicles.VehicleWheel.IsInAir // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5e3c274
	float GetSuspensionOffset(); // Function PhysXVehicles.VehicleWheel.GetSuspensionOffset // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5e3c1c8
	float GetSteerAngle(); // Function PhysXVehicles.VehicleWheel.GetSteerAngle // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5e3c1a0
	float GetRotationAngle(); // Function PhysXVehicles.VehicleWheel.GetRotationAngle // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5e3c150
	float GetLongitudinalSlip(); // Function PhysXVehicles.VehicleWheel.GetLongitudinalSlip // Final|Native|Public|BlueprintCallable // @ game+0x5e3c128
	float GetLateralSlip(); // Function PhysXVehicles.VehicleWheel.GetLateralSlip // Final|Native|Public|BlueprintCallable // @ game+0x5e3c100
};

// Class PhysXVehicles.WheeledVehicleMovementComponent
// Size: 0x420 (Inherited: 0x290)
struct UWheeledVehicleMovementComponent : UPawnMovementComponent {
	char bDeprecatedSpringOffsetMode : 1; // 0x290(0x01)
	char pad_290_1 : 7; // 0x290(0x01)
	char pad_291[0x7]; // 0x291(0x07)
	struct TArray<bool> TirePunctured; // 0x298(0x10)
	struct TArray<struct FWheelSetup> WheelSetups; // 0x2a8(0x10)
	struct TArray<struct FVehicleAntiRollbarSetup> AntirollSetups; // 0x2b8(0x10)
	float Mass; // 0x2c8(0x04)
	float DragCoefficient; // 0x2cc(0x04)
	float ChassisWidth; // 0x2d0(0x04)
	float ChassisHeight; // 0x2d4(0x04)
	bool bReverseAsBrake; // 0x2d8(0x01)
	char pad_2D9[0x3]; // 0x2d9(0x03)
	float DragArea; // 0x2dc(0x04)
	float EstimatedMaxEngineSpeed; // 0x2e0(0x04)
	float MaxEngineRPM; // 0x2e4(0x04)
	float DebugDragMagnitude; // 0x2e8(0x04)
	struct FVector InertiaTensorScale; // 0x2ec(0x0c)
	float MinNormalizedTireLoad; // 0x2f8(0x04)
	float MinNormalizedTireLoadFiltered; // 0x2fc(0x04)
	float MaxNormalizedTireLoad; // 0x300(0x04)
	float MaxNormalizedTireLoadFiltered; // 0x304(0x04)
	float ServerSuspensionDampingRate; // 0x308(0x04)
	float ThresholdLongitudinalSpeed; // 0x30c(0x04)
	int32 LowForwardSpeedSubStepCount; // 0x310(0x04)
	int32 HighForwardSpeedSubStepCount; // 0x314(0x04)
	struct TArray<struct UVehicleWheel*> Wheels; // 0x318(0x10)
	char pad_328[0x18]; // 0x328(0x18)
	char bUseRVOAvoidance : 1; // 0x340(0x01)
	char pad_340_1 : 7; // 0x340(0x01)
	char pad_341[0x3]; // 0x341(0x03)
	float RVOAvoidanceRadius; // 0x344(0x04)
	float RVOAvoidanceHeight; // 0x348(0x04)
	float AvoidanceConsiderationRadius; // 0x34c(0x04)
	float RVOSteeringStep; // 0x350(0x04)
	float RVOThrottleStep; // 0x354(0x04)
	int32 AvoidanceUID; // 0x358(0x04)
	struct FNavAvoidanceMask AvoidanceGroup; // 0x35c(0x04)
	struct FNavAvoidanceMask GroupsToAvoid; // 0x360(0x04)
	struct FNavAvoidanceMask GroupsToIgnore; // 0x364(0x04)
	float AvoidanceWeight; // 0x368(0x04)
	struct FVector PendingLaunchVelocity; // 0x36c(0x0c)
	char pad_378[0x4]; // 0x378(0x04)
	struct FReplicatedVehicleState ReplicatedState; // 0x37c(0x14)
	char pad_390[0x4]; // 0x390(0x04)
	float RawSteeringInput; // 0x394(0x04)
	float RawThrottleInput; // 0x398(0x04)
	float RawBrakeInput; // 0x39c(0x04)
	char bRawHandbrakeInput : 1; // 0x3a0(0x01)
	char bRawGearUpInput : 1; // 0x3a0(0x01)
	char bRawGearDownInput : 1; // 0x3a0(0x01)
	char pad_3A0_3 : 5; // 0x3a0(0x01)
	char pad_3A1[0x3]; // 0x3a1(0x03)
	float LastForwardInput; // 0x3a4(0x04)
	float LastRightInput; // 0x3a8(0x04)
	float LastHandbrakeInput; // 0x3ac(0x04)
	int32 LastGear; // 0x3b0(0x04)
	float SteeringInput; // 0x3b4(0x04)
	float ThrottleInput; // 0x3b8(0x04)
	float BrakeInput; // 0x3bc(0x04)
	float HandbrakeInput; // 0x3c0(0x04)
	float IdleBrakeInput; // 0x3c4(0x04)
	float StopThreshold; // 0x3c8(0x04)
	float WrongDirectionThreshold; // 0x3cc(0x04)
	struct FVehicleInputRate ThrottleInputRate; // 0x3d0(0x08)
	struct FVehicleInputRate BrakeInputRate; // 0x3d8(0x08)
	struct FVehicleInputRate HandbrakeInputRate; // 0x3e0(0x08)
	struct FVehicleInputRate SteeringInputRate; // 0x3e8(0x08)
	char bWasAvoidanceUpdated : 1; // 0x3f0(0x01)
	char pad_3F0_1 : 7; // 0x3f0(0x01)
	char pad_3F1[0x2f]; // 0x3f1(0x2f)

	void SetUseAutoGears(bool bUseAuto); // Function PhysXVehicles.WheeledVehicleMovementComponent.SetUseAutoGears // Final|Native|Public|BlueprintCallable // @ game+0x5e3d1b0
	void SetThrottleInput(float Throttle); // Function PhysXVehicles.WheeledVehicleMovementComponent.SetThrottleInput // Final|Native|Public|BlueprintCallable // @ game+0x5e3d100
	void SetTargetGear(int32 GearNum, bool bImmediate); // Function PhysXVehicles.WheeledVehicleMovementComponent.SetTargetGear // Final|Native|Public|BlueprintCallable // @ game+0x5e3d024
	void SetSteeringInput(float Steering); // Function PhysXVehicles.WheeledVehicleMovementComponent.SetSteeringInput // Final|Native|Public|BlueprintCallable // @ game+0x5e3cf74
	void SetHandbrakeInput(bool bNewHandbrake); // Function PhysXVehicles.WheeledVehicleMovementComponent.SetHandbrakeInput // Final|Native|Public|BlueprintCallable // @ game+0x5e3cdfc
	void SetGroupsToIgnoreMask(struct FNavAvoidanceMask GroupMask); // Function PhysXVehicles.WheeledVehicleMovementComponent.SetGroupsToIgnoreMask // Final|Native|Public|HasOutParms|BlueprintCallable // @ game+0x5e3cd60
	void SetGroupsToIgnore(int32 GroupFlags); // Function PhysXVehicles.WheeledVehicleMovementComponent.SetGroupsToIgnore // Final|Native|Public|BlueprintCallable // @ game+0x5e3ccd4
	void SetGroupsToAvoidMask(struct FNavAvoidanceMask GroupMask); // Function PhysXVehicles.WheeledVehicleMovementComponent.SetGroupsToAvoidMask // Final|Native|Public|HasOutParms|BlueprintCallable // @ game+0x5e3cc38
	void SetGroupsToAvoid(int32 GroupFlags); // Function PhysXVehicles.WheeledVehicleMovementComponent.SetGroupsToAvoid // Final|Native|Public|BlueprintCallable // @ game+0x5e3cbac
	void SetGearUp(bool bNewGearUp); // Function PhysXVehicles.WheeledVehicleMovementComponent.SetGearUp // Final|Native|Public|BlueprintCallable // @ game+0x5e3cb10
	void SetGearDown(bool bNewGearDown); // Function PhysXVehicles.WheeledVehicleMovementComponent.SetGearDown // Final|Native|Public|BlueprintCallable // @ game+0x5e3ca74
	void SetBrakeInput(float Brake); // Function PhysXVehicles.WheeledVehicleMovementComponent.SetBrakeInput // Final|Native|Public|BlueprintCallable // @ game+0x5e3c804
	void SetAvoidanceGroupMask(struct FNavAvoidanceMask GroupMask); // Function PhysXVehicles.WheeledVehicleMovementComponent.SetAvoidanceGroupMask // Final|Native|Public|HasOutParms|BlueprintCallable // @ game+0x5e3c768
	void SetAvoidanceGroup(int32 GroupFlags); // Function PhysXVehicles.WheeledVehicleMovementComponent.SetAvoidanceGroup // Final|Native|Public|BlueprintCallable // @ game+0x5e3c6dc
	void SetAvoidanceEnabled(bool bEnable); // Function PhysXVehicles.WheeledVehicleMovementComponent.SetAvoidanceEnabled // Final|Native|Public|BlueprintCallable // @ game+0x5e3c5f4
	void ServerUpdateState(float InSteeringInput, float InThrottleInput, float InBrakeInput, float InHandbrakeInput, int32 CurrentGear, uint32 Checksum); // Function PhysXVehicles.WheeledVehicleMovementComponent.ServerUpdateState // Net|Native|Event|Protected|NetServer|NetValidate // @ game+0x5e3c38c
	void OnRep_TirePunctured(struct TArray<bool> LastTirePunctured); // Function PhysXVehicles.WheeledVehicleMovementComponent.OnRep_TirePunctured // Native|Public // @ game+0x5e3c298
	bool GetUseAutoGears(); // Function PhysXVehicles.WheeledVehicleMovementComponent.GetUseAutoGears // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5e3c228
	int32 GetTargetGear(); // Function PhysXVehicles.WheeledVehicleMovementComponent.GetTargetGear // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5e3c1f0
	float GetSideSpeed(); // Function PhysXVehicles.WheeledVehicleMovementComponent.GetSideSpeed // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5e3c178
	float GetForwardSpeed(); // Function PhysXVehicles.WheeledVehicleMovementComponent.GetForwardSpeed // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5e3c0d8
	float GetEngineRotationSpeed(); // Function PhysXVehicles.WheeledVehicleMovementComponent.GetEngineRotationSpeed // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5e3c0b0
	float GetEngineMaxRotationSpeed(); // Function PhysXVehicles.WheeledVehicleMovementComponent.GetEngineMaxRotationSpeed // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5e3c098
	int32 GetCurrentGear(); // Function PhysXVehicles.WheeledVehicleMovementComponent.GetCurrentGear // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5e3c060
};

// Class PhysXVehicles.WheeledVehicleMovementComponent4W
// Size: 0x580 (Inherited: 0x420)
struct UWheeledVehicleMovementComponent4W : UWheeledVehicleMovementComponent {
	struct FVehicleEngineData EngineSetup; // 0x418(0x90)
	struct FVehicleDifferential4WData DifferentialSetup; // 0x4a8(0x1c)
	struct FVehicleTransmissionData TransmissionSetup; // 0x4c8(0x30)
	struct FRuntimeFloatCurve SteeringCurve; // 0x4f8(0x78)
	float AckermannAccuracy; // 0x570(0x04)
	char pad_578[0x8]; // 0x578(0x08)
};

// Class PhysXVehicles.WheeledVehicle
// Size: 0x460 (Inherited: 0x450)
struct AWheeledVehicle : APawn {
	struct USkeletalMeshComponent* Mesh; // 0x450(0x08)
	struct UWheeledVehicleMovementComponent* VehicleMovement; // 0x458(0x08)
};

// Class PhysXVehicles.VehicleAnimInstance
// Size: 0x920 (Inherited: 0x3a8)
struct UVehicleAnimInstance : UAnimInstance {
	char pad_3A8[0x558]; // 0x3a8(0x558)
	struct UWheeledVehicleMovementComponent* WheeledVehicleMovementComponent; // 0x900(0x08)
	bool bUseSupsensionInterpolation; // 0x908(0x01)
	char pad_909[0x3]; // 0x909(0x03)
	float VehicleSuspensionInterpSpeed_ContactUpwards; // 0x90c(0x04)
	float VehicleSuspensionInterpSpeed_Contact; // 0x910(0x04)
	float VehicleSuspensionInterpSpeed_NoContact; // 0x914(0x04)
	char pad_918[0x8]; // 0x918(0x08)

	struct AWheeledVehicle* GetVehicle(); // Function PhysXVehicles.VehicleAnimInstance.GetVehicle // Final|Native|Public|BlueprintCallable // @ game+0x5e3c250
};

// Class PhysXVehicles.TireConfig
// Size: 0x90 (Inherited: 0x40)
struct UTireConfig : UDataAsset {
	float FrictionScale; // 0x40(0x04)
	char pad_44[0x4]; // 0x44(0x04)
	struct TArray<struct FTireConfigMaterialFriction> TireFrictionScales; // 0x48(0x10)
	char pad_58[0x8]; // 0x58(0x08)
	struct FTireConfigFrictionVsSlipGraph FrictionVsSlipConfig; // 0x60(0x28)
	bool bOverrideCamberStiffness; // 0x88(0x01)
	char pad_89[0x3]; // 0x89(0x03)
	float CamberStiffnessOverride; // 0x8c(0x04)
};

// Class PhysXVehicles.SimpleWheeledVehicleMovementComponent
// Size: 0x420 (Inherited: 0x420)
struct USimpleWheeledVehicleMovementComponent : UWheeledVehicleMovementComponent {

	void SetSteerAngle(float SteerAngle, int32 WheelIndex); // Function PhysXVehicles.SimpleWheeledVehicleMovementComponent.SetSteerAngle // Final|Native|Public|BlueprintCallable // @ game+0x5e3ce94
	void SetDriveTorque(float DriveTorque, int32 WheelIndex); // Function PhysXVehicles.SimpleWheeledVehicleMovementComponent.SetDriveTorque // Final|Native|Public|BlueprintCallable // @ game+0x5e3c994
	void SetBrakeTorque(float BrakeTorque, int32 WheelIndex); // Function PhysXVehicles.SimpleWheeledVehicleMovementComponent.SetBrakeTorque // Final|Native|Public|BlueprintCallable // @ game+0x5e3c8b4
};

