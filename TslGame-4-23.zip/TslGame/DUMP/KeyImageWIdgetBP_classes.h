// WidgetBlueprintGeneratedClass KeyImageWIdgetBP.KeyImageWIdgetBP_C
// Size: 0x478 (Inherited: 0x478)
struct UKeyImageWIdgetBP_C : UTslKeyboardAndMouseIconWidget {
};

