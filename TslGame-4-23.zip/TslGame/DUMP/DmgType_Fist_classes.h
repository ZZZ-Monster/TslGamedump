// BlueprintGeneratedClass DmgType_Fist.DmgType_Fist_C
// Size: 0x100 (Inherited: 0x100)
struct UDmgType_Fist_C : UTslDamageType {
};

