// Class MediaAssets.MediaOverlays
// Size: 0xc0 (Inherited: 0x38)
struct UMediaOverlays : UObject {
	char pad_38[0x88]; // 0x38(0x88)

	void GetTexts(struct TArray<struct FMediaPlayerOverlay> OutTexts, struct FTimespan Time); // Function MediaAssets.MediaOverlays.GetTexts // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5b811f8
	void GetSubtitles(struct TArray<struct FMediaPlayerOverlay> OutSubtitles, struct FTimespan Time); // Function MediaAssets.MediaOverlays.GetSubtitles // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5b810dc
	void GetCaptions(struct TArray<struct FMediaPlayerOverlay> OutCaptions, struct FTimespan Time); // Function MediaAssets.MediaOverlays.GetCaptions // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5b80974
};

// Class MediaAssets.MediaPlayer
// Size: 0x170 (Inherited: 0x38)
struct UMediaPlayer : UObject {
	char pad_38[0x18]; // 0x38(0x18)
	struct FMulticastDelegate OnEndReached; // 0x50(0x10)
	struct FMulticastDelegate OnMediaClosed; // 0x60(0x10)
	struct FMulticastDelegate OnMediaOpened; // 0x70(0x10)
	struct FMulticastDelegate OnMediaOpenFailed; // 0x80(0x10)
	struct FMulticastDelegate OnPlaybackResumed; // 0x90(0x10)
	struct FMulticastDelegate OnPlaybackSuspended; // 0xa0(0x10)
	bool PlayOnOpen; // 0xb0(0x01)
	char pad_B1[0x3]; // 0xb1(0x03)
	char Shuffle : 1; // 0xb4(0x01)
	char Loop : 1; // 0xb4(0x01)
	char pad_B4_2 : 6; // 0xb4(0x01)
	char pad_B5[0x3]; // 0xb5(0x03)
	struct UMediaOverlays* Overlays; // 0xb8(0x08)
	struct UMediaPlaylist* PlayList; // 0xc0(0x08)
	int32 PlaylistIndex; // 0xc8(0x04)
	char pad_CC[0x4]; // 0xcc(0x04)
	struct UMediaSoundWave* SoundWave; // 0xd0(0x08)
	struct UMediaTexture* VideoTexture; // 0xd8(0x08)
	char pad_E0[0x90]; // 0xe0(0x90)

	bool SupportsSeeking(); // Function MediaAssets.MediaPlayer.SupportsSeeking // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b8272c
	bool SupportsScrubbing(); // Function MediaAssets.MediaPlayer.SupportsScrubbing // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b826dc
	bool SupportsRate(float Rate, bool Unthinned); // Function MediaAssets.MediaPlayer.SupportsRate // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b825e8
	void SetVideoTexture(struct UMediaTexture* NewTexture); // Function MediaAssets.MediaPlayer.SetVideoTexture // Final|Native|Public|BlueprintCallable // @ game+0x5b82558
	void SetSoundWave(struct UMediaSoundWave* NewSoundWave); // Function MediaAssets.MediaPlayer.SetSoundWave // Final|Native|Public|BlueprintCallable // @ game+0x5b824c8
	bool SetRate(float Rate); // Function MediaAssets.MediaPlayer.SetRate // Final|Native|Public|BlueprintCallable // @ game+0x5b82420
	void SetOverlays(struct UMediaOverlays* NewOverlays); // Function MediaAssets.MediaPlayer.SetOverlays // Final|Native|Public|BlueprintCallable // @ game+0x5b82390
	bool SetLooping(bool Looping); // Function MediaAssets.MediaPlayer.SetLooping // Final|Native|Public|BlueprintCallable // @ game+0x5b822f0
	void SetDesiredPlayerName(struct FName PlayerName); // Function MediaAssets.MediaPlayer.SetDesiredPlayerName // Final|Native|Public|BlueprintCallable // @ game+0x5b8219c
	bool SelectTrack(enum class EMediaPlayerTrack TrackType, int32 TrackIndex); // Function MediaAssets.MediaPlayer.SelectTrack // Final|Native|Public|BlueprintCallable // @ game+0x5b8208c
	bool Seek(struct FTimespan Time); // Function MediaAssets.MediaPlayer.Seek // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b81fc4
	bool Rewind(); // Function MediaAssets.MediaPlayer.Rewind // Final|Native|Public|BlueprintCallable // @ game+0x5b81f68
	bool Reopen(); // Function MediaAssets.MediaPlayer.Reopen // Final|Native|Public|BlueprintCallable // @ game+0x5b81efc
	bool Previous(); // Function MediaAssets.MediaPlayer.Previous // Final|Native|Public|BlueprintCallable // @ game+0x5b81d78
	bool Play(); // Function MediaAssets.MediaPlayer.Play // Final|Native|Public|BlueprintCallable // @ game+0x5b81d44
	bool Pause(); // Function MediaAssets.MediaPlayer.Pause // Final|Native|Public|BlueprintCallable // @ game+0x5b81d14
	bool OpenUrl(struct FString URL); // Function MediaAssets.MediaPlayer.OpenUrl // Final|Native|Public|BlueprintCallable // @ game+0x5b81c48
	bool OpenSource(struct UMediaSource* MediaSource); // Function MediaAssets.MediaPlayer.OpenSource // Final|Native|Public|BlueprintCallable // @ game+0x5b81ba8
	bool OpenPlaylistIndex(struct UMediaPlaylist* InPlaylist, int32 Index); // Function MediaAssets.MediaPlayer.OpenPlaylistIndex // Final|Native|Public|BlueprintCallable // @ game+0x5b81ac0
	bool OpenPlaylist(struct UMediaPlaylist* InPlaylist); // Function MediaAssets.MediaPlayer.OpenPlaylist // Final|Native|Public|BlueprintCallable // @ game+0x5b81a1c
	bool OpenFile(struct FString FilePath); // Function MediaAssets.MediaPlayer.OpenFile // Final|Native|Public|BlueprintCallable // @ game+0x5b81950
	bool Next(); // Function MediaAssets.MediaPlayer.Next // Final|Native|Public|BlueprintCallable // @ game+0x5b81918
	bool IsReady(); // Function MediaAssets.MediaPlayer.IsReady // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b81890
	bool IsPreparing(); // Function MediaAssets.MediaPlayer.IsPreparing // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b81840
	bool IsPlaying(); // Function MediaAssets.MediaPlayer.IsPlaying // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b817f0
	bool IsPaused(); // Function MediaAssets.MediaPlayer.IsPaused // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b817a0
	bool IsLooping(); // Function MediaAssets.MediaPlayer.IsLooping // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b81750
	struct FString GetUrl(); // Function MediaAssets.MediaPlayer.GetUrl // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b815e0
	struct FString GetTrackLanguage(enum class EMediaPlayerTrack TrackType, int32 TrackIndex); // Function MediaAssets.MediaPlayer.GetTrackLanguage // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b81498
	struct FText GetTrackDisplayName(enum class EMediaPlayerTrack TrackType, int32 TrackIndex); // Function MediaAssets.MediaPlayer.GetTrackDisplayName // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b81360
	struct FTimespan GetTime(); // Function MediaAssets.MediaPlayer.GetTime // Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5b81314
	int32 GetSelectedTrack(enum class EMediaPlayerTrack TrackType); // Function MediaAssets.MediaPlayer.GetSelectedTrack // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b81028
	struct FFloatRange GetReverseRates(bool Unthinned); // Function MediaAssets.MediaPlayer.GetReverseRates // Final|Native|Public|BlueprintCallable // @ game+0x5b80f6c
	float GetRate(); // Function MediaAssets.MediaPlayer.GetRate // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b80f28
	struct FName GetPlayerName(); // Function MediaAssets.MediaPlayer.GetPlayerName // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b80d54
	int32 GetNumTracks(enum class EMediaPlayerTrack TrackType); // Function MediaAssets.MediaPlayer.GetNumTracks // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b80c94
	struct FFloatRange GetForwardRates(bool Unthinned); // Function MediaAssets.MediaPlayer.GetForwardRates // Final|Native|Public|BlueprintCallable // @ game+0x5b80af4
	struct FTimespan GetDuration(); // Function MediaAssets.MediaPlayer.GetDuration // Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5b80aa8
	struct FName GetDesiredPlayerName(); // Function MediaAssets.MediaPlayer.GetDesiredPlayerName // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b80a8c
	void Close(); // Function MediaAssets.MediaPlayer.Close // Final|Native|Public|BlueprintCallable // @ game+0x5b80898
	bool CanPlayUrl(struct FString URL); // Function MediaAssets.MediaPlayer.CanPlayUrl // Final|Native|Public|BlueprintCallable // @ game+0x5b807a4
	bool CanPlaySource(struct UMediaSource* MediaSource); // Function MediaAssets.MediaPlayer.CanPlaySource // Final|Native|Public|BlueprintCallable // @ game+0x5b80704
	bool CanPause(); // Function MediaAssets.MediaPlayer.CanPause // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b806b8
};

// Class MediaAssets.MediaPlaylist
// Size: 0x48 (Inherited: 0x38)
struct UMediaPlaylist : UObject {
	struct TArray<struct UMediaSource*> Items; // 0x38(0x10)

	void RemoveAt(int32 Index); // Function MediaAssets.MediaPlaylist.RemoveAt // Final|Native|Public|BlueprintCallable // @ game+0x5b81e34
	void Remove(struct UMediaSource* MediaSource); // Function MediaAssets.MediaPlaylist.Remove // Final|Native|Public|BlueprintCallable // @ game+0x5b81d9c
	int32 Num(); // Function MediaAssets.MediaPlaylist.Num // Final|Native|Public|BlueprintCallable // @ game+0x5b8193c
	void Insert(struct UMediaSource* MediaSource, int32 Index); // Function MediaAssets.MediaPlaylist.Insert // Final|Native|Public|BlueprintCallable // @ game+0x5b81638
	struct UMediaSource* GetRandom(int32 InOutIndex); // Function MediaAssets.MediaPlaylist.GetRandom // Final|Native|Public|HasOutParms|BlueprintCallable // @ game+0x5b80e7c
	struct UMediaSource* GetPrevious(int32 InOutIndex); // Function MediaAssets.MediaPlaylist.GetPrevious // Final|Native|Public|HasOutParms|BlueprintCallable // @ game+0x5b80da4
	struct UMediaSource* GetNext(int32 InOutIndex); // Function MediaAssets.MediaPlaylist.GetNext // Final|Native|Public|HasOutParms|BlueprintCallable // @ game+0x5b80be8
	struct UMediaSource* Get(int32 Index); // Function MediaAssets.MediaPlaylist.Get // Final|Native|Public|BlueprintCallable // @ game+0x5b808ac
	void Add(struct UMediaSource* MediaSource); // Function MediaAssets.MediaPlaylist.Add // Final|Native|Public|BlueprintCallable // @ game+0x5b80604
};

// Class MediaAssets.MediaSoundWave
// Size: 0x370 (Inherited: 0x298)
struct UMediaSoundWave : USoundWave {
	char pad_298[0x8]; // 0x298(0x08)
	int32 AudioTrackIndex; // 0x2a0(0x04)
	char pad_2A4[0x4]; // 0x2a4(0x04)
	struct UMediaPlayer* MediaPlayer; // 0x2a8(0x08)
	char pad_2B0[0xc0]; // 0x2b0(0xc0)
};

// Class MediaAssets.MediaSource
// Size: 0x40 (Inherited: 0x38)
struct UMediaSource : UObject {
	char pad_38[0x8]; // 0x38(0x08)
};

// Class MediaAssets.BaseMediaSource
// Size: 0x48 (Inherited: 0x40)
struct UBaseMediaSource : UMediaSource {
	struct FName PlayerName; // 0x40(0x08)
};

// Class MediaAssets.FileMediaSource
// Size: 0x60 (Inherited: 0x48)
struct UFileMediaSource : UBaseMediaSource {
	struct FString FilePath; // 0x48(0x10)
	bool PrecacheFile; // 0x58(0x01)
	char pad_59[0x7]; // 0x59(0x07)

	void SetFilePath(struct FString path); // Function MediaAssets.FileMediaSource.SetFilePath // Final|Native|Public|BlueprintCallable // @ game+0x5b82230
};

// Class MediaAssets.StreamMediaSource
// Size: 0x58 (Inherited: 0x48)
struct UStreamMediaSource : UBaseMediaSource {
	struct FString StreamUrl; // 0x48(0x10)
};

// Class MediaAssets.PlatformMediaSource
// Size: 0x48 (Inherited: 0x40)
struct UPlatformMediaSource : UMediaSource {
	struct UMediaSource* MediaSource; // 0x40(0x08)
};

// Class MediaAssets.MediaTexture
// Size: 0x1b0 (Inherited: 0xc8)
struct UMediaTexture : UTexture {
	char pad_C8[0x8]; // 0xc8(0x08)
	enum class TextureAddress AddressX; // 0xd0(0x01)
	enum class TextureAddress AddressY; // 0xd1(0x01)
	char pad_D2[0x2]; // 0xd2(0x02)
	struct FLinearColor ClearColor; // 0xd4(0x10)
	char pad_E4[0x4]; // 0xe4(0x04)
	struct UMediaPlayer* MediaPlayer; // 0xe8(0x08)
	int32 VideoTrackIndex; // 0xf0(0x04)
	char pad_F4[0xbc]; // 0xf4(0xbc)

	int32 GetWidth(); // Function MediaAssets.MediaTexture.GetWidth // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b81600
	int32 GetHeight(); // Function MediaAssets.MediaTexture.GetHeight // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b80bb0
	float GetAspectRatio(); // Function MediaAssets.MediaTexture.GetAspectRatio // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b8094c
};

