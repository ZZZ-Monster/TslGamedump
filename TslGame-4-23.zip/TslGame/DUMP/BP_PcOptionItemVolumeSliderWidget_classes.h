// WidgetBlueprintGeneratedClass BP_PcOptionItemVolumeSliderWidget.BP_PcOptionItemVolumeSliderWidget_C
// Size: 0x890 (Inherited: 0x888)
struct UBP_PcOptionItemVolumeSliderWidget_C : UTslGameOptionItemVolumeSliderWidget {
	struct UTslUniversalInputVisibilitySwitcher* TslUniversalInputVisibilitySwitcher_1; // 0x888(0x08)
};

