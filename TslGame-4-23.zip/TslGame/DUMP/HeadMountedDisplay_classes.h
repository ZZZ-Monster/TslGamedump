// Class HeadMountedDisplay.MotionControllerComponent
// Size: 0xa30 (Inherited: 0x9d0)
struct UMotionControllerComponent : UPrimitiveComponent {
	int32 PlayerIndex; // 0x9d0(0x04)
	enum class EControllerHand Hand; // 0x9d4(0x01)
	char pad_9D5[0x3]; // 0x9d5(0x03)
	char bDisableLowLatencyUpdate : 1; // 0x9d8(0x01)
	char pad_9D8_1 : 7; // 0x9d8(0x01)
	char pad_9D9[0x3]; // 0x9d9(0x03)
	enum class ETrackingStatus CurrentTrackingStatus; // 0x9dc(0x01)
	char pad_9DD[0x53]; // 0x9dd(0x53)

	bool IsTracked(); // Function HeadMountedDisplay.MotionControllerComponent.IsTracked // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x507dad4
};

// Class HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary
// Size: 0x38 (Inherited: 0x38)
struct UMotionTrackedDeviceFunctionLibrary : UBlueprintFunctionLibrary {

	void SetIsControllerMotionTrackingEnabledByDefault(bool Enable); // Function HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary.SetIsControllerMotionTrackingEnabledByDefault // Final|Native|Static|Public|BlueprintCallable // @ game+0x507daec
	bool IsMotionTrackingEnabledForDevice(int32 PlayerIndex, enum class EControllerHand Hand); // Function HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary.IsMotionTrackingEnabledForDevice // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x507d9fc
	bool IsMotionTrackingEnabledForComponent(struct UMotionControllerComponent* MotionControllerComponent); // Function HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary.IsMotionTrackingEnabledForComponent // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x507d958
	bool IsMotionTrackedDeviceCountManagementNecessary(); // Function HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary.IsMotionTrackedDeviceCountManagementNecessary // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x507d90c
	int32 GetMotionTrackingEnabledControllerCount(); // Function HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary.GetMotionTrackingEnabledControllerCount // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x507d87c
	int32 GetMaximumMotionTrackedControllerCount(); // Function HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary.GetMaximumMotionTrackedControllerCount // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x507d7ec
	bool EnableMotionTrackingOfDevice(int32 PlayerIndex, enum class EControllerHand Hand); // Function HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary.EnableMotionTrackingOfDevice // Final|Native|Static|Public|BlueprintCallable // @ game+0x507d714
	bool EnableMotionTrackingForComponent(struct UMotionControllerComponent* MotionControllerComponent); // Function HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary.EnableMotionTrackingForComponent // Final|Native|Static|Public|BlueprintCallable // @ game+0x507d670
	void DisableMotionTrackingOfDevice(int32 PlayerIndex, enum class EControllerHand Hand); // Function HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary.DisableMotionTrackingOfDevice // Final|Native|Static|Public|BlueprintCallable // @ game+0x507d59c
	void DisableMotionTrackingOfControllersForPlayer(int32 PlayerIndex); // Function HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary.DisableMotionTrackingOfControllersForPlayer // Final|Native|Static|Public|BlueprintCallable // @ game+0x507d520
	void DisableMotionTrackingOfAllControllers(); // Function HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary.DisableMotionTrackingOfAllControllers // Final|Native|Static|Public|BlueprintCallable // @ game+0x507d4a4
	void DisableMotionTrackingForComponent(struct UMotionControllerComponent* MotionControllerComponent); // Function HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary.DisableMotionTrackingForComponent // Final|Native|Static|Public|BlueprintCallable // @ game+0x507d41c
};

// Class HeadMountedDisplay.VRNotificationsComponent
// Size: 0x280 (Inherited: 0x200)
struct UVRNotificationsComponent : UActorComponent {
	struct FMulticastDelegate HMDTrackingInitializingAndNeedsHMDToBeTrackedDelegate; // 0x200(0x10)
	struct FMulticastDelegate HMDTrackingInitializedDelegate; // 0x210(0x10)
	struct FMulticastDelegate HMDRecenteredDelegate; // 0x220(0x10)
	struct FMulticastDelegate HMDLostDelegate; // 0x230(0x10)
	struct FMulticastDelegate HMDReconnectedDelegate; // 0x240(0x10)
	struct FMulticastDelegate HMDConnectCanceledDelegate; // 0x250(0x10)
	struct FMulticastDelegate HMDPutOnHeadDelegate; // 0x260(0x10)
	struct FMulticastDelegate HMDRemovedFromHeadDelegate; // 0x270(0x10)

	void VRNotificationsDelegate__DelegateSignature(); // DelegateFunction HeadMountedDisplay.VRNotificationsComponent.VRNotificationsDelegate__DelegateSignature // MulticastDelegate|Public|Delegate // @ game+0x33e45c
};

