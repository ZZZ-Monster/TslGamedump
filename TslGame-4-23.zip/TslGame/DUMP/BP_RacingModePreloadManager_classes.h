// BlueprintGeneratedClass BP_RacingModePreloadManager.BP_RacingModePreloadManager_C
// Size: 0xf0 (Inherited: 0xf0)
struct UBP_RacingModePreloadManager_C : UTslRacingPreloadManager {
};

