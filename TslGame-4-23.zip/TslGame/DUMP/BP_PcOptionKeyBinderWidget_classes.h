// WidgetBlueprintGeneratedClass BP_PcOptionKeyBinderWidget.BP_PcOptionKeyBinderWidget_C
// Size: 0x838 (Inherited: 0x838)
struct UBP_PcOptionKeyBinderWidget_C : UTslGameOptionItemKeyBinderWidget {
};

