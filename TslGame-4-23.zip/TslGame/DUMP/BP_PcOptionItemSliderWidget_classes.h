// WidgetBlueprintGeneratedClass BP_PcOptionItemSliderWidget.BP_PcOptionItemSliderWidget_C
// Size: 0x840 (Inherited: 0x840)
struct UBP_PcOptionItemSliderWidget_C : UTslGameOptionItemSliderWidget {
};

