// BlueprintGeneratedClass Implement_Boost_Drink.Implement_Boost_Drink_C
// Size: 0x40 (Inherited: 0x40)
struct UImplement_Boost_Drink_C : UCastableItemImplement_Boost {
};

