// BlueprintGeneratedClass CS_AntiLeanRight.CS_AntiLeanRight_C
// Size: 0x170 (Inherited: 0x170)
struct UCS_AntiLeanRight_C : UCS_AntiLeanLeft_C {
};

