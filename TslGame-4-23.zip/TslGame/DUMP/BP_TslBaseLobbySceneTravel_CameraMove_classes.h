// BlueprintGeneratedClass BP_TslBaseLobbySceneTravel_CameraMove.BP_TslBaseLobbySceneTravel_CameraMove_C
// Size: 0x4a0 (Inherited: 0x480)
struct ABP_TslBaseLobbySceneTravel_CameraMove_C : ATslBaseLobbySceneTravel {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x480(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x488(0x08)
	float CameraMove_Value_5540DD1349359D05D9E53CACA6BBFA89; // 0x490(0x04)
	enum class ETimelineDirection CameraMove__Direction_5540DD1349359D05D9E53CACA6BBFA89; // 0x494(0x01)
	char pad_495[0x3]; // 0x495(0x03)
	struct UTimelineComponent* CameraMove; // 0x498(0x08)

	void UserConstructionScript(); // Function BP_TslBaseLobbySceneTravel_CameraMove.BP_TslBaseLobbySceneTravel_CameraMove_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void CameraMove__FinishedFunc(); // Function BP_TslBaseLobbySceneTravel_CameraMove.BP_TslBaseLobbySceneTravel_CameraMove_C.CameraMove__FinishedFunc // BlueprintEvent // @ game+0x33e45c
	void CameraMove__UpdateFunc(); // Function BP_TslBaseLobbySceneTravel_CameraMove.BP_TslBaseLobbySceneTravel_CameraMove_C.CameraMove__UpdateFunc // BlueprintEvent // @ game+0x33e45c
	void OnStartTravel(); // Function BP_TslBaseLobbySceneTravel_CameraMove.BP_TslBaseLobbySceneTravel_CameraMove_C.OnStartTravel // Event|Public|BlueprintEvent // @ game+0x33e45c
	void ExecuteUbergraph_BP_TslBaseLobbySceneTravel_CameraMove(int32 EntryPoint); // Function BP_TslBaseLobbySceneTravel_CameraMove.BP_TslBaseLobbySceneTravel_CameraMove_C.ExecuteUbergraph_BP_TslBaseLobbySceneTravel_CameraMove // HasDefaults // @ game+0x33e45c
};

