// WidgetBlueprintGeneratedClass HudMain.HudMain_C
// Size: 0x4c0 (Inherited: 0x430)
struct UHudMain_C : UHudMainBaseWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x430(0x08)
	struct UCanvasPanel* HideOnObserverSpectating; // 0x438(0x08)
	struct UCanvasPanel* Main; // 0x440(0x08)
	struct FMulticastDelegate ButtonClickedDispatcher; // 0x448(0x10)
	struct UHitNotifyWidget_C* HitNotify; // 0x458(0x08)
	struct FColorBlindColorSet ColorBlindColorSet_SpetatingName; // 0x460(0x10)
	struct FTimerHandle ReplayGetTimeHandler; // 0x470(0x08)
	struct FWidgetTransform ObserverSpectatingDownPos; // 0x478(0x1c)
	struct FWidgetTransform ObserverSpectatingUpPos; // 0x494(0x1c)
	float LastOptionToggleTime; // 0x4b0(0x04)
	float SholderPressedTime; // 0x4b4(0x04)
	struct UWBP_BlackZoneWarning_C* BlackZoneWarningWidget; // 0x4b8(0x08)

	void OnInsideBlackZone(); // Function HudMain.HudMain_C.OnInsideBlackZone // Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void OnNewBlackZone(); // Function HudMain.HudMain_C.OnNewBlackZone // Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void OnKey_ThrowableItemWheelReleased(); // Function HudMain.HudMain_C.OnKey_ThrowableItemWheelReleased // Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void OnKey_ThrowableItemWheelPressed(); // Function HudMain.HudMain_C.OnKey_ThrowableItemWheelPressed // Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void OnKey_HealItemWheelReleased(); // Function HudMain.HudMain_C.OnKey_HealItemWheelReleased // Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void OnKey_HealItemWheelPressed(); // Function HudMain.HudMain_C.OnKey_HealItemWheelPressed // Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void MapIconShowNameOnly(); // Function HudMain.HudMain_C.MapIconShowNameOnly // Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void MapIconShowIconOnly(); // Function HudMain.HudMain_C.MapIconShowIconOnly // Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void MapIconShowBoth(); // Function HudMain.HudMain_C.MapIconShowBoth // Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void MapIconShow(bool bShowIcon, bool bShowName); // Function HudMain.HudMain_C.MapIconShow // Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void OnToggleAnticheatCenterBar(); // Function HudMain.HudMain_C.OnToggleAnticheatCenterBar // Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void OnKey_EmoteWheelReleased(); // Function HudMain.HudMain_C.OnKey_EmoteWheelReleased // Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void OnKey_EmoteWheelPressed(); // Function HudMain.HudMain_C.OnKey_EmoteWheelPressed // Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	bool OnInit_Delegate(struct ATslBaseHUD* TslBaseHUD); // Function HudMain.HudMain_C.OnInit_Delegate // Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	bool OnInit_Replay(struct ATslBaseHUD* TslBaseHUD); // Function HudMain.HudMain_C.OnInit_Replay // Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	bool OnInit_Input(struct ATslBaseHUD* TslBaseHUD); // Function HudMain.HudMain_C.OnInit_Input // Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	bool OnInit_Widget(struct ATslBaseHUD* TslBaseHUD); // Function HudMain.HudMain_C.OnInit_Widget // Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	struct FEventReply OnMouseMove(struct FGeometry MyGeometry, struct FPointerEvent MouseEvent); // Function HudMain.HudMain_C.OnMouseMove // BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void SetObserverSpectatingUp(); // Function HudMain.HudMain_C.SetObserverSpectatingUp // Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void SetObserverSpectatingDown(); // Function HudMain.HudMain_C.SetObserverSpectatingDown // Public|HasDefaults|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void ShouldShowReplayMenu(bool bShow); // Function HudMain.HudMain_C.ShouldShowReplayMenu // Public|HasOutParms|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void BindEventForShowReplayTimeline(); // Function HudMain.HudMain_C.BindEventForShowReplayTimeline // Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void ShowReplayTimeLine(bool bShow); // Function HudMain.HudMain_C.ShowReplayTimeLine // Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void SetHUDForIngameReplayMenu(); // Function HudMain.HudMain_C.SetHUDForIngameReplayMenu // Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void BindEventForMapClosing(); // Function HudMain.HudMain_C.BindEventForMapClosing // Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void OnKey_ReplayMenuOrEscape(); // Function HudMain.HudMain_C.OnKey_ReplayMenuOrEscape // Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void InitForReplay(); // Function HudMain.HudMain_C.InitForReplay // Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void OnToggleOption(); // Function HudMain.HudMain_C.OnToggleOption // Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void OnMapHide(); // Function HudMain.HudMain_C.OnMapHide // Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void OnMapShow(); // Function HudMain.HudMain_C.OnMapShow // Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void OnKey_MapReleased(); // Function HudMain.HudMain_C.OnKey_MapReleased // Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void OnKey_MapPressed(); // Function HudMain.HudMain_C.OnKey_MapPressed // Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void OnShowCarePackageItemList(); // Function HudMain.HudMain_C.OnShowCarePackageItemList // Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void IsShowMapOrInventory(bool bIsShow); // Function HudMain.HudMain_C.IsShowMapOrInventory // Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const // @ game+0x33e45c
	void OnTogglePlayerList(); // Function HudMain.HudMain_C.OnTogglePlayerList // Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void IsCharacterAlive(bool IsAlive); // Function HudMain.HudMain_C.IsCharacterAlive // Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure // @ game+0x33e45c
	void OnNitifyHit(float DamagePercent, enum class EDamageTypeCategory DamageTypeCategory); // Function HudMain.HudMain_C.OnNitifyHit // Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void OnKey_SystemMenuOrEscape(); // Function HudMain.HudMain_C.OnKey_SystemMenuOrEscape // Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void OnToggleMap(); // Function HudMain.HudMain_C.OnToggleMap // Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void OnPossessPawnChange(); // Function HudMain.HudMain_C.OnPossessPawnChange // Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void Construct(); // Function HudMain.HudMain_C.Construct // BlueprintCosmetic|Event|Public|BlueprintEvent // @ game+0x33e45c
	void HideMapForReplay(); // Function HudMain.HudMain_C.HideMapForReplay // BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void CheckReplayTimer(); // Function HudMain.HudMain_C.CheckReplayTimer // BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void CreateCheckReplayTimer(); // Function HudMain.HudMain_C.CreateCheckReplayTimer // BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void ExecuteUbergraph_HudMain(int32 EntryPoint); // Function HudMain.HudMain_C.ExecuteUbergraph_HudMain // HasDefaults // @ game+0x33e45c
	void ButtonClickedDispatcher__DelegateSignature(); // Function HudMain.HudMain_C.ButtonClickedDispatcher__DelegateSignature // Public|Delegate|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
};

