// WidgetBlueprintGeneratedClass BP_PcOptionHoverWidget.BP_PcOptionHoverWidget_C
// Size: 0x470 (Inherited: 0x460)
struct UBP_PcOptionHoverWidget_C : UTslGameOptionHoverWidget {
	struct UWidgetAnimation* Out; // 0x460(0x08)
	struct UWidgetAnimation* Hover; // 0x468(0x08)
};

