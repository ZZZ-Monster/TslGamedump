// Class MovieScene.MovieSceneSignedObject
// Size: 0xc0 (Inherited: 0x38)
struct UMovieSceneSignedObject : UObject {
	struct FGuid Signature; // 0x38(0x10)
	char pad_48[0x78]; // 0x48(0x78)
};

// Class MovieScene.MovieScene
// Size: 0x140 (Inherited: 0xc0)
struct UMovieScene : UMovieSceneSignedObject {
	struct TArray<struct FMovieSceneSpawnable> Spawnables; // 0xc0(0x10)
	struct TArray<struct FMovieScenePossessable> Possessables; // 0xd0(0x10)
	struct TArray<struct FMovieSceneBinding> ObjectBindings; // 0xe0(0x10)
	struct TArray<struct UMovieSceneTrack*> MasterTracks; // 0xf0(0x10)
	struct UMovieSceneTrack* CameraCutTrack; // 0x100(0x08)
	struct FFloatRange SelectionRange; // 0x108(0x10)
	struct FFloatRange PlaybackRange; // 0x118(0x10)
	bool bForceFixedFrameIntervalPlayback; // 0x128(0x01)
	char pad_129[0x3]; // 0x129(0x03)
	float FixedFrameInterval; // 0x12c(0x04)
	float InTime; // 0x130(0x04)
	float OutTime; // 0x134(0x04)
	float StartTime; // 0x138(0x04)
	float EndTime; // 0x13c(0x04)
};

// Class MovieScene.MovieSceneBindingOverridesInterface
// Size: 0x38 (Inherited: 0x38)
struct UMovieSceneBindingOverridesInterface : UInterface {
};

// Class MovieScene.MovieSceneBindingOverrides
// Size: 0xa8 (Inherited: 0x38)
struct UMovieSceneBindingOverrides : UObject {
	char pad_38[0x8]; // 0x38(0x08)
	struct TArray<struct FMovieSceneBindingOverrideData> BindingData; // 0x40(0x10)
	char pad_50[0x58]; // 0x50(0x58)
};

// Class MovieScene.MovieSceneBindingOwnerInterface
// Size: 0x38 (Inherited: 0x38)
struct UMovieSceneBindingOwnerInterface : UInterface {
};

// Class MovieScene.MovieSceneFolder
// Size: 0x80 (Inherited: 0x38)
struct UMovieSceneFolder : UObject {
	struct FName FolderName; // 0x38(0x08)
	struct TArray<struct UMovieSceneFolder*> ChildFolders; // 0x40(0x10)
	struct TArray<struct UMovieSceneTrack*> ChildMasterTracks; // 0x50(0x10)
	struct TArray<struct FString> ChildObjectBindingStrings; // 0x60(0x10)
	char pad_70[0x10]; // 0x70(0x10)
};

// Class MovieScene.MovieSceneSequencePlayer
// Size: 0x710 (Inherited: 0x38)
struct UMovieSceneSequencePlayer : UObject {
	char pad_38[0x348]; // 0x38(0x348)
	struct FMulticastDelegate OnPlay; // 0x380(0x10)
	struct FMulticastDelegate OnStop; // 0x390(0x10)
	struct FMulticastDelegate OnPause; // 0x3a0(0x10)
	char bIsPlaying : 1; // 0x3b0(0x01)
	char bReversePlayback : 1; // 0x3b0(0x01)
	char bPendingFirstUpdate : 1; // 0x3b0(0x01)
	char pad_3B0_3 : 5; // 0x3b0(0x01)
	char pad_3B1[0x7]; // 0x3b1(0x07)
	struct UMovieSceneSequence* Sequence; // 0x3b8(0x08)
	float TimeCursorPosition; // 0x3c0(0x04)
	float StartTime; // 0x3c4(0x04)
	float EndTime; // 0x3c8(0x04)
	int32 CurrentNumLoops; // 0x3cc(0x04)
	char pad_3D0[0x10]; // 0x3d0(0x10)
	struct FMovieSceneSequencePlaybackSettings PlaybackSettings; // 0x3e0(0x28)
	char pad_408[0x308]; // 0x408(0x308)

	void Stop(); // Function MovieScene.MovieSceneSequencePlayer.Stop // Final|Native|Public|BlueprintCallable // @ game+0xbf44bc
	void StartPlayingNextTick(); // Function MovieScene.MovieSceneSequencePlayer.StartPlayingNextTick // Final|Native|Public|BlueprintCallable // @ game+0x530e8f4
	void SetPlayRate(float PlayRate); // Function MovieScene.MovieSceneSequencePlayer.SetPlayRate // Final|Native|Public|BlueprintCallable // @ game+0x530e780
	void SetPlaybackRange(float NewStartTime, float NewEndTime); // Function MovieScene.MovieSceneSequencePlayer.SetPlaybackRange // Final|Native|Public|BlueprintCallable // @ game+0x530e818
	void SetPlaybackPosition(float NewPlaybackPosition); // Function MovieScene.MovieSceneSequencePlayer.SetPlaybackPosition // Final|Native|Public|BlueprintCallable // @ game+0xd163a0
	void PlayReverse(); // Function MovieScene.MovieSceneSequencePlayer.PlayReverse // Final|Native|Public|BlueprintCallable // @ game+0x530e764
	void PlayLooping(int32 NumLoops); // Function MovieScene.MovieSceneSequencePlayer.PlayLooping // Final|Native|Public|BlueprintCallable // @ game+0x530e6cc
	void Play(); // Function MovieScene.MovieSceneSequencePlayer.Play // Final|Native|Public|BlueprintCallable // @ game+0xe015b4
	void Pause(); // Function MovieScene.MovieSceneSequencePlayer.Pause // Final|Native|Public|BlueprintCallable // @ game+0x530e6b8
	bool IsPlaying(); // Function MovieScene.MovieSceneSequencePlayer.IsPlaying // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x530e69c
	float GetPlayRate(); // Function MovieScene.MovieSceneSequencePlayer.GetPlayRate // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x530e654
	float GetPlaybackStart(); // Function MovieScene.MovieSceneSequencePlayer.GetPlaybackStart // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x530e684
	float GetPlaybackPosition(); // Function MovieScene.MovieSceneSequencePlayer.GetPlaybackPosition // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x4d6d460
	float GetPlaybackEnd(); // Function MovieScene.MovieSceneSequencePlayer.GetPlaybackEnd // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x530e66c
	float GetLength(); // Function MovieScene.MovieSceneSequencePlayer.GetLength // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x530e630
	struct TArray<struct UObject*> GetBoundObjects(struct FMovieSceneObjectBindingID ObjectBinding); // Function MovieScene.MovieSceneSequencePlayer.GetBoundObjects // Final|Native|Public|BlueprintCallable // @ game+0x530e50c
	void ChangePlaybackDirection(); // Function MovieScene.MovieSceneSequencePlayer.ChangePlaybackDirection // Final|Native|Public|BlueprintCallable // @ game+0x530e4e0
};

// Class MovieScene.MovieSceneSection
// Size: 0xe0 (Inherited: 0xc0)
struct UMovieSceneSection : UMovieSceneSignedObject {
	struct FMovieSceneSectionEvalOptions EvalOptions; // 0xc0(0x02)
	char pad_C2[0x2]; // 0xc2(0x02)
	float StartTime; // 0xc4(0x04)
	float EndTime; // 0xc8(0x04)
	int32 RowIndex; // 0xcc(0x04)
	int32 OverlapPriority; // 0xd0(0x04)
	char bIsActive : 1; // 0xd4(0x01)
	char bIsLocked : 1; // 0xd4(0x01)
	char bIsInfinite : 1; // 0xd4(0x01)
	char pad_D4_3 : 5; // 0xd4(0x01)
	char pad_D5[0x3]; // 0xd5(0x03)
	float PrerollTime; // 0xd8(0x04)
	float PostrollTime; // 0xdc(0x04)
};

// Class MovieScene.MovieSceneTrack
// Size: 0xd0 (Inherited: 0xc0)
struct UMovieSceneTrack : UMovieSceneSignedObject {
	struct FMovieSceneTrackEvalOptions EvalOptions; // 0xc0(0x04)
	char pad_C4[0xc]; // 0xc4(0x0c)
};

// Class MovieScene.MovieSceneSegmentCompilerTestTrack
// Size: 0xe0 (Inherited: 0xd0)
struct UMovieSceneSegmentCompilerTestTrack : UMovieSceneTrack {
	bool bHighPassFilter; // 0xc8(0x01)
	struct TArray<struct UMovieSceneSection*> SectionArray; // 0xd0(0x10)
};

// Class MovieScene.MovieSceneSegmentCompilerTestSection
// Size: 0xe0 (Inherited: 0xe0)
struct UMovieSceneSegmentCompilerTestSection : UMovieSceneSection {
};

// Class MovieScene.MovieSceneSequence
// Size: 0x340 (Inherited: 0xc0)
struct UMovieSceneSequence : UMovieSceneSignedObject {
	struct FCachedMovieSceneEvaluationTemplate EvaluationTemplate; // 0xc0(0x220)
	struct FMovieSceneTrackCompilationParams TemplateParameters; // 0x2e0(0x02)
	char pad_2E2[0x6]; // 0x2e2(0x06)
	struct TMap<struct UObject*, struct FCachedMovieSceneEvaluationTemplate> InstancedSubSequenceEvaluationTemplates; // 0x2e8(0x50)
	bool bParentContextsAreSignificant; // 0x338(0x01)
	char pad_339[0x7]; // 0x339(0x07)
};

// Class MovieScene.MovieSceneNameableTrack
// Size: 0xd0 (Inherited: 0xd0)
struct UMovieSceneNameableTrack : UMovieSceneTrack {
};

