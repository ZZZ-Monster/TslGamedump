// BlueprintGeneratedClass BP_MasteryBannerController.BP_MasteryBannerController_C
// Size: 0x478 (Inherited: 0x478)
struct ABP_MasteryBannerController_C : AMasteryBannerController {
};

