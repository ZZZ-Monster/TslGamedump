// WidgetBlueprintGeneratedClass BP_FlaregunUiWidget.BP_FlaregunUiWidget_C
// Size: 0x2d0 (Inherited: 0x2b8)
struct UBP_FlaregunUiWidget_C : UTslFlareGunWidget {
	struct UInvalidationBox* InvalidationBox_5; // 0x2b8(0x08)
	struct UInvalidationBox* InvalidationBox_6; // 0x2c0(0x08)
	struct USizeBox* SpecialAirdropsRemaingingTitleSizeBox; // 0x2c8(0x08)
};

