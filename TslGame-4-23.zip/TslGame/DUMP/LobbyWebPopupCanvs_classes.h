// WidgetBlueprintGeneratedClass LobbyWebPopupCanvs.LobbyWebPopupCanvs_C
// Size: 0x290 (Inherited: 0x260)
struct ULobbyWebPopupCanvs_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UCanvasPanel* WebPopupCavas; // 0x268(0x08)
	struct TArray<struct UWebPopup_C*> PanelAddedWebPopupArray; // 0x270(0x10)
	struct TArray<struct UWebPopup_C*> PreCreatePopupArray; // 0x280(0x10)

	bool HasChildren(); // Function LobbyWebPopupCanvs.LobbyWebPopupCanvs_C.HasChildren // Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const // @ game+0x33e45c
	void CreateWebPopupAndAddPanel(struct FWebPopupParam Param, bool bShow, bool bReuse, struct UWebPopup_C* WebPopup); // Function LobbyWebPopupCanvs.LobbyWebPopupCanvs_C.CreateWebPopupAndAddPanel // Public|HasOutParms|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void ShowWebPopupImpl(struct FWebPopupParam PopupParam); // Function LobbyWebPopupCanvs.LobbyWebPopupCanvs_C.ShowWebPopupImpl // Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void OnPreloadWebPopupImpl(struct TArray<struct FWebPopupParam> Params); // Function LobbyWebPopupCanvs.LobbyWebPopupCanvs_C.OnPreloadWebPopupImpl // Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void GetWebPopupFromPopupId(struct FString PopupId, struct UWebPopup_C* WebPopup); // Function LobbyWebPopupCanvs.LobbyWebPopupCanvs_C.GetWebPopupFromPopupId // Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure // @ game+0x33e45c
	void ChangeWebPopupUriImpl(struct FString PopupId, struct FString Uri); // Function LobbyWebPopupCanvs.LobbyWebPopupCanvs_C.ChangeWebPopupUriImpl // Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void OnCloseWebPopupImpl(struct FString PopupId); // Function LobbyWebPopupCanvs.LobbyWebPopupCanvs_C.OnCloseWebPopupImpl // Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void CloseWebPopupByID(struct FString WebPopupID, bool bForceRemoveParent); // Function LobbyWebPopupCanvs.LobbyWebPopupCanvs_C.CloseWebPopupByID // Public|HasDefaults|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void RemoveWebPopup(struct UWebPopup_C* Widget); // Function LobbyWebPopupCanvs.LobbyWebPopupCanvs_C.RemoveWebPopup // Private|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void AddWebPopup(struct UWebPopup_C* Widget); // Function LobbyWebPopupCanvs.LobbyWebPopupCanvs_C.AddWebPopup // Private|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void CanShowWebPopup(struct FString PopupId, bool Result); // Function LobbyWebPopupCanvs.LobbyWebPopupCanvs_C.CanShowWebPopup // Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void CreateWebPopupImpl(struct FWebPopupParam Param, bool bShow, bool bReuse); // Function LobbyWebPopupCanvs.LobbyWebPopupCanvs_C.CreateWebPopupImpl // Public|HasDefaults|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void CloseWebPopup(struct FString PopupId); // Function LobbyWebPopupCanvs.LobbyWebPopupCanvs_C.CloseWebPopup // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void ShowWebPopup(struct FWebPopupParam Param); // Function LobbyWebPopupCanvs.LobbyWebPopupCanvs_C.ShowWebPopup // Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void PreloadWebPopup(struct TArray<struct FWebPopupParam> WebPopupParams); // Function LobbyWebPopupCanvs.LobbyWebPopupCanvs_C.PreloadWebPopup // Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void Construct(); // Function LobbyWebPopupCanvs.LobbyWebPopupCanvs_C.Construct // BlueprintCosmetic|Event|Public|BlueprintEvent // @ game+0x33e45c
	void ExecuteUbergraph_LobbyWebPopupCanvs(int32 EntryPoint); // Function LobbyWebPopupCanvs.LobbyWebPopupCanvs_C.ExecuteUbergraph_LobbyWebPopupCanvs // HasDefaults // @ game+0x33e45c
};

