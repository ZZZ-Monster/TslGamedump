// BlueprintGeneratedClass P_FBRBuff_Fortitude_BP.P_FBRBuff_Fortitude_BP_C
// Size: 0x41c (Inherited: 0x418)
struct AP_FBRBuff_Fortitude_BP_C : ATslServerParticle {
	float NewVar_1; // 0x418(0x04)

	void UserConstructionScript(); // Function P_FBRBuff_Fortitude_BP.P_FBRBuff_Fortitude_BP_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
};

