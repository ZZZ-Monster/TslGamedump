// Class AvfMediaFactory.AvfMediaSettings
// Size: 0x40 (Inherited: 0x38)
struct UAvfMediaSettings : UObject {
	bool NativeAudioOut; // 0x38(0x01)
	char pad_39[0x7]; // 0x39(0x07)
};

