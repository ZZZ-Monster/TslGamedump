// WidgetBlueprintGeneratedClass KeyWidgetBP.KeyWidgetBP_C
// Size: 0x570 (Inherited: 0x558)
struct UKeyWidgetBP_C : UTslKeyWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x558(0x08)
	struct UImage* BorderImage; // 0x560(0x08)
	struct UTextBlock* KeyNameTextBlock; // 0x568(0x08)

	void PreConstruct(bool IsDesignTime); // Function KeyWidgetBP.KeyWidgetBP_C.PreConstruct // BlueprintCosmetic|Event|Public|BlueprintEvent // @ game+0x33e45c
	void ExecuteUbergraph_KeyWidgetBP(int32 EntryPoint); // Function KeyWidgetBP.KeyWidgetBP_C.ExecuteUbergraph_KeyWidgetBP // HasDefaults // @ game+0x33e45c
};

