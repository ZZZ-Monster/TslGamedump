// BlueprintGeneratedClass AnimNotify_AkEvent.AnimNotify_AkEvent_C
// Size: 0x60 (Inherited: 0x60)
struct UAnimNotify_AkEvent_C : UAnimNotify_AkEvent {
};

