// BlueprintGeneratedClass Powerup_AdrenalineSyringe.Powerup_AdrenalineSyringe_C
// Size: 0x450 (Inherited: 0x440)
struct APowerup_AdrenalineSyringe_C : APowerup_Base_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x440(0x08)
	struct FTimerHandle Timer2Handle; // 0x448(0x08)

	void UserConstructionScript(); // Function Powerup_AdrenalineSyringe.Powerup_AdrenalineSyringe_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void ReceiveBeginPlay(); // Function Powerup_AdrenalineSyringe.Powerup_AdrenalineSyringe_C.ReceiveBeginPlay // Event|Protected|BlueprintEvent // @ game+0x33e45c
	void CustomEvent_1(); // Function Powerup_AdrenalineSyringe.Powerup_AdrenalineSyringe_C.CustomEvent_1 // BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void ReceiveDestroyed(); // Function Powerup_AdrenalineSyringe.Powerup_AdrenalineSyringe_C.ReceiveDestroyed // Event|Public|BlueprintEvent // @ game+0x33e45c
	void ExecuteUbergraph_Powerup_AdrenalineSyringe(int32 EntryPoint); // Function Powerup_AdrenalineSyringe.Powerup_AdrenalineSyringe_C.ExecuteUbergraph_Powerup_AdrenalineSyringe // HasDefaults // @ game+0x33e45c
};

