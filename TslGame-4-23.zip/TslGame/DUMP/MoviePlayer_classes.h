// Class MoviePlayer.MoviePlayerSettings
// Size: 0x50 (Inherited: 0x38)
struct UMoviePlayerSettings : UObject {
	bool bWaitForMoviesToComplete; // 0x38(0x01)
	bool bMoviesAreSkippable; // 0x39(0x01)
	char pad_3A[0x6]; // 0x3a(0x06)
	struct TArray<struct FString> StartupMovies; // 0x40(0x10)
};

