// Class GameplayAbilities.AbilitySystemInterface
// Size: 0x38 (Inherited: 0x38)
struct UAbilitySystemInterface : UInterface {
};

// Class GameplayAbilities.AbilitySystemComponent
// Size: 0x1860 (Inherited: 0x270)
struct UAbilitySystemComponent : UGameplayTasksComponent {
	char pad_270[0x8]; // 0x270(0x08)
	char bIsNetDirty : 1; // 0x278(0x01)
	char pad_278_1 : 7; // 0x278(0x01)
	char pad_279[0x7]; // 0x279(0x07)
	struct TArray<struct FAttributeDefaults> DefaultStartingData; // 0x280(0x10)
	struct FName AffectedAnimInstanceTag; // 0x290(0x08)
	char pad_298[0x5c8]; // 0x298(0x5c8)
	float OutgoingDuration; // 0x860(0x04)
	float IncomingDuration; // 0x864(0x04)
	char pad_868[0x80]; // 0x868(0x80)
	bool UserAbilityActivationInhibited; // 0x8e8(0x01)
	bool ReplicationProxyEnabled; // 0x8e9(0x01)
	bool bSuppressGrantAbility; // 0x8ea(0x01)
	bool bSuppressGameplayCues; // 0x8eb(0x01)
	char pad_8EC[0x4]; // 0x8ec(0x04)
	struct TArray<struct AGameplayAbilityTargetActor*> SpawnedTargetActors; // 0x8f0(0x10)
	char pad_900[0x38]; // 0x900(0x38)
	struct FGameplayAbilitySpecContainer ActivatableAbilities; // 0x938(0xc8)
	char pad_A00[0x30]; // 0xa00(0x30)
	struct TArray<struct UGameplayAbility*> AllReplicatedInstancedAbilities; // 0xa30(0x10)
	char pad_A40[0x20c]; // 0xa40(0x20c)
	bool bCachedIsNetSimulated; // 0xc4c(0x01)
	bool bPendingMontageRep; // 0xc4d(0x01)
	char pad_C4E[0x2]; // 0xc4e(0x02)
	struct FGameplayAbilityLocalAnimMontage LocalAnimMontageInfo; // 0xc50(0x30)
	char pad_C80[0xa0]; // 0xc80(0xa0)
	struct FActiveGameplayEffectsContainer ActiveGameplayEffects; // 0xd20(0x4e0)
	struct FActiveGameplayCueContainer ActiveGameplayCues; // 0x1200(0xd0)
	struct FActiveGameplayCueContainer MinimalReplicationGameplayCues; // 0x12d0(0xd0)
	char pad_13A0[0x318]; // 0x13a0(0x318)
	struct TArray<struct UAttributeSet*> SpawnedAttributes; // 0x16b8(0x10)
	struct TArray<struct FString> ClientDebugStrings; // 0x16c8(0x10)
	struct AActor* OwnerActor; // 0x16d8(0x08)
	struct AActor* AvatarActor; // 0x16e0(0x08)
	struct FGameplayAbilityRepAnimMontage RepAnimMontageInfo; // 0x16e8(0x38)
	struct TArray<bool> BlockedAbilityBindings; // 0x1720(0x10)
	struct FMinimalReplicationTagCountMap MinimalReplicationTags; // 0x1730(0x60)
	struct TArray<struct FString> ServerDebugStrings; // 0x1790(0x10)
	struct FReplicatedPredictionKeyMap ReplicatedPredictionKeyMap; // 0x17a0(0xc0)

	bool TryActivateAbilityByClass(struct UClass* InAbilityToActivate, bool bAllowRemoteActivation); // Function GameplayAbilities.AbilitySystemComponent.TryActivateAbilityByClass // Final|Native|Public|BlueprintCallable // @ game+0x5e12eb0
	bool TryActivateAbilitiesByTag(struct FGameplayTagContainer GameplayTagContainer, bool bAllowRemoteActivation); // Function GameplayAbilities.AbilitySystemComponent.TryActivateAbilitiesByTag // Final|Native|Public|HasOutParms|BlueprintCallable // @ game+0x5e12d5c
	void TargetConfirm(); // Function GameplayAbilities.AbilitySystemComponent.TargetConfirm // Native|Public|BlueprintCallable // @ game+0x5e12d2c
	void TargetCancel(); // Function GameplayAbilities.AbilitySystemComponent.TargetCancel // Native|Public|BlueprintCallable // @ game+0x5afa6ac
	void SetUserAbilityActivationInhibited(bool NewInhibit); // Function GameplayAbilities.AbilitySystemComponent.SetUserAbilityActivationInhibited // Native|Public|BlueprintCallable // @ game+0x5e1281c
	void SetActiveGameplayEffectLevelUsingQuery(struct FGameplayEffectQuery Query, int32 NewLevel); // Function GameplayAbilities.AbilitySystemComponent.SetActiveGameplayEffectLevelUsingQuery // BlueprintAuthorityOnly|Native|Public|BlueprintCallable // @ game+0x5e125a0
	void SetActiveGameplayEffectLevel(struct FActiveGameplayEffectHandle ActiveHandle, int32 NewLevel); // Function GameplayAbilities.AbilitySystemComponent.SetActiveGameplayEffectLevel // BlueprintAuthorityOnly|Native|Public|BlueprintCallable // @ game+0x5e124bc
	void ServerTryActivateAbilityWithEventData(struct FGameplayAbilitySpecHandle AbilityToActivate, bool InputPressed, struct FPredictionKey PredictionKey, struct FGameplayEventData TriggerEventData); // Function GameplayAbilities.AbilitySystemComponent.ServerTryActivateAbilityWithEventData // Net|NetReliableNative|Event|Protected|NetServer|NetValidate // @ game+0x5e12254
	void ServerTryActivateAbility(struct FGameplayAbilitySpecHandle AbilityToActivate, bool InputPressed, struct FPredictionKey PredictionKey); // Function GameplayAbilities.AbilitySystemComponent.ServerTryActivateAbility // Net|NetReliableNative|Event|Protected|NetServer|NetValidate // @ game+0x5e120c0
	void ServerSetReplicatedTargetDataCancelled(struct FGameplayAbilitySpecHandle AbilityHandle, struct FPredictionKey AbilityOriginalPredictionKey, struct FPredictionKey CurrentPredictionKey); // Function GameplayAbilities.AbilitySystemComponent.ServerSetReplicatedTargetDataCancelled // Net|NetReliableNative|Event|Public|NetServer|NetValidate // @ game+0x5e11f00
	void ServerSetReplicatedTargetData(struct FGameplayAbilitySpecHandle AbilityHandle, struct FPredictionKey AbilityOriginalPredictionKey, struct FGameplayAbilityTargetDataHandle ReplicatedTargetDataHandle, struct FGameplayTag ApplicationTag, struct FPredictionKey CurrentPredictionKey); // Function GameplayAbilities.AbilitySystemComponent.ServerSetReplicatedTargetData // Net|NetReliableNative|Event|Public|NetServer|NetValidate // @ game+0x5e11bf4
	void ServerSetReplicatedEventWithPayload(enum class EAbilityGenericReplicatedEvent EventType, struct FGameplayAbilitySpecHandle AbilityHandle, struct FPredictionKey AbilityOriginalPredictionKey, struct FPredictionKey CurrentPredictionKey, struct FVector_NetQuantize100 VectorPayload); // Function GameplayAbilities.AbilitySystemComponent.ServerSetReplicatedEventWithPayload // Net|NetReliableNative|Event|Public|NetServer|NetValidate // @ game+0x5e11964
	void ServerSetReplicatedEvent(enum class EAbilityGenericReplicatedEvent EventType, struct FGameplayAbilitySpecHandle AbilityHandle, struct FPredictionKey AbilityOriginalPredictionKey, struct FPredictionKey CurrentPredictionKey); // Function GameplayAbilities.AbilitySystemComponent.ServerSetReplicatedEvent // Net|NetReliableNative|Event|Public|NetServer|NetValidate // @ game+0x5e11748
	void ServerSetInputReleased(struct FGameplayAbilitySpecHandle AbilityHandle); // Function GameplayAbilities.AbilitySystemComponent.ServerSetInputReleased // Net|NetReliableNative|Event|Public|NetServer|NetValidate // @ game+0x5e11698
	void ServerSetInputPressed(struct FGameplayAbilitySpecHandle AbilityHandle); // Function GameplayAbilities.AbilitySystemComponent.ServerSetInputPressed // Net|NetReliableNative|Event|Public|NetServer|NetValidate // @ game+0x5e115e8
	void ServerPrintDebug_RequestWithStrings(struct TArray<struct FString> Strings); // Function GameplayAbilities.AbilitySystemComponent.ServerPrintDebug_RequestWithStrings // Net|NetReliableNative|Event|Public|NetServer|NetValidate // @ game+0x5e1150c
	void ServerPrintDebug_Request(); // Function GameplayAbilities.AbilitySystemComponent.ServerPrintDebug_Request // Net|NetReliableNative|Event|Public|NetServer|NetValidate // @ game+0x5e114c0
	void ServerEndAbility(struct FGameplayAbilitySpecHandle AbilityToEnd, struct FGameplayAbilityActivationInfo ActivationInfo, struct FPredictionKey PredictionKey); // Function GameplayAbilities.AbilitySystemComponent.ServerEndAbility // Net|NetReliableNative|Event|Protected|NetServer|NetValidate // @ game+0x5e112d0
	void ServerCurrentMontageSetPlayRate(struct UAnimMontage* ClientAnimMontage, float InPlayRate); // Function GameplayAbilities.AbilitySystemComponent.ServerCurrentMontageSetPlayRate // Net|NetReliableNative|Event|Protected|NetServer|NetValidate // @ game+0x5e111bc
	void ServerCurrentMontageSetNextSectionName(struct UAnimMontage* ClientAnimMontage, float ClientPosition, struct FName SectionName, struct FName NextSectionName); // Function GameplayAbilities.AbilitySystemComponent.ServerCurrentMontageSetNextSectionName // Net|NetReliableNative|Event|Protected|NetServer|NetValidate // @ game+0x5e10ffc
	void ServerCurrentMontageJumpToSectionName(struct UAnimMontage* ClientAnimMontage, struct FName SectionName); // Function GameplayAbilities.AbilitySystemComponent.ServerCurrentMontageJumpToSectionName // Net|NetReliableNative|Event|Protected|NetServer|NetValidate // @ game+0x5e10ee8
	void ServerCancelAbility(struct FGameplayAbilitySpecHandle AbilityToCancel, struct FGameplayAbilityActivationInfo ActivationInfo); // Function GameplayAbilities.AbilitySystemComponent.ServerCancelAbility // Net|NetReliableNative|Event|Protected|NetServer|NetValidate // @ game+0x5e10d78
	void ServerAbilityRPCBatch(struct FServerAbilityRPCBatch BatchInfo); // Function GameplayAbilities.AbilitySystemComponent.ServerAbilityRPCBatch // Net|NetReliableNative|Event|Public|NetServer|NetValidate // @ game+0x5e10be4
	void RemoveActiveGameplayEffectBySourceEffect(struct UClass* GameplayEffect, struct UAbilitySystemComponent* InstigatorAbilitySystemComponent, int32 StacksToRemove); // Function GameplayAbilities.AbilitySystemComponent.RemoveActiveGameplayEffectBySourceEffect // BlueprintAuthorityOnly|Native|Public|BlueprintCallable // @ game+0x5e1083c
	bool RemoveActiveGameplayEffect(struct FActiveGameplayEffectHandle Handle, int32 StacksToRemove); // Function GameplayAbilities.AbilitySystemComponent.RemoveActiveGameplayEffect // BlueprintAuthorityOnly|Native|Public|BlueprintCallable // @ game+0x5e10748
	int32 RemoveActiveEffectsWithTags(struct FGameplayTagContainer Tags); // Function GameplayAbilities.AbilitySystemComponent.RemoveActiveEffectsWithTags // Final|Native|Public|BlueprintCallable // @ game+0x5e10654
	int32 RemoveActiveEffectsWithSourceTags(struct FGameplayTagContainer Tags); // Function GameplayAbilities.AbilitySystemComponent.RemoveActiveEffectsWithSourceTags // Final|Native|Public|BlueprintCallable // @ game+0x5e10560
	int32 RemoveActiveEffectsWithGrantedTags(struct FGameplayTagContainer Tags); // Function GameplayAbilities.AbilitySystemComponent.RemoveActiveEffectsWithGrantedTags // Final|Native|Public|BlueprintCallable // @ game+0x5e1046c
	int32 RemoveActiveEffectsWithAppliedTags(struct FGameplayTagContainer Tags); // Function GameplayAbilities.AbilitySystemComponent.RemoveActiveEffectsWithAppliedTags // Final|Native|Public|BlueprintCallable // @ game+0x5e1046c
	void OnRep_ServerDebugString(); // Function GameplayAbilities.AbilitySystemComponent.OnRep_ServerDebugString // Native|Public // @ game+0x4d8c7b4
	void OnRep_ReplicatedAnimMontage(); // Function GameplayAbilities.AbilitySystemComponent.OnRep_ReplicatedAnimMontage // Native|Protected // @ game+0xe3f660
	void OnRep_OwningActor(); // Function GameplayAbilities.AbilitySystemComponent.OnRep_OwningActor // Final|Native|Public // @ game+0x5e0ff18
	void OnRep_ClientDebugString(); // Function GameplayAbilities.AbilitySystemComponent.OnRep_ClientDebugString // Native|Public // @ game+0x4cdc38c
	void OnRep_ActivateAbilities(); // Function GameplayAbilities.AbilitySystemComponent.OnRep_ActivateAbilities // Native|Protected // @ game+0x5e0ff00
	void NetMulticast_InvokeGameplayCuesExecuted_WithParams(struct FGameplayTagContainer GameplayCueTags, struct FPredictionKey PredictionKey, struct FGameplayCueParameters GameplayCueParameters); // Function GameplayAbilities.AbilitySystemComponent.NetMulticast_InvokeGameplayCuesExecuted_WithParams // Net|Native|Event|NetMulticast|Public // @ game+0x5e0e9e8
	void NetMulticast_InvokeGameplayCuesExecuted(struct FGameplayTagContainer GameplayCueTags, struct FPredictionKey PredictionKey, struct FGameplayEffectContextHandle EffectContext); // Function GameplayAbilities.AbilitySystemComponent.NetMulticast_InvokeGameplayCuesExecuted // Net|Native|Event|NetMulticast|Public // @ game+0x5e0e7d0
	void NetMulticast_InvokeGameplayCuesAddedAndWhileActive_WithParams(struct FGameplayTagContainer GameplayCueTags, struct FPredictionKey PredictionKey, struct FGameplayCueParameters GameplayCueParameters); // Function GameplayAbilities.AbilitySystemComponent.NetMulticast_InvokeGameplayCuesAddedAndWhileActive_WithParams // Net|Native|Event|NetMulticast|Public // @ game+0x5e0e5d0
	void NetMulticast_InvokeGameplayCueExecuted_WithParams(struct FGameplayTag GameplayCueTag, struct FPredictionKey PredictionKey, struct FGameplayCueParameters GameplayCueParameters); // Function GameplayAbilities.AbilitySystemComponent.NetMulticast_InvokeGameplayCueExecuted_WithParams // Net|Native|Event|NetMulticast|Public // @ game+0x5e0e428
	void NetMulticast_InvokeGameplayCueExecuted_FromSpec(struct FGameplayEffectSpecForRPC Spec, struct FPredictionKey PredictionKey); // Function GameplayAbilities.AbilitySystemComponent.NetMulticast_InvokeGameplayCueExecuted_FromSpec // Net|Native|Event|NetMulticast|Public // @ game+0x5e0e2dc
	void NetMulticast_InvokeGameplayCueExecuted(struct FGameplayTag GameplayCueTag, struct FPredictionKey PredictionKey, struct FGameplayEffectContextHandle EffectContext); // Function GameplayAbilities.AbilitySystemComponent.NetMulticast_InvokeGameplayCueExecuted // Net|Native|Event|NetMulticast|Public // @ game+0x5e0e124
	void NetMulticast_InvokeGameplayCueAddedAndWhileActive_WithParams(struct FGameplayTag GameplayCueTag, struct FPredictionKey PredictionKey, struct FGameplayCueParameters GameplayCueParameters); // Function GameplayAbilities.AbilitySystemComponent.NetMulticast_InvokeGameplayCueAddedAndWhileActive_WithParams // Net|Native|Event|NetMulticast|Public // @ game+0x5e0ddd4
	void NetMulticast_InvokeGameplayCueAddedAndWhileActive_FromSpec(struct FGameplayEffectSpecForRPC Spec, struct FPredictionKey PredictionKey); // Function GameplayAbilities.AbilitySystemComponent.NetMulticast_InvokeGameplayCueAddedAndWhileActive_FromSpec // Net|Native|Event|NetMulticast|Public // @ game+0x5e0dc9c
	void NetMulticast_InvokeGameplayCueAdded_WithParams(struct FGameplayTag GameplayCueTag, struct FPredictionKey PredictionKey, struct FGameplayCueParameters Parameters); // Function GameplayAbilities.AbilitySystemComponent.NetMulticast_InvokeGameplayCueAdded_WithParams // Net|Native|Event|NetMulticast|Public // @ game+0x5e0df7c
	void NetMulticast_InvokeGameplayCueAdded(struct FGameplayTag GameplayCueTag, struct FPredictionKey PredictionKey, struct FGameplayEffectContextHandle EffectContext); // Function GameplayAbilities.AbilitySystemComponent.NetMulticast_InvokeGameplayCueAdded // Net|Native|Event|NetMulticast|Public // @ game+0x5e0dae4
	struct FGameplayEffectSpecHandle MakeOutgoingSpec(struct UClass* GameplayEffectClass, float Level, struct FGameplayEffectContextHandle Context); // Function GameplayAbilities.AbilitySystemComponent.MakeOutgoingSpec // Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5e0d308
	struct FGameplayEffectContextHandle MakeEffectContext(); // Function GameplayAbilities.AbilitySystemComponent.MakeEffectContext // Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5e0d124
	void K2_InitStats(struct UClass* Attributes, struct UDataTable* DataTable); // Function GameplayAbilities.AbilitySystemComponent.K2_InitStats // Final|Native|Public|BlueprintCallable // @ game+0x5e0cfb4
	bool IsGameplayCueActive(struct FGameplayTag GameplayCueTag); // Function GameplayAbilities.AbilitySystemComponent.IsGameplayCueActive // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5e0c3b0
	bool GetUserAbilityActivationInhibited(); // Function GameplayAbilities.AbilitySystemComponent.GetUserAbilityActivationInhibited // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5e0c384
	float GetGameplayEffectMagnitude(struct FActiveGameplayEffectHandle Handle, struct FGameplayAttribute Attribute); // Function GameplayAbilities.AbilitySystemComponent.GetGameplayEffectMagnitude // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5e0c000
	int32 GetGameplayEffectCount(struct UClass* SourceGameplayEffect, struct UAbilitySystemComponent* OptionalInstigatorFilterComponent, bool bEnforceOnGoingCheck); // Function GameplayAbilities.AbilitySystemComponent.GetGameplayEffectCount // Final|Native|Public|BlueprintCallable|BlueprintPure // @ game+0x5e0bed0
	struct TArray<struct FActiveGameplayEffectHandle> GetActiveEffectsWithAllTags(struct FGameplayTagContainer Tags); // Function GameplayAbilities.AbilitySystemComponent.GetActiveEffectsWithAllTags // Final|Native|Public|BlueprintCallable|Const // @ game+0x5e0badc
	struct TArray<struct FActiveGameplayEffectHandle> GetActiveEffects(struct FGameplayEffectQuery Query); // Function GameplayAbilities.AbilitySystemComponent.GetActiveEffects // Final|Native|Public|HasOutParms|BlueprintCallable|Const // @ game+0x5e0b984
	void ClientTryActivateAbility(struct FGameplayAbilitySpecHandle AbilityToActivate); // Function GameplayAbilities.AbilitySystemComponent.ClientTryActivateAbility // Net|NetReliableNative|Event|Protected|NetClient // @ game+0x5e0a9d0
	void ClientSetReplicatedEvent(enum class EAbilityGenericReplicatedEvent EventType, struct FGameplayAbilitySpecHandle AbilityHandle, struct FPredictionKey AbilityOriginalPredictionKey); // Function GameplayAbilities.AbilitySystemComponent.ClientSetReplicatedEvent // Net|NetReliableNative|Event|Public|NetClient // @ game+0x5e0a880
	void ClientPrintDebug_Response(struct TArray<struct FString> Strings, int32 GameFlags); // Function GameplayAbilities.AbilitySystemComponent.ClientPrintDebug_Response // Net|NetReliableNative|Event|Public|NetClient // @ game+0x5e0a770
	void ClientEndAbility(struct FGameplayAbilitySpecHandle AbilityToEnd, struct FGameplayAbilityActivationInfo ActivationInfo); // Function GameplayAbilities.AbilitySystemComponent.ClientEndAbility // Net|NetReliableNative|Event|Protected|NetClient // @ game+0x5e0a650
	void ClientCancelAbility(struct FGameplayAbilitySpecHandle AbilityToCancel, struct FGameplayAbilityActivationInfo ActivationInfo); // Function GameplayAbilities.AbilitySystemComponent.ClientCancelAbility // Net|NetReliableNative|Event|Protected|NetClient // @ game+0x5e0a530
	void ClientActivateAbilitySucceedWithEventData(struct FGameplayAbilitySpecHandle AbilityToActivate, struct FPredictionKey PredictionKey, struct FGameplayEventData TriggerEventData); // Function GameplayAbilities.AbilitySystemComponent.ClientActivateAbilitySucceedWithEventData // Net|NetReliableNative|Event|Protected|NetClient // @ game+0x5e0a378
	void ClientActivateAbilitySucceed(struct FGameplayAbilitySpecHandle AbilityToActivate, struct FPredictionKey PredictionKey); // Function GameplayAbilities.AbilitySystemComponent.ClientActivateAbilitySucceed // Net|NetReliableNative|Event|Protected|NetClient // @ game+0x5e0a278
	void ClientActivateAbilityFailed(struct FGameplayAbilitySpecHandle AbilityToActivate, int16 PredictionKey); // Function GameplayAbilities.AbilitySystemComponent.ClientActivateAbilityFailed // Net|NetReliableNative|Event|Protected|NetClient // @ game+0x5e0a198
	struct FActiveGameplayEffectHandle BP_ApplyGameplayEffectToTarget(struct UClass* GameplayEffectClass, struct UAbilitySystemComponent* Target, float Level, struct FGameplayEffectContextHandle Context); // Function GameplayAbilities.AbilitySystemComponent.BP_ApplyGameplayEffectToTarget // Final|Native|Public|BlueprintCallable // @ game+0x5e091e4
	struct FActiveGameplayEffectHandle BP_ApplyGameplayEffectToSelf(struct UClass* GameplayEffectClass, float Level, struct FGameplayEffectContextHandle EffectContext); // Function GameplayAbilities.AbilitySystemComponent.BP_ApplyGameplayEffectToSelf // Final|Native|Public|BlueprintCallable // @ game+0x5e09044
	struct FActiveGameplayEffectHandle BP_ApplyGameplayEffectSpecToTarget(struct FGameplayEffectSpecHandle SpecHandle, struct UAbilitySystemComponent* Target); // Function GameplayAbilities.AbilitySystemComponent.BP_ApplyGameplayEffectSpecToTarget // Final|Native|Public|HasOutParms|BlueprintCallable // @ game+0x5e08d70
	struct FActiveGameplayEffectHandle BP_ApplyGameplayEffectSpecToSelf(struct FGameplayEffectSpecHandle SpecHandle); // Function GameplayAbilities.AbilitySystemComponent.BP_ApplyGameplayEffectSpecToSelf // Final|Native|Public|HasOutParms|BlueprintCallable // @ game+0x5e08c38
	void AbilityConfirmOrCancel__DelegateSignature(); // DelegateFunction GameplayAbilities.AbilitySystemComponent.AbilityConfirmOrCancel__DelegateSignature // MulticastDelegate|Public|Delegate // @ game+0x33e45c
	void AbilityAbilityKey__DelegateSignature(int32 InputID); // DelegateFunction GameplayAbilities.AbilitySystemComponent.AbilityAbilityKey__DelegateSignature // MulticastDelegate|Public|Delegate // @ game+0x33e45c
};

// Class GameplayAbilities.AttributeSet
// Size: 0x40 (Inherited: 0x38)
struct UAttributeSet : UObject {
	char pad_38[0x8]; // 0x38(0x08)
};

// Class GameplayAbilities.AbilityTask
// Size: 0x90 (Inherited: 0x78)
struct UAbilityTask : UGameplayTask {
	struct UGameplayAbility* Ability; // 0x78(0x08)
	struct UAbilitySystemComponent* AbilitySystemComponent; // 0x80(0x08)
	char pad_88[0x8]; // 0x88(0x08)
};

// Class GameplayAbilities.GameplayEffectCalculation
// Size: 0x48 (Inherited: 0x38)
struct UGameplayEffectCalculation : UObject {
	struct TArray<struct FGameplayEffectAttributeCaptureDefinition> RelevantAttributesToCapture; // 0x38(0x10)
};

// Class GameplayAbilities.GameplayEffectExecutionCalculation
// Size: 0x50 (Inherited: 0x48)
struct UGameplayEffectExecutionCalculation : UGameplayEffectCalculation {
	bool bRequiresPassedInTags; // 0x48(0x01)
	char pad_49[0x7]; // 0x49(0x07)

	void Execute(struct FGameplayEffectCustomExecutionParameters ExecutionParams, struct FGameplayEffectCustomExecutionOutput OutExecutionOutput); // Function GameplayAbilities.GameplayEffectExecutionCalculation.Execute // Native|Event|Public|HasOutParms|BlueprintEvent|Const // @ game+0x5e0b15c
};

// Class GameplayAbilities.GameplayAbility
// Size: 0x580 (Inherited: 0x38)
struct UGameplayAbility : UObject {
	char pad_38[0x238]; // 0x38(0x238)
	struct FGameplayTagContainer AbilityTags; // 0x270(0x20)
	bool bReplicateInputDirectly; // 0x290(0x01)
	bool RemoteInstanceEnded; // 0x291(0x01)
	char pad_292[0x4]; // 0x292(0x04)
	enum class EGameplayAbilityReplicationPolicy ReplicationPolicy; // 0x296(0x01)
	enum class EGameplayAbilityInstancingPolicy InstancingPolicy; // 0x297(0x01)
	bool bServerRespectsRemoteAbilityCancellation; // 0x298(0x01)
	bool bRetriggerInstancedAbility; // 0x299(0x01)
	char pad_29A[0x6]; // 0x29a(0x06)
	struct FGameplayAbilityActivationInfo CurrentActivationInfo; // 0x2a0(0x20)
	struct FGameplayEventData CurrentEventData; // 0x2c0(0xb0)
	enum class EGameplayAbilityNetExecutionPolicy NetExecutionPolicy; // 0x370(0x01)
	enum class EGameplayAbilityNetSecurityPolicy NetSecurityPolicy; // 0x371(0x01)
	char pad_372[0x6]; // 0x372(0x06)
	struct UClass* CostGameplayEffectClass; // 0x378(0x08)
	struct TArray<struct FAbilityTriggerData> AbilityTriggers; // 0x380(0x10)
	struct UClass* CooldownGameplayEffectClass; // 0x390(0x08)
	struct FGameplayTagContainer CancelAbilitiesWithTag; // 0x398(0x20)
	struct FGameplayTagContainer BlockAbilitiesWithTag; // 0x3b8(0x20)
	struct FGameplayTagContainer ActivationOwnedTags; // 0x3d8(0x20)
	struct FGameplayTagContainer ActivationRequiredTags; // 0x3f8(0x20)
	struct FGameplayTagContainer ActivationBlockedTags; // 0x418(0x20)
	struct FGameplayTagContainer SourceRequiredTags; // 0x438(0x20)
	struct FGameplayTagContainer SourceBlockedTags; // 0x458(0x20)
	struct FGameplayTagContainer TargetRequiredTags; // 0x478(0x20)
	struct FGameplayTagContainer TargetBlockedTags; // 0x498(0x20)
	char pad_4B8[0x20]; // 0x4b8(0x20)
	struct TArray<struct UGameplayTask*> ActiveTasks; // 0x4d8(0x10)
	char pad_4E8[0x10]; // 0x4e8(0x10)
	struct UAnimMontage* CurrentMontage; // 0x4f8(0x08)
	char pad_500[0x60]; // 0x500(0x60)
	bool bIsActive; // 0x560(0x01)
	bool bIsAbilityEnding; // 0x561(0x01)
	bool bIsCancelable; // 0x562(0x01)
	bool bIsBlockingOtherAbilities; // 0x563(0x01)
	char pad_564[0x14]; // 0x564(0x14)
	bool bMarkPendingKillOnAbilityEnd; // 0x578(0x01)
	char pad_579[0x7]; // 0x579(0x07)

	void SetShouldBlockOtherAbilities(bool bShouldBlockAbilities); // Function GameplayAbilities.GameplayAbility.SetShouldBlockOtherAbilities // Native|Public|BlueprintCallable // @ game+0x5e12784
	void SetCanBeCanceled(bool bCanBeCanceled); // Function GameplayAbilities.GameplayAbility.SetCanBeCanceled // Native|Public|BlueprintCallable // @ game+0x5e126ec
	void SendGameplayEvent(struct FGameplayTag EventTag, struct FGameplayEventData Payload); // Function GameplayAbilities.GameplayAbility.SendGameplayEvent // Native|Protected|BlueprintCallable // @ game+0x5e10a9c
	void RemoveGrantedByEffect(); // Function GameplayAbilities.GameplayAbility.RemoveGrantedByEffect // Native|Public|BlueprintCallable // @ game+0x5e10960
	void MontageStop(float OverrideBlendOutTime); // Function GameplayAbilities.GameplayAbility.MontageStop // Final|Native|Protected|BlueprintCallable // @ game+0x5e0d830
	void MontageSetNextSectionName(struct FName FromSectionName, struct FName ToSectionName); // Function GameplayAbilities.GameplayAbility.MontageSetNextSectionName // Final|Native|Protected|BlueprintCallable // @ game+0x5e0d738
	void MontageJumpToSection(struct FName SectionName); // Function GameplayAbilities.GameplayAbility.MontageJumpToSection // Final|Native|Protected|BlueprintCallable // @ game+0x5e0d690
	struct FGameplayAbilityTargetingLocationInfo MakeTargetLocationInfoFromOwnerSkeletalMeshComponent(struct FName SocketName); // Function GameplayAbilities.GameplayAbility.MakeTargetLocationInfoFromOwnerSkeletalMeshComponent // Final|Native|Protected|BlueprintCallable|BlueprintPure // @ game+0x5e0d590
	struct FGameplayAbilityTargetingLocationInfo MakeTargetLocationInfoFromOwnerActor(); // Function GameplayAbilities.GameplayAbility.MakeTargetLocationInfoFromOwnerActor // Final|Native|Protected|BlueprintCallable|BlueprintPure // @ game+0x5e0d500
	struct FGameplayEffectSpecHandle MakeOutgoingGameplayEffectSpec(struct UClass* GameplayEffectClass, float Level); // Function GameplayAbilities.GameplayAbility.MakeOutgoingGameplayEffectSpec // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5e0d1c0
	bool K2_ShouldAbilityRespondToEvent(struct FGameplayAbilityActorInfo ActorInfo, struct FGameplayEventData Payload); // Function GameplayAbilities.GameplayAbility.K2_ShouldAbilityRespondToEvent // Event|Protected|BlueprintEvent|Const // @ game+0x33e45c
	void K2_RemoveGameplayCue(struct FGameplayTag GameplayCueTag); // Function GameplayAbilities.GameplayAbility.K2_RemoveGameplayCue // Native|Protected|BlueprintCallable // @ game+0x5e0d090
	void K2_OnEndAbility(bool bWasCancelled); // Function GameplayAbilities.GameplayAbility.K2_OnEndAbility // Event|Protected|BlueprintEvent // @ game+0x33e45c
	bool K2_HasAuthority(); // Function GameplayAbilities.GameplayAbility.K2_HasAuthority // Final|Native|Public|BlueprintCallable|Const // @ game+0x5e0cf98
	void K2_ExecuteGameplayCueWithParams(struct FGameplayTag GameplayCueTag, struct FGameplayCueParameters GameplayCueParameters); // Function GameplayAbilities.GameplayAbility.K2_ExecuteGameplayCueWithParams // Native|Protected|HasOutParms|BlueprintCallable // @ game+0x5e0ce68
	void K2_ExecuteGameplayCue(struct FGameplayTag GameplayCueTag, struct FGameplayEffectContextHandle Context); // Function GameplayAbilities.GameplayAbility.K2_ExecuteGameplayCue // Native|Protected|BlueprintCallable // @ game+0x5e0cd18
	void K2_EndAbility(); // Function GameplayAbilities.GameplayAbility.K2_EndAbility // Native|Protected|BlueprintCallable // @ game+0x5b6a6d0
	void K2_CommitExecute(); // Function GameplayAbilities.GameplayAbility.K2_CommitExecute // Event|Public|BlueprintEvent // @ game+0x33e45c
	bool K2_CommitAbilityCost(bool BroadcastCommitEvent); // Function GameplayAbilities.GameplayAbility.K2_CommitAbilityCost // Native|Public|BlueprintCallable // @ game+0x5e0cc70
	bool K2_CommitAbilityCooldown(bool BroadcastCommitEvent, bool ForceCooldown); // Function GameplayAbilities.GameplayAbility.K2_CommitAbilityCooldown // Native|Public|BlueprintCallable // @ game+0x5e0cb7c
	bool K2_CommitAbility(); // Function GameplayAbilities.GameplayAbility.K2_CommitAbility // Native|Public|BlueprintCallable // @ game+0xe36fe4
	bool K2_CheckAbilityCost(); // Function GameplayAbilities.GameplayAbility.K2_CheckAbilityCost // Native|Public|BlueprintCallable // @ game+0x5e0cb54
	bool K2_CheckAbilityCooldown(); // Function GameplayAbilities.GameplayAbility.K2_CheckAbilityCooldown // Native|Public|BlueprintCallable // @ game+0x5e0cb2c
	void K2_CancelAbility(); // Function GameplayAbilities.GameplayAbility.K2_CancelAbility // Final|Native|Public|BlueprintCallable // @ game+0x5e0cabc
	bool K2_CanActivateAbility(struct FGameplayAbilityActorInfo ActorInfo, struct FGameplayAbilitySpecHandle Handle, struct FGameplayTagContainer RelevantTags); // Function GameplayAbilities.GameplayAbility.K2_CanActivateAbility // Event|Protected|HasOutParms|BlueprintEvent|Const // @ game+0x33e45c
	struct TArray<struct FActiveGameplayEffectHandle> K2_ApplyGameplayEffectSpecToTarget(struct FGameplayEffectSpecHandle EffectSpecHandle, struct FGameplayAbilityTargetDataHandle TargetData); // Function GameplayAbilities.GameplayAbility.K2_ApplyGameplayEffectSpecToTarget // Final|Native|Protected|BlueprintCallable // @ game+0x5e0c884
	struct FActiveGameplayEffectHandle K2_ApplyGameplayEffectSpecToOwner(struct FGameplayEffectSpecHandle EffectSpecHandle); // Function GameplayAbilities.GameplayAbility.K2_ApplyGameplayEffectSpecToOwner // Final|Native|Protected|BlueprintCallable // @ game+0x5e0c780
	void K2_AddGameplayCueWithParams(struct FGameplayTag GameplayCueTag, struct FGameplayCueParameters GameplayCueParameter, bool bRemoveOnAbilityEnd); // Function GameplayAbilities.GameplayAbility.K2_AddGameplayCueWithParams // Native|Protected|HasOutParms|BlueprintCallable // @ game+0x5e0c608
	void K2_AddGameplayCue(struct FGameplayTag GameplayCueTag, struct FGameplayEffectContextHandle Context, bool bRemoveOnAbilityEnd); // Function GameplayAbilities.GameplayAbility.K2_AddGameplayCue // Native|Protected|BlueprintCallable // @ game+0x5e0c478
	void K2_ActivateAbilityFromEvent(struct FGameplayEventData EventData); // Function GameplayAbilities.GameplayAbility.K2_ActivateAbilityFromEvent // Event|Protected|HasOutParms|BlueprintEvent // @ game+0x33e45c
	void K2_ActivateAbility(); // Function GameplayAbilities.GameplayAbility.K2_ActivateAbility // Event|Protected|BlueprintEvent // @ game+0x33e45c
	bool IsLocallyControlled(); // Function GameplayAbilities.GameplayAbility.IsLocallyControlled // Final|Native|Public|BlueprintCallable|Const // @ game+0x5e0c454
	void InvalidateClientPredictionKey(); // Function GameplayAbilities.GameplayAbility.InvalidateClientPredictionKey // Final|Native|Public|BlueprintCallable|Const // @ game+0x5e0c39c
	struct UObject* GetSourceObject_BP(struct FGameplayAbilitySpecHandle Handle, struct FGameplayAbilityActorInfo ActorInfo); // Function GameplayAbilities.GameplayAbility.GetSourceObject_BP // Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const // @ game+0x5e0c268
	struct USkeletalMeshComponent* GetOwningComponentFromActorInfo(); // Function GameplayAbilities.GameplayAbility.GetOwningComponentFromActorInfo // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5e0c244
	struct AActor* GetOwningActorFromActorInfo(); // Function GameplayAbilities.GameplayAbility.GetOwningActorFromActorInfo // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5e0c220
	struct FGameplayEffectContextHandle GetGrantedByEffectContext(); // Function GameplayAbilities.GameplayAbility.GetGrantedByEffectContext // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5e0c13c
	struct UObject* GetCurrentSourceObject(); // Function GameplayAbilities.GameplayAbility.GetCurrentSourceObject // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5e0be7c
	struct UAnimMontage* GetCurrentMontage(); // Function GameplayAbilities.GameplayAbility.GetCurrentMontage // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5e0be64
	float GetCooldownTimeRemaining(); // Function GameplayAbilities.GameplayAbility.GetCooldownTimeRemaining // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5e0be1c
	struct FGameplayEffectContextHandle GetContextFromOwner(struct FGameplayAbilityTargetDataHandle OptionalTargetData); // Function GameplayAbilities.GameplayAbility.GetContextFromOwner // Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5e0bc80
	struct AActor* GetAvatarActorFromActorInfo(); // Function GameplayAbilities.GameplayAbility.GetAvatarActorFromActorInfo // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5e0bc5c
	struct FGameplayAbilityActorInfo GetActorInfo(); // Function GameplayAbilities.GameplayAbility.GetActorInfo // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5e0bc28
	struct UAbilitySystemComponent* GetAbilitySystemComponentFromActorInfo(); // Function GameplayAbilities.GameplayAbility.GetAbilitySystemComponentFromActorInfo // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5e0b960
	int32 GetAbilityLevel_BP(struct FGameplayAbilitySpecHandle Handle, struct FGameplayAbilityActorInfo ActorInfo); // Function GameplayAbilities.GameplayAbility.GetAbilityLevel_BP // Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const // @ game+0x5e0b844
	int32 GetAbilityLevel(); // Function GameplayAbilities.GameplayAbility.GetAbilityLevel // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5e0b820
	void EndTaskByInstanceName(struct FName InstanceName); // Function GameplayAbilities.GameplayAbility.EndTaskByInstanceName // Final|Native|Protected|BlueprintCallable // @ game+0x5e0b0cc
	void EndAbilityState(struct FName OptionalStateNameToEnd); // Function GameplayAbilities.GameplayAbility.EndAbilityState // Final|Native|Protected|BlueprintCallable // @ game+0x5e0b02c
	void ConfirmTaskByInstanceName(struct FName InstanceName, bool bEndTask); // Function GameplayAbilities.GameplayAbility.ConfirmTaskByInstanceName // Final|Native|Protected|BlueprintCallable // @ game+0x5e0aa64
	void CancelTaskByInstanceName(struct FName InstanceName); // Function GameplayAbilities.GameplayAbility.CancelTaskByInstanceName // Final|Native|Protected|BlueprintCallable // @ game+0x5e0a108
	void BP_RemoveGameplayEffectFromOwnerWithHandle(struct FActiveGameplayEffectHandle Handle, int32 StacksToRemove); // Function GameplayAbilities.GameplayAbility.BP_RemoveGameplayEffectFromOwnerWithHandle // Final|Native|Protected|BlueprintCallable // @ game+0x5e098bc
	void BP_RemoveGameplayEffectFromOwnerWithGrantedTags(struct FGameplayTagContainer WithGrantedTags, int32 StacksToRemove); // Function GameplayAbilities.GameplayAbility.BP_RemoveGameplayEffectFromOwnerWithGrantedTags // Final|Native|Protected|BlueprintCallable // @ game+0x5e09788
	void BP_RemoveGameplayEffectFromOwnerWithAssetTags(struct FGameplayTagContainer WithAssetTags, int32 StacksToRemove); // Function GameplayAbilities.GameplayAbility.BP_RemoveGameplayEffectFromOwnerWithAssetTags // Final|Native|Protected|BlueprintCallable // @ game+0x5e09654
	struct TArray<struct FActiveGameplayEffectHandle> BP_ApplyGameplayEffectToTarget(struct FGameplayAbilityTargetDataHandle TargetData, struct UClass* GameplayEffectClass, int32 GameplayEffectLevel, int32 Stacks); // Function GameplayAbilities.GameplayAbility.BP_ApplyGameplayEffectToTarget // Final|Native|Protected|BlueprintCallable // @ game+0x5e093d8
	struct FActiveGameplayEffectHandle BP_ApplyGameplayEffectToOwner(struct UClass* GameplayEffectClass, int32 GameplayEffectLevel, int32 Stacks); // Function GameplayAbilities.GameplayAbility.BP_ApplyGameplayEffectToOwner // Final|Native|Protected|BlueprintCallable // @ game+0x5e08f0c
};

// Class GameplayAbilities.GameplayEffect
// Size: 0x890 (Inherited: 0x38)
struct UGameplayEffect : UObject {
	char pad_38[0x8]; // 0x38(0x08)
	enum class EGameplayEffectDurationType DurationPolicy; // 0x40(0x01)
	char pad_41[0x7]; // 0x41(0x07)
	struct FGameplayEffectModifierMagnitude DurationMagnitude; // 0x48(0x200)
	struct FScalableFloat Period; // 0x248(0x30)
	bool bExecutePeriodicEffectOnApplication; // 0x278(0x01)
	enum class EGameplayEffectPeriodInhibitionRemovedPolicy PeriodicInhibitionPolicy; // 0x279(0x01)
	char pad_27A[0x6]; // 0x27a(0x06)
	struct TArray<struct FGameplayModifierInfo> Modifiers; // 0x280(0x10)
	struct TArray<struct FGameplayEffectExecutionDefinition> Executions; // 0x290(0x10)
	struct FScalableFloat ChanceToApplyToTarget; // 0x2a0(0x30)
	struct TArray<struct UClass*> ApplicationRequirements; // 0x2d0(0x10)
	struct TArray<struct UClass*> TargetEffectClasses; // 0x2e0(0x10)
	struct TArray<struct FConditionalGameplayEffect> ConditionalGameplayEffects; // 0x2f0(0x10)
	struct TArray<struct UClass*> OverflowEffects; // 0x300(0x10)
	bool bDenyOverflowApplication; // 0x310(0x01)
	bool bClearStackOnOverflow; // 0x311(0x01)
	char pad_312[0x6]; // 0x312(0x06)
	struct TArray<struct UClass*> PrematureExpirationEffectClasses; // 0x318(0x10)
	struct TArray<struct UClass*> RoutineExpirationEffectClasses; // 0x328(0x10)
	bool bRequireModifierSuccessToTriggerCues; // 0x338(0x01)
	bool bSuppressStackingCues; // 0x339(0x01)
	char pad_33A[0x6]; // 0x33a(0x06)
	struct TArray<struct FGameplayEffectCue> GameplayCues; // 0x340(0x10)
	struct UGameplayEffectUIData* UIData; // 0x350(0x08)
	struct FInheritedTagContainer InheritableGameplayEffectTags; // 0x358(0x60)
	struct FInheritedTagContainer InheritableOwnedTagsContainer; // 0x3b8(0x60)
	struct FGameplayTagRequirements OngoingTagRequirements; // 0x418(0x40)
	struct FGameplayTagRequirements ApplicationTagRequirements; // 0x458(0x40)
	struct FGameplayTagRequirements RemovalTagRequirements; // 0x498(0x40)
	struct FInheritedTagContainer RemoveGameplayEffectsWithTags; // 0x4d8(0x60)
	struct FGameplayTagRequirements GrantedApplicationImmunityTags; // 0x538(0x40)
	char pad_578[0x8]; // 0x578(0x08)
	struct FGameplayEffectQuery GrantedApplicationImmunityQuery; // 0x580(0x170)
	char pad_6F0[0x10]; // 0x6f0(0x10)
	struct FGameplayEffectQuery RemoveGameplayEffectQuery; // 0x700(0x170)
	char pad_870[0x1]; // 0x870(0x01)
	enum class EGameplayEffectStackingType StackingType; // 0x871(0x01)
	char pad_872[0x2]; // 0x872(0x02)
	int32 StackLimitCount; // 0x874(0x04)
	enum class EGameplayEffectStackingDurationPolicy StackDurationRefreshPolicy; // 0x878(0x01)
	enum class EGameplayEffectStackingPeriodPolicy StackPeriodResetPolicy; // 0x879(0x01)
	enum class EGameplayEffectStackingExpirationPolicy StackExpirationPolicy; // 0x87a(0x01)
	char pad_87B[0x5]; // 0x87b(0x05)
	struct TArray<struct FGameplayAbilitySpecDef> GrantedAbilities; // 0x880(0x10)
};

// Class GameplayAbilities.AbilityAsync
// Size: 0x40 (Inherited: 0x38)
struct UAbilityAsync : UBlueprintAsyncActionBase {
	char pad_38[0x8]; // 0x38(0x08)

	void EndAction(); // Function GameplayAbilities.AbilityAsync.EndAction // Native|Public|BlueprintCallable // @ game+0xa18960
};

// Class GameplayAbilities.AbilityAsync_WaitGameplayEffectApplied
// Size: 0x100 (Inherited: 0x40)
struct UAbilityAsync_WaitGameplayEffectApplied : UAbilityAsync {
	struct FMulticastDelegate OnApplied; // 0x40(0x10)
	char pad_50[0xb0]; // 0x50(0xb0)

	struct UAbilityAsync_WaitGameplayEffectApplied* WaitGameplayEffectAppliedToActor(struct AActor* TargetActor, struct FGameplayTargetDataFilterHandle SourceFilter, struct FGameplayTagRequirements SourceTagRequirements, struct FGameplayTagRequirements TargetTagRequirements, bool TriggerOnce, bool ListenForPeriodicEffect); // Function GameplayAbilities.AbilityAsync_WaitGameplayEffectApplied.WaitGameplayEffectAppliedToActor // Final|Native|Static|Public|BlueprintCallable // @ game+0x5dad68c
	void OnAppliedDelegate__DelegateSignature(struct AActor* Source, struct FGameplayEffectSpecHandle SpecHandle, struct FActiveGameplayEffectHandle ActiveHandle); // DelegateFunction GameplayAbilities.AbilityAsync_WaitGameplayEffectApplied.OnAppliedDelegate__DelegateSignature // MulticastDelegate|Public|Delegate // @ game+0x33e45c
};

// Class GameplayAbilities.AbilityAsync_WaitGameplayEvent
// Size: 0x68 (Inherited: 0x40)
struct UAbilityAsync_WaitGameplayEvent : UAbilityAsync {
	struct FMulticastDelegate EventReceived; // 0x40(0x10)
	char pad_50[0x18]; // 0x50(0x18)

	struct UAbilityAsync_WaitGameplayEvent* WaitGameplayEventToActor(struct AActor* TargetActor, struct FGameplayTag EventTag, bool OnlyTriggerOnce, bool OnlyMatchExact); // Function GameplayAbilities.AbilityAsync_WaitGameplayEvent.WaitGameplayEventToActor // Final|Native|Static|Public|BlueprintCallable // @ game+0x5dad9dc
	void EventReceivedDelegate__DelegateSignature(struct FGameplayEventData Payload); // DelegateFunction GameplayAbilities.AbilityAsync_WaitGameplayEvent.EventReceivedDelegate__DelegateSignature // MulticastDelegate|Public|Delegate // @ game+0x33e45c
};

// Class GameplayAbilities.AbilityAsync_WaitGameplayTag
// Size: 0x60 (Inherited: 0x40)
struct UAbilityAsync_WaitGameplayTag : UAbilityAsync {
	char pad_40[0x20]; // 0x40(0x20)

	void AsyncWaitGameplayTagDelegate__DelegateSignature(); // DelegateFunction GameplayAbilities.AbilityAsync_WaitGameplayTag.AsyncWaitGameplayTagDelegate__DelegateSignature // MulticastDelegate|Public|Delegate // @ game+0x33e45c
};

// Class GameplayAbilities.AbilityAsync_WaitGameplayTagAdded
// Size: 0x70 (Inherited: 0x60)
struct UAbilityAsync_WaitGameplayTagAdded : UAbilityAsync_WaitGameplayTag {
	struct FMulticastDelegate Added; // 0x60(0x10)

	struct UAbilityAsync_WaitGameplayTagAdded* WaitGameplayTagAddToActor(struct AActor* TargetActor, struct FGameplayTag Tag, bool OnlyTriggerOnce); // Function GameplayAbilities.AbilityAsync_WaitGameplayTagAdded.WaitGameplayTagAddToActor // Final|Native|Static|Public|BlueprintCallable // @ game+0x5dadb58
};

// Class GameplayAbilities.AbilityAsync_WaitGameplayTagRemoved
// Size: 0x70 (Inherited: 0x60)
struct UAbilityAsync_WaitGameplayTagRemoved : UAbilityAsync_WaitGameplayTag {
	struct FMulticastDelegate Removed; // 0x60(0x10)

	struct UAbilityAsync_WaitGameplayTagRemoved* WaitGameplayTagRemoveFromActor(struct AActor* TargetActor, struct FGameplayTag Tag, bool OnlyTriggerOnce); // Function GameplayAbilities.AbilityAsync_WaitGameplayTagRemoved.WaitGameplayTagRemoveFromActor // Final|Native|Static|Public|BlueprintCallable // @ game+0x5dadc78
};

// Class GameplayAbilities.GameplayCueInterface
// Size: 0x38 (Inherited: 0x38)
struct UGameplayCueInterface : UInterface {

	void ForwardGameplayCueToParent(); // Function GameplayAbilities.GameplayCueInterface.ForwardGameplayCueToParent // BlueprintCosmetic|Native|Public|BlueprintCallable // @ game+0x5da91f8
	void BlueprintCustomHandler(enum class EGameplayCueEvent EventType, struct FGameplayCueParameters Parameters); // Function GameplayAbilities.GameplayCueInterface.BlueprintCustomHandler // BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent // @ game+0x33e45c
};

// Class GameplayAbilities.AbilitySystemBlueprintLibrary
// Size: 0x38 (Inherited: 0x38)
struct UAbilitySystemBlueprintLibrary : UBlueprintFunctionLibrary {

	bool TargetDataHasOrigin(struct FGameplayAbilityTargetDataHandle TargetData, int32 Index); // Function GameplayAbilities.AbilitySystemBlueprintLibrary.TargetDataHasOrigin // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x5dad4b4
	bool TargetDataHasHitResult(struct FGameplayAbilityTargetDataHandle HitResult, int32 Index); // Function GameplayAbilities.AbilitySystemBlueprintLibrary.TargetDataHasHitResult // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x5dad2f4
	bool TargetDataHasEndPoint(struct FGameplayAbilityTargetDataHandle TargetData, int32 Index); // Function GameplayAbilities.AbilitySystemBlueprintLibrary.TargetDataHasEndPoint // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x5dad11c
	bool TargetDataHasActor(struct FGameplayAbilityTargetDataHandle TargetData, int32 Index); // Function GameplayAbilities.AbilitySystemBlueprintLibrary.TargetDataHasActor // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x5dacf44
	struct FGameplayEffectSpecHandle SetStackCountToMax(struct FGameplayEffectSpecHandle SpecHandle); // Function GameplayAbilities.AbilitySystemBlueprintLibrary.SetStackCountToMax // Final|Native|Static|Public|BlueprintCallable // @ game+0x5dace00
	struct FGameplayEffectSpecHandle SetStackCount(struct FGameplayEffectSpecHandle SpecHandle, int32 StackCount); // Function GameplayAbilities.AbilitySystemBlueprintLibrary.SetStackCount // Final|Native|Static|Public|BlueprintCallable // @ game+0x5dacc08
	struct FGameplayEffectSpecHandle SetDuration(struct FGameplayEffectSpecHandle SpecHandle, float Duration); // Function GameplayAbilities.AbilitySystemBlueprintLibrary.SetDuration // Final|Native|Static|Public|BlueprintCallable // @ game+0x5daca74
	void SendGameplayEventToActor(struct AActor* Actor, struct FGameplayTag EventTag, struct FGameplayEventData Payload); // Function GameplayAbilities.AbilitySystemBlueprintLibrary.SendGameplayEventToActor // Final|Native|Static|Public|BlueprintCallable // @ game+0x5dac8e4
	bool NotEqual_GameplayAttributeGameplayAttribute(struct FGameplayAttribute AttributeA, struct FGameplayAttribute AttributeB); // Function GameplayAbilities.AbilitySystemBlueprintLibrary.NotEqual_GameplayAttributeGameplayAttribute // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5dac71c
	struct FGameplayEffectSpecHandle MakeSpecHandle(struct UGameplayEffect* InGameplayEffect, struct AActor* InInstigator, struct AActor* InEffectCauser, float InLevel); // Function GameplayAbilities.AbilitySystemBlueprintLibrary.MakeSpecHandle // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5dac540
	struct FGameplayCueParameters MakeGameplayCueParameters(float NormalizedMagnitude, float RawMagnitude, struct FGameplayEffectContextHandle EffectContext, struct FGameplayTag MatchedTagName, struct FGameplayTag OriginalTag, struct FGameplayTagContainer AggregatedSourceTags, struct FGameplayTagContainer AggregatedTargetTags, struct FVector Location, struct FVector Normal, struct AActor* Instigator, struct AActor* EffectCauser, struct UObject* SourceObject, struct UPhysicalMaterial* PhysicalMaterial, int32 GameplayEffectLevel, int32 AbilityLevel, struct USceneComponent* TargetAttachComponent, bool bReplicateLocationWhenUsingMinimalRepProxy); // Function GameplayAbilities.AbilitySystemBlueprintLibrary.MakeGameplayCueParameters // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5dabe40
	struct FGameplayTargetDataFilterHandle MakeFilterHandle(struct FGameplayTargetDataFilter Filter, struct AActor* FilterActor); // Function GameplayAbilities.AbilitySystemBlueprintLibrary.MakeFilterHandle // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5dabcb0
	bool IsValid(struct FGameplayAttribute Attribute); // Function GameplayAbilities.AbilitySystemBlueprintLibrary.IsValid // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5dabbb0
	bool IsInstigatorLocallyControlledPlayer(struct FGameplayCueParameters Parameters); // Function GameplayAbilities.AbilitySystemBlueprintLibrary.IsInstigatorLocallyControlledPlayer // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5dababc
	bool IsInstigatorLocallyControlled(struct FGameplayCueParameters Parameters); // Function GameplayAbilities.AbilitySystemBlueprintLibrary.IsInstigatorLocallyControlled // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5dab9c8
	bool HasHitResult(struct FGameplayCueParameters Parameters); // Function GameplayAbilities.AbilitySystemBlueprintLibrary.HasHitResult // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5dab8c4
	struct FTransform GetTargetDataOrigin(struct FGameplayAbilityTargetDataHandle TargetData, int32 Index); // Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetTargetDataOrigin // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5dab718
	struct FTransform GetTargetDataEndPointTransform(struct FGameplayAbilityTargetDataHandle TargetData, int32 Index); // Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetTargetDataEndPointTransform // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5dab52c
	struct FVector GetTargetDataEndPoint(struct FGameplayAbilityTargetDataHandle TargetData, int32 Index); // Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetTargetDataEndPoint // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5dab390
	struct FVector GetOrigin(struct FGameplayCueParameters Parameters); // Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetOrigin // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5dab268
	float GetModifiedAttributeMagnitude(struct FGameplayEffectSpecHandle SpecHandle, struct FGameplayAttribute Attribute); // Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetModifiedAttributeMagnitude // Final|Native|Static|Public|BlueprintCallable // @ game+0x5dab0d4
	struct FTransform GetInstigatorTransform(struct FGameplayCueParameters Parameters); // Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetInstigatorTransform // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5daafc4
	struct AActor* GetInstigatorActor(struct FGameplayCueParameters Parameters); // Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetInstigatorActor // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5daaef0
	struct FHitResult GetHitResultFromTargetData(struct FGameplayAbilityTargetDataHandle HitResult, int32 Index); // Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetHitResultFromTargetData // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x5daacf0
	struct FHitResult GetHitResult(struct FGameplayCueParameters Parameters); // Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetHitResult // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5daac0c
	bool GetGameplayCueEndLocationAndNormal(struct AActor* TargetActor, struct FGameplayCueParameters Parameters, struct FVector Location, struct FVector Normal); // Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetGameplayCueEndLocationAndNormal // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5daaa2c
	bool GetGameplayCueDirection(struct AActor* TargetActor, struct FGameplayCueParameters Parameters, struct FVector Direction); // Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetGameplayCueDirection // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5daa8a4
	float GetFloatAttributeFromAbilitySystemComponent(struct UAbilitySystemComponent* AbilitySystem, struct FGameplayAttribute Attribute, bool bSuccessfullyFoundAttribute); // Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetFloatAttributeFromAbilitySystemComponent // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x5daa720
	float GetFloatAttributeBaseFromAbilitySystemComponent(struct UAbilitySystemComponent* AbilitySystemComponent, struct FGameplayAttribute Attribute, bool bSuccessfullyFoundAttribute); // Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetFloatAttributeBaseFromAbilitySystemComponent // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x5daa59c
	float GetFloatAttributeBase(struct AActor* Actor, struct FGameplayAttribute Attribute, bool bSuccessfullyFoundAttribute); // Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetFloatAttributeBase // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x5daa418
	float GetFloatAttribute(struct AActor* Actor, struct FGameplayAttribute Attribute, bool bSuccessfullyFoundAttribute); // Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetFloatAttribute // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x5daa294
	struct FGameplayEffectContextHandle GetEffectContext(struct FGameplayEffectSpecHandle SpecHandle); // Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetEffectContext // Final|Native|Static|Public|BlueprintCallable // @ game+0x5daa148
	int32 GetDataCountFromTargetData(struct FGameplayAbilityTargetDataHandle TargetData); // Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetDataCountFromTargetData // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x5daa010
	struct TArray<struct FGameplayEffectSpecHandle> GetAllLinkedGameplayEffectSpecHandles(struct FGameplayEffectSpecHandle SpecHandle); // Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetAllLinkedGameplayEffectSpecHandles // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5da9efc
	struct TArray<struct AActor*> GetAllActorsFromTargetData(struct FGameplayAbilityTargetDataHandle TargetData); // Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetAllActorsFromTargetData // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x5da9d70
	struct TArray<struct AActor*> GetActorsFromTargetData(struct FGameplayAbilityTargetDataHandle TargetData, int32 Index); // Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetActorsFromTargetData // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x5da9b98
	int32 GetActorCount(struct FGameplayCueParameters Parameters); // Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetActorCount // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5da9a90
	struct AActor* GetActorByIndex(struct FGameplayCueParameters Parameters, int32 Index); // Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetActorByIndex // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5da9968
	float GetActiveGameplayEffectTotalDuration(struct FActiveGameplayEffectHandle ActiveHandle); // Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetActiveGameplayEffectTotalDuration // Final|Native|Static|Public|BlueprintCallable // @ game+0x5da98d4
	float GetActiveGameplayEffectStartTime(struct FActiveGameplayEffectHandle ActiveHandle); // Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetActiveGameplayEffectStartTime // Final|Native|Static|Public|BlueprintCallable // @ game+0x5da9840
	int32 GetActiveGameplayEffectStackLimitCount(struct FActiveGameplayEffectHandle ActiveHandle); // Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetActiveGameplayEffectStackLimitCount // Final|Native|Static|Public|BlueprintCallable // @ game+0x5da9774
	int32 GetActiveGameplayEffectStackCount(struct FActiveGameplayEffectHandle ActiveHandle); // Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetActiveGameplayEffectStackCount // Final|Native|Static|Public|BlueprintCallable // @ game+0x5da96b4
	float GetActiveGameplayEffectRemainingDuration(struct UObject* WorldContextObject, struct FActiveGameplayEffectHandle ActiveHandle); // Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetActiveGameplayEffectRemainingDuration // Final|Native|Static|Public|BlueprintCallable // @ game+0x5da95d4
	float GetActiveGameplayEffectExpectedEndTime(struct FActiveGameplayEffectHandle ActiveHandle); // Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetActiveGameplayEffectExpectedEndTime // Final|Native|Static|Public|BlueprintCallable // @ game+0x5da9540
	struct FString GetActiveGameplayEffectDebugString(struct FActiveGameplayEffectHandle ActiveHandle); // Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetActiveGameplayEffectDebugString // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5da945c
	struct UAbilitySystemComponent* GetAbilitySystemComponent(struct AActor* Actor); // Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetAbilitySystemComponent // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5da93cc
	void ForwardGameplayCueToTarget(TScriptInterface<struct UGameplayCueInterface> TargetCueInterface, enum class EGameplayCueEvent EventType, struct FGameplayCueParameters Parameters); // Function GameplayAbilities.AbilitySystemBlueprintLibrary.ForwardGameplayCueToTarget // Final|Native|Static|Public|BlueprintCallable // @ game+0x5da920c
	struct FGameplayAbilityTargetDataHandle FilterTargetData(struct FGameplayAbilityTargetDataHandle TargetDataHandle, struct FGameplayTargetDataFilterHandle ActorFilterClass); // Function GameplayAbilities.AbilitySystemBlueprintLibrary.FilterTargetData // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x5da8f94
	float EvaluateAttributeValueWithTagsAndBase(struct UAbilitySystemComponent* AbilitySystem, struct FGameplayAttribute Attribute, struct FGameplayTagContainer SourceTags, struct FGameplayTagContainer TargetTags, float BaseValue, bool bSuccess); // Function GameplayAbilities.AbilitySystemBlueprintLibrary.EvaluateAttributeValueWithTagsAndBase // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x5da8c94
	float EvaluateAttributeValueWithTags(struct UAbilitySystemComponent* AbilitySystem, struct FGameplayAttribute Attribute, struct FGameplayTagContainer SourceTags, struct FGameplayTagContainer TargetTags, bool bSuccess); // Function GameplayAbilities.AbilitySystemBlueprintLibrary.EvaluateAttributeValueWithTags // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x5da89e8
	bool EqualEqual_GameplayAttributeGameplayAttribute(struct FGameplayAttribute AttributeA, struct FGameplayAttribute AttributeB); // Function GameplayAbilities.AbilitySystemBlueprintLibrary.EqualEqual_GameplayAttributeGameplayAttribute // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5da8820
	void EffectContextSetOrigin(struct FGameplayEffectContextHandle EffectContext, struct FVector Origin); // Function GameplayAbilities.AbilitySystemBlueprintLibrary.EffectContextSetOrigin // Final|Native|Static|Public|HasDefaults|BlueprintCallable // @ game+0x5da868c
	bool EffectContextIsValid(struct FGameplayEffectContextHandle EffectContext); // Function GameplayAbilities.AbilitySystemBlueprintLibrary.EffectContextIsValid // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5da855c
	bool EffectContextIsInstigatorLocallyControlled(struct FGameplayEffectContextHandle EffectContext); // Function GameplayAbilities.AbilitySystemBlueprintLibrary.EffectContextIsInstigatorLocallyControlled // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5da8408
	bool EffectContextHasHitResult(struct FGameplayEffectContextHandle EffectContext); // Function GameplayAbilities.AbilitySystemBlueprintLibrary.EffectContextHasHitResult // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5da82b4
	struct UObject* EffectContextGetSourceObject(struct FGameplayEffectContextHandle EffectContext); // Function GameplayAbilities.AbilitySystemBlueprintLibrary.EffectContextGetSourceObject // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5da8164
	struct AActor* EffectContextGetOriginalInstigatorActor(struct FGameplayEffectContextHandle EffectContext); // Function GameplayAbilities.AbilitySystemBlueprintLibrary.EffectContextGetOriginalInstigatorActor // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5da8014
	struct FVector EffectContextGetOrigin(struct FGameplayEffectContextHandle EffectContext); // Function GameplayAbilities.AbilitySystemBlueprintLibrary.EffectContextGetOrigin // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5da7f0c
	struct AActor* EffectContextGetInstigatorActor(struct FGameplayEffectContextHandle EffectContext); // Function GameplayAbilities.AbilitySystemBlueprintLibrary.EffectContextGetInstigatorActor // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5da7dbc
	struct FHitResult EffectContextGetHitResult(struct FGameplayEffectContextHandle EffectContext); // Function GameplayAbilities.AbilitySystemBlueprintLibrary.EffectContextGetHitResult // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5da7cb0
	struct AActor* EffectContextGetEffectCauser(struct FGameplayEffectContextHandle EffectContext); // Function GameplayAbilities.AbilitySystemBlueprintLibrary.EffectContextGetEffectCauser // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5da7b60
	void EffectContextAddHitResult(struct FGameplayEffectContextHandle EffectContext, struct FHitResult HitResult, bool bReset); // Function GameplayAbilities.AbilitySystemBlueprintLibrary.EffectContextAddHitResult // Final|Native|Static|Public|BlueprintCallable // @ game+0x5da7944
	bool DoesTargetDataContainActor(struct FGameplayAbilityTargetDataHandle TargetData, int32 Index, struct AActor* Actor); // Function GameplayAbilities.AbilitySystemBlueprintLibrary.DoesTargetDataContainActor // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x5da776c
	bool DoesGameplayCueMeetTagRequirements(struct FGameplayCueParameters Parameters, struct FGameplayTagRequirements SourceTagReqs, struct FGameplayTagRequirements TargetTagReqs); // Function GameplayAbilities.AbilitySystemBlueprintLibrary.DoesGameplayCueMeetTagRequirements // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x5da74d4
	struct FGameplayEffectSpecHandle CloneSpecHandle(struct AActor* InNewInstigator, struct AActor* InEffectCauser, struct FGameplayEffectSpecHandle GameplayEffectSpecHandle_Clone); // Function GameplayAbilities.AbilitySystemBlueprintLibrary.CloneSpecHandle // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5da72f0
	void BreakGameplayCueParameters(struct FGameplayCueParameters Parameters, float NormalizedMagnitude, float RawMagnitude, struct FGameplayEffectContextHandle EffectContext, struct FGameplayTag MatchedTagName, struct FGameplayTag OriginalTag, struct FGameplayTagContainer AggregatedSourceTags, struct FGameplayTagContainer AggregatedTargetTags, struct FVector Location, struct FVector Normal, struct AActor* Instigator, struct AActor* EffectCauser, struct UObject* SourceObject, struct UPhysicalMaterial* PhysicalMaterial, int32 GameplayEffectLevel, int32 AbilityLevel, struct USceneComponent* TargetAttachComponent, bool bReplicateLocationWhenUsingMinimalRepProxy); // Function GameplayAbilities.AbilitySystemBlueprintLibrary.BreakGameplayCueParameters // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5da6aa8
	struct FGameplayEffectSpecHandle AssignTagSetByCallerMagnitude(struct FGameplayEffectSpecHandle SpecHandle, struct FGameplayTag DataTag, float Magnitude); // Function GameplayAbilities.AbilitySystemBlueprintLibrary.AssignTagSetByCallerMagnitude // Final|Native|Static|Public|BlueprintCallable // @ game+0x5da68bc
	struct FGameplayEffectSpecHandle AssignSetByCallerMagnitude(struct FGameplayEffectSpecHandle SpecHandle, struct FName DataName, float Magnitude); // Function GameplayAbilities.AbilitySystemBlueprintLibrary.AssignSetByCallerMagnitude // Final|Native|Static|Public|BlueprintCallable // @ game+0x5da66d0
	struct FGameplayAbilityTargetDataHandle AppendTargetDataHandle(struct FGameplayAbilityTargetDataHandle TargetHandle, struct FGameplayAbilityTargetDataHandle HandleToAdd); // Function GameplayAbilities.AbilitySystemBlueprintLibrary.AppendTargetDataHandle // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x5da6444
	struct FGameplayEffectSpecHandle AddLinkedGameplayEffectSpec(struct FGameplayEffectSpecHandle SpecHandle, struct FGameplayEffectSpecHandle LinkedGameplayEffectSpec); // Function GameplayAbilities.AbilitySystemBlueprintLibrary.AddLinkedGameplayEffectSpec // Final|Native|Static|Public|BlueprintCallable // @ game+0x5da6250
	struct FGameplayEffectSpecHandle AddLinkedGameplayEffect(struct FGameplayEffectSpecHandle SpecHandle, struct UClass* LinkedGameplayEffect); // Function GameplayAbilities.AbilitySystemBlueprintLibrary.AddLinkedGameplayEffect // Final|Native|Static|Public|BlueprintCallable // @ game+0x5da60b8
	struct FGameplayEffectSpecHandle AddGrantedTags(struct FGameplayEffectSpecHandle SpecHandle, struct FGameplayTagContainer NewGameplayTags); // Function GameplayAbilities.AbilitySystemBlueprintLibrary.AddGrantedTags // Final|Native|Static|Public|BlueprintCallable // @ game+0x5da5ec4
	struct FGameplayEffectSpecHandle AddGrantedTag(struct FGameplayEffectSpecHandle SpecHandle, struct FGameplayTag NewGameplayTag); // Function GameplayAbilities.AbilitySystemBlueprintLibrary.AddGrantedTag // Final|Native|Static|Public|BlueprintCallable // @ game+0x5da5d28
	struct FGameplayEffectSpecHandle AddAssetTags(struct FGameplayEffectSpecHandle SpecHandle, struct FGameplayTagContainer NewGameplayTags); // Function GameplayAbilities.AbilitySystemBlueprintLibrary.AddAssetTags // Final|Native|Static|Public|BlueprintCallable // @ game+0x5da5b34
	struct FGameplayEffectSpecHandle AddAssetTag(struct FGameplayEffectSpecHandle SpecHandle, struct FGameplayTag NewGameplayTag); // Function GameplayAbilities.AbilitySystemBlueprintLibrary.AddAssetTag // Final|Native|Static|Public|BlueprintCallable // @ game+0x5da5998
	struct FGameplayAbilityTargetDataHandle AbilityTargetDataFromLocations(struct FGameplayAbilityTargetingLocationInfo SourceLocation, struct FGameplayAbilityTargetingLocationInfo TargetLocation); // Function GameplayAbilities.AbilitySystemBlueprintLibrary.AbilityTargetDataFromLocations // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x5da573c
	struct FGameplayAbilityTargetDataHandle AbilityTargetDataFromHitResult(struct FHitResult HitResult); // Function GameplayAbilities.AbilitySystemBlueprintLibrary.AbilityTargetDataFromHitResult // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x5da55c0
	struct FGameplayAbilityTargetDataHandle AbilityTargetDataFromActorArray(struct TArray<struct AActor*> ActorArray, bool OneTargetPerHandle); // Function GameplayAbilities.AbilitySystemBlueprintLibrary.AbilityTargetDataFromActorArray // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x5da540c
	struct FGameplayAbilityTargetDataHandle AbilityTargetDataFromActor(struct AActor* Actor); // Function GameplayAbilities.AbilitySystemBlueprintLibrary.AbilityTargetDataFromActor // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5da52d8
};

// Class GameplayAbilities.AbilitySystemReplicationProxyInterface
// Size: 0x38 (Inherited: 0x38)
struct UAbilitySystemReplicationProxyInterface : UInterface {
};

// Class GameplayAbilities.AbilitySystemDebugHUD
// Size: 0x4d8 (Inherited: 0x4d8)
struct AAbilitySystemDebugHUD : AHUD {
};

// Class GameplayAbilities.AbilitySystemGlobals
// Size: 0x350 (Inherited: 0x38)
struct UAbilitySystemGlobals : UObject {
	struct FStringClassReference AbilitySystemGlobalsClassName; // 0x38(0x10)
	char pad_48[0x88]; // 0x48(0x88)
	struct FGameplayTag ActivateFailIsDeadTag; // 0xd0(0x08)
	struct FName ActivateFailIsDeadName; // 0xd8(0x08)
	struct FGameplayTag ActivateFailCooldownTag; // 0xe0(0x08)
	struct FName ActivateFailCooldownName; // 0xe8(0x08)
	struct FGameplayTag ActivateFailCostTag; // 0xf0(0x08)
	struct FName ActivateFailCostName; // 0xf8(0x08)
	struct FGameplayTag ActivateFailTagsBlockedTag; // 0x100(0x08)
	struct FName ActivateFailTagsBlockedName; // 0x108(0x08)
	struct FGameplayTag ActivateFailTagsMissingTag; // 0x110(0x08)
	struct FName ActivateFailTagsMissingName; // 0x118(0x08)
	struct FGameplayTag ActivateFailNetworkingTag; // 0x120(0x08)
	struct FName ActivateFailNetworkingName; // 0x128(0x08)
	int32 MinimalReplicationTagCountBits; // 0x130(0x04)
	char pad_134[0x4]; // 0x134(0x04)
	struct FNetSerializeScriptStructCache TargetDataStructCache; // 0x138(0x10)
	bool bAllowGameplayModEvaluationChannels; // 0x148(0x01)
	enum class EGameplayModEvaluationChannel DefaultGameplayModEvaluationChannel; // 0x149(0x01)
	char pad_14A[0x6]; // 0x14a(0x06)
	struct FName GameplayModEvaluationChannelAliases[0x0a]; // 0x150(0x50)
	struct FStringAssetReference GlobalCurveTableName; // 0x1a0(0x10)
	struct UCurveTable* GlobalCurveTable; // 0x1b0(0x08)
	struct FStringAssetReference GlobalAttributeMetaDataTableName; // 0x1b8(0x10)
	struct UDataTable* GlobalAttributeMetaDataTable; // 0x1c8(0x08)
	struct FStringAssetReference GlobalAttributeSetDefaultsTableName; // 0x1d0(0x10)
	struct TArray<struct FStringAssetReference> GlobalAttributeSetDefaultsTableNames; // 0x1e0(0x10)
	struct TArray<struct UCurveTable*> GlobalAttributeDefaultsTables; // 0x1f0(0x10)
	struct FStringAssetReference GlobalGameplayCueManagerClass; // 0x200(0x10)
	struct FStringAssetReference GlobalGameplayCueManagerName; // 0x210(0x10)
	struct TArray<struct FString> GameplayCueNotifyPaths; // 0x220(0x10)
	struct FStringAssetReference GameplayTagResponseTableName; // 0x230(0x10)
	struct UGameplayTagReponseTable* GameplayTagResponseTable; // 0x240(0x08)
	bool PredictTargetGameplayEffects; // 0x248(0x01)
	char pad_249[0x7]; // 0x249(0x07)
	struct UGameplayCueManager* GlobalGameplayCueManager; // 0x250(0x08)
	char pad_258[0xf8]; // 0x258(0xf8)

	void ToggleIgnoreAbilitySystemCosts(); // Function GameplayAbilities.AbilitySystemGlobals.ToggleIgnoreAbilitySystemCosts // Exec|Native|Public // @ game+0x5e12d44
	void ToggleIgnoreAbilitySystemCooldowns(); // Function GameplayAbilities.AbilitySystemGlobals.ToggleIgnoreAbilitySystemCooldowns // Exec|Native|Public // @ game+0x5b6ee08
	void ServerEndPlayerAbility(struct FString AbilityNameMatch); // Function GameplayAbilities.AbilitySystemGlobals.ServerEndPlayerAbility // Final|Exec|Native|Public // @ game+0x4cf23c0
	void ServerCancelPlayerAbility(struct FString AbilityNameMatch); // Function GameplayAbilities.AbilitySystemGlobals.ServerCancelPlayerAbility // Final|Exec|Native|Public // @ game+0x4cf23c0
	void ServerActivatePlayerAbility(struct FString AbilityNameMatch); // Function GameplayAbilities.AbilitySystemGlobals.ServerActivatePlayerAbility // Final|Exec|Native|Public // @ game+0x4cf23c0
	void ListPlayerAbilities(); // Function GameplayAbilities.AbilitySystemGlobals.ListPlayerAbilities // Final|Exec|Native|Public // @ game+0xc0af08
};

// Class GameplayAbilities.AbilitySystemTestPawn
// Size: 0x498 (Inherited: 0x478)
struct AAbilitySystemTestPawn : ADefaultPawn {
	char pad_478[0x18]; // 0x478(0x18)
	struct UAbilitySystemComponent* AbilitySystemComponent; // 0x490(0x08)
};

// Class GameplayAbilities.AbilityTask_ApplyRootMotion_Base
// Size: 0xc8 (Inherited: 0x90)
struct UAbilityTask_ApplyRootMotion_Base : UAbilityTask {
	struct FName ForceName; // 0x90(0x08)
	enum class ERootMotionFinishVelocityMode FinishVelocityMode; // 0x98(0x01)
	char pad_99[0x3]; // 0x99(0x03)
	struct FVector FinishSetVelocity; // 0x9c(0x0c)
	float FinishClampVelocity; // 0xa8(0x04)
	char pad_AC[0x4]; // 0xac(0x04)
	struct UCharacterMovementComponent* MovementComponent; // 0xb0(0x08)
	char pad_B8[0x10]; // 0xb8(0x10)
};

// Class GameplayAbilities.AbilityTask_ApplyRootMotionConstantForce
// Size: 0x100 (Inherited: 0xc8)
struct UAbilityTask_ApplyRootMotionConstantForce : UAbilityTask_ApplyRootMotion_Base {
	struct FMulticastDelegate OnFinish; // 0xc8(0x10)
	struct FVector WorldDirection; // 0xd8(0x0c)
	float Strength; // 0xe4(0x04)
	float Duration; // 0xe8(0x04)
	bool bIsAdditive; // 0xec(0x01)
	char pad_ED[0x3]; // 0xed(0x03)
	struct UCurveFloat* StrengthOverTime; // 0xf0(0x08)
	bool bEnableGravity; // 0xf8(0x01)
	char pad_F9[0x7]; // 0xf9(0x07)

	struct UAbilityTask_ApplyRootMotionConstantForce* ApplyRootMotionConstantForce(struct UGameplayAbility* OwningAbility, struct FName TaskInstanceName, struct FVector WorldDirection, float Strength, float Duration, bool bIsAdditive, struct UCurveFloat* StrengthOverTime, enum class ERootMotionFinishVelocityMode VelocityOnFinishMode, struct FVector SetVelocityOnFinish, float ClampVelocityOnFinish, bool bEnableGravity); // Function GameplayAbilities.AbilityTask_ApplyRootMotionConstantForce.ApplyRootMotionConstantForce // Final|Native|Static|Public|HasDefaults|BlueprintCallable // @ game+0x5e06d84
};

// Class GameplayAbilities.AbilityTask_ApplyRootMotionJumpForce
// Size: 0x120 (Inherited: 0xc8)
struct UAbilityTask_ApplyRootMotionJumpForce : UAbilityTask_ApplyRootMotion_Base {
	struct FMulticastDelegate OnFinish; // 0xc8(0x10)
	struct FMulticastDelegate OnLanded; // 0xd8(0x10)
	struct FRotator Rotation; // 0xe8(0x0c)
	float Distance; // 0xf4(0x04)
	float Height; // 0xf8(0x04)
	float Duration; // 0xfc(0x04)
	float MinimumLandedTriggerTime; // 0x100(0x04)
	bool bFinishOnLanded; // 0x104(0x01)
	char pad_105[0x3]; // 0x105(0x03)
	struct UCurveVector* PathOffsetCurve; // 0x108(0x08)
	struct UCurveFloat* TimeMappingCurve; // 0x110(0x08)
	char pad_118[0x8]; // 0x118(0x08)

	void OnLandedCallback(struct FHitResult Hit); // Function GameplayAbilities.AbilityTask_ApplyRootMotionJumpForce.OnLandedCallback // Final|Native|Public|HasOutParms // @ game+0x5e0f874
	void Finish(); // Function GameplayAbilities.AbilityTask_ApplyRootMotionJumpForce.Finish // Final|Native|Public|BlueprintCallable // @ game+0x5e0b3a4
	struct UAbilityTask_ApplyRootMotionJumpForce* ApplyRootMotionJumpForce(struct UGameplayAbility* OwningAbility, struct FName TaskInstanceName, struct FRotator Rotation, float Distance, float Height, float Duration, float MinimumLandedTriggerTime, bool bFinishOnLanded, enum class ERootMotionFinishVelocityMode VelocityOnFinishMode, struct FVector SetVelocityOnFinish, float ClampVelocityOnFinish, struct UCurveVector* PathOffsetCurve, struct UCurveFloat* TimeMappingCurve); // Function GameplayAbilities.AbilityTask_ApplyRootMotionJumpForce.ApplyRootMotionJumpForce // Final|Native|Static|Public|HasDefaults|BlueprintCallable // @ game+0x5e07154
};

// Class GameplayAbilities.AbilityTask_ApplyRootMotionMoveToActorForce
// Size: 0x140 (Inherited: 0xc8)
struct UAbilityTask_ApplyRootMotionMoveToActorForce : UAbilityTask_ApplyRootMotion_Base {
	struct FMulticastDelegate OnFinished; // 0xc8(0x10)
	char pad_D8[0x8]; // 0xd8(0x08)
	struct FVector StartLocation; // 0xe0(0x0c)
	struct FVector TargetLocation; // 0xec(0x0c)
	struct AActor* TargetActor; // 0xf8(0x08)
	struct FVector TargetLocationOffset; // 0x100(0x0c)
	enum class ERootMotionMoveToActorTargetOffsetType OffsetAlignment; // 0x10c(0x01)
	char pad_10D[0x3]; // 0x10d(0x03)
	float Duration; // 0x110(0x04)
	bool bDisableDestinationReachedInterrupt; // 0x114(0x01)
	bool bSetNewMovementMode; // 0x115(0x01)
	enum class EMovementMode NewMovementMode; // 0x116(0x01)
	bool bRestrictSpeedToExpected; // 0x117(0x01)
	struct UCurveVector* PathOffsetCurve; // 0x118(0x08)
	struct UCurveFloat* TimeMappingCurve; // 0x120(0x08)
	struct UCurveFloat* TargetLerpSpeedHorizontalCurve; // 0x128(0x08)
	struct UCurveFloat* TargetLerpSpeedVerticalCurve; // 0x130(0x08)
	char pad_138[0x8]; // 0x138(0x08)

	void OnTargetActorSwapped(struct AActor* OriginalTarget, struct AActor* NewTarget); // Function GameplayAbilities.AbilityTask_ApplyRootMotionMoveToActorForce.OnTargetActorSwapped // Final|Native|Public // @ game+0x5e0ff64
	void OnRep_TargetLocation(); // Function GameplayAbilities.AbilityTask_ApplyRootMotionMoveToActorForce.OnRep_TargetLocation // Final|Native|Protected // @ game+0x5e0ff2c
	struct UAbilityTask_ApplyRootMotionMoveToActorForce* ApplyRootMotionMoveToTargetDataActorForce(struct UGameplayAbility* OwningAbility, struct FName TaskInstanceName, struct FGameplayAbilityTargetDataHandle TargetDataHandle, int32 TargetDataIndex, int32 TargetActorIndex, struct FVector TargetLocationOffset, enum class ERootMotionMoveToActorTargetOffsetType OffsetAlignment, float Duration, struct UCurveFloat* TargetLerpSpeedHorizontal, struct UCurveFloat* TargetLerpSpeedVertical, bool bSetNewMovementMode, enum class EMovementMode MovementMode, bool bRestrictSpeedToExpected, struct UCurveVector* PathOffsetCurve, struct UCurveFloat* TimeMappingCurve, enum class ERootMotionFinishVelocityMode VelocityOnFinishMode, struct FVector SetVelocityOnFinish, float ClampVelocityOnFinish, bool bDisableDestinationReachedInterrupt); // Function GameplayAbilities.AbilityTask_ApplyRootMotionMoveToActorForce.ApplyRootMotionMoveToTargetDataActorForce // Final|Native|Static|Public|HasDefaults|BlueprintCallable // @ game+0x5e07f48
	struct UAbilityTask_ApplyRootMotionMoveToActorForce* ApplyRootMotionMoveToActorForce(struct UGameplayAbility* OwningAbility, struct FName TaskInstanceName, struct AActor* TargetActor, struct FVector TargetLocationOffset, enum class ERootMotionMoveToActorTargetOffsetType OffsetAlignment, float Duration, struct UCurveFloat* TargetLerpSpeedHorizontal, struct UCurveFloat* TargetLerpSpeedVertical, bool bSetNewMovementMode, enum class EMovementMode MovementMode, bool bRestrictSpeedToExpected, struct UCurveVector* PathOffsetCurve, struct UCurveFloat* TimeMappingCurve, enum class ERootMotionFinishVelocityMode VelocityOnFinishMode, struct FVector SetVelocityOnFinish, float ClampVelocityOnFinish, bool bDisableDestinationReachedInterrupt); // Function GameplayAbilities.AbilityTask_ApplyRootMotionMoveToActorForce.ApplyRootMotionMoveToActorForce // Final|Native|Static|Public|HasDefaults|BlueprintCallable // @ game+0x5e075c8
};

// Class GameplayAbilities.AbilityTask_ApplyRootMotionMoveToForce
// Size: 0x118 (Inherited: 0xc8)
struct UAbilityTask_ApplyRootMotionMoveToForce : UAbilityTask_ApplyRootMotion_Base {
	struct FMulticastDelegate OnTimedOut; // 0xc8(0x10)
	struct FMulticastDelegate OnTimedOutAndDestinationReached; // 0xd8(0x10)
	struct FVector StartLocation; // 0xe8(0x0c)
	struct FVector TargetLocation; // 0xf4(0x0c)
	float Duration; // 0x100(0x04)
	bool bSetNewMovementMode; // 0x104(0x01)
	enum class EMovementMode NewMovementMode; // 0x105(0x01)
	bool bRestrictSpeedToExpected; // 0x106(0x01)
	char pad_107[0x1]; // 0x107(0x01)
	struct UCurveVector* PathOffsetCurve; // 0x108(0x08)
	char pad_110[0x8]; // 0x110(0x08)

	struct UAbilityTask_ApplyRootMotionMoveToForce* ApplyRootMotionMoveToForce(struct UGameplayAbility* OwningAbility, struct FName TaskInstanceName, struct FVector TargetLocation, float Duration, bool bSetNewMovementMode, enum class EMovementMode MovementMode, bool bRestrictSpeedToExpected, struct UCurveVector* PathOffsetCurve, enum class ERootMotionFinishVelocityMode VelocityOnFinishMode, struct FVector SetVelocityOnFinish, float ClampVelocityOnFinish); // Function GameplayAbilities.AbilityTask_ApplyRootMotionMoveToForce.ApplyRootMotionMoveToForce // Final|Native|Static|Public|HasDefaults|BlueprintCallable // @ game+0x5e07b7c
};

// Class GameplayAbilities.AbilityTask_ApplyRootMotionRadialForce
// Size: 0x120 (Inherited: 0xc8)
struct UAbilityTask_ApplyRootMotionRadialForce : UAbilityTask_ApplyRootMotion_Base {
	struct FMulticastDelegate OnFinish; // 0xc8(0x10)
	struct FVector Location; // 0xd8(0x0c)
	char pad_E4[0x4]; // 0xe4(0x04)
	struct AActor* LocationActor; // 0xe8(0x08)
	float Strength; // 0xf0(0x04)
	float Duration; // 0xf4(0x04)
	float Radius; // 0xf8(0x04)
	bool bIsPush; // 0xfc(0x01)
	bool bIsAdditive; // 0xfd(0x01)
	bool bNoZForce; // 0xfe(0x01)
	char pad_FF[0x1]; // 0xff(0x01)
	struct UCurveFloat* StrengthDistanceFalloff; // 0x100(0x08)
	struct UCurveFloat* StrengthOverTime; // 0x108(0x08)
	bool bUseFixedWorldDirection; // 0x110(0x01)
	char pad_111[0x3]; // 0x111(0x03)
	struct FRotator FixedWorldDirection; // 0x114(0x0c)

	struct UAbilityTask_ApplyRootMotionRadialForce* ApplyRootMotionRadialForce(struct UGameplayAbility* OwningAbility, struct FName TaskInstanceName, struct FVector Location, struct AActor* LocationActor, float Strength, float Duration, float Radius, bool bIsPush, bool bIsAdditive, bool bNoZForce, struct UCurveFloat* StrengthDistanceFalloff, struct UCurveFloat* StrengthOverTime, bool bUseFixedWorldDirection, struct FRotator FixedWorldDirection, enum class ERootMotionFinishVelocityMode VelocityOnFinishMode, struct FVector SetVelocityOnFinish, float ClampVelocityOnFinish); // Function GameplayAbilities.AbilityTask_ApplyRootMotionRadialForce.ApplyRootMotionRadialForce // Final|Native|Static|Public|HasDefaults|BlueprintCallable // @ game+0x5e08650
};

// Class GameplayAbilities.AbilityTask_MoveToLocation
// Size: 0xd8 (Inherited: 0x90)
struct UAbilityTask_MoveToLocation : UAbilityTask {
	struct FMulticastDelegate OnTargetLocationReached; // 0x90(0x10)
	char pad_A0[0x4]; // 0xa0(0x04)
	struct FVector StartLocation; // 0xa4(0x0c)
	struct FVector TargetLocation; // 0xb0(0x0c)
	float DurationOfMovement; // 0xbc(0x04)
	char pad_C0[0x8]; // 0xc0(0x08)
	struct UCurveFloat* LerpCurve; // 0xc8(0x08)
	struct UCurveVector* LerpCurveVector; // 0xd0(0x08)

	struct UAbilityTask_MoveToLocation* MoveToLocation(struct UGameplayAbility* OwningAbility, struct FName TaskInstanceName, struct FVector Location, float Duration, struct UCurveFloat* OptionalInterpolationCurve, struct UCurveVector* OptionalVectorInterpolationCurve); // Function GameplayAbilities.AbilityTask_MoveToLocation.MoveToLocation // Final|Native|Static|Public|HasDefaults|BlueprintCallable // @ game+0x5e0d8c8
};

// Class GameplayAbilities.AbilityTask_NetworkSyncPoint
// Size: 0xa8 (Inherited: 0x90)
struct UAbilityTask_NetworkSyncPoint : UAbilityTask {
	struct FMulticastDelegate OnSync; // 0x90(0x10)
	char pad_A0[0x8]; // 0xa0(0x08)

	struct UAbilityTask_NetworkSyncPoint* WaitNetSync(struct UGameplayAbility* OwningAbility, enum class EAbilityTaskNetSyncType SyncType); // Function GameplayAbilities.AbilityTask_NetworkSyncPoint.WaitNetSync // Final|Native|Static|Public|BlueprintCallable // @ game+0x5e1655c
	void OnSignalCallback(); // Function GameplayAbilities.AbilityTask_NetworkSyncPoint.OnSignalCallback // Final|Native|Public // @ game+0x5e0ff50
};

// Class GameplayAbilities.AbilityTask_PlayMontageAndWait
// Size: 0x180 (Inherited: 0x90)
struct UAbilityTask_PlayMontageAndWait : UAbilityTask {
	struct FMulticastDelegate OnCompleted; // 0x90(0x10)
	struct FMulticastDelegate OnBlendOut; // 0xa0(0x10)
	struct FMulticastDelegate OnInterrupted; // 0xb0(0x10)
	struct FMulticastDelegate OnCancelled; // 0xc0(0x10)
	char pad_D0[0x88]; // 0xd0(0x88)
	struct UAnimMontage* MontageToPlay; // 0x158(0x08)
	float Rate; // 0x160(0x04)
	char pad_164[0x4]; // 0x164(0x04)
	struct FName StartSection; // 0x168(0x08)
	float AnimRootMotionTranslationScale; // 0x170(0x04)
	float StartTimeSeconds; // 0x174(0x04)
	bool bStopWhenAbilityEnds; // 0x178(0x01)
	char pad_179[0x7]; // 0x179(0x07)

	void OnMontageInterrupted(); // Function GameplayAbilities.AbilityTask_PlayMontageAndWait.OnMontageInterrupted // Final|Native|Public // @ game+0x5e0fb34
	void OnMontageEnded(struct UAnimMontage* Montage, bool bInterrupted); // Function GameplayAbilities.AbilityTask_PlayMontageAndWait.OnMontageEnded // Final|Native|Public // @ game+0x5e0fa54
	void OnMontageBlendingOut(struct UAnimMontage* Montage, bool bInterrupted); // Function GameplayAbilities.AbilityTask_PlayMontageAndWait.OnMontageBlendingOut // Final|Native|Public // @ game+0x5e0f974
	struct UAbilityTask_PlayMontageAndWait* CreatePlayMontageAndWaitProxy(struct UGameplayAbility* OwningAbility, struct FName TaskInstanceName, struct UAnimMontage* MontageToPlay, float Rate, struct FName StartSection, bool bStopWhenAbilityEnds, float AnimRootMotionTranslationScale, float StartTimeSeconds); // Function GameplayAbilities.AbilityTask_PlayMontageAndWait.CreatePlayMontageAndWaitProxy // Final|Native|Static|Public|BlueprintCallable // @ game+0x5e0ab44
};

// Class GameplayAbilities.AbilityTask_Repeat
// Size: 0xc8 (Inherited: 0x90)
struct UAbilityTask_Repeat : UAbilityTask {
	struct FMulticastDelegate OnPerformAction; // 0x90(0x10)
	struct FMulticastDelegate OnFinished; // 0xa0(0x10)
	char pad_B0[0x18]; // 0xb0(0x18)

	struct UAbilityTask_Repeat* RepeatAction(struct UGameplayAbility* OwningAbility, float TimeBetweenActions, int32 TotalActionCount); // Function GameplayAbilities.AbilityTask_Repeat.RepeatAction // Final|Native|Static|Public|BlueprintCallable // @ game+0x5e10978
};

// Class GameplayAbilities.AbilityTask_SpawnActor
// Size: 0xd8 (Inherited: 0x90)
struct UAbilityTask_SpawnActor : UAbilityTask {
	struct FMulticastDelegate SUCCESS; // 0x90(0x10)
	struct FMulticastDelegate DidNotSpawn; // 0xa0(0x10)
	char pad_B0[0x28]; // 0xb0(0x28)

	struct UAbilityTask_SpawnActor* SpawnActor(struct UGameplayAbility* OwningAbility, struct FGameplayAbilityTargetDataHandle TargetData, struct UClass* Class); // Function GameplayAbilities.AbilityTask_SpawnActor.SpawnActor // Final|Native|Static|Public|BlueprintCallable // @ game+0x5e128b4
	void FinishSpawningActor(struct UGameplayAbility* OwningAbility, struct FGameplayAbilityTargetDataHandle TargetData, struct AActor* SpawnedActor); // Function GameplayAbilities.AbilityTask_SpawnActor.FinishSpawningActor // Final|Native|Public|BlueprintCallable // @ game+0x5e0b3b8
	bool BeginSpawningActor(struct UGameplayAbility* OwningAbility, struct FGameplayAbilityTargetDataHandle TargetData, struct UClass* Class, struct AActor* SpawnedActor); // Function GameplayAbilities.AbilityTask_SpawnActor.BeginSpawningActor // Final|Native|Public|HasOutParms|BlueprintCallable // @ game+0x5e099c0
};

// Class GameplayAbilities.AbilityTask_StartAbilityState
// Size: 0xc8 (Inherited: 0x90)
struct UAbilityTask_StartAbilityState : UAbilityTask {
	struct FMulticastDelegate OnStateEnded; // 0x90(0x10)
	struct FMulticastDelegate OnStateInterrupted; // 0xa0(0x10)
	char pad_B0[0x18]; // 0xb0(0x18)

	struct UAbilityTask_StartAbilityState* StartAbilityState(struct UGameplayAbility* OwningAbility, struct FName StateName, bool bEndCurrentState); // Function GameplayAbilities.AbilityTask_StartAbilityState.StartAbilityState // Final|Native|Static|Public|BlueprintCallable // @ game+0x5e12a8c
};

// Class GameplayAbilities.GameplayAbilityWorldReticle
// Size: 0x410 (Inherited: 0x3f0)
struct AGameplayAbilityWorldReticle : AActor {
	struct FWorldReticleParameters Parameters; // 0x3f0(0x0c)
	bool bFaceOwnerFlat; // 0x3fc(0x01)
	bool bSnapToTargetedActor; // 0x3fd(0x01)
	bool bIsTargetValid; // 0x3fe(0x01)
	bool bIsTargetAnActor; // 0x3ff(0x01)
	struct APlayerController* MasterPC; // 0x400(0x08)
	struct AActor* TargetingActor; // 0x408(0x08)

	void SetReticleMaterialParamVector(struct FName ParamName, struct FVector Value); // Function GameplayAbilities.GameplayAbilityWorldReticle.SetReticleMaterialParamVector // Event|Public|HasDefaults|BlueprintEvent // @ game+0x33e45c
	void SetReticleMaterialParamFloat(struct FName ParamName, float Value); // Function GameplayAbilities.GameplayAbilityWorldReticle.SetReticleMaterialParamFloat // Event|Public|BlueprintEvent // @ game+0x33e45c
	void OnValidTargetChanged(bool bNewValue); // Function GameplayAbilities.GameplayAbilityWorldReticle.OnValidTargetChanged // Event|Public|BlueprintEvent // @ game+0x33e45c
	void OnTargetingAnActor(bool bNewValue); // Function GameplayAbilities.GameplayAbilityWorldReticle.OnTargetingAnActor // Event|Public|BlueprintEvent // @ game+0x33e45c
	void OnParametersInitialized(); // Function GameplayAbilities.GameplayAbilityWorldReticle.OnParametersInitialized // Event|Public|BlueprintEvent // @ game+0x33e45c
	void FaceTowardSource(bool bFaceIn2D); // Function GameplayAbilities.GameplayAbilityWorldReticle.FaceTowardSource // Final|Native|Public|BlueprintCallable // @ game+0x5e0b310
};

// Class GameplayAbilities.GameplayAbilityTargetActor
// Size: 0x5c0 (Inherited: 0x3f0)
struct AGameplayAbilityTargetActor : AActor {
	bool ShouldProduceTargetDataOnServer; // 0x3f0(0x01)
	char pad_3F1[0xf]; // 0x3f1(0x0f)
	struct FGameplayAbilityTargetingLocationInfo StartLocation; // 0x400(0x70)
	char pad_470[0xe0]; // 0x470(0xe0)
	struct APlayerController* MasterPC; // 0x550(0x08)
	struct UGameplayAbility* OwningAbility; // 0x558(0x08)
	bool bDestroyOnConfirmation; // 0x560(0x01)
	char pad_561[0x7]; // 0x561(0x07)
	struct AActor* SourceActor; // 0x568(0x08)
	struct FWorldReticleParameters ReticleParams; // 0x570(0x0c)
	char pad_57C[0x4]; // 0x57c(0x04)
	struct UClass* ReticleClass; // 0x580(0x08)
	struct FGameplayTargetDataFilterHandle Filter; // 0x588(0x10)
	bool bDebug; // 0x598(0x01)
	char pad_599[0x17]; // 0x599(0x17)
	struct UAbilitySystemComponent* GenericDelegateBoundASC; // 0x5b0(0x08)
	char pad_5B8[0x8]; // 0x5b8(0x08)

	void ConfirmTargeting(); // Function GameplayAbilities.GameplayAbilityTargetActor.ConfirmTargeting // Native|Public // @ game+0x769f14
	void CancelTargeting(); // Function GameplayAbilities.GameplayAbilityTargetActor.CancelTargeting // Native|Public // @ game+0x4d679f8
};

// Class GameplayAbilities.AbilityTask_VisualizeTargeting
// Size: 0xb8 (Inherited: 0x90)
struct UAbilityTask_VisualizeTargeting : UAbilityTask {
	struct FMulticastDelegate TimeElapsed; // 0x90(0x10)
	char pad_A0[0x18]; // 0xa0(0x18)

	struct UAbilityTask_VisualizeTargeting* VisualizeTargetingUsingActor(struct UGameplayAbility* OwningAbility, struct AGameplayAbilityTargetActor* TargetActor, struct FName TaskInstanceName, float Duration); // Function GameplayAbilities.AbilityTask_VisualizeTargeting.VisualizeTargetingUsingActor // Final|Native|Static|Public|BlueprintCallable // @ game+0x5e1315c
	struct UAbilityTask_VisualizeTargeting* VisualizeTargeting(struct UGameplayAbility* OwningAbility, struct UClass* Class, struct FName TaskInstanceName, float Duration); // Function GameplayAbilities.AbilityTask_VisualizeTargeting.VisualizeTargeting // Final|Native|Static|Public|BlueprintCallable // @ game+0x5e12fec
	void FinishSpawningActor(struct UGameplayAbility* OwningAbility, struct AGameplayAbilityTargetActor* SpawnedActor); // Function GameplayAbilities.AbilityTask_VisualizeTargeting.FinishSpawningActor // Final|Native|Public|BlueprintCallable // @ game+0x5e0b590
	bool BeginSpawningActor(struct UGameplayAbility* OwningAbility, struct UClass* Class, struct AGameplayAbilityTargetActor* SpawnedActor); // Function GameplayAbilities.AbilityTask_VisualizeTargeting.BeginSpawningActor // Final|Native|Public|HasOutParms|BlueprintCallable // @ game+0x5e09bfc
};

// Class GameplayAbilities.AbilityTask_WaitAbilityActivate
// Size: 0x148 (Inherited: 0x90)
struct UAbilityTask_WaitAbilityActivate : UAbilityTask {
	struct FMulticastDelegate OnActivate; // 0x90(0x10)
	char pad_A0[0xa8]; // 0xa0(0xa8)

	struct UAbilityTask_WaitAbilityActivate* WaitForAbilityActivateWithTagRequirements(struct UGameplayAbility* OwningAbility, struct FGameplayTagRequirements TagRequirements, bool IncludeTriggeredAbilities, bool TriggerOnce); // Function GameplayAbilities.AbilityTask_WaitAbilityActivate.WaitForAbilityActivateWithTagRequirements // Final|Native|Static|Public|BlueprintCallable // @ game+0x5e13768
	struct UAbilityTask_WaitAbilityActivate* WaitForAbilityActivate_Query(struct UGameplayAbility* OwningAbility, struct FGameplayTagQuery Query, bool IncludeTriggeredAbilities, bool TriggerOnce); // Function GameplayAbilities.AbilityTask_WaitAbilityActivate.WaitForAbilityActivate_Query // Final|Native|Static|Public|BlueprintCallable // @ game+0x5e1396c
	struct UAbilityTask_WaitAbilityActivate* WaitForAbilityActivate(struct UGameplayAbility* OwningAbility, struct FGameplayTag WithTag, struct FGameplayTag WithoutTag, bool IncludeTriggeredAbilities, bool TriggerOnce); // Function GameplayAbilities.AbilityTask_WaitAbilityActivate.WaitForAbilityActivate // Final|Native|Static|Public|BlueprintCallable // @ game+0x5e13580
	void OnAbilityActivate(struct UGameplayAbility* ActivatedAbility); // Function GameplayAbilities.AbilityTask_WaitAbilityActivate.OnAbilityActivate // Final|Native|Public // @ game+0x5e0ebe8
};

// Class GameplayAbilities.AbilityTask_WaitAbilityCommit
// Size: 0x108 (Inherited: 0x90)
struct UAbilityTask_WaitAbilityCommit : UAbilityTask {
	struct FMulticastDelegate OnCommit; // 0x90(0x10)
	char pad_A0[0x68]; // 0xa0(0x68)

	struct UAbilityTask_WaitAbilityCommit* WaitForAbilityCommit_Query(struct UGameplayAbility* OwningAbility, struct FGameplayTagQuery Query, bool TriggerOnce); // Function GameplayAbilities.AbilityTask_WaitAbilityCommit.WaitForAbilityCommit_Query // Final|Native|Static|Public|BlueprintCallable // @ game+0x5e13d10
	struct UAbilityTask_WaitAbilityCommit* WaitForAbilityCommit(struct UGameplayAbility* OwningAbility, struct FGameplayTag WithTag, struct FGameplayTag WithoutTage, bool TriggerOnce); // Function GameplayAbilities.AbilityTask_WaitAbilityCommit.WaitForAbilityCommit // Final|Native|Static|Public|BlueprintCallable // @ game+0x5e13b7c
	void OnAbilityCommit(struct UGameplayAbility* ActivatedAbility); // Function GameplayAbilities.AbilityTask_WaitAbilityCommit.OnAbilityCommit // Final|Native|Public // @ game+0x5e0ec78
};

// Class GameplayAbilities.AbilityTask_WaitAttributeChange
// Size: 0xf0 (Inherited: 0x90)
struct UAbilityTask_WaitAttributeChange : UAbilityTask {
	struct FMulticastDelegate OnChange; // 0x90(0x10)
	char pad_A0[0x48]; // 0xa0(0x48)
	struct UAbilitySystemComponent* ExternalOwner; // 0xe8(0x08)

	struct UAbilityTask_WaitAttributeChange* WaitForAttributeChangeWithComparison(struct UGameplayAbility* OwningAbility, struct FGameplayAttribute InAttribute, struct FGameplayTag InWithTag, struct FGameplayTag InWithoutTag, enum class EWaitAttributeChangeComparison InComparisonType, float InComparisonValue, bool TriggerOnce, struct AActor* OptionalExternalOwner); // Function GameplayAbilities.AbilityTask_WaitAttributeChange.WaitForAttributeChangeWithComparison // Final|Native|Static|Public|BlueprintCallable // @ game+0x5e146d0
	struct UAbilityTask_WaitAttributeChange* WaitForAttributeChange(struct UGameplayAbility* OwningAbility, struct FGameplayAttribute Attribute, struct FGameplayTag WithSrcTag, struct FGameplayTag WithoutSrcTag, bool TriggerOnce, struct AActor* OptionalExternalOwner); // Function GameplayAbilities.AbilityTask_WaitAttributeChange.WaitForAttributeChange // Final|Native|Static|Public|BlueprintCallable // @ game+0x5e13ecc
};

// Class GameplayAbilities.AbilityTask_WaitAttributeChangeRatioThreshold
// Size: 0x120 (Inherited: 0x90)
struct UAbilityTask_WaitAttributeChangeRatioThreshold : UAbilityTask {
	struct FMulticastDelegate OnChange; // 0x90(0x10)
	char pad_A0[0x78]; // 0xa0(0x78)
	struct UAbilitySystemComponent* ExternalOwner; // 0x118(0x08)

	struct UAbilityTask_WaitAttributeChangeRatioThreshold* WaitForAttributeChangeRatioThreshold(struct UGameplayAbility* OwningAbility, struct FGameplayAttribute AttributeNumerator, struct FGameplayAttribute AttributeDenominator, enum class EWaitAttributeChangeComparison ComparisonType, float ComparisonValue, bool bTriggerOnce, struct AActor* OptionalExternalOwner); // Function GameplayAbilities.AbilityTask_WaitAttributeChangeRatioThreshold.WaitForAttributeChangeRatioThreshold // Final|Native|Static|Public|BlueprintCallable // @ game+0x5e1413c
};

// Class GameplayAbilities.AbilityTask_WaitAttributeChangeThreshold
// Size: 0xe8 (Inherited: 0x90)
struct UAbilityTask_WaitAttributeChangeThreshold : UAbilityTask {
	struct FMulticastDelegate OnChange; // 0x90(0x10)
	char pad_A0[0x40]; // 0xa0(0x40)
	struct UAbilitySystemComponent* ExternalOwner; // 0xe0(0x08)

	struct UAbilityTask_WaitAttributeChangeThreshold* WaitForAttributeChangeThreshold(struct UGameplayAbility* OwningAbility, struct FGameplayAttribute Attribute, enum class EWaitAttributeChangeComparison ComparisonType, float ComparisonValue, bool bTriggerOnce, struct AActor* OptionalExternalOwner); // Function GameplayAbilities.AbilityTask_WaitAttributeChangeThreshold.WaitForAttributeChangeThreshold // Final|Native|Static|Public|BlueprintCallable // @ game+0x5e14460
};

// Class GameplayAbilities.AbilityTask_WaitCancel
// Size: 0xa8 (Inherited: 0x90)
struct UAbilityTask_WaitCancel : UAbilityTask {
	struct FMulticastDelegate OnCancel; // 0x90(0x10)
	char pad_A0[0x8]; // 0xa0(0x08)

	struct UAbilityTask_WaitCancel* WaitCancel(struct UGameplayAbility* OwningAbility); // Function GameplayAbilities.AbilityTask_WaitCancel.WaitCancel // Final|Native|Static|Public|BlueprintCallable // @ game+0x5e132cc
	void OnLocalCancelCallback(); // Function GameplayAbilities.AbilityTask_WaitCancel.OnLocalCancelCallback // Final|Native|Public // @ game+0x5e0f938
	void OnCancelCallback(); // Function GameplayAbilities.AbilityTask_WaitCancel.OnCancelCallback // Final|Native|Public // @ game+0x5e0f108
};

// Class GameplayAbilities.AbilityTask_WaitConfirm
// Size: 0xb0 (Inherited: 0x90)
struct UAbilityTask_WaitConfirm : UAbilityTask {
	struct FMulticastDelegate OnConfirm; // 0x90(0x10)
	char pad_A0[0x10]; // 0xa0(0x10)

	struct UAbilityTask_WaitConfirm* WaitConfirm(struct UGameplayAbility* OwningAbility); // Function GameplayAbilities.AbilityTask_WaitConfirm.WaitConfirm // Final|Native|Static|Public|BlueprintCallable // @ game+0x5e13360
	void OnConfirmCallback(struct UGameplayAbility* InAbility); // Function GameplayAbilities.AbilityTask_WaitConfirm.OnConfirmCallback // Final|Native|Public // @ game+0x5e0f130
};

// Class GameplayAbilities.AbilityTask_WaitConfirmCancel
// Size: 0xb8 (Inherited: 0x90)
struct UAbilityTask_WaitConfirmCancel : UAbilityTask {
	struct FMulticastDelegate OnConfirm; // 0x90(0x10)
	struct FMulticastDelegate OnCancel; // 0xa0(0x10)
	char pad_B0[0x8]; // 0xb0(0x08)

	struct UAbilityTask_WaitConfirmCancel* WaitConfirmCancel(struct UGameplayAbility* OwningAbility); // Function GameplayAbilities.AbilityTask_WaitConfirmCancel.WaitConfirmCancel // Final|Native|Static|Public|BlueprintCallable // @ game+0x5e133f4
	void OnLocalConfirmCallback(); // Function GameplayAbilities.AbilityTask_WaitConfirmCancel.OnLocalConfirmCallback // Final|Native|Public // @ game+0x5e0f960
	void OnLocalCancelCallback(); // Function GameplayAbilities.AbilityTask_WaitConfirmCancel.OnLocalCancelCallback // Final|Native|Public // @ game+0x5e0f94c
	void OnConfirmCallback(); // Function GameplayAbilities.AbilityTask_WaitConfirmCancel.OnConfirmCallback // Final|Native|Public // @ game+0x5e0f1c0
	void OnCancelCallback(); // Function GameplayAbilities.AbilityTask_WaitConfirmCancel.OnCancelCallback // Final|Native|Public // @ game+0x5e0f11c
};

// Class GameplayAbilities.AbilityTask_WaitDelay
// Size: 0xa8 (Inherited: 0x90)
struct UAbilityTask_WaitDelay : UAbilityTask {
	struct FMulticastDelegate OnFinish; // 0x90(0x10)
	char pad_A0[0x8]; // 0xa0(0x08)

	struct UAbilityTask_WaitDelay* WaitDelay(struct UGameplayAbility* OwningAbility, float Time); // Function GameplayAbilities.AbilityTask_WaitDelay.WaitDelay // Final|Native|Static|Public|BlueprintCallable // @ game+0x5e13488
};

// Class GameplayAbilities.AbilityTask_WaitGameplayEffectApplied
// Size: 0x1c8 (Inherited: 0x90)
struct UAbilityTask_WaitGameplayEffectApplied : UAbilityTask {
	char pad_90[0x128]; // 0x90(0x128)
	struct UAbilitySystemComponent* ExternalOwner; // 0x1b8(0x08)
	char pad_1C0[0x8]; // 0x1c0(0x08)

	void OnApplyGameplayEffectCallback(struct UAbilitySystemComponent* Target, struct FGameplayEffectSpec SpecApplied, struct FActiveGameplayEffectHandle ActiveHandle); // Function GameplayAbilities.AbilityTask_WaitGameplayEffectApplied.OnApplyGameplayEffectCallback // Final|Native|Public|HasOutParms // @ game+0x5e0ef68
};

// Class GameplayAbilities.AbilityTask_WaitGameplayEffectApplied_Self
// Size: 0x1e8 (Inherited: 0x1c8)
struct UAbilityTask_WaitGameplayEffectApplied_Self : UAbilityTask_WaitGameplayEffectApplied {
	struct FMulticastDelegate OnApplied; // 0x1c8(0x10)
	char pad_1D8[0x10]; // 0x1d8(0x10)

	struct UAbilityTask_WaitGameplayEffectApplied_Self* WaitGameplayEffectAppliedToSelf_Query(struct UGameplayAbility* OwningAbility, struct FGameplayTargetDataFilterHandle SourceFilter, struct FGameplayTagQuery SourceTagQuery, struct FGameplayTagQuery TargetTagQuery, bool TriggerOnce, struct AActor* OptionalExternalOwner, bool ListenForPeriodicEffect); // Function GameplayAbilities.AbilityTask_WaitGameplayEffectApplied_Self.WaitGameplayEffectAppliedToSelf_Query // Final|Native|Static|Public|BlueprintCallable // @ game+0x5e15068
	struct UAbilityTask_WaitGameplayEffectApplied_Self* WaitGameplayEffectAppliedToSelf(struct UGameplayAbility* OwningAbility, struct FGameplayTargetDataFilterHandle SourceFilter, struct FGameplayTagRequirements SourceTagRequirements, struct FGameplayTagRequirements TargetTagRequirements, bool TriggerOnce, struct AActor* OptionalExternalOwner, bool ListenForPeriodicEffect); // Function GameplayAbilities.AbilityTask_WaitGameplayEffectApplied_Self.WaitGameplayEffectAppliedToSelf // Final|Native|Static|Public|BlueprintCallable // @ game+0x5e14c64
};

// Class GameplayAbilities.AbilityTask_WaitGameplayEffectApplied_Target
// Size: 0x1e8 (Inherited: 0x1c8)
struct UAbilityTask_WaitGameplayEffectApplied_Target : UAbilityTask_WaitGameplayEffectApplied {
	struct FMulticastDelegate OnApplied; // 0x1c8(0x10)
	char pad_1D8[0x10]; // 0x1d8(0x10)

	struct UAbilityTask_WaitGameplayEffectApplied_Target* WaitGameplayEffectAppliedToTarget_Query(struct UGameplayAbility* OwningAbility, struct FGameplayTargetDataFilterHandle SourceFilter, struct FGameplayTagQuery SourceTagQuery, struct FGameplayTagQuery TargetTagQuery, bool TriggerOnce, struct AActor* OptionalExternalOwner, bool ListenForPeriodicEffect); // Function GameplayAbilities.AbilityTask_WaitGameplayEffectApplied_Target.WaitGameplayEffectAppliedToTarget_Query // Final|Native|Static|Public|BlueprintCallable // @ game+0x5e15818
	struct UAbilityTask_WaitGameplayEffectApplied_Target* WaitGameplayEffectAppliedToTarget(struct UGameplayAbility* OwningAbility, struct FGameplayTargetDataFilterHandle TargetFilter, struct FGameplayTagRequirements SourceTagRequirements, struct FGameplayTagRequirements TargetTagRequirements, bool TriggerOnce, struct AActor* OptionalExternalOwner, bool ListenForPeriodicEffects); // Function GameplayAbilities.AbilityTask_WaitGameplayEffectApplied_Target.WaitGameplayEffectAppliedToTarget // Final|Native|Static|Public|BlueprintCallable // @ game+0x5e15414
};

// Class GameplayAbilities.AbilityTask_WaitGameplayEffectBlockedImmunity
// Size: 0x138 (Inherited: 0x90)
struct UAbilityTask_WaitGameplayEffectBlockedImmunity : UAbilityTask {
	struct FMulticastDelegate bLocked; // 0x90(0x10)
	char pad_A0[0x88]; // 0xa0(0x88)
	struct UAbilitySystemComponent* ExternalOwner; // 0x128(0x08)
	char pad_130[0x8]; // 0x130(0x08)

	struct UAbilityTask_WaitGameplayEffectBlockedImmunity* WaitGameplayEffectBlockedByImmunity(struct UGameplayAbility* OwningAbility, struct FGameplayTagRequirements SourceTagRequirements, struct FGameplayTagRequirements TargetTagRequirements, struct AActor* OptionalExternalTarget, bool OnlyTriggerOnce); // Function GameplayAbilities.AbilityTask_WaitGameplayEffectBlockedImmunity.WaitGameplayEffectBlockedByImmunity // Final|Native|Static|Public|BlueprintCallable // @ game+0x5e15bc4
};

// Class GameplayAbilities.AbilityTask_WaitGameplayEffectRemoved
// Size: 0xd0 (Inherited: 0x90)
struct UAbilityTask_WaitGameplayEffectRemoved : UAbilityTask {
	struct FMulticastDelegate OnRemoved; // 0x90(0x10)
	struct FMulticastDelegate InvalidHandle; // 0xa0(0x10)
	char pad_B0[0x20]; // 0xb0(0x20)

	struct UAbilityTask_WaitGameplayEffectRemoved* WaitForGameplayEffectRemoved(struct UGameplayAbility* OwningAbility, struct FActiveGameplayEffectHandle Handle); // Function GameplayAbilities.AbilityTask_WaitGameplayEffectRemoved.WaitForGameplayEffectRemoved // Final|Native|Static|Public|BlueprintCallable // @ game+0x5e149f0
	void OnGameplayEffectRemoved(struct FGameplayEffectRemovalInfo InGameplayEffectRemovalInfo); // Function GameplayAbilities.AbilityTask_WaitGameplayEffectRemoved.OnGameplayEffectRemoved // Final|Native|Public|HasOutParms // @ game+0x5e0f434
};

// Class GameplayAbilities.AbilityTask_WaitGameplayEffectStackChange
// Size: 0xc8 (Inherited: 0x90)
struct UAbilityTask_WaitGameplayEffectStackChange : UAbilityTask {
	struct FMulticastDelegate OnChange; // 0x90(0x10)
	struct FMulticastDelegate InvalidHandle; // 0xa0(0x10)
	char pad_B0[0x18]; // 0xb0(0x18)

	struct UAbilityTask_WaitGameplayEffectStackChange* WaitForGameplayEffectStackChange(struct UGameplayAbility* OwningAbility, struct FActiveGameplayEffectHandle Handle); // Function GameplayAbilities.AbilityTask_WaitGameplayEffectStackChange.WaitForGameplayEffectStackChange // Final|Native|Static|Public|BlueprintCallable // @ game+0x5e14ae0
	void OnGameplayEffectStackChange(struct FActiveGameplayEffectHandle Handle, int32 NewCount, int32 OldCount); // Function GameplayAbilities.AbilityTask_WaitGameplayEffectStackChange.OnGameplayEffectStackChange // Final|Native|Public // @ game+0x5e0f534
};

// Class GameplayAbilities.AbilityTask_WaitGameplayEvent
// Size: 0xc0 (Inherited: 0x90)
struct UAbilityTask_WaitGameplayEvent : UAbilityTask {
	struct FMulticastDelegate EventReceived; // 0x90(0x10)
	char pad_A0[0x8]; // 0xa0(0x08)
	struct UAbilitySystemComponent* OptionalExternalTarget; // 0xa8(0x08)
	char pad_B0[0x10]; // 0xb0(0x10)

	struct UAbilityTask_WaitGameplayEvent* WaitGameplayEvent(struct UGameplayAbility* OwningAbility, struct FGameplayTag EventTag, struct AActor* OptionalExternalTarget, bool OnlyTriggerOnce, bool OnlyMatchExact); // Function GameplayAbilities.AbilityTask_WaitGameplayEvent.WaitGameplayEvent // Final|Native|Static|Public|BlueprintCallable // @ game+0x5e15e54
};

// Class GameplayAbilities.AbilityTask_WaitGameplayTag
// Size: 0xb8 (Inherited: 0x90)
struct UAbilityTask_WaitGameplayTag : UAbilityTask {
	char pad_90[0x10]; // 0x90(0x10)
	struct UAbilitySystemComponent* OptionalExternalTarget; // 0xa0(0x08)
	char pad_A8[0x10]; // 0xa8(0x10)

	void GameplayTagCallback(struct FGameplayTag Tag, int32 NewCount); // Function GameplayAbilities.AbilityTask_WaitGameplayTag.GameplayTagCallback // Native|Public // @ game+0x5e0b740
};

// Class GameplayAbilities.AbilityTask_WaitGameplayTagAdded
// Size: 0xc8 (Inherited: 0xb8)
struct UAbilityTask_WaitGameplayTagAdded : UAbilityTask_WaitGameplayTag {
	struct FMulticastDelegate Added; // 0xb8(0x10)

	struct UAbilityTask_WaitGameplayTagAdded* WaitGameplayTagAdd(struct UGameplayAbility* OwningAbility, struct FGameplayTag Tag, struct AActor* InOptionalExternalTarget, bool OnlyTriggerOnce); // Function GameplayAbilities.AbilityTask_WaitGameplayTagAdded.WaitGameplayTagAdd // Final|Native|Static|Public|BlueprintCallable // @ game+0x5e1605c
};

// Class GameplayAbilities.AbilityTask_WaitGameplayTagRemoved
// Size: 0xc8 (Inherited: 0xb8)
struct UAbilityTask_WaitGameplayTagRemoved : UAbilityTask_WaitGameplayTag {
	struct FMulticastDelegate Removed; // 0xb8(0x10)

	struct UAbilityTask_WaitGameplayTagRemoved* WaitGameplayTagRemove(struct UGameplayAbility* OwningAbility, struct FGameplayTag Tag, struct AActor* InOptionalExternalTarget, bool OnlyTriggerOnce); // Function GameplayAbilities.AbilityTask_WaitGameplayTagRemoved.WaitGameplayTagRemove // Final|Native|Static|Public|BlueprintCallable // @ game+0x5e161f4
};

// Class GameplayAbilities.AbilityTask_WaitInputPress
// Size: 0xb0 (Inherited: 0x90)
struct UAbilityTask_WaitInputPress : UAbilityTask {
	struct FMulticastDelegate OnPress; // 0x90(0x10)
	char pad_A0[0x10]; // 0xa0(0x10)

	struct UAbilityTask_WaitInputPress* WaitInputPress(struct UGameplayAbility* OwningAbility, bool bTestAlreadyPressed); // Function GameplayAbilities.AbilityTask_WaitInputPress.WaitInputPress // Final|Native|Static|Public|BlueprintCallable // @ game+0x5e1638c
	void OnPressCallback(); // Function GameplayAbilities.AbilityTask_WaitInputPress.OnPressCallback // Final|Native|Public // @ game+0x5e0fc78
};

// Class GameplayAbilities.AbilityTask_WaitInputRelease
// Size: 0xb0 (Inherited: 0x90)
struct UAbilityTask_WaitInputRelease : UAbilityTask {
	struct FMulticastDelegate OnRelease; // 0x90(0x10)
	char pad_A0[0x10]; // 0xa0(0x10)

	struct UAbilityTask_WaitInputRelease* WaitInputRelease(struct UGameplayAbility* OwningAbility, bool bTestAlreadyReleased); // Function GameplayAbilities.AbilityTask_WaitInputRelease.WaitInputRelease // Final|Native|Static|Public|BlueprintCallable // @ game+0x5e16474
	void OnReleaseCallback(); // Function GameplayAbilities.AbilityTask_WaitInputRelease.OnReleaseCallback // Final|Native|Public // @ game+0x5e0fc8c
};

// Class GameplayAbilities.AbilityTask_WaitMovementModeChange
// Size: 0xb0 (Inherited: 0x90)
struct UAbilityTask_WaitMovementModeChange : UAbilityTask {
	struct FMulticastDelegate OnChange; // 0x90(0x10)
	char pad_A0[0x10]; // 0xa0(0x10)

	void OnMovementModeChange(struct ACharacter* Character, enum class EMovementMode PrevMovementMode, bool PreviousCustomMode); // Function GameplayAbilities.AbilityTask_WaitMovementModeChange.OnMovementModeChange // Final|Native|Public // @ game+0x5e0fb48
	struct UAbilityTask_WaitMovementModeChange* CreateWaitMovementModeChange(struct UGameplayAbility* OwningAbility, enum class EMovementMode NewMode); // Function GameplayAbilities.AbilityTask_WaitMovementModeChange.CreateWaitMovementModeChange // Final|Native|Static|Public|BlueprintCallable // @ game+0x5e0ae04
};

// Class GameplayAbilities.AbilityTask_WaitOverlap
// Size: 0xa0 (Inherited: 0x90)
struct UAbilityTask_WaitOverlap : UAbilityTask {
	struct FMulticastDelegate OnOverlap; // 0x90(0x10)

	struct UAbilityTask_WaitOverlap* WaitForOverlap(struct UGameplayAbility* OwningAbility); // Function GameplayAbilities.AbilityTask_WaitOverlap.WaitForOverlap // Final|Native|Static|Public|BlueprintCallable // @ game+0x5e14bd0
	void OnHitCallback(struct UPrimitiveComponent* HitComp, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, struct FVector NormalImpulse, struct FHitResult Hit); // Function GameplayAbilities.AbilityTask_WaitOverlap.OnHitCallback // Final|Native|Public|HasOutParms|HasDefaults // @ game+0x5e0f664
};

// Class GameplayAbilities.AbilityTask_WaitTargetData
// Size: 0xd0 (Inherited: 0x90)
struct UAbilityTask_WaitTargetData : UAbilityTask {
	struct FMulticastDelegate ValidData; // 0x90(0x10)
	struct FMulticastDelegate Cancelled; // 0xa0(0x10)
	struct UClass* TargetClass; // 0xb0(0x08)
	struct AGameplayAbilityTargetActor* TargetActor; // 0xb8(0x08)
	char pad_C0[0x10]; // 0xc0(0x10)

	struct UAbilityTask_WaitTargetData* WaitTargetDataUsingActor(struct UGameplayAbility* OwningAbility, struct FName TaskInstanceName, enum class EGameplayTargetingConfirmation ConfirmationType, struct AGameplayAbilityTargetActor* TargetActor); // Function GameplayAbilities.AbilityTask_WaitTargetData.WaitTargetDataUsingActor // Final|Native|Static|Public|BlueprintCallable // @ game+0x5e167c4
	struct UAbilityTask_WaitTargetData* WaitTargetData(struct UGameplayAbility* OwningAbility, struct FName TaskInstanceName, enum class EGameplayTargetingConfirmation ConfirmationType, struct UClass* Class); // Function GameplayAbilities.AbilityTask_WaitTargetData.WaitTargetData // Final|Native|Static|Public|BlueprintCallable // @ game+0x5e16640
	void OnTargetDataReplicatedCancelledCallback(); // Function GameplayAbilities.AbilityTask_WaitTargetData.OnTargetDataReplicatedCancelledCallback // Final|Native|Public // @ game+0x5e10458
	void OnTargetDataReplicatedCallback(struct FGameplayAbilityTargetDataHandle Data, struct FGameplayTag ActivationTag); // Function GameplayAbilities.AbilityTask_WaitTargetData.OnTargetDataReplicatedCallback // Final|Native|Public|HasOutParms // @ game+0x5e102cc
	void OnTargetDataReadyCallback(struct FGameplayAbilityTargetDataHandle Data); // Function GameplayAbilities.AbilityTask_WaitTargetData.OnTargetDataReadyCallback // Final|Native|Public|HasOutParms // @ game+0x5e10190
	void OnTargetDataCancelledCallback(struct FGameplayAbilityTargetDataHandle Data); // Function GameplayAbilities.AbilityTask_WaitTargetData.OnTargetDataCancelledCallback // Final|Native|Public|HasOutParms // @ game+0x5e10054
	void FinishSpawningActor(struct UGameplayAbility* OwningAbility, struct AGameplayAbilityTargetActor* SpawnedActor); // Function GameplayAbilities.AbilityTask_WaitTargetData.FinishSpawningActor // Final|Native|Public|BlueprintCallable // @ game+0x5e0b668
	bool BeginSpawningActor(struct UGameplayAbility* OwningAbility, struct UClass* Class, struct AGameplayAbilityTargetActor* SpawnedActor); // Function GameplayAbilities.AbilityTask_WaitTargetData.BeginSpawningActor // Final|Native|Public|HasOutParms|BlueprintCallable // @ game+0x5e09d38
};

// Class GameplayAbilities.AbilityTask_WaitVelocityChange
// Size: 0xb8 (Inherited: 0x90)
struct UAbilityTask_WaitVelocityChange : UAbilityTask {
	struct FMulticastDelegate OnVelocityChage; // 0x90(0x10)
	struct UMovementComponent* CachedMovementComponent; // 0xa0(0x08)
	char pad_A8[0x10]; // 0xa8(0x10)

	struct UAbilityTask_WaitVelocityChange* CreateWaitVelocityChange(struct UGameplayAbility* OwningAbility, struct FVector Direction, float MinimumMagnitude); // Function GameplayAbilities.AbilityTask_WaitVelocityChange.CreateWaitVelocityChange // Final|Native|Static|Public|HasDefaults|BlueprintCallable // @ game+0x5e0aeec
};

// Class GameplayAbilities.AbilitySystemTestAttributeSet
// Size: 0x80 (Inherited: 0x40)
struct UAbilitySystemTestAttributeSet : UAttributeSet {
	float MaxHealth; // 0x40(0x04)
	float Health; // 0x44(0x04)
	float Mana; // 0x48(0x04)
	float MaxMana; // 0x4c(0x04)
	float Damage; // 0x50(0x04)
	float SpellDamage; // 0x54(0x04)
	float PhysicalDamage; // 0x58(0x04)
	float CritChance; // 0x5c(0x04)
	float CritMultiplier; // 0x60(0x04)
	float ArmorDamageReduction; // 0x64(0x04)
	float DodgeChance; // 0x68(0x04)
	float LifeSteal; // 0x6c(0x04)
	float Strength; // 0x70(0x04)
	float StackingAttribute1; // 0x74(0x04)
	float StackingAttribute2; // 0x78(0x04)
	float NoStackAttribute; // 0x7c(0x04)
};

// Class GameplayAbilities.GameplayAbility_CharacterJump
// Size: 0x580 (Inherited: 0x580)
struct UGameplayAbility_CharacterJump : UGameplayAbility {
};

// Class GameplayAbilities.GameplayAbility_Montage
// Size: 0x5c0 (Inherited: 0x580)
struct UGameplayAbility_Montage : UGameplayAbility {
	struct UAnimMontage* MontageToPlay; // 0x580(0x08)
	float PlayRate; // 0x588(0x04)
	char pad_58C[0x4]; // 0x58c(0x04)
	struct FName SectionName; // 0x590(0x08)
	struct TArray<struct UClass*> GameplayEffectClassesWhileAnimating; // 0x598(0x10)
	struct TArray<struct UGameplayEffect*> GameplayEffectsWhileAnimating; // 0x5a8(0x10)
	char pad_5B8[0x8]; // 0x5b8(0x08)
};

// Class GameplayAbilities.GameplayAbilityBlueprint
// Size: 0x1b0 (Inherited: 0x1b0)
struct UGameplayAbilityBlueprint : UBlueprint {
};

// Class GameplayAbilities.GameplayAbilitySet
// Size: 0x50 (Inherited: 0x40)
struct UGameplayAbilitySet : UDataAsset {
	struct TArray<struct FGameplayAbilityBindInfo> Abilities; // 0x40(0x10)
};

// Class GameplayAbilities.GameplayAbilityTargetActor_Radius
// Size: 0x5c0 (Inherited: 0x5c0)
struct AGameplayAbilityTargetActor_Radius : AGameplayAbilityTargetActor {
	float Radius; // 0x5b8(0x04)
};

// Class GameplayAbilities.GameplayAbilityTargetActor_Trace
// Size: 0x5e0 (Inherited: 0x5c0)
struct AGameplayAbilityTargetActor_Trace : AGameplayAbilityTargetActor {
	float MaxRange; // 0x5b8(0x04)
	struct FCollisionProfileName TraceProfile; // 0x5c0(0x08)
	bool bTraceAffectsAimPitch; // 0x5c8(0x01)
	char pad_5CD[0x13]; // 0x5cd(0x13)
};

// Class GameplayAbilities.GameplayAbilityTargetActor_GroundTrace
// Size: 0x600 (Inherited: 0x5e0)
struct AGameplayAbilityTargetActor_GroundTrace : AGameplayAbilityTargetActor_Trace {
	float CollisionRadius; // 0x5d8(0x04)
	float CollisionHeight; // 0x5dc(0x04)
	char pad_5E8[0x18]; // 0x5e8(0x18)
};

// Class GameplayAbilities.GameplayAbilityTargetActor_ActorPlacement
// Size: 0x610 (Inherited: 0x600)
struct AGameplayAbilityTargetActor_ActorPlacement : AGameplayAbilityTargetActor_GroundTrace {
	struct UClass* PlacedActorClass; // 0x5f8(0x08)
	struct UMaterialInterface* PlacedActorMaterial; // 0x600(0x08)
};

// Class GameplayAbilities.GameplayAbilityTargetActor_SingleLineTrace
// Size: 0x5e0 (Inherited: 0x5e0)
struct AGameplayAbilityTargetActor_SingleLineTrace : AGameplayAbilityTargetActor_Trace {
};

// Class GameplayAbilities.GameplayAbilityWorldReticle_ActorVisualization
// Size: 0x428 (Inherited: 0x410)
struct AGameplayAbilityWorldReticle_ActorVisualization : AGameplayAbilityWorldReticle {
	struct UCapsuleComponent* CollisionComponent; // 0x410(0x08)
	struct TArray<struct UActorComponent*> VisualizationComponents; // 0x418(0x10)
};

// Class GameplayAbilities.GameplayCueTranslator
// Size: 0x38 (Inherited: 0x38)
struct UGameplayCueTranslator : UObject {
};

// Class GameplayAbilities.GameplayCueTranslator_Test
// Size: 0x38 (Inherited: 0x38)
struct UGameplayCueTranslator_Test : UGameplayCueTranslator {
};

// Class GameplayAbilities.GameplayCueManager
// Size: 0x470 (Inherited: 0x40)
struct UGameplayCueManager : UDataAsset {
	char pad_40[0x70]; // 0x40(0x70)
	struct FGameplayCueObjectLibrary RuntimeGameplayCueObjectLibrary; // 0xb0(0xb0)
	struct FGameplayCueObjectLibrary EditorGameplayCueObjectLibrary; // 0x160(0xb0)
	char pad_210[0x1a0]; // 0x210(0x1a0)
	struct TArray<struct UClass*> LoadedGameplayCueNotifyClasses; // 0x3b0(0x10)
	struct TArray<struct UClass*> GameplayCueClassesForPreallocation; // 0x3c0(0x10)
	struct TArray<struct FGameplayCuePendingExecute> PendingExecuteCues; // 0x3d0(0x10)
	int32 GameplayCueSendContextCount; // 0x3e0(0x04)
	char pad_3E4[0x4]; // 0x3e4(0x04)
	struct TArray<struct FPreallocationInfo> PreallocationInfoList_Internal; // 0x3e8(0x10)
	char pad_3F8[0x78]; // 0x3f8(0x78)
};

// Class GameplayAbilities.GameplayCueNotify_Actor
// Size: 0x450 (Inherited: 0x3f0)
struct AGameplayCueNotify_Actor : AActor {
	bool bAutoDestroyOnRemove; // 0x3f0(0x01)
	char pad_3F1[0x3]; // 0x3f1(0x03)
	float AutoDestroyDelay; // 0x3f4(0x04)
	bool WarnIfTimelineIsStillRunning; // 0x3f8(0x01)
	bool WarnIfLatentActionIsStillRunning; // 0x3f9(0x01)
	char pad_3FA[0x6]; // 0x3fa(0x06)
	struct FGameplayTag GameplayCueTag; // 0x400(0x08)
	struct FName GameplayCueName; // 0x408(0x08)
	bool bAutoAttachToOwner; // 0x410(0x01)
	bool IsOverride; // 0x411(0x01)
	bool bUniqueInstancePerInstigator; // 0x412(0x01)
	bool bUniqueInstancePerSourceObject; // 0x413(0x01)
	bool bAllowMultipleOnActiveEvents; // 0x414(0x01)
	bool bAllowMultipleWhileActiveEvents; // 0x415(0x01)
	char pad_416[0x2]; // 0x416(0x02)
	int32 NumPreallocatedInstances; // 0x418(0x04)
	char pad_41C[0x34]; // 0x41c(0x34)

	bool WhileActive(struct AActor* MyTarget, struct FGameplayCueParameters Parameters); // Function GameplayAbilities.GameplayCueNotify_Actor.WhileActive // Native|Event|Public|HasOutParms|BlueprintEvent // @ game+0x5e16948
	bool OnRemove(struct AActor* MyTarget, struct FGameplayCueParameters Parameters); // Function GameplayAbilities.GameplayCueNotify_Actor.OnRemove // Native|Event|Public|HasOutParms|BlueprintEvent // @ game+0x5e0fca0
	void OnOwnerDestroyed(struct AActor* DestroyedActor); // Function GameplayAbilities.GameplayCueNotify_Actor.OnOwnerDestroyed // Native|Public // @ game+0x4dd1ecc
	bool OnExecute(struct AActor* MyTarget, struct FGameplayCueParameters Parameters); // Function GameplayAbilities.GameplayCueNotify_Actor.OnExecute // Native|Event|Public|HasOutParms|BlueprintEvent // @ game+0x5e0f1d4
	bool OnActive(struct AActor* MyTarget, struct FGameplayCueParameters Parameters); // Function GameplayAbilities.GameplayCueNotify_Actor.OnActive // Native|Event|Public|HasOutParms|BlueprintEvent // @ game+0x5e0ed08
	void K2_HandleGameplayCue(struct AActor* MyTarget, enum class EGameplayCueEvent EventType, struct FGameplayCueParameters Parameters); // Function GameplayAbilities.GameplayCueNotify_Actor.K2_HandleGameplayCue // Event|Public|HasOutParms|BlueprintEvent // @ game+0x33e45c
	void K2_EndGameplayCue(); // Function GameplayAbilities.GameplayCueNotify_Actor.K2_EndGameplayCue // Native|Public|BlueprintCallable // @ game+0x9848f0
};

// Class GameplayAbilities.GameplayCueNotify_Static
// Size: 0x50 (Inherited: 0x38)
struct UGameplayCueNotify_Static : UObject {
	struct FGameplayTag GameplayCueTag; // 0x38(0x08)
	struct FName GameplayCueName; // 0x40(0x08)
	bool IsOverride; // 0x48(0x01)
	char pad_49[0x7]; // 0x49(0x07)

	bool WhileActive(struct AActor* MyTarget, struct FGameplayCueParameters Parameters); // Function GameplayAbilities.GameplayCueNotify_Static.WhileActive // Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const // @ game+0x5e16a78
	bool OnRemove(struct AActor* MyTarget, struct FGameplayCueParameters Parameters); // Function GameplayAbilities.GameplayCueNotify_Static.OnRemove // Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const // @ game+0x5e0fdd0
	bool OnExecute(struct AActor* MyTarget, struct FGameplayCueParameters Parameters); // Function GameplayAbilities.GameplayCueNotify_Static.OnExecute // Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const // @ game+0x5e0f304
	bool OnActive(struct AActor* MyTarget, struct FGameplayCueParameters Parameters); // Function GameplayAbilities.GameplayCueNotify_Static.OnActive // Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const // @ game+0x5e0ee38
	void K2_HandleGameplayCue(struct AActor* MyTarget, enum class EGameplayCueEvent EventType, struct FGameplayCueParameters Parameters); // Function GameplayAbilities.GameplayCueNotify_Static.K2_HandleGameplayCue // Event|Public|HasOutParms|BlueprintEvent|Const // @ game+0x33e45c
};

// Class GameplayAbilities.GameplayCueNotify_HitImpact
// Size: 0x60 (Inherited: 0x50)
struct UGameplayCueNotify_HitImpact : UGameplayCueNotify_Static {
	struct USoundBase* Sound; // 0x50(0x08)
	struct UParticleSystem* ParticleSystem; // 0x58(0x08)
};

// Class GameplayAbilities.GameplayCueSet
// Size: 0xa0 (Inherited: 0x40)
struct UGameplayCueSet : UDataAsset {
	struct TArray<struct FGameplayCueNotifyData> GameplayCueData; // 0x40(0x10)
	char pad_50[0x50]; // 0x50(0x50)
};

// Class GameplayAbilities.GameplayEffectTemplate
// Size: 0x890 (Inherited: 0x890)
struct UGameplayEffectTemplate : UGameplayEffect {
};

// Class GameplayAbilities.GameplayModMagnitudeCalculation
// Size: 0x50 (Inherited: 0x48)
struct UGameplayModMagnitudeCalculation : UGameplayEffectCalculation {
	bool bAllowNonNetAuthorityDependencyRegistration; // 0x48(0x01)
	char pad_49[0x7]; // 0x49(0x07)

	float CalculateBaseMagnitude(struct FGameplayEffectSpec Spec); // Function GameplayAbilities.GameplayModMagnitudeCalculation.CalculateBaseMagnitude // Native|Event|Public|HasOutParms|BlueprintEvent|Const // @ game+0x5e09e74
};

// Class GameplayAbilities.GameplayEffectCustomApplicationRequirement
// Size: 0x38 (Inherited: 0x38)
struct UGameplayEffectCustomApplicationRequirement : UObject {

	bool CanApplyGameplayEffect(struct UGameplayEffect* GameplayEffect, struct FGameplayEffectSpec Spec, struct UAbilitySystemComponent* ASC); // Function GameplayAbilities.GameplayEffectCustomApplicationRequirement.CanApplyGameplayEffect // Native|Event|Public|HasOutParms|BlueprintEvent|Const // @ game+0x5e09f6c
};

// Class GameplayAbilities.GameplayEffectUIData
// Size: 0x38 (Inherited: 0x38)
struct UGameplayEffectUIData : UObject {
};

// Class GameplayAbilities.GameplayEffectUIData_TextOnly
// Size: 0x50 (Inherited: 0x38)
struct UGameplayEffectUIData_TextOnly : UGameplayEffectUIData {
	struct FText Description; // 0x38(0x18)
};

// Class GameplayAbilities.GameplayTagReponseTable
// Size: 0x220 (Inherited: 0x40)
struct UGameplayTagReponseTable : UDataAsset {
	struct TArray<struct FGameplayTagResponseTableEntry> Entries; // 0x40(0x10)
	char pad_50[0x1d0]; // 0x50(0x1d0)

	void TagResponseEvent(struct FGameplayTag Tag, int32 NewCount, struct UAbilitySystemComponent* ASC, int32 Idx); // Function GameplayAbilities.GameplayTagReponseTable.TagResponseEvent // Final|Native|Protected // @ game+0x5e12bb0
};

// Class GameplayAbilities.TickableAttributeSetInterface
// Size: 0x38 (Inherited: 0x38)
struct UTickableAttributeSetInterface : UInterface {
};

