// BlueprintGeneratedClass M_OutPlayArea2.M_OutPlayArea2_C
// Size: 0x488 (Inherited: 0x478)
struct AM_OutPlayArea2_C : ATslPostProcessEffect {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x478(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x480(0x08)

	void UserConstructionScript(); // Function M_OutPlayArea2.M_OutPlayArea2_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void OnSetEffectParameter(struct FString ParameterName, float Value); // Function M_OutPlayArea2.M_OutPlayArea2_C.OnSetEffectParameter // BlueprintCosmetic|Event|Public|BlueprintEvent // @ game+0x33e45c
	void ExecuteUbergraph_M_OutPlayArea2(int32 EntryPoint); // Function M_OutPlayArea2.M_OutPlayArea2_C.ExecuteUbergraph_M_OutPlayArea2 //  // @ game+0x33e45c
};

