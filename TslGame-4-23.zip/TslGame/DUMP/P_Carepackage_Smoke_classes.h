// BlueprintGeneratedClass P_Carepackage_Smoke.P_Carepackage_Smoke_C
// Size: 0x4f0 (Inherited: 0x4f0)
struct AP_Carepackage_Smoke_C : ATslParticle {
};

