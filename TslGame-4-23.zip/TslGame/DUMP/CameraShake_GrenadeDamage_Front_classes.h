// BlueprintGeneratedClass CameraShake_GrenadeDamage_Front.CameraShake_GrenadeDamage_Front_C
// Size: 0x170 (Inherited: 0x170)
struct UCameraShake_GrenadeDamage_Front_C : UCameraShake {
};

