// Class AudioMixer.SubmixEffectDynamicsProcessorPreset
// Size: 0xc8 (Inherited: 0x50)
struct USubmixEffectDynamicsProcessorPreset : USoundEffectSubmixPreset {
	char pad_50[0x50]; // 0x50(0x50)
	struct FSubmixEffectDynamicsProcessorSettings Settings; // 0xa0(0x28)

	void SetSettings(struct FSubmixEffectDynamicsProcessorSettings InSettings); // Function AudioMixer.SubmixEffectDynamicsProcessorPreset.SetSettings // Final|Native|Public|HasOutParms|BlueprintCallable // @ game+0x5baf524
};

// Class AudioMixer.AudioMixerBlueprintLibrary
// Size: 0x38 (Inherited: 0x38)
struct UAudioMixerBlueprintLibrary : UBlueprintFunctionLibrary {

	void SetBypassSourceEffectChainEntry(struct UObject* WorldContextObject, struct USoundEffectSourcePresetChain* PresetChain, int32 EntryIndex, bool bBypassed); // Function AudioMixer.AudioMixerBlueprintLibrary.SetBypassSourceEffectChainEntry // Final|Native|Static|Public|BlueprintCallable // @ game+0x5baf3c0
	void RemoveSourceEffectFromPresetChain(struct UObject* WorldContextObject, struct USoundEffectSourcePresetChain* PresetChain, int32 EntryIndex); // Function AudioMixer.AudioMixerBlueprintLibrary.RemoveSourceEffectFromPresetChain // Final|Native|Static|Public|BlueprintCallable // @ game+0x5baf2a8
	void RemoveMasterSubmixEffect(struct UObject* WorldContextObject, struct USoundEffectSubmixPreset* SubmixEffectPreset); // Function AudioMixer.AudioMixerBlueprintLibrary.RemoveMasterSubmixEffect // Final|Native|Static|Public|BlueprintCallable // @ game+0x5baf180
	int32 GetNumberOfEntriesInSourceEffectChain(struct UObject* WorldContextObject, struct USoundEffectSourcePresetChain* PresetChain); // Function AudioMixer.AudioMixerBlueprintLibrary.GetNumberOfEntriesInSourceEffectChain // Final|Native|Static|Public|BlueprintCallable // @ game+0x5baf064
	void ClearMasterSubmixEffects(struct UObject* WorldContextObject); // Function AudioMixer.AudioMixerBlueprintLibrary.ClearMasterSubmixEffects // Final|Native|Static|Public|BlueprintCallable // @ game+0x5baefb0
	void AddSourceEffectToPresetChain(struct UObject* WorldContextObject, struct USoundEffectSourcePresetChain* PresetChain, struct FSourceEffectChainEntry Entry); // Function AudioMixer.AudioMixerBlueprintLibrary.AddSourceEffectToPresetChain // Final|Native|Static|Public|BlueprintCallable // @ game+0x5baee94
	void AddMasterSubmixEffect(struct UObject* WorldContextObject, struct USoundEffectSubmixPreset* SubmixEffectPreset); // Function AudioMixer.AudioMixerBlueprintLibrary.AddMasterSubmixEffect // Final|Native|Static|Public|BlueprintCallable // @ game+0x5baedbc
};

// Class AudioMixer.SubmixEffectReverbPreset
// Size: 0xd8 (Inherited: 0x50)
struct USubmixEffectReverbPreset : USoundEffectSubmixPreset {
	char pad_50[0x58]; // 0x50(0x58)
	struct FSubmixEffectReverbSettings Settings; // 0xa8(0x30)

	void SetSettingsWithReverbEffect(struct UReverbEffect* InReverbEffect, float WetLevel); // Function AudioMixer.SubmixEffectReverbPreset.SetSettingsWithReverbEffect // Final|Native|Public|BlueprintCallable // @ game+0x5baf84c
	void SetSettings(struct FSubmixEffectReverbSettings InSettings); // Function AudioMixer.SubmixEffectReverbPreset.SetSettings // Final|Native|Public|HasOutParms|BlueprintCallable // @ game+0x5baf620
};

// Class AudioMixer.SubmixEffectSubmixEQPreset
// Size: 0x98 (Inherited: 0x50)
struct USubmixEffectSubmixEQPreset : USoundEffectSubmixPreset {
	char pad_50[0x38]; // 0x50(0x38)
	struct FSubmixEffectSubmixEQSettings Settings; // 0x88(0x10)

	void SetSettings(struct FSubmixEffectSubmixEQSettings InSettings); // Function AudioMixer.SubmixEffectSubmixEQPreset.SetSettings // Final|Native|Public|HasOutParms|BlueprintCallable // @ game+0x5baf72c
};

// Class AudioMixer.SynthSound
// Size: 0x340 (Inherited: 0x320)
struct USynthSound : USoundWaveProcedural {
	char pad_320[0x20]; // 0x320(0x20)
};

// Class AudioMixer.SynthComponent
// Size: 0x680 (Inherited: 0x4b0)
struct USynthComponent : USceneComponent {
	char bAutoDestroy : 1; // 0x4b0(0x01)
	char bStopWhenOwnerDestroyed : 1; // 0x4b0(0x01)
	char bAllowSpatialization : 1; // 0x4b0(0x01)
	char bOverrideAttenuation : 1; // 0x4b0(0x01)
	char pad_4B0_4 : 4; // 0x4b0(0x01)
	char pad_4B1[0x7]; // 0x4b1(0x07)
	struct USoundAttenuation* AttenuationSettings; // 0x4b8(0x08)
	struct FSoundAttenuationSettings AttenuationOverrides; // 0x4c0(0x130)
	struct USoundConcurrency* ConcurrencySettings; // 0x5f0(0x08)
	struct USoundClass* SoundClass; // 0x5f8(0x08)
	struct USoundEffectSourcePresetChain* SourceEffectChain; // 0x600(0x08)
	float DefaultMasterReverbSendAmount; // 0x608(0x04)
	char pad_60C[0x4]; // 0x60c(0x04)
	struct USoundSubmix* SoundSubmix; // 0x610(0x08)
	struct TArray<struct FSoundSubmixSendInfo> SoundSubmixSends; // 0x618(0x10)
	char pad_628[0x8]; // 0x628(0x08)
	struct USynthSound* Synth; // 0x630(0x08)
	struct UAudioComponent* AudioComponent; // 0x638(0x08)
	char pad_640[0x40]; // 0x640(0x40)

	void Stop(); // Function AudioMixer.SynthComponent.Stop // Final|Native|Public|BlueprintCallable // @ game+0x5bafa2c
	void Start(); // Function AudioMixer.SynthComponent.Start // Final|Native|Public|BlueprintCallable // @ game+0x5bafa18
	void SetSubmixSend(struct USoundSubmix* Submix, float SendLevel); // Function AudioMixer.SynthComponent.SetSubmixSend // Final|Native|Public|BlueprintCallable // @ game+0x5baf92c
	bool IsPlaying(); // Function AudioMixer.SynthComponent.IsPlaying // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5baf13c
};

