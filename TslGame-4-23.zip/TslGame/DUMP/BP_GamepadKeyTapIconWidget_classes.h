// WidgetBlueprintGeneratedClass BP_GamepadKeyTapIconWidget.BP_GamepadKeyTapIconWidget_C
// Size: 0x45c (Inherited: 0x448)
struct UBP_GamepadKeyTapIconWidget_C : UTslGamepadKeyTapIconWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x448(0x08)
	struct UWidgetSwitcher* TapSwitcher; // 0x450(0x08)
	int32 KeyIndex; // 0x458(0x04)

	void PreConstruct(bool IsDesignTime); // Function BP_GamepadKeyTapIconWidget.BP_GamepadKeyTapIconWidget_C.PreConstruct // BlueprintCosmetic|Event|Public|BlueprintEvent // @ game+0x33e45c
	void ExecuteUbergraph_BP_GamepadKeyTapIconWidget(int32 EntryPoint); // Function BP_GamepadKeyTapIconWidget.BP_GamepadKeyTapIconWidget_C.ExecuteUbergraph_BP_GamepadKeyTapIconWidget //  // @ game+0x33e45c
};

