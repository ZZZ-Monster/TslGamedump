// WidgetBlueprintGeneratedClass BP_ObserverPlayerIconMuzzleFlash.BP_ObserverPlayerIconMuzzleFlash_C
// Size: 0x278 (Inherited: 0x260)
struct UBP_ObserverPlayerIconMuzzleFlash_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UWidgetAnimation* MuzzleFlashPlay; // 0x268(0x08)
	struct UImage* Image_MuzzleFlash; // 0x270(0x08)

	void PlayMuzzleFlashAnim(); // Function BP_ObserverPlayerIconMuzzleFlash.BP_ObserverPlayerIconMuzzleFlash_C.PlayMuzzleFlashAnim // Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void Construct(); // Function BP_ObserverPlayerIconMuzzleFlash.BP_ObserverPlayerIconMuzzleFlash_C.Construct // BlueprintCosmetic|Event|Public|BlueprintEvent // @ game+0x33e45c
	void ExecuteUbergraph_BP_ObserverPlayerIconMuzzleFlash(int32 EntryPoint); // Function BP_ObserverPlayerIconMuzzleFlash.BP_ObserverPlayerIconMuzzleFlash_C.ExecuteUbergraph_BP_ObserverPlayerIconMuzzleFlash //  // @ game+0x33e45c
};

