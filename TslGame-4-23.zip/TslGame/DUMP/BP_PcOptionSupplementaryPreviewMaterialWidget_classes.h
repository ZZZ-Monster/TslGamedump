// WidgetBlueprintGeneratedClass BP_PcOptionSupplementaryPreviewMaterialWidget.BP_PcOptionSupplementaryPreviewMaterialWidget_C
// Size: 0x4a8 (Inherited: 0x4a8)
struct UBP_PcOptionSupplementaryPreviewMaterialWidget_C : UTslGameOptionSupplementaryPreviewMaterialWidget {
};

