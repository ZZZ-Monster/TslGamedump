// Enum MK3DPublisher.ECapurerMode
enum class ECapurerMode : uint8 {
	ECapturerNone,
	ECapturerMovie,
	ECapturerSound,
	ECapurerMode_MAX,
};

