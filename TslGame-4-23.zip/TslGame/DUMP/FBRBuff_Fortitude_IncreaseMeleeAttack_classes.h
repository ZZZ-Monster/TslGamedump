// BlueprintGeneratedClass FBRBuff_Fortitude_IncreaseMeleeAttack.FBRBuff_Fortitude_IncreaseMeleeAttack_C
// Size: 0x4a8 (Inherited: 0x4a0)
struct AFBRBuff_Fortitude_IncreaseMeleeAttack_C : ATslFBRBuff {
	struct USceneComponent* DefaultSceneRoot; // 0x4a0(0x08)

	void UserConstructionScript(); // Function FBRBuff_Fortitude_IncreaseMeleeAttack.FBRBuff_Fortitude_IncreaseMeleeAttack_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
};

