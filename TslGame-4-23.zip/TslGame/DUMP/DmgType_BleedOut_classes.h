// BlueprintGeneratedClass DmgType_BleedOut.DmgType_BleedOut_C
// Size: 0x100 (Inherited: 0x100)
struct UDmgType_BleedOut_C : UTslDamageType {
};

