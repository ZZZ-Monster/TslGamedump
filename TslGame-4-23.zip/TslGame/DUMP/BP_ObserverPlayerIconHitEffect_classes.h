// WidgetBlueprintGeneratedClass BP_ObserverPlayerIconHitEffect.BP_ObserverPlayerIconHitEffect_C
// Size: 0x278 (Inherited: 0x260)
struct UBP_ObserverPlayerIconHitEffect_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UWidgetAnimation* HitEffectPlay; // 0x268(0x08)
	struct UImage* Image_HitEffect; // 0x270(0x08)

	void Construct(); // Function BP_ObserverPlayerIconHitEffect.BP_ObserverPlayerIconHitEffect_C.Construct // BlueprintCosmetic|Event|Public|BlueprintEvent // @ game+0x33e45c
	void ExecuteUbergraph_BP_ObserverPlayerIconHitEffect(int32 EntryPoint); // Function BP_ObserverPlayerIconHitEffect.BP_ObserverPlayerIconHitEffect_C.ExecuteUbergraph_BP_ObserverPlayerIconHitEffect //  // @ game+0x33e45c
};

