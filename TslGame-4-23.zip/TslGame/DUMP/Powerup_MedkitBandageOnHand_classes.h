// BlueprintGeneratedClass Powerup_MedkitBandageOnHand.Powerup_MedkitBandageOnHand_C
// Size: 0x440 (Inherited: 0x440)
struct APowerup_MedkitBandageOnHand_C : APowerup_Base_C {
};

