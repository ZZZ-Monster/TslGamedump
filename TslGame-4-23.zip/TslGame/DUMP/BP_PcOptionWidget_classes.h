// WidgetBlueprintGeneratedClass BP_PcOptionWidget.BP_PcOptionWidget_C
// Size: 0x9a8 (Inherited: 0x988)
struct UBP_PcOptionWidget_C : UTslGameOptionWidget {
	struct UBP_GamepadMultipleKeyIconWidget_C* BP_GamepadMultipleKeyIconWidget; // 0x988(0x08)
	struct UBP_GamepadMultipleKeyIconWidget_C* BP_GamepadMultipleKeyIconWidget_1; // 0x990(0x08)
	struct UBP_GamepadMultipleKeyIconWidget_C* BP_GamepadMultipleKeyIconWidget_2; // 0x998(0x08)
	struct USafeZone* SafeZone_5; // 0x9a0(0x08)
};

