// Class OnlineSubsystem.NamedInterfaces
// Size: 0xd0 (Inherited: 0x38)
struct UNamedInterfaces : UObject {
	struct TArray<struct FNamedInterface> NamedInterfaces; // 0x38(0x10)
	struct TArray<struct FNamedInterfaceDef> NamedInterfaceDefs; // 0x48(0x10)
	char pad_58[0x78]; // 0x58(0x78)
};

// Class OnlineSubsystem.TurnBasedMatchInterface
// Size: 0x38 (Inherited: 0x38)
struct UTurnBasedMatchInterface : UInterface {

	void OnMatchReceivedTurn(struct FString Match, bool bDidBecomeActive); // Function OnlineSubsystem.TurnBasedMatchInterface.OnMatchReceivedTurn // Event|Public|BlueprintEvent // @ game+0x33e45c
	void OnMatchEnded(struct FString Match); // Function OnlineSubsystem.TurnBasedMatchInterface.OnMatchEnded // Event|Public|BlueprintEvent // @ game+0x33e45c
};

