// WidgetBlueprintGeneratedClass MouseWidgetBP.MouseWidgetBP_C
// Size: 0x478 (Inherited: 0x478)
struct UMouseWidgetBP_C : UTslMouseWidget {
};

