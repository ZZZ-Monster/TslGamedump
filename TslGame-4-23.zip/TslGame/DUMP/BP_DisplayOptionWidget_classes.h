// WidgetBlueprintGeneratedClass BP_DisplayOptionWidget.BP_DisplayOptionWidget_C
// Size: 0xa10 (Inherited: 0x9e0)
struct UBP_DisplayOptionWidget_C : UTslDisplayOptionWidget {
	struct UBP_GamepadMultipleKeyIconWidget_C* BP_GamepadMultipleKeyIconWidget; // 0x9e0(0x08)
	struct UBP_GamepadMultipleKeyIconWidget_C* BP_GamepadMultipleKeyIconWidget_1; // 0x9e8(0x08)
	struct UTextBlock* BtnsKM_0_Text; // 0x9f0(0x08)
	struct UTextBlock* BtnsKM_1_Text; // 0x9f8(0x08)
	struct UBP_DisplayOptionSliderWidget_C* DisplayOptionSlider; // 0xa00(0x08)
	struct UImage* IconBgImage; // 0xa08(0x08)
};

