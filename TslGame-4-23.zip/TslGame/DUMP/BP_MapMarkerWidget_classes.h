// WidgetBlueprintGeneratedClass BP_MapMarkerWidget.BP_MapMarkerWidget_C
// Size: 0x4e5 (Inherited: 0x478)
struct UBP_MapMarkerWidget_C : UMapMarkerBaseWidget {
	struct UWidgetAnimation* MyMarkerEmerging; // 0x478(0x08)
	struct UImage* AttackImage; // 0x480(0x08)
	struct UImage* CommanderImage; // 0x488(0x08)
	struct UImage* CommanderMapMarkerImage; // 0x490(0x08)
	struct UImage* DangerImage; // 0x498(0x08)
	struct UImage* DefenseImage; // 0x4a0(0x08)
	struct UImage* ItemImage; // 0x4a8(0x08)
	struct UImage* RegroupImage; // 0x4b0(0x08)
	struct UImage* SingleMarkerImage; // 0x4b8(0x08)
	struct UImage* TacticalMapMarkerImage; // 0x4c0(0x08)
	struct UImage* TeamMarkerImage; // 0x4c8(0x08)
	struct UImage* VehicleImage; // 0x4d0(0x08)
	struct UMaterialInstanceDynamic* MarkerMaterial; // 0x4d8(0x08)
	int32 Number; // 0x4e0(0x04)
	bool bShow; // 0x4e4(0x01)
};

