// BlueprintGeneratedClass CS_WeapGun_Sniper_762_Kar98_Scope.CS_WeapGun_Sniper_762_Kar98_Scope_C
// Size: 0x170 (Inherited: 0x170)
struct UCS_WeapGun_Sniper_762_Kar98_Scope_C : UCameraShake {
};

