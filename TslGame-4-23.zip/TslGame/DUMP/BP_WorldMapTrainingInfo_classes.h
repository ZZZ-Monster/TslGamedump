// WidgetBlueprintGeneratedClass BP_WorldMapTrainingInfo.BP_WorldMapTrainingInfo_C
// Size: 0x260 (Inherited: 0x260)
struct UBP_WorldMapTrainingInfo_C : UUserWidget {
};

