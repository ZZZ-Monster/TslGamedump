// WidgetBlueprintGeneratedClass BP_OutSideTeamIconWidget.BP_OutSideTeamIconWidget_C
// Size: 0x450 (Inherited: 0x448)
struct UBP_OutSideTeamIconWidget_C : UOutsideTeamIconWidget {
	struct UImage* Icon; // 0x448(0x08)
};

