// BlueprintGeneratedClass GamepadHelpInterface.GamepadHelpInterface_C
// Size: 0x38 (Inherited: 0x38)
struct UGamepadHelpInterface_C : UInterface {

	void GetGamePadHelpWidgetClass(struct UClass* GuideClass); // Function GamepadHelpInterface.GamepadHelpInterface_C.GetGamePadHelpWidgetClass // Public|HasOutParms|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
};

