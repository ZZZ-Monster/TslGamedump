// Class CinematicCamera.CameraRig_Crane
// Size: 0x420 (Inherited: 0x3f0)
struct ACameraRig_Crane : AActor {
	float CranePitch; // 0x3f0(0x04)
	float CraneYaw; // 0x3f4(0x04)
	float CraneArmLength; // 0x3f8(0x04)
	bool bLockMountPitch; // 0x3fc(0x01)
	bool bLockMountYaw; // 0x3fd(0x01)
	char pad_3FE[0x2]; // 0x3fe(0x02)
	struct USceneComponent* TransformComponent; // 0x400(0x08)
	struct USceneComponent* CraneYawControl; // 0x408(0x08)
	struct USceneComponent* CranePitchControl; // 0x410(0x08)
	struct USceneComponent* CraneCameraMount; // 0x418(0x08)
};

// Class CinematicCamera.CameraRig_Rail
// Size: 0x410 (Inherited: 0x3f0)
struct ACameraRig_Rail : AActor {
	float CurrentPositionOnRail; // 0x3f0(0x04)
	char pad_3F4[0x4]; // 0x3f4(0x04)
	struct USceneComponent* TransformComponent; // 0x3f8(0x08)
	struct USplineComponent* RailSplineComponent; // 0x400(0x08)
	struct USceneComponent* RailCameraMount; // 0x408(0x08)
};

// Class CinematicCamera.CineCameraActor
// Size: 0x9d0 (Inherited: 0x990)
struct ACineCameraActor : ACameraActor {
	struct FCameraLookatTrackingSettings LookatTrackingSettings; // 0x990(0x30)
	char pad_9C0[0x10]; // 0x9c0(0x10)

	struct UCineCameraComponent* GetCineCameraComponent(); // Function CinematicCamera.CineCameraActor.GetCineCameraComponent // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x53b9dac
};

// Class CinematicCamera.CineCameraComponent
// Size: 0xb60 (Inherited: 0xaa0)
struct UCineCameraComponent : UCameraComponent {
	struct FCameraFilmbackSettings FilmbackSettings; // 0xaa0(0x0c)
	struct FCameraLensSettings LensSettings; // 0xaac(0x14)
	struct FCameraFocusSettings FocusSettings; // 0xac0(0x38)
	float CurrentFocalLength; // 0xaf8(0x04)
	float CurrentAperture; // 0xafc(0x04)
	float CurrentFocusDistance; // 0xb00(0x04)
	char pad_B04[0xc]; // 0xb04(0x0c)
	struct TArray<struct FNamedFilmbackPreset> FilmbackPresets; // 0xb10(0x10)
	struct TArray<struct FNamedLensPreset> LensPresets; // 0xb20(0x10)
	struct FString DefaultFilmbackPresetName; // 0xb30(0x10)
	struct FString DefaultLensPresetName; // 0xb40(0x10)
	float DefaultLensFocalLength; // 0xb50(0x04)
	float DefaultLensFStop; // 0xb54(0x04)
	char pad_B58[0x8]; // 0xb58(0x08)

	float GetVerticalFieldOfView(); // Function CinematicCamera.CineCameraComponent.GetVerticalFieldOfView // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x53b9dec
	float GetHorizontalFieldOfView(); // Function CinematicCamera.CineCameraComponent.GetHorizontalFieldOfView // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x53b9dc4
};

