// Class MK3DPublisher.AudioCapturer
// Size: 0x470 (Inherited: 0x3f0)
struct AAudioCapturer : AActor {
	char pad_3F0[0x80]; // 0x3f0(0x80)
};

// Class MK3DPublisher.CaptureFunctionLibrary
// Size: 0x38 (Inherited: 0x38)
struct UCaptureFunctionLibrary : UBlueprintFunctionLibrary {

	void VideoSaveFileDialog(struct FString TempPath, struct TArray<struct FString> OutFiles); // Function MK3DPublisher.CaptureFunctionLibrary.VideoSaveFileDialog // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x5cb4f24
	struct FString TimeStampFileNameWebM(); // Function MK3DPublisher.CaptureFunctionLibrary.TimeStampFileNameWebM // Final|Native|Static|Public|BlueprintCallable // @ game+0x5cb4e28
	struct FString TimeSecondsToStringHHMMDD(float InSeconds); // Function MK3DPublisher.CaptureFunctionLibrary.TimeSecondsToStringHHMMDD // Final|Native|Static|Public|BlueprintCallable // @ game+0x5cb4d40
	struct FString TimeSecondsToStringAboutMinute(float InSeconds); // Function MK3DPublisher.CaptureFunctionLibrary.TimeSecondsToStringAboutMinute // Final|Native|Static|Public|BlueprintCallable // @ game+0x5cb4c58
	void StopAudioCapture(); // Function MK3DPublisher.CaptureFunctionLibrary.StopAudioCapture // Final|Native|Static|Public|BlueprintCallable // @ game+0x5cb4bec
	void StartRenderTake(int32 Width, int32 Height, int32 Frame, int32 VideoBitrate, struct FString outputPath, bool includeFileName); // Function MK3DPublisher.CaptureFunctionLibrary.StartRenderTake // Final|Native|Static|Public|BlueprintCallable // @ game+0x5cb498c
	void StartRender(int32 Width, int32 Height, int32 Frame, int32 VideoBitrate, struct FString outputPath, bool includeFileName); // Function MK3DPublisher.CaptureFunctionLibrary.StartRender // Final|Native|Static|Public|BlueprintCallable // @ game+0x5cb472c
	void StartDefinedRender(); // Function MK3DPublisher.CaptureFunctionLibrary.StartDefinedRender // Final|Native|Static|Public|BlueprintCallable // @ game+0x5cb4718
	void StartAudioCapture(); // Function MK3DPublisher.CaptureFunctionLibrary.StartAudioCapture // Final|Native|Static|Public|BlueprintCallable // @ game+0x5cb46b0
	bool SettingVideoResolutionByString(struct FString Str, int32 Width, int32 Height, int32 VideoBitrate); // Function MK3DPublisher.CaptureFunctionLibrary.SettingVideoResolutionByString // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x5cb44b4
	bool SettingVideoResolutionByIndex(int32 Index, int32 Width, int32 Height, int32 VideoBitrate); // Function MK3DPublisher.CaptureFunctionLibrary.SettingVideoResolutionByIndex // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x5cb4318
	void SetRecordingTime(int32 TotalTimeMS); // Function MK3DPublisher.CaptureFunctionLibrary.SetRecordingTime // Final|Native|Static|Public|BlueprintCallable // @ game+0x5cb4270
	void SetNoCapture(bool bNoCapture); // Function MK3DPublisher.CaptureFunctionLibrary.SetNoCapture // Final|Native|Static|Public|BlueprintCallable // @ game+0x5cb41c4
	void ResumeAudio(); // Function MK3DPublisher.CaptureFunctionLibrary.ResumeAudio // Final|Native|Static|Public|BlueprintCallable // @ game+0x5cb4160
	void PauseAudio(); // Function MK3DPublisher.CaptureFunctionLibrary.PauseAudio // Final|Native|Static|Public|BlueprintCallable // @ game+0x5cb40fc
	void OnFixedFrameRateSetting(float Fps); // Function MK3DPublisher.CaptureFunctionLibrary.OnFixedFrameRateSetting // Final|Native|Static|Public|BlueprintCallable // @ game+0x5cb4078
	void OnConsoleVariableSetting(); // Function MK3DPublisher.CaptureFunctionLibrary.OnConsoleVariableSetting // Final|Native|Static|Public|BlueprintCallable // @ game+0x5cb4014
	void OffFixedFrameRateSetting(); // Function MK3DPublisher.CaptureFunctionLibrary.OffFixedFrameRateSetting // Final|Native|Static|Public|BlueprintCallable // @ game+0x5cb3fb4
	void OffConsoleVariableSetting(); // Function MK3DPublisher.CaptureFunctionLibrary.OffConsoleVariableSetting // Final|Native|Static|Public|BlueprintCallable // @ game+0x5cb3f50
	bool IsReplayJumpingByCaptureManager(); // Function MK3DPublisher.CaptureFunctionLibrary.IsReplayJumpingByCaptureManager // Final|Native|Static|Public|BlueprintCallable // @ game+0x5cb3eec
	bool IsRecordingComplete(); // Function MK3DPublisher.CaptureFunctionLibrary.IsRecordingComplete // Final|Native|Static|Public|BlueprintCallable // @ game+0x5cb3ec8
	bool IsCapturing(); // Function MK3DPublisher.CaptureFunctionLibrary.IsCapturing // Final|Native|Static|Public|BlueprintCallable // @ game+0x5cb3e64
	void InputRenderTakes(struct TArray<float> InArr); // Function MK3DPublisher.CaptureFunctionLibrary.InputRenderTakes // Final|Native|Static|Public|BlueprintCallable // @ game+0x5cb3d24
	void InitArrayVideoQualityString(struct TArray<struct FString> Array); // Function MK3DPublisher.CaptureFunctionLibrary.InitArrayVideoQualityString // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x5cb3c70
	void InitArrayResolutionString(struct TArray<struct FString> Array); // Function MK3DPublisher.CaptureFunctionLibrary.InitArrayResolutionString // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x5cb3bbc
	void InitArrayFrameRateString(struct TArray<int32> Array); // Function MK3DPublisher.CaptureFunctionLibrary.InitArrayFrameRateString // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x5cb3ab4
	struct FString GetVideoOutputPath(); // Function MK3DPublisher.CaptureFunctionLibrary.GetVideoOutputPath // Final|Native|Static|Public|BlueprintCallable // @ game+0x5cb3a2c
	float GetProgressPercentFloat(); // Function MK3DPublisher.CaptureFunctionLibrary.GetProgressPercentFloat // Final|Native|Static|Public|BlueprintCallable // @ game+0x5cb3a04
	int32 GetProgressPercent(); // Function MK3DPublisher.CaptureFunctionLibrary.GetProgressPercent // Final|Native|Static|Public|BlueprintCallable // @ game+0x5cb39d4
	int32 GetCapturerModeToInt(); // Function MK3DPublisher.CaptureFunctionLibrary.GetCapturerModeToInt // Final|Native|Static|Public|BlueprintCallable // @ game+0x5cb3974
	struct FString GetArrayItemVideoQualityString(int32 inIdx, int32 outIdx); // Function MK3DPublisher.CaptureFunctionLibrary.GetArrayItemVideoQualityString // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x5cb37d8
	float GetArrayItemVideoQualityRatio(int32 inIdx, int32 outIdx); // Function MK3DPublisher.CaptureFunctionLibrary.GetArrayItemVideoQualityRatio // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x5cb36cc
	struct FString GetArrayItemResolutions(int32 inIdx, int32 outIdx); // Function MK3DPublisher.CaptureFunctionLibrary.GetArrayItemResolutions // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x5cb3538
	int32 GetArrayItemFrameRates(int32 inIdx, int32 outIdx); // Function MK3DPublisher.CaptureFunctionLibrary.GetArrayItemFrameRates // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x5cb3430
	void CancelRender(); // Function MK3DPublisher.CaptureFunctionLibrary.CancelRender // Final|Native|Static|Public|BlueprintCallable // @ game+0x5cb3398
	int32 CalculateVideoQuality(int32 InHeight); // Function MK3DPublisher.CaptureFunctionLibrary.CalculateVideoQuality // Final|Native|Static|Public|BlueprintCallable // @ game+0x5cb330c
	float CalcProgressPercentFloat(int32 TotalTimeMS); // Function MK3DPublisher.CaptureFunctionLibrary.CalcProgressPercentFloat // Final|Native|Static|Public|BlueprintCallable // @ game+0x5cb327c
	float CalcProgressPercentEx(); // Function MK3DPublisher.CaptureFunctionLibrary.CalcProgressPercentEx // Final|Native|Static|Public|BlueprintCallable // @ game+0x5cb3254
	int32 CalcProgressPercent(int32 TotalTimeMS); // Function MK3DPublisher.CaptureFunctionLibrary.CalcProgressPercent // Final|Native|Static|Public|BlueprintCallable // @ game+0x5cb31bc
	void CalcProgressCount(int32 OutTotalCount, int32 OutCurrentNum); // Function MK3DPublisher.CaptureFunctionLibrary.CalcProgressCount // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x5cb3090
	int32 CalcCaptureAboutMinute(int32 Width, int32 Height, int32 pageCount); // Function MK3DPublisher.CaptureFunctionLibrary.CalcCaptureAboutMinute // Final|Native|Static|Public|BlueprintCallable // @ game+0x5cb2f78
	void BindFunctionLibraryReturnCodeDelegate(DelegateProperty InDelegate); // Function MK3DPublisher.CaptureFunctionLibrary.BindFunctionLibraryReturnCodeDelegate // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x5cb2ecc
	void BindFunctionLibraryReplayJumpDelegate(DelegateProperty InDelegate); // Function MK3DPublisher.CaptureFunctionLibrary.BindFunctionLibraryReplayJumpDelegate // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x5cb2e20
	void BindFunctionLibraryRederCompleteDelegate(DelegateProperty InDelegate); // Function MK3DPublisher.CaptureFunctionLibrary.BindFunctionLibraryRederCompleteDelegate // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x5cb2d74
	void BindFunctionLibraryOnPauseDelegate(DelegateProperty InDelegate); // Function MK3DPublisher.CaptureFunctionLibrary.BindFunctionLibraryOnPauseDelegate // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x5cb2cc8
	bool AddCaptureWidget(struct UUserWidget* InWidget); // Function MK3DPublisher.CaptureFunctionLibrary.AddCaptureWidget // Final|Native|Static|Public|BlueprintCallable // @ game+0x5cb2c38
};

// Class MK3DPublisher.ViewportCapturer
// Size: 0x488 (Inherited: 0x3f0)
struct AViewportCapturer : AActor {
	char pad_3F0[0x98]; // 0x3f0(0x98)
};

