// BlueprintGeneratedClass CameraShake_GrenadeDamage.CameraShake_GrenadeDamage_C
// Size: 0x170 (Inherited: 0x170)
struct UCameraShake_GrenadeDamage_C : UCameraShake {
};

