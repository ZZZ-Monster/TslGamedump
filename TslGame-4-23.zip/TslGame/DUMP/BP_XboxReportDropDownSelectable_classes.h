// WidgetBlueprintGeneratedClass BP_XboxReportDropDownSelectable.BP_XboxReportDropDownSelectable_C
// Size: 0x5f0 (Inherited: 0x5a8)
struct UBP_XboxReportDropDownSelectable_C : UTslReportDropDownListSelectable {
	struct UImage* ArrowDown_Image; // 0x5a8(0x08)
	struct UImage* ArrowUp_Image; // 0x5b0(0x08)
	struct UImage* CheckFocused_Image; // 0x5b8(0x08)
	struct UImage* CheckNormal_Image; // 0x5c0(0x08)
	struct UTextBlock* DisplayClosed_Text; // 0x5c8(0x08)
	struct UTextBlock* DisplayFocused_Text; // 0x5d0(0x08)
	struct UTextBlock* DisplayNormal_Text; // 0x5d8(0x08)
	struct UTextBlock* DisplayOpened_Text; // 0x5e0(0x08)
	struct UWidgetSwitcher* Dropdown_Switcher; // 0x5e8(0x08)
};

