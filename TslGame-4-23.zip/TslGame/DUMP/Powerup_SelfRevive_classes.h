// BlueprintGeneratedClass Powerup_SelfRevive.Powerup_SelfRevive_C
// Size: 0x448 (Inherited: 0x440)
struct APowerup_SelfRevive_C : APowerup_Base_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x440(0x08)

	void UserConstructionScript(); // Function Powerup_SelfRevive.Powerup_SelfRevive_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void ReceiveBeginPlay(); // Function Powerup_SelfRevive.Powerup_SelfRevive_C.ReceiveBeginPlay // Event|Protected|BlueprintEvent // @ game+0x33e45c
	void ExecuteUbergraph_Powerup_SelfRevive(int32 EntryPoint); // Function Powerup_SelfRevive.Powerup_SelfRevive_C.ExecuteUbergraph_Powerup_SelfRevive //  // @ game+0x33e45c
};

