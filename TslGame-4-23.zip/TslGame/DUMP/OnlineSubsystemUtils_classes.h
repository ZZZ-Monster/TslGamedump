// Class OnlineSubsystemUtils.IpConnection
// Size: 0x65868 (Inherited: 0x65848)
struct UIpConnection : UNetConnection {
	char pad_65848[0x20]; // 0x65848(0x20)
};

// Class OnlineSubsystemUtils.AchievementBlueprintLibrary
// Size: 0x38 (Inherited: 0x38)
struct UAchievementBlueprintLibrary : UBlueprintFunctionLibrary {

	void GetCachedAchievementProgress(struct UObject* WorldContextObject, struct APlayerController* PlayerController, struct FName AchievementID, bool bFoundID, float Progress); // Function OnlineSubsystemUtils.AchievementBlueprintLibrary.GetCachedAchievementProgress // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x5d2380c
	void GetCachedAchievementDescription(struct UObject* WorldContextObject, struct APlayerController* PlayerController, struct FName AchievementID, bool bFoundID, struct FText Title, struct FText LockedDescription, struct FText UnlockedDescription, bool bHidden); // Function OnlineSubsystemUtils.AchievementBlueprintLibrary.GetCachedAchievementDescription // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x5d23444
};

// Class OnlineSubsystemUtils.AchievementQueryCallbackProxy
// Size: 0x70 (Inherited: 0x38)
struct UAchievementQueryCallbackProxy : UOnlineBlueprintCallProxyBase {
	struct FMulticastDelegate OnSuccess; // 0x38(0x10)
	struct FMulticastDelegate OnFailure; // 0x48(0x10)
	char pad_58[0x18]; // 0x58(0x18)

	struct UAchievementQueryCallbackProxy* CacheAchievements(struct UObject* WorldContextObject, struct APlayerController* PlayerController); // Function OnlineSubsystemUtils.AchievementQueryCallbackProxy.CacheAchievements // Final|Native|Static|Public|BlueprintCallable // @ game+0x5d220d4
	struct UAchievementQueryCallbackProxy* CacheAchievementDescriptions(struct UObject* WorldContextObject, struct APlayerController* PlayerController); // Function OnlineSubsystemUtils.AchievementQueryCallbackProxy.CacheAchievementDescriptions // Final|Native|Static|Public|BlueprintCallable // @ game+0x5d21fdc
};

// Class OnlineSubsystemUtils.AchievementWriteCallbackProxy
// Size: 0x88 (Inherited: 0x38)
struct UAchievementWriteCallbackProxy : UOnlineBlueprintCallProxyBase {
	struct FMulticastDelegate OnSuccess; // 0x38(0x10)
	struct FMulticastDelegate OnFailure; // 0x48(0x10)
	char pad_58[0x30]; // 0x58(0x30)

	struct UAchievementWriteCallbackProxy* WriteAchievementProgress(struct UObject* WorldContextObject, struct APlayerController* PlayerController, struct FName AchievementName, float Progress, int32 UserTag); // Function OnlineSubsystemUtils.AchievementWriteCallbackProxy.WriteAchievementProgress // Final|Native|Static|Public|BlueprintCallable // @ game+0x5d25148
};

// Class OnlineSubsystemUtils.ConnectionCallbackProxy
// Size: 0xb0 (Inherited: 0x38)
struct UConnectionCallbackProxy : UOnlineBlueprintCallProxyBase {
	struct FMulticastDelegate OnSuccess; // 0x38(0x10)
	struct FMulticastDelegate OnFailure; // 0x48(0x10)
	char pad_58[0x58]; // 0x58(0x58)

	struct UConnectionCallbackProxy* ConnectToService(struct UObject* WorldContextObject, struct APlayerController* PlayerController); // Function OnlineSubsystemUtils.ConnectionCallbackProxy.ConnectToService // Final|Native|Static|Public|BlueprintCallable // @ game+0x5d22390
};

// Class OnlineSubsystemUtils.CreateSessionCallbackProxy
// Size: 0x100 (Inherited: 0x38)
struct UCreateSessionCallbackProxy : UOnlineBlueprintCallProxyBase {
	struct FMulticastDelegate OnSuccess; // 0x38(0x10)
	struct FMulticastDelegate OnFailure; // 0x48(0x10)
	char pad_58[0xa8]; // 0x58(0xa8)

	struct UCreateSessionCallbackProxy* CreateSession(struct UObject* WorldContextObject, struct APlayerController* PlayerController, int32 PublicConnections, bool bUseLAN); // Function OnlineSubsystemUtils.CreateSessionCallbackProxy.CreateSession // Final|Native|Static|Public|BlueprintCallable // @ game+0x5d229a0
};

// Class OnlineSubsystemUtils.DestroySessionCallbackProxy
// Size: 0xb0 (Inherited: 0x38)
struct UDestroySessionCallbackProxy : UOnlineBlueprintCallProxyBase {
	struct FMulticastDelegate OnSuccess; // 0x38(0x10)
	struct FMulticastDelegate OnFailure; // 0x48(0x10)
	char pad_58[0x58]; // 0x58(0x58)

	struct UDestroySessionCallbackProxy* DestroySession(struct UObject* WorldContextObject, struct APlayerController* PlayerController); // Function OnlineSubsystemUtils.DestroySessionCallbackProxy.DestroySession // Final|Native|Static|Public|BlueprintCallable // @ game+0x5d22b0c
};

// Class OnlineSubsystemUtils.EndMatchCallbackProxy
// Size: 0x88 (Inherited: 0x38)
struct UEndMatchCallbackProxy : UOnlineBlueprintCallProxyBase {
	struct FMulticastDelegate OnSuccess; // 0x38(0x10)
	struct FMulticastDelegate OnFailure; // 0x48(0x10)
	char pad_58[0x30]; // 0x58(0x30)

	struct UEndMatchCallbackProxy* EndMatch(struct UObject* WorldContextObject, struct APlayerController* PlayerController, TScriptInterface<struct UTurnBasedMatchInterface> MatchActor, struct FString MatchId, enum class EMPMatchOutcome LocalPlayerOutcome, enum class EMPMatchOutcome OtherPlayersOutcome); // Function OnlineSubsystemUtils.EndMatchCallbackProxy.EndMatch // Final|Native|Static|Public|BlueprintCallable // @ game+0x5d22be8
};

// Class OnlineSubsystemUtils.EndTurnCallbackProxy
// Size: 0x80 (Inherited: 0x38)
struct UEndTurnCallbackProxy : UOnlineBlueprintCallProxyBase {
	struct FMulticastDelegate OnSuccess; // 0x38(0x10)
	struct FMulticastDelegate OnFailure; // 0x48(0x10)
	char pad_58[0x28]; // 0x58(0x28)

	struct UEndTurnCallbackProxy* EndTurn(struct UObject* WorldContextObject, struct APlayerController* PlayerController, struct FString MatchId, TScriptInterface<struct UTurnBasedMatchInterface> TurnBasedMatchInterface); // Function OnlineSubsystemUtils.EndTurnCallbackProxy.EndTurn // Final|Native|Static|Public|BlueprintCallable // @ game+0x5d22e78
};

// Class OnlineSubsystemUtils.FindSessionsCallbackProxy
// Size: 0xd0 (Inherited: 0x38)
struct UFindSessionsCallbackProxy : UOnlineBlueprintCallProxyBase {
	struct FMulticastDelegate OnSuccess; // 0x38(0x10)
	struct FMulticastDelegate OnFailure; // 0x48(0x10)
	char pad_58[0x78]; // 0x58(0x78)

	struct FString GetServerName(struct FBlueprintSessionResult Result); // Function OnlineSubsystemUtils.FindSessionsCallbackProxy.GetServerName // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x5d243cc
	int32 GetPingInMs(struct FBlueprintSessionResult Result); // Function OnlineSubsystemUtils.FindSessionsCallbackProxy.GetPingInMs // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x5d24044
	int32 GetMaxPlayers(struct FBlueprintSessionResult Result); // Function OnlineSubsystemUtils.FindSessionsCallbackProxy.GetMaxPlayers // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x5d23d20
	int32 GetCurrentPlayers(struct FBlueprintSessionResult Result); // Function OnlineSubsystemUtils.FindSessionsCallbackProxy.GetCurrentPlayers // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x5d239f4
	struct UFindSessionsCallbackProxy* FindSessions(struct UObject* WorldContextObject, struct APlayerController* PlayerController, int32 MaxResults, bool bUseLAN); // Function OnlineSubsystemUtils.FindSessionsCallbackProxy.FindSessions // Final|Native|Static|Public|BlueprintCallable // @ game+0x5d23068
};

// Class OnlineSubsystemUtils.FindTurnBasedMatchCallbackProxy
// Size: 0x90 (Inherited: 0x38)
struct UFindTurnBasedMatchCallbackProxy : UOnlineBlueprintCallProxyBase {
	struct FMulticastDelegate OnSuccess; // 0x38(0x10)
	struct FMulticastDelegate OnFailure; // 0x48(0x10)
	char pad_58[0x38]; // 0x58(0x38)

	struct UFindTurnBasedMatchCallbackProxy* FindTurnBasedMatch(struct UObject* WorldContextObject, struct APlayerController* PlayerController, TScriptInterface<struct UTurnBasedMatchInterface> MatchActor, int32 MinPlayers, int32 MaxPlayers, int32 PlayerGroup, bool ShowExistingMatches); // Function OnlineSubsystemUtils.FindTurnBasedMatchCallbackProxy.FindTurnBasedMatch // Final|Native|Static|Public|BlueprintCallable // @ game+0x5d231d4
};

// Class OnlineSubsystemUtils.InAppPurchaseCallbackProxy
// Size: 0xd0 (Inherited: 0x38)
struct UInAppPurchaseCallbackProxy : UObject {
	struct FMulticastDelegate OnSuccess; // 0x38(0x10)
	struct FMulticastDelegate OnFailure; // 0x48(0x10)
	char pad_58[0x78]; // 0x58(0x78)

	struct UInAppPurchaseCallbackProxy* CreateProxyObjectForInAppPurchase(struct APlayerController* PlayerController, struct FInAppPurchaseProductRequest ProductRequest); // Function OnlineSubsystemUtils.InAppPurchaseCallbackProxy.CreateProxyObjectForInAppPurchase // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x5d22548
};

// Class OnlineSubsystemUtils.InAppPurchaseQueryCallbackProxy
// Size: 0xe0 (Inherited: 0x38)
struct UInAppPurchaseQueryCallbackProxy : UObject {
	struct FMulticastDelegate OnSuccess; // 0x38(0x10)
	struct FMulticastDelegate OnFailure; // 0x48(0x10)
	char pad_58[0x88]; // 0x58(0x88)

	struct UInAppPurchaseQueryCallbackProxy* CreateProxyObjectForInAppPurchaseQuery(struct APlayerController* PlayerController, struct TArray<struct FString> ProductIdentifiers); // Function OnlineSubsystemUtils.InAppPurchaseQueryCallbackProxy.CreateProxyObjectForInAppPurchaseQuery // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x5d22664
};

// Class OnlineSubsystemUtils.InAppPurchaseRestoreCallbackProxy
// Size: 0xe0 (Inherited: 0x38)
struct UInAppPurchaseRestoreCallbackProxy : UObject {
	struct FMulticastDelegate OnSuccess; // 0x38(0x10)
	struct FMulticastDelegate OnFailure; // 0x48(0x10)
	char pad_58[0x88]; // 0x58(0x88)

	struct UInAppPurchaseRestoreCallbackProxy* CreateProxyObjectForInAppPurchaseRestore(struct TArray<struct FInAppPurchaseProductRequest> ConsumableProductFlags, struct APlayerController* PlayerController); // Function OnlineSubsystemUtils.InAppPurchaseRestoreCallbackProxy.CreateProxyObjectForInAppPurchaseRestore // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x5d2277c
};

// Class OnlineSubsystemUtils.IpNetDriver
// Size: 0x500 (Inherited: 0x4d0)
struct UIpNetDriver : UNetDriver {
	char LogPortUnreach : 1; // 0x4d0(0x01)
	char AllowPlayerPortUnreach : 1; // 0x4d0(0x01)
	char pad_4D0_2 : 6; // 0x4d0(0x01)
	char pad_4D1[0x3]; // 0x4d1(0x03)
	uint32 MaxPortCountToTry; // 0x4d4(0x04)
	char pad_4D8[0x18]; // 0x4d8(0x18)
	uint32 ServerDesiredSocketReceiveBufferBytes; // 0x4f0(0x04)
	uint32 ServerDesiredSocketSendBufferBytes; // 0x4f4(0x04)
	uint32 ClientDesiredSocketReceiveBufferBytes; // 0x4f8(0x04)
	uint32 ClientDesiredSocketSendBufferBytes; // 0x4fc(0x04)
};

// Class OnlineSubsystemUtils.JoinSessionCallbackProxy
// Size: 0x170 (Inherited: 0x38)
struct UJoinSessionCallbackProxy : UOnlineBlueprintCallProxyBase {
	struct FMulticastDelegate OnSuccess; // 0x38(0x10)
	struct FMulticastDelegate OnFailure; // 0x48(0x10)
	char pad_58[0x118]; // 0x58(0x118)

	struct UJoinSessionCallbackProxy* JoinSession(struct UObject* WorldContextObject, struct APlayerController* PlayerController, struct FBlueprintSessionResult SearchResult); // Function OnlineSubsystemUtils.JoinSessionCallbackProxy.JoinSession // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x5d24598
};

// Class OnlineSubsystemUtils.LeaderboardBlueprintLibrary
// Size: 0x38 (Inherited: 0x38)
struct ULeaderboardBlueprintLibrary : UBlueprintFunctionLibrary {

	bool WriteLeaderboardInteger(struct APlayerController* PlayerController, struct FName StatName, int32 StatValue); // Function OnlineSubsystemUtils.LeaderboardBlueprintLibrary.WriteLeaderboardInteger // Final|Native|Static|Public|BlueprintCallable // @ game+0x5d25304
};

// Class OnlineSubsystemUtils.LeaderboardFlushCallbackProxy
// Size: 0xb0 (Inherited: 0x38)
struct ULeaderboardFlushCallbackProxy : UObject {
	struct FMulticastDelegate OnSuccess; // 0x38(0x10)
	struct FMulticastDelegate OnFailure; // 0x48(0x10)
	char pad_58[0x58]; // 0x58(0x58)

	struct ULeaderboardFlushCallbackProxy* CreateProxyObjectForFlush(struct APlayerController* PlayerController, struct FName SessionName); // Function OnlineSubsystemUtils.LeaderboardFlushCallbackProxy.CreateProxyObjectForFlush // Final|Native|Static|Public|BlueprintCallable // @ game+0x5d2246c
};

// Class OnlineSubsystemUtils.LeaderboardQueryCallbackProxy
// Size: 0xe0 (Inherited: 0x38)
struct ULeaderboardQueryCallbackProxy : UObject {
	struct FMulticastDelegate OnSuccess; // 0x38(0x10)
	struct FMulticastDelegate OnFailure; // 0x48(0x10)
	char pad_58[0x88]; // 0x58(0x88)

	struct ULeaderboardQueryCallbackProxy* CreateProxyObjectForIntQuery(struct APlayerController* PlayerController, struct FName StatName); // Function OnlineSubsystemUtils.LeaderboardQueryCallbackProxy.CreateProxyObjectForIntQuery // Final|Native|Static|Public|BlueprintCallable // @ game+0x5d228c4
};

// Class OnlineSubsystemUtils.LogoutCallbackProxy
// Size: 0x70 (Inherited: 0x38)
struct ULogoutCallbackProxy : UBlueprintAsyncActionBase {
	struct FMulticastDelegate OnSuccess; // 0x38(0x10)
	struct FMulticastDelegate OnFailure; // 0x48(0x10)
	char pad_58[0x18]; // 0x58(0x18)

	struct ULogoutCallbackProxy* Logout(struct UObject* WorldContextObject, struct APlayerController* PlayerController); // Function OnlineSubsystemUtils.LogoutCallbackProxy.Logout // Final|Native|Static|Public|BlueprintCallable // @ game+0x5d24788
};

// Class OnlineSubsystemUtils.OnlineBeacon
// Size: 0x418 (Inherited: 0x3f0)
struct AOnlineBeacon : AActor {
	char pad_3F0[0x8]; // 0x3f0(0x08)
	float BeaconConnectionInitialTimeout; // 0x3f8(0x04)
	float BeaconConnectionTimeout; // 0x3fc(0x04)
	struct UNetDriver* NetDriver; // 0x400(0x08)
	char pad_408[0x10]; // 0x408(0x10)
};

// Class OnlineSubsystemUtils.OnlineBeaconClient
// Size: 0x4a0 (Inherited: 0x418)
struct AOnlineBeaconClient : AOnlineBeacon {
	struct AOnlineBeaconHostObject* BeaconOwner; // 0x418(0x08)
	struct UNetConnection* BeaconConnection; // 0x420(0x08)
	enum class EBeaconConnectionState ConnectionState; // 0x428(0x01)
	char pad_429[0x77]; // 0x429(0x77)

	void ClientOnConnected(); // Function OnlineSubsystemUtils.OnlineBeaconClient.ClientOnConnected // Final|Net|NetReliableNative|Event|Private|NetClient // @ game+0x4d679f8
};

// Class OnlineSubsystemUtils.PartyBeaconState
// Size: 0x80 (Inherited: 0x38)
struct UPartyBeaconState : UObject {
	struct FName SessionName; // 0x38(0x08)
	int32 NumConsumedReservations; // 0x40(0x04)
	int32 MaxReservations; // 0x44(0x04)
	int32 NumTeams; // 0x48(0x04)
	int32 NumPlayersPerTeam; // 0x4c(0x04)
	struct FName TeamAssignmentMethod; // 0x50(0x08)
	int32 ReservedHostTeamNum; // 0x58(0x04)
	int32 ForceTeamNum; // 0x5c(0x04)
	struct TArray<struct FPartyReservation> Reservations; // 0x60(0x10)
	char pad_70[0x10]; // 0x70(0x10)
};

// Class OnlineSubsystemUtils.PartyBeaconClient
// Size: 0x5d0 (Inherited: 0x4a0)
struct APartyBeaconClient : AOnlineBeaconClient {
	char pad_4A0[0xc0]; // 0x4a0(0xc0)
	struct FString DestSessionId; // 0x560(0x10)
	struct FPartyReservation PendingReservation; // 0x570(0x30)
	enum class EClientRequestType RequestType; // 0x5a0(0x01)
	bool bPendingReservationSent; // 0x5a1(0x01)
	bool bCancelReservation; // 0x5a2(0x01)
	char pad_5A3[0x2d]; // 0x5a3(0x2d)

	void ServerUpdateReservationRequest(struct FString SessionId, struct FPartyReservation ReservationUpdate); // Function OnlineSubsystemUtils.PartyBeaconClient.ServerUpdateReservationRequest // Net|NetReliableNative|Event|Protected|NetServer|NetValidate // @ game+0x5d24eb8
	void ServerReservationRequest(struct FString SessionId, struct FPartyReservation Reservation); // Function OnlineSubsystemUtils.PartyBeaconClient.ServerReservationRequest // Net|NetReliableNative|Event|Protected|NetServer|NetValidate // @ game+0x5d24d04
	void ServerCancelReservationRequest(struct FUniqueNetIdRepl PartyLeader); // Function OnlineSubsystemUtils.PartyBeaconClient.ServerCancelReservationRequest // Net|NetReliableNative|Event|Protected|NetServer|NetValidate // @ game+0x5d24ba8
	void ClientSendReservationUpdates(int32 NumRemainingReservations); // Function OnlineSubsystemUtils.PartyBeaconClient.ClientSendReservationUpdates // Net|NetReliableNative|Event|Public|NetClient // @ game+0x5d222fc
	void ClientSendReservationFull(); // Function OnlineSubsystemUtils.PartyBeaconClient.ClientSendReservationFull // Net|NetReliableNative|Event|Public|NetClient // @ game+0xab7ee8
	void ClientReservationResponse(enum class EPartyReservationResult ReservationResponse); // Function OnlineSubsystemUtils.PartyBeaconClient.ClientReservationResponse // Net|NetReliableNative|Event|Public|NetClient // @ game+0x5d22264
	void ClientCancelReservationResponse(enum class EPartyReservationResult ReservationResponse); // Function OnlineSubsystemUtils.PartyBeaconClient.ClientCancelReservationResponse // Net|NetReliableNative|Event|Public|NetClient // @ game+0x5d221cc
};

// Class OnlineSubsystemUtils.TestBeaconClient
// Size: 0x4a0 (Inherited: 0x4a0)
struct ATestBeaconClient : AOnlineBeaconClient {

	void ServerPong(); // Function OnlineSubsystemUtils.TestBeaconClient.ServerPong // Net|NetReliableNative|Event|Public|NetServer|NetValidate // @ game+0x5d24cb8
	void ClientPing(); // Function OnlineSubsystemUtils.TestBeaconClient.ClientPing // Net|NetReliableNative|Event|Public|NetClient // @ game+0x4d8c7b4
};

// Class OnlineSubsystemUtils.OnlineBeaconHost
// Size: 0x4d0 (Inherited: 0x418)
struct AOnlineBeaconHost : AOnlineBeacon {
	int32 ListenPort; // 0x418(0x04)
	char pad_41C[0x4]; // 0x41c(0x04)
	struct TArray<struct AOnlineBeaconClient*> ClientActors; // 0x420(0x10)
	char pad_430[0xa0]; // 0x430(0xa0)
};

// Class OnlineSubsystemUtils.OnlineBeaconHostObject
// Size: 0x418 (Inherited: 0x3f0)
struct AOnlineBeaconHostObject : AActor {
	struct FString BeaconTypeName; // 0x3f0(0x10)
	struct UClass* ClientBeaconActorClass; // 0x400(0x08)
	struct TArray<struct AOnlineBeaconClient*> ClientActors; // 0x408(0x10)
};

// Class OnlineSubsystemUtils.PartyBeaconHost
// Size: 0x570 (Inherited: 0x418)
struct APartyBeaconHost : AOnlineBeaconHostObject {
	struct UPartyBeaconState* State; // 0x418(0x08)
	char pad_420[0x140]; // 0x420(0x140)
	bool bLogoutOnSessionTimeout; // 0x560(0x01)
	char pad_561[0x3]; // 0x561(0x03)
	float SessionTimeoutSecs; // 0x564(0x04)
	float TravelSessionTimeoutSecs; // 0x568(0x04)
	char pad_56C[0x4]; // 0x56c(0x04)
};

// Class OnlineSubsystemUtils.TestBeaconHost
// Size: 0x418 (Inherited: 0x418)
struct ATestBeaconHost : AOnlineBeaconHostObject {
};

// Class OnlineSubsystemUtils.OnlineEngineInterfaceImpl
// Size: 0x180 (Inherited: 0x38)
struct UOnlineEngineInterfaceImpl : UOnlineEngineInterface {
	struct FName VoiceSubsystemNameOverride; // 0x38(0x08)
	char pad_40[0x140]; // 0x40(0x140)
};

// Class OnlineSubsystemUtils.OnlinePIESettings
// Size: 0x60 (Inherited: 0x48)
struct UOnlinePIESettings : UDeveloperSettings {
	bool bOnlinePIEEnabled; // 0x48(0x01)
	char pad_49[0x7]; // 0x49(0x07)
	struct TArray<struct FPIELoginSettingsInternal> Logins; // 0x50(0x10)
};

// Class OnlineSubsystemUtils.OnlineSessionClient
// Size: 0x2d0 (Inherited: 0x38)
struct UOnlineSessionClient : UOnlineSession {
	char pad_38[0x288]; // 0x38(0x288)
	bool bIsFromInvite; // 0x2c0(0x01)
	bool bHandlingDisconnect; // 0x2c1(0x01)
	char pad_2C2[0xe]; // 0x2c2(0x0e)
};

// Class OnlineSubsystemUtils.QuitMatchCallbackProxy
// Size: 0x80 (Inherited: 0x38)
struct UQuitMatchCallbackProxy : UOnlineBlueprintCallProxyBase {
	struct FMulticastDelegate OnSuccess; // 0x38(0x10)
	struct FMulticastDelegate OnFailure; // 0x48(0x10)
	char pad_58[0x28]; // 0x58(0x28)

	struct UQuitMatchCallbackProxy* QuitMatch(struct UObject* WorldContextObject, struct APlayerController* PlayerController, struct FString MatchId, enum class EMPMatchOutcome Outcome, int32 TurnTimeoutInSeconds); // Function OnlineSubsystemUtils.QuitMatchCallbackProxy.QuitMatch // Final|Native|Static|Public|BlueprintCallable // @ game+0x5d24864
};

// Class OnlineSubsystemUtils.ShowLoginUICallbackProxy
// Size: 0x68 (Inherited: 0x38)
struct UShowLoginUICallbackProxy : UBlueprintAsyncActionBase {
	struct FMulticastDelegate OnSuccess; // 0x38(0x10)
	struct FMulticastDelegate OnFailure; // 0x48(0x10)
	char pad_58[0x10]; // 0x58(0x10)

	struct UShowLoginUICallbackProxy* ShowExternalLoginUI(struct UObject* WorldContextObject, struct APlayerController* InPlayerController); // Function OnlineSubsystemUtils.ShowLoginUICallbackProxy.ShowExternalLoginUI // Final|Native|Static|Public|BlueprintCallable // @ game+0x5d2506c
};

// Class OnlineSubsystemUtils.TurnBasedBlueprintLibrary
// Size: 0x38 (Inherited: 0x38)
struct UTurnBasedBlueprintLibrary : UBlueprintFunctionLibrary {

	void RegisterTurnBasedMatchInterfaceObject(struct UObject* WorldContextObject, struct APlayerController* PlayerController, struct UObject* Object); // Function OnlineSubsystemUtils.TurnBasedBlueprintLibrary.RegisterTurnBasedMatchInterfaceObject // Final|Native|Static|Public|BlueprintCallable // @ game+0x5d24a90
	void GetPlayerDisplayName(struct UObject* WorldContextObject, struct APlayerController* PlayerController, struct FString MatchId, int32 PlayerIndex, struct FString PlayerDisplayName); // Function OnlineSubsystemUtils.TurnBasedBlueprintLibrary.GetPlayerDisplayName // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x5d24184
	void GetMyPlayerIndex(struct UObject* WorldContextObject, struct APlayerController* PlayerController, struct FString MatchId, int32 PlayerIndex); // Function OnlineSubsystemUtils.TurnBasedBlueprintLibrary.GetMyPlayerIndex // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x5d23e5c
	void GetIsMyTurn(struct UObject* WorldContextObject, struct APlayerController* PlayerController, struct FString MatchId, bool bIsMyTurn); // Function OnlineSubsystemUtils.TurnBasedBlueprintLibrary.GetIsMyTurn // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x5d23b38
};

