// BlueprintGeneratedClass Buff_DecreaseBreathInHolding.Buff_DecreaseBreathInHolding_C
// Size: 0x4a0 (Inherited: 0x480)
struct ABuff_DecreaseBreathInHolding_C : ACharacterBreathBuff {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x480(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x488(0x08)
	struct FTslStringClass BuffClass; // 0x490(0x10)

	void UserConstructionScript(); // Function Buff_DecreaseBreathInHolding.Buff_DecreaseBreathInHolding_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void TickBuff(struct ATslCharacter* OtherCharacter); // Function Buff_DecreaseBreathInHolding.Buff_DecreaseBreathInHolding_C.TickBuff // Event|Public|BlueprintEvent // @ game+0x33e45c
	void ExecuteUbergraph_Buff_DecreaseBreathInHolding(int32 EntryPoint); // Function Buff_DecreaseBreathInHolding.Buff_DecreaseBreathInHolding_C.ExecuteUbergraph_Buff_DecreaseBreathInHolding //  // @ game+0x33e45c
};

