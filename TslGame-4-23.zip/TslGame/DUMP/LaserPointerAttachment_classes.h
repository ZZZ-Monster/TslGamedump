// BlueprintGeneratedClass LaserPointerAttachment.LaserPointerAttachment_C
// Size: 0xc70 (Inherited: 0xc70)
struct ULaserPointerAttachment_C : UTslLaserPointerAttachment {
};

