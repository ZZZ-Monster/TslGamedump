// BlueprintGeneratedClass LobbyParachute.LobbyParachute_C
// Size: 0x430 (Inherited: 0x430)
struct ALobbyParachute_C : ALobbyParachute {

	void UserConstructionScript(); // Function LobbyParachute.LobbyParachute_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
};

