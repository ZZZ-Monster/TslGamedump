// Class AkAudio.AkAutoPlayInterface
// Size: 0x38 (Inherited: 0x38)
struct UAkAutoPlayInterface : UInterface {
};

// Class AkAudio.AkAmbientSound
// Size: 0x410 (Inherited: 0x3f0)
struct AAkAmbientSound : AActor {
	char pad_3F0[0x10]; // 0x3f0(0x10)
	struct UAkComponent* AkComponent; // 0x400(0x08)
	bool AutoPost; // 0x408(0x01)
	char pad_409[0x3]; // 0x409(0x03)
	float AutoPlayDistance; // 0x40c(0x04)

	void StopAmbientSound(); // Function AkAudio.AkAmbientSound.StopAmbientSound // Final|BlueprintCosmetic|Native|Public|BlueprintCallable // @ game+0x5cd0670
	void StartAmbientSound(); // Function AkAudio.AkAmbientSound.StartAmbientSound // Final|BlueprintCosmetic|Native|Public|BlueprintCallable // @ game+0x5cd0388
	bool IsCurrentlyPlaying(); // Function AkAudio.AkAmbientSound.IsCurrentlyPlaying // Final|Native|Public|BlueprintCallable // @ game+0x5ccea94
};

// Class AkAudio.AkAudioBank
// Size: 0x40 (Inherited: 0x38)
struct UAkAudioBank : UObject {
	bool AutoLoad; // 0x38(0x01)
	char pad_39[0x7]; // 0x39(0x07)
};

// Class AkAudio.AkAudioEvent
// Size: 0x50 (Inherited: 0x38)
struct UAkAudioEvent : UObject {
	struct UAkAudioBank* RequiredBank; // 0x38(0x08)
	float MaxAttenuationRadius; // 0x40(0x04)
	bool IsInfinite; // 0x44(0x01)
	char pad_45[0x3]; // 0x45(0x03)
	float MinimumDuration; // 0x48(0x04)
	float MaximumDuration; // 0x4c(0x04)
};

// Class AkAudio.AkAuxBus
// Size: 0x48 (Inherited: 0x38)
struct UAkAuxBus : UObject {
	struct UAkAudioBank* RequiredBank; // 0x38(0x08)
	char pad_40[0x8]; // 0x40(0x08)
};

// Class AkAudio.AkComponent
// Size: 0x6c0 (Inherited: 0x4b0)
struct UAkComponent : USceneComponent {
	char pad_4B0[0x10]; // 0x4b0(0x10)
	bool StopWhenOwnerDestroyed; // 0x4c0(0x01)
	bool bUseDoppler; // 0x4c1(0x01)
	char pad_4C2[0x2]; // 0x4c2(0x02)
	float AttenuationScalingFactor; // 0x4c4(0x04)
	struct UAkAudioEvent* AkAudioEvent; // 0x4c8(0x08)
	struct FString EventName; // 0x4d0(0x10)
	char pad_4E0[0x4]; // 0x4e0(0x04)
	bool bUseReverbVolumes; // 0x4e4(0x01)
	char pad_4E5[0x87]; // 0x4e5(0x87)
	struct FAkOcclusionSettings OcclusionSettings; // 0x56c(0x10)
	char pad_57C[0xa8]; // 0x57c(0xa8)
	float LastRelativeSpeed; // 0x624(0x04)
	char pad_628[0x98]; // 0x628(0x98)

	void UseVolumesForRTPCs(bool inUseVolumesForRTPCs); // Function AkAudio.AkComponent.UseVolumesForRTPCs // Final|BlueprintCosmetic|Native|Public|BlueprintCallable // @ game+0x5cd0b0c
	void UseReverbVolumes(bool inUseReverbVolumes); // Function AkAudio.AkComponent.UseReverbVolumes // Final|BlueprintCosmetic|Native|Public|BlueprintCallable // @ game+0x5cd09a4
	void UseIndoorCheck(bool inUseIndoorCheck); // Function AkAudio.AkComponent.UseIndoorCheck // Final|BlueprintCosmetic|Native|Public|BlueprintCallable // @ game+0x5cd0914
	void StopPlayingID(int32 PlayingID); // Function AkAudio.AkComponent.StopPlayingID // Final|Native|Public|BlueprintCallable // @ game+0x5cd068c
	void Stop(); // Function AkAudio.AkComponent.Stop // Final|BlueprintCosmetic|Native|Public|BlueprintCallable // @ game+0x5cd0530
	void SetSwitch(struct FString SwitchGroup, struct FString SwitchState); // Function AkAudio.AkComponent.SetSwitch // Final|BlueprintCosmetic|Native|Public|BlueprintCallable // @ game+0xd4e9d4
	void SetStopWhenOwnerDestroyed(bool bStopWhenOwnerDestroyed); // Function AkAudio.AkComponent.SetStopWhenOwnerDestroyed // Final|BlueprintCosmetic|Native|Public|BlueprintCallable // @ game+0x5cd0160
	void SetRTPCValue(struct FString RTPC, float Value, int32 InterpolationTimeMs); // Function AkAudio.AkComponent.SetRTPCValue // Final|BlueprintCosmetic|Native|Public|BlueprintCallable // @ game+0x8e8710
	void SetOutputBusVolume(float BusVolume); // Function AkAudio.AkComponent.SetOutputBusVolume // Final|BlueprintCosmetic|Native|Public|BlueprintCallable // @ game+0x5ccfdac
	void SetMinVolumeRTPCUpdateInterval(float Interval); // Function AkAudio.AkComponent.SetMinVolumeRTPCUpdateInterval // Final|BlueprintCosmetic|Native|Public|BlueprintCallable // @ game+0x5ccfd14
	void SetAttenuationScalingFactor(float Value); // Function AkAudio.AkComponent.SetAttenuationScalingFactor // BlueprintCosmetic|Native|Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x5ccfc78
	void SetActiveListeners(int32 in_uListenerMask); // Function AkAudio.AkComponent.SetActiveListeners // BlueprintCosmetic|Native|Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x5ccfbe4
	void PostTrigger(struct FString Trigger); // Function AkAudio.AkComponent.PostTrigger // Final|BlueprintCosmetic|Native|Public|BlueprintCallable // @ game+0x5ccf9d0
	int32 PostAssociatedAkEvent(); // Function AkAudio.AkComponent.PostAssociatedAkEvent // Final|BlueprintCosmetic|Native|Public|BlueprintCallable // @ game+0xe1d378
	int32 PostAkEventByName(struct FString in_EventName); // Function AkAudio.AkComponent.PostAkEventByName // Final|BlueprintCosmetic|Native|Public|BlueprintCallable // @ game+0x5ccef24
	int32 PostAkEvent(struct UAkAudioEvent* AkEvent, struct FString in_EventName); // Function AkAudio.AkComponent.PostAkEvent // Final|BlueprintCosmetic|Native|Public|BlueprintCallable // @ game+0x5ccee0c
	bool IsUsingVolumesForRTPCs(); // Function AkAudio.AkComponent.IsUsingVolumesForRTPCs // Final|BlueprintCosmetic|Native|Public|BlueprintCallable // @ game+0x5cceae4
	bool IsCurrentlyPlaying(); // Function AkAudio.AkComponent.IsCurrentlyPlaying // Final|Native|Public|BlueprintCallable // @ game+0x5cceac0
	float GetAttenuationRadius(); // Function AkAudio.AkComponent.GetAttenuationRadius // BlueprintCosmetic|Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const // @ game+0x5ccea68
	void CalculateRelativeSpeed(float DeltaTime); // Function AkAudio.AkComponent.CalculateRelativeSpeed // Final|Native|Public|BlueprintCallable // @ game+0x5cce830
};

// Class AkAudio.AkGameplayStatics
// Size: 0x38 (Inherited: 0x38)
struct UAkGameplayStatics : UBlueprintFunctionLibrary {

	void UseReverbVolumes(bool inUseReverbVolumes, struct AActor* Actor); // Function AkAudio.AkGameplayStatics.UseReverbVolumes // Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable // @ game+0x5cd0a34
	void UnloadBankByName(struct FString BankName); // Function AkAudio.AkGameplayStatics.UnloadBankByName // Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable // @ game+0x5cd0864
	void UnloadBank(struct UAkAudioBank* Bank, struct FString BankName); // Function AkAudio.AkGameplayStatics.UnloadBank // Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable // @ game+0x5cd074c
	void StopProfilerCapture(); // Function AkAudio.AkGameplayStatics.StopProfilerCapture // Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable // @ game+0x5cd071c
	void StopOutputCapture(); // Function AkAudio.AkGameplayStatics.StopOutputCapture // Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable // @ game+0x4d7ebd8
	void StopAllAmbientSounds(struct UObject* WorldContextObject); // Function AkAudio.AkGameplayStatics.StopAllAmbientSounds // Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable // @ game+0x5cd05f0
	void StopAll(); // Function AkAudio.AkGameplayStatics.StopAll // Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable // @ game+0x5cd05c4
	void StopActor(struct AActor* Actor); // Function AkAudio.AkGameplayStatics.StopActor // Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable // @ game+0x5cd0544
	void StartProfilerCapture(struct FString FileName); // Function AkAudio.AkGameplayStatics.StartProfilerCapture // Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable // @ game+0x5cd0480
	void StartOutputCapture(struct FString FileName); // Function AkAudio.AkGameplayStatics.StartOutputCapture // Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable // @ game+0x5cd03d0
	void StartAllAmbientSounds(struct UObject* WorldContextObject); // Function AkAudio.AkGameplayStatics.StartAllAmbientSounds // Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable // @ game+0x5cd0308
	struct UAkComponent* SpawnAkComponentAtLocation(struct UObject* WorldContextObject, struct UAkAudioEvent* AkEvent, struct FVector Location, struct FRotator Orientation, bool AutoPost, struct FString EventName, bool AutoDestroy); // Function AkAudio.AkGameplayStatics.SpawnAkComponentAtLocation // Final|BlueprintCosmetic|Native|Static|Public|HasDefaults|BlueprintCallable // @ game+0x68affc
	void SetSwitch(struct FName SwitchGroup, struct FName SwitchState, struct AActor* Actor); // Function AkAudio.AkGameplayStatics.SetSwitch // Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable // @ game+0x5cd01f0
	void SetState(struct FName StateGroup, struct FName State); // Function AkAudio.AkGameplayStatics.SetState // Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable // @ game+0x5cd0088
	void SetRTPCValue(struct FName RTPC, float Value, int32 InterpolationTimeMs, struct AActor* Actor); // Function AkAudio.AkGameplayStatics.SetRTPCValue // Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable // @ game+0x5ccff20
	void SetOutputBusVolume(float BusVolume, struct AActor* Actor); // Function AkAudio.AkGameplayStatics.SetOutputBusVolume // Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable // @ game+0x5ccfe44
	void PostTrigger(struct FName Trigger, struct AActor* Actor); // Function AkAudio.AkGameplayStatics.PostTrigger // Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable // @ game+0x5ccfb0c
	void PostEventByName(struct FString EventName, struct AActor* Actor, bool bStopWhenAttachedToDestroyed); // Function AkAudio.AkGameplayStatics.PostEventByName // Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable // @ game+0x5ccf874
	int32 PostEventAttached(struct UAkAudioEvent* AkEvent, struct AActor* Actor, struct FName AttachPointName, bool bStopWhenAttachedToDestroyed, struct FString EventName); // Function AkAudio.AkGameplayStatics.PostEventAttached // Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable // @ game+0x5ccf64c
	void PostEventAtLocationByName(struct FString EventName, struct FVector Location, struct FRotator Orientation, struct UObject* WorldContextObject, bool UseReverb); // Function AkAudio.AkGameplayStatics.PostEventAtLocationByName // Final|BlueprintCosmetic|Native|Static|Public|HasDefaults|BlueprintCallable // @ game+0x5ccf430
	int32 PostEventAtLocation(struct UAkAudioEvent* AkEvent, struct FVector Location, struct FRotator Orientation, struct FString EventName, struct UObject* WorldContextObject, bool UseReverb); // Function AkAudio.AkGameplayStatics.PostEventAtLocation // Final|BlueprintCosmetic|Native|Static|Public|HasDefaults|BlueprintCallable // @ game+0x5ccf1c8
	int32 PostEvent(struct UAkAudioEvent* AkEvent, struct AActor* Actor, bool bStopWhenAttachedToDestroyed, struct FString EventName); // Function AkAudio.AkGameplayStatics.PostEvent // Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable // @ game+0x5cceff0
	void LoadInitBank(); // Function AkAudio.AkGameplayStatics.LoadInitBank // Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable // @ game+0x5ccede4
	void LoadBanks(struct TArray<struct UAkAudioBank*> SoundBanks, bool SynchronizeSoundBanks); // Function AkAudio.AkGameplayStatics.LoadBanks // Final|BlueprintCosmetic|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x5ccecc4
	void LoadBankByName(struct FString BankName); // Function AkAudio.AkGameplayStatics.LoadBankByName // Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable // @ game+0x5ccec14
	void LoadBank(struct UAkAudioBank* Bank, struct FString BankName); // Function AkAudio.AkGameplayStatics.LoadBank // Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable // @ game+0x5cceafc
	struct UAkComponent* GetAkComponent(struct USceneComponent* AttachToComponent, struct FName AttachPointName, struct FVector Location, enum class EAttachLocation LocationType); // Function AkAudio.AkGameplayStatics.GetAkComponent // Final|BlueprintCosmetic|Native|Static|Public|HasDefaults|BlueprintCallable // @ game+0x5cce8f0
	void ClearBanks(); // Function AkAudio.AkGameplayStatics.ClearBanks // Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable // @ game+0x5cce8c8
	void AddOutputCaptureMarker(struct FString MarkerText); // Function AkAudio.AkGameplayStatics.AddOutputCaptureMarker // Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable // @ game+0x5cce774
};

// Class AkAudio.AkReverbVolume
// Size: 0x460 (Inherited: 0x428)
struct AAkReverbVolume : AVolume {
	char bEnabled : 1; // 0x428(0x01)
	char pad_428_1 : 7; // 0x428(0x01)
	char pad_429[0x7]; // 0x429(0x07)
	struct UAkAuxBus* AuxBus; // 0x430(0x08)
	struct FString AuxBusName; // 0x438(0x10)
	float SendLevel; // 0x448(0x04)
	float FadeRate; // 0x44c(0x04)
	float Priority; // 0x450(0x04)
	char pad_454[0x4]; // 0x454(0x04)
	struct AAkReverbVolume* NextLowerPriorityAkReverbVolume; // 0x458(0x08)
};

// Class AkAudio.AkSettings
// Size: 0xb0 (Inherited: 0x38)
struct UAkSettings : UObject {
	bool MaxSimultaneousReverbVolumes; // 0x38(0x01)
	char pad_39[0x7]; // 0x39(0x07)
	struct FFilePath WwiseProjectPath; // 0x40(0x10)
	struct FDirectoryPath WwiseWindowsInstallationPath; // 0x50(0x10)
	struct FFilePath WwiseMacInstallationPath; // 0x60(0x10)
	bool SuppressWwiseProjectPathWarnings; // 0x70(0x01)
	char pad_71[0x3f]; // 0x71(0x3f)
};

// Class AkAudio.AkSoundVolume
// Size: 0x3f8 (Inherited: 0x3f0)
struct AAkSoundVolume : AActor {
	struct UAkSoundVolumeComponent* SoundVolumeComponent; // 0x3f0(0x08)
};

// Class AkAudio.AkSoundVolumeComponentBase
// Size: 0x4c0 (Inherited: 0x4b0)
struct UAkSoundVolumeComponentBase : USceneComponent {
	char pad_4B0[0x10]; // 0x4b0(0x10)
};

// Class AkAudio.AkSoundVolumeComponent
// Size: 0x610 (Inherited: 0x4c0)
struct UAkSoundVolumeComponent : UAkSoundVolumeComponentBase {
	struct FAkReverbSoundVolume Struct; // 0x4b8(0x158)
};

// Class AkAudio.AkSoundVolumePortalComponent
// Size: 0x5b0 (Inherited: 0x4c0)
struct UAkSoundVolumePortalComponent : UAkSoundVolumeComponentBase {
	struct FAkReverbSoundVolumePortal Struct; // 0x4c0(0xf0)
};

// Class AkAudio.AkSoundVolumeManager
// Size: 0x1f0 (Inherited: 0x40)
struct UAkSoundVolumeManager : UWorldSubsystem {
	char pad_40[0x150]; // 0x40(0x150)
	struct TMap<struct UObject*, struct FAkVolumesData> VolumeOwnedMap; // 0x190(0x50)
	char pad_1E0[0x10]; // 0x1e0(0x10)
};

// Class AkAudio.AkSoundVolumePortal
// Size: 0x3f8 (Inherited: 0x3f0)
struct AAkSoundVolumePortal : AActor {
	struct UAkSoundVolumePortalComponent* SoundVolumePortalComponent; // 0x3f0(0x08)
};

// Class AkAudio.AkSoundVolumeRTPCs
// Size: 0x50 (Inherited: 0x40)
struct UAkSoundVolumeRTPCs : UDataAsset {
	struct TArray<struct FAkSoundVolumeRTPC> RTPCData; // 0x40(0x10)
};

// Class AkAudio.AkSoundVolumesContainerComponent
// Size: 0x260 (Inherited: 0x200)
struct UAkSoundVolumesContainerComponent : UActorComponent {
	struct TArray<struct FAkReverbSoundVolume> Volumes; // 0x200(0x10)
	struct TArray<struct FAkReverbSoundVolumePortal> Portals; // 0x210(0x10)
	struct TArray<struct FAkReverbSoundVolumeBakedData> VolumesBakedData; // 0x220(0x10)
	struct TArray<struct FAkReverbSoundPortalsBakedData> PortalsBakedData; // 0x230(0x10)
	char pad_240[0x20]; // 0x240(0x20)
};

// Class AkAudio.InterpTrackAkAudioEvent
// Size: 0xb8 (Inherited: 0xa0)
struct UInterpTrackAkAudioEvent : UInterpTrackVectorBase {
	struct TArray<struct FAkAudioEventTrackKey> Events; // 0xa0(0x10)
	char bContinueEventOnMatineeEnd : 1; // 0xb0(0x01)
	char pad_B0_1 : 7; // 0xb0(0x01)
	char pad_B1[0x7]; // 0xb1(0x07)
};

// Class AkAudio.InterpTrackAkAudioRTPC
// Size: 0xb8 (Inherited: 0xa0)
struct UInterpTrackAkAudioRTPC : UInterpTrackFloatBase {
	struct FString Param; // 0xa0(0x10)
	char bPlayOnReverse : 1; // 0xb0(0x01)
	char bContinueRTPCOnMatineeEnd : 1; // 0xb0(0x01)
	char pad_B0_2 : 6; // 0xb0(0x01)
	char pad_B1[0x7]; // 0xb1(0x07)
};

// Class AkAudio.InterpTrackInstAkAudioEvent
// Size: 0x40 (Inherited: 0x38)
struct UInterpTrackInstAkAudioEvent : UInterpTrackInst {
	float LastUpdatePosition; // 0x38(0x04)
	char pad_3C[0x4]; // 0x3c(0x04)
};

// Class AkAudio.InterpTrackInstAkAudioRTPC
// Size: 0x40 (Inherited: 0x38)
struct UInterpTrackInstAkAudioRTPC : UInterpTrackInst {
	float LastUpdatePosition; // 0x38(0x04)
	char pad_3C[0x4]; // 0x3c(0x04)
};

// Class AkAudio.MovieSceneAkAudioEventSection
// Size: 0x100 (Inherited: 0xe0)
struct UMovieSceneAkAudioEventSection : UMovieSceneSection {
	struct UAkAudioEvent* Event; // 0xe0(0x08)
	struct FString EventName; // 0xe8(0x10)
	char pad_F8[0x8]; // 0xf8(0x08)
};

// Class AkAudio.MovieSceneAkAudioRTPCSection
// Size: 0x170 (Inherited: 0xe0)
struct UMovieSceneAkAudioRTPCSection : UMovieSceneSection {
	char pad_E0[0x8]; // 0xe0(0x08)
	struct FString Name; // 0xe8(0x10)
	struct FRichCurve FloatCurve; // 0xf8(0x70)
	char pad_168[0x8]; // 0x168(0x08)
};

// Class AkAudio.MovieSceneAkTrack
// Size: 0xe0 (Inherited: 0xd0)
struct UMovieSceneAkTrack : UMovieSceneTrack {
	struct TArray<struct UMovieSceneSection*> Sections; // 0xc8(0x10)
	char bIsAMasterTrack : 1; // 0xd8(0x01)
};

// Class AkAudio.MovieSceneAkAudioEventTrack
// Size: 0xe0 (Inherited: 0xe0)
struct UMovieSceneAkAudioEventTrack : UMovieSceneAkTrack {
};

// Class AkAudio.MovieSceneAkAudioRTPCTrack
// Size: 0xe0 (Inherited: 0xe0)
struct UMovieSceneAkAudioRTPCTrack : UMovieSceneAkTrack {
};

