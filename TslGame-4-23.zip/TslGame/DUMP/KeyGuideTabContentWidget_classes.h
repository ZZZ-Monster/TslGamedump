// WidgetBlueprintGeneratedClass KeyGuideTabContentWidget.KeyGuideTabContentWidget_C
// Size: 0x528 (Inherited: 0x510)
struct UKeyGuideTabContentWidget_C : UTslTabSelectorContentsWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x510(0x08)
	struct UTextBlock* TitleNormal; // 0x518(0x08)
	struct UTextBlock* TitleSelected; // 0x520(0x08)

	void PreConstruct(bool IsDesignTime); // Function KeyGuideTabContentWidget.KeyGuideTabContentWidget_C.PreConstruct // BlueprintCosmetic|Event|Public|BlueprintEvent // @ game+0x33e45c
	void ExecuteUbergraph_KeyGuideTabContentWidget(int32 EntryPoint); // Function KeyGuideTabContentWidget.KeyGuideTabContentWidget_C.ExecuteUbergraph_KeyGuideTabContentWidget //  // @ game+0x33e45c
};

