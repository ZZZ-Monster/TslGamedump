// BlueprintGeneratedClass BP_TslBaseLobbySceneTravel_FadeInOut.BP_TslBaseLobbySceneTravel_FadeInOut_C
// Size: 0x4c2 (Inherited: 0x480)
struct ABP_TslBaseLobbySceneTravel_FadeInOut_C : ATslBaseLobbySceneTravel {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x480(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x488(0x08)
	float FadeOut_NewTrack_1_8B04B86146E56AB9DBD19681161BF2DF; // 0x490(0x04)
	enum class ETimelineDirection FadeOut__Direction_8B04B86146E56AB9DBD19681161BF2DF; // 0x494(0x01)
	char pad_495[0x3]; // 0x495(0x03)
	struct UTimelineComponent* FadeOut; // 0x498(0x08)
	float FadeIn_NewTrack_0_DC1B4FDE4D7381B0DD0E4589AFE5ADF5; // 0x4a0(0x04)
	enum class ETimelineDirection FadeIn__Direction_DC1B4FDE4D7381B0DD0E4589AFE5ADF5; // 0x4a4(0x01)
	char pad_4A5[0x3]; // 0x4a5(0x03)
	struct UTimelineComponent* FadeIn; // 0x4a8(0x08)
	float FadeInOut_Value_B2D7FECA48EE8B02C48CD780AAAEC96C; // 0x4b0(0x04)
	enum class ETimelineDirection FadeInOut__Direction_B2D7FECA48EE8B02C48CD780AAAEC96C; // 0x4b4(0x01)
	char pad_4B5[0x3]; // 0x4b5(0x03)
	struct UTimelineComponent* FadeInOut; // 0x4b8(0x08)
	bool bStatFadeOut; // 0x4c0(0x01)
	bool bFinishFadeIn; // 0x4c1(0x01)

	void UserConstructionScript(); // Function BP_TslBaseLobbySceneTravel_FadeInOut.BP_TslBaseLobbySceneTravel_FadeInOut_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void FadeInOut__FinishedFunc(); // Function BP_TslBaseLobbySceneTravel_FadeInOut.BP_TslBaseLobbySceneTravel_FadeInOut_C.FadeInOut__FinishedFunc // BlueprintEvent // @ game+0x33e45c
	void FadeInOut__UpdateFunc(); // Function BP_TslBaseLobbySceneTravel_FadeInOut.BP_TslBaseLobbySceneTravel_FadeInOut_C.FadeInOut__UpdateFunc // BlueprintEvent // @ game+0x33e45c
	void FadeIn__FinishedFunc(); // Function BP_TslBaseLobbySceneTravel_FadeInOut.BP_TslBaseLobbySceneTravel_FadeInOut_C.FadeIn__FinishedFunc // BlueprintEvent // @ game+0x33e45c
	void FadeIn__UpdateFunc(); // Function BP_TslBaseLobbySceneTravel_FadeInOut.BP_TslBaseLobbySceneTravel_FadeInOut_C.FadeIn__UpdateFunc // BlueprintEvent // @ game+0x33e45c
	void FadeOut__FinishedFunc(); // Function BP_TslBaseLobbySceneTravel_FadeInOut.BP_TslBaseLobbySceneTravel_FadeInOut_C.FadeOut__FinishedFunc // BlueprintEvent // @ game+0x33e45c
	void FadeOut__UpdateFunc(); // Function BP_TslBaseLobbySceneTravel_FadeInOut.BP_TslBaseLobbySceneTravel_FadeInOut_C.FadeOut__UpdateFunc // BlueprintEvent // @ game+0x33e45c
	void OnStartTravel(); // Function BP_TslBaseLobbySceneTravel_FadeInOut.BP_TslBaseLobbySceneTravel_FadeInOut_C.OnStartTravel // Event|Public|BlueprintEvent // @ game+0x33e45c
	void ReceiveEndPlay(enum class EEndPlayReason EndPlayReason); // Function BP_TslBaseLobbySceneTravel_FadeInOut.BP_TslBaseLobbySceneTravel_FadeInOut_C.ReceiveEndPlay // Event|Public|BlueprintEvent // @ game+0x33e45c
	void ReceiveTick(float DeltaSeconds); // Function BP_TslBaseLobbySceneTravel_FadeInOut.BP_TslBaseLobbySceneTravel_FadeInOut_C.ReceiveTick // Event|Public|BlueprintEvent // @ game+0x33e45c
	void ExecuteUbergraph_BP_TslBaseLobbySceneTravel_FadeInOut(int32 EntryPoint); // Function BP_TslBaseLobbySceneTravel_FadeInOut.BP_TslBaseLobbySceneTravel_FadeInOut_C.ExecuteUbergraph_BP_TslBaseLobbySceneTravel_FadeInOut //  // @ game+0x33e45c
};

