// WidgetBlueprintGeneratedClass BP_PcOptionItemMusicDropDownListWidget.BP_PcOptionItemMusicDropDownListWidget_C
// Size: 0x880 (Inherited: 0x878)
struct UBP_PcOptionItemMusicDropDownListWidget_C : UTslGameOptionItemMusicDropDownListWidget {
	struct UTslUniversalInputComboBoxString* ComboBox; // 0x878(0x08)
};

