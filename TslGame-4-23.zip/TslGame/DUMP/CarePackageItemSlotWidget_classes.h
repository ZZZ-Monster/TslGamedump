// WidgetBlueprintGeneratedClass CarePackageItemSlotWidget.CarePackageItemSlotWidget_C
// Size: 0x460 (Inherited: 0x448)
struct UCarePackageItemSlotWidget_C : UCarePackageItemSlotWidget {
	struct UImage* DestroyedItemTint; // 0x448(0x08)
	struct UImage* DurabilityGauge; // 0x450(0x08)
	struct USizeBox* IconSizeBox; // 0x458(0x08)
};

