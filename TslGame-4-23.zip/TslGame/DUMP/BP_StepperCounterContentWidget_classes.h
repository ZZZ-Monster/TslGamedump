// WidgetBlueprintGeneratedClass BP_StepperCounterContentWidget.BP_StepperCounterContentWidget_C
// Size: 0x458 (Inherited: 0x448)
struct UBP_StepperCounterContentWidget_C : UTslStepperCounterContentWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x448(0x08)
	struct UWidgetSwitcher* StateSwitcher; // 0x450(0x08)

	void UpdateDesign_Selected(); // Function BP_StepperCounterContentWidget.BP_StepperCounterContentWidget_C.UpdateDesign_Selected // Event|Public|BlueprintEvent // @ game+0x33e45c
	void UpdateDesign_Normal(); // Function BP_StepperCounterContentWidget.BP_StepperCounterContentWidget_C.UpdateDesign_Normal // Event|Public|BlueprintEvent // @ game+0x33e45c
	void ExecuteUbergraph_BP_StepperCounterContentWidget(int32 EntryPoint); // Function BP_StepperCounterContentWidget.BP_StepperCounterContentWidget_C.ExecuteUbergraph_BP_StepperCounterContentWidget //  // @ game+0x33e45c
};

