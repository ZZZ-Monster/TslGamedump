// WidgetBlueprintGeneratedClass MainLobbyHUD.MainLobbyHUD_C
// Size: 0x560 (Inherited: 0x260)
struct UMainLobbyHUD_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UButton* Button_NewSystemMenu; // 0x268(0x08)
	struct UButton* Button_Quit; // 0x270(0x08)
	struct UButton* Button_Reload; // 0x278(0x08)
	struct UButton* Button_Setting; // 0x280(0x08)
	struct UInvalidationBox* InvalidationBox_1; // 0x288(0x08)
	struct UInvalidationBox* InvalidationBox_2; // 0x290(0x08)
	struct UImage* LoadingSpinnerImage; // 0x298(0x08)
	struct UVerticalBox* MessageVBox; // 0x2a0(0x08)
	struct UButton* ReplayTestButton; // 0x2a8(0x08)
	struct UScaleBox* StageCurtain; // 0x2b0(0x08)
	struct UCanvasPanel* WebPopupCavas; // 0x2b8(0x08)
	struct ALobbyHUD* HUD; // 0x2c0(0x08)
	int32 ContinousReloadCount; // 0x2c8(0x04)
	char pad_2CC[0x4]; // 0x2cc(0x04)
	struct FDateTime LastReload; // 0x2d0(0x08)
	struct TArray<struct UWebPopup_C*> VisibleWebPopupArray; // 0x2d8(0x10)
	float NameTagHeight; // 0x2e8(0x04)
	char pad_2EC[0x4]; // 0x2ec(0x04)
	struct AReplayList_BP_C* refReplayListBp; // 0x2f0(0x08)
	struct ULobbyNameTagHUD_C* LobbyNameTagHUD; // 0x2f8(0x08)
	struct FHudUiConfig Browser_Config; // 0x300(0x40)
	struct FHudUiConfig LobbyNameTagHUD_Config; // 0x340(0x40)
	struct FHudUiConfig PopupBox_Config; // 0x380(0x40)
	struct FHudUiConfig NewLobbySystemMenu_Config; // 0x3c0(0x40)
	struct FHudUiConfig GameRatingWidget_Config; // 0x400(0x40)
	struct FHudUiConfig ViewModeConfig; // 0x440(0x40)
	struct FHudUiConfig ViewModeHelper; // 0x480(0x40)
	struct FHudUiConfig WebpopupCanvas_Config; // 0x4c0(0x40)
	struct FHudUiConfig LobbyBlur_Config; // 0x500(0x40)
	struct TArray<struct FHudUiConfig> DebugUI; // 0x540(0x10)
	struct FString LobbySystemMenuName; // 0x550(0x10)

	bool HasChildren(); // Function MainLobbyHUD.MainLobbyHUD_C.HasChildren // Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const // @ game+0x33e45c
	void ToggleSystemMenu(); // Function MainLobbyHUD.MainLobbyHUD_C.ToggleSystemMenu // Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void CloseWebPopupImpl(struct FString PopupId); // Function MainLobbyHUD.MainLobbyHUD_C.CloseWebPopupImpl // Public|HasDefaults|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void HideCurtain(); // Function MainLobbyHUD.MainLobbyHUD_C.HideCurtain // Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void ShowCurtain(); // Function MainLobbyHUD.MainLobbyHUD_C.ShowCurtain // Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void OnKey_LobbySystemMenu(); // Function MainLobbyHUD.MainLobbyHUD_C.OnKey_LobbySystemMenu // Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	struct FEventReply OnKeyDown(struct FGeometry MyGeometry, struct FKeyEvent InKeyEvent); // Function MainLobbyHUD.MainLobbyHUD_C.OnKeyDown // BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void OnPrepass_isShipping(struct UWidget* BoundWidget); // Function MainLobbyHUD.MainLobbyHUD_C.OnPrepass_isShipping // Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void CleanUpNameTagWidget(int32 SlotIndex); // Function MainLobbyHUD.MainLobbyHUD_C.CleanUpNameTagWidget // Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void SetupNameTagWidget(int32 SlotIndex); // Function MainLobbyHUD.MainLobbyHUD_C.SetupNameTagWidget // Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void GetNameTagWidget(int32 SlotIndex, struct UTslLobbyNameTagWidget* Widget); // Function MainLobbyHUD.MainLobbyHUD_C.GetNameTagWidget // Public|HasOutParms|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void OnDestroyCharacter(int32 SlotIndex); // Function MainLobbyHUD.MainLobbyHUD_C.OnDestroyCharacter // Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void OnCreateCharacter(int32 SlotIndex); // Function MainLobbyHUD.MainLobbyHUD_C.OnCreateCharacter // Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void CloseWebPopupByID(struct FString WebPopupID); // Function MainLobbyHUD.MainLobbyHUD_C.CloseWebPopupByID // Public|HasDefaults|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void RemoveWebPopup(struct UWebPopup_C* Widget); // Function MainLobbyHUD.MainLobbyHUD_C.RemoveWebPopup // Private|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void AddWebPopup(struct UWebPopup_C* Widget); // Function MainLobbyHUD.MainLobbyHUD_C.AddWebPopup // Private|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void CanShowWebPopup(struct FString PopupId, bool Result); // Function MainLobbyHUD.MainLobbyHUD_C.CanShowWebPopup // Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void ShowWebPopupImpl(struct FWebPopupParam Param); // Function MainLobbyHUD.MainLobbyHUD_C.ShowWebPopupImpl // Public|HasDefaults|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void OnReload(); // Function MainLobbyHUD.MainLobbyHUD_C.OnReload // Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void GetMainCoherentWidget(struct UCoherentUIGTWidget* Browser); // Function MainLobbyHUD.MainLobbyHUD_C.GetMainCoherentWidget // Public|HasOutParms|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void OnKey_SystemMenuOrEscape(); // Function MainLobbyHUD.MainLobbyHUD_C.OnKey_SystemMenuOrEscape // Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void InitializeHUD(); // Function MainLobbyHUD.MainLobbyHUD_C.InitializeHUD // Public|HasDefaults|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void BndEvt__Button_Setting_K2Node_ComponentBoundEvent_190_OnButtonClickedEvent__DelegateSignature(); // Function MainLobbyHUD.MainLobbyHUD_C.BndEvt__Button_Setting_K2Node_ComponentBoundEvent_190_OnButtonClickedEvent__DelegateSignature // BlueprintEvent // @ game+0x33e45c
	void BndEvt__Button_Reload_K2Node_ComponentBoundEvent_210_OnButtonClickedEvent__DelegateSignature(); // Function MainLobbyHUD.MainLobbyHUD_C.BndEvt__Button_Reload_K2Node_ComponentBoundEvent_210_OnButtonClickedEvent__DelegateSignature // BlueprintEvent // @ game+0x33e45c
	void BndEvt__Button_Quit_K2Node_ComponentBoundEvent_229_OnButtonClickedEvent__DelegateSignature(); // Function MainLobbyHUD.MainLobbyHUD_C.BndEvt__Button_Quit_K2Node_ComponentBoundEvent_229_OnButtonClickedEvent__DelegateSignature // BlueprintEvent // @ game+0x33e45c
	void ShowWebPopup(struct FWebPopupParam Param); // Function MainLobbyHUD.MainLobbyHUD_C.ShowWebPopup // Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void Construct(); // Function MainLobbyHUD.MainLobbyHUD_C.Construct // BlueprintCosmetic|Event|Public|BlueprintEvent // @ game+0x33e45c
	void PreloadWebPopup(struct TArray<struct FWebPopupParam> WebPopupParams); // Function MainLobbyHUD.MainLobbyHUD_C.PreloadWebPopup // Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void BndEvt__Button_0_K2Node_ComponentBoundEvent_35_OnButtonClickedEvent__DelegateSignature(); // Function MainLobbyHUD.MainLobbyHUD_C.BndEvt__Button_0_K2Node_ComponentBoundEvent_35_OnButtonClickedEvent__DelegateSignature // BlueprintEvent // @ game+0x33e45c
	void BndEvt__Button_NewSystemMenu_K2Node_ComponentBoundEvent_90_OnButtonClickedEvent__DelegateSignature(); // Function MainLobbyHUD.MainLobbyHUD_C.BndEvt__Button_NewSystemMenu_K2Node_ComponentBoundEvent_90_OnButtonClickedEvent__DelegateSignature // BlueprintEvent // @ game+0x33e45c
	void CloseWebPopup(struct FString PopupId); // Function MainLobbyHUD.MainLobbyHUD_C.CloseWebPopup // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void InitializeMainUMGHUD(); // Function MainLobbyHUD.MainLobbyHUD_C.InitializeMainUMGHUD // Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
	void ExecuteUbergraph_MainLobbyHUD(int32 EntryPoint); // Function MainLobbyHUD.MainLobbyHUD_C.ExecuteUbergraph_MainLobbyHUD // HasDefaults // @ game+0x33e45c
};

