// WidgetBlueprintGeneratedClass BP_CompassWidget.BP_CompassWidget_C
// Size: 0x608 (Inherited: 0x5d0)
struct UBP_CompassWidget_C : UTslCompassWidget {
	struct UImage* Compass_Center; // 0x5d0(0x08)
	struct UVerticalBox* CompassMain; // 0x5d8(0x08)
	struct UInvalidationBox* InvalidationBox_3; // 0x5e0(0x08)
	struct UOverlay* My; // 0x5e8(0x08)
	struct UOverlay* MyMarkerLyaer; // 0x5f0(0x08)
	struct UOverlay* MyPingLayer; // 0x5f8(0x08)
	struct UOverlay* PingLayer; // 0x600(0x08)
};

