// BlueprintGeneratedClass MainMenuPostProcessEffect.MainMenuPostProcessEffect_C
// Size: 0x480 (Inherited: 0x478)
struct AMainMenuPostProcessEffect_C : ATslPostProcessEffect {
	struct USceneComponent* DefaultSceneRoot; // 0x478(0x08)

	void UserConstructionScript(); // Function MainMenuPostProcessEffect.MainMenuPostProcessEffect_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x33e45c
};

