// WidgetBlueprintGeneratedClass PlatoonCarePackageDropIndicator.PlatoonCarePackageDropIndicator_C
// Size: 0x448 (Inherited: 0x428)
struct UPlatoonCarePackageDropIndicator_C : UTslPlatoonCarePackageDropIndicatorWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x428(0x08)
	struct UWidgetSwitcher* ImageSwitcher; // 0x430(0x08)
	struct UImage* OnDelivery; // 0x438(0x08)
	struct UImage* OnGround; // 0x440(0x08)

	void BP_UpdateIconType(enum class EPlatoonCarePackageType Type); // Function PlatoonCarePackageDropIndicator.PlatoonCarePackageDropIndicator_C.BP_UpdateIconType // Event|Public|BlueprintEvent // @ game+0x33e45c
	void BP_UpdateIconImage(enum class EPlatoonSupportRequestEventType IconType); // Function PlatoonCarePackageDropIndicator.PlatoonCarePackageDropIndicator_C.BP_UpdateIconImage // Event|Public|BlueprintEvent // @ game+0x33e45c
	void ExecuteUbergraph_PlatoonCarePackageDropIndicator(int32 EntryPoint); // Function PlatoonCarePackageDropIndicator.PlatoonCarePackageDropIndicator_C.ExecuteUbergraph_PlatoonCarePackageDropIndicator // HasDefaults // @ game+0x33e45c
};

