// Class Engine.Actor
// Size: 0x3f0 (Inherited: 0x38)
struct AActor : UObject {
	struct TArray<struct FName> Tags; // 0x38(0x10)
	char pad_48[0xc]; // 0x48(0x0c)
	float ForceReplicateInterleavingFreq; // 0x54(0x04)
	char pad_58_0 : 3; // 0x58(0x01)
	char bActorEnableCollision : 1; // 0x58(0x01)
	char pad_58_4 : 4; // 0x58(0x01)
	char pad_59_0 : 1; // 0x59(0x01)
	char bReplayRewindable : 1; // 0x59(0x01)
	char bReplicates : 1; // 0x59(0x01)
	char pad_59_3 : 5; // 0x59(0x01)
	char pad_5A[0x6]; // 0x5a(0x06)
	struct FName NetDriverName; // 0x60(0x08)
	enum class ENetRole RemoteRole; // 0x68(0x01)
	char pad_69[0x7]; // 0x69(0x07)
	struct AActor* Owner; // 0x70(0x08)
	struct FRepMovement ReplicatedMovement; // 0x78(0x34)
	char pad_AC[0x4]; // 0xac(0x04)
	struct FRepAttachment AttachmentReplication; // 0xb0(0x40)
	struct APawn* Instigator; // 0xf0(0x08)
	struct TArray<struct AMatineeActor*> ControllingMatineeActors; // 0xf8(0x10)
	enum class EAutoReceiveInput AutoReceiveInput; // 0x108(0x01)
	char pad_109[0x3]; // 0x109(0x03)
	struct FGuid DestructibleId; // 0x10c(0x10)
	bool bIsDestroyedVersion; // 0x11c(0x01)
	bool RemoveFromLevelLOD; // 0x11d(0x01)
	char pad_11E[0x2]; // 0x11e(0x02)
	struct FActorTickFunction PrimaryActorTick; // 0x120(0x58)
	struct UChildActorComponent* ParentComponent; // 0x178(0x08)
	enum class ENetRole Role; // 0x180(0x01)
	char bAutoDestroyWhenFinished : 1; // 0x181(0x01)
	char bCanBeDamaged : 1; // 0x181(0x01)
	char bActorIsBeingDestroyed : 1; // 0x181(0x01)
	char bCollideWhenPlacing : 1; // 0x181(0x01)
	char bFindCameraComponentWhenViewTarget : 1; // 0x181(0x01)
	char bRelevantForNetworkReplays : 1; // 0x181(0x01)
	char bGenerateOverlapEventsDuringLevelStreaming : 1; // 0x181(0x01)
	char bIgnoreDestroyActorFromBlueprint : 1; // 0x181(0x01)
	char bCanBeInCluster : 1; // 0x182(0x01)
	char pad_182_1 : 7; // 0x182(0x01)
	char pad_183[0x5]; // 0x183(0x05)
	struct FMulticastDelegate OnInputTouchBegin; // 0x188(0x10)
	struct FMulticastDelegate OnInputTouchEnter; // 0x198(0x10)
	int32 InputPriority; // 0x1a8(0x04)
	char pad_1AC[0x4]; // 0x1ac(0x04)
	struct FMulticastDelegate OnInputTouchLeave; // 0x1b0(0x10)
	struct FMulticastDelegate OnReleased; // 0x1c0(0x10)
	struct FMulticastDelegate OnEndCursorOver; // 0x1d0(0x10)
	char pad_1E0[0x4]; // 0x1e0(0x04)
	float MinNetUpdateFrequency; // 0x1e4(0x04)
	struct UInputComponent* InputComponent; // 0x1e8(0x08)
	char bAllowReceiveTickEventOnDedicatedServer : 1; // 0x1f0(0x01)
	char pad_1F0_1 : 4; // 0x1f0(0x01)
	char bActorSeamlessTraveled : 1; // 0x1f0(0x01)
	char bIgnoresOriginShifting : 1; // 0x1f0(0x01)
	char bEnableAutoLODGeneration : 1; // 0x1f0(0x01)
	enum class EActorUpdateOverlapsMethod UpdateOverlapsMethodDuringLevelStreaming; // 0x1f1(0x01)
	enum class EActorUpdateOverlapsMethod DefaultUpdateOverlapsMethodDuringLevelStreaming; // 0x1f2(0x01)
	char pad_1F3[0x55]; // 0x1f3(0x55)
	struct FMulticastDelegate OnClicked; // 0x248(0x10)
	char bHidden : 1; // 0x258(0x01)
	char bNetTemporary : 1; // 0x258(0x01)
	char bNetStartup : 1; // 0x258(0x01)
	char bOnlyRelevantToOwner : 1; // 0x258(0x01)
	char bAlwaysRelevant : 1; // 0x258(0x01)
	char bReplicateMovement : 1; // 0x258(0x01)
	char bIsSetSpectatedDelay : 1; // 0x258(0x01)
	char bTearOff : 1; // 0x258(0x01)
	char bExchangedRoles : 1; // 0x259(0x01)
	char pad_259_1 : 1; // 0x259(0x01)
	char bNetLoadOnClient : 1; // 0x259(0x01)
	char bNetUseOwnerRelevancy : 1; // 0x259(0x01)
	char bBlockInput : 1; // 0x259(0x01)
	char pad_259_5 : 1; // 0x259(0x01)
	char bAllowTickBeforeBeginPlay : 1; // 0x259(0x01)
	char pad_259_7 : 1; // 0x259(0x01)
	char pad_25A[0x2]; // 0x25a(0x02)
	float CustomTimeDilation; // 0x25c(0x04)
	struct FMulticastDelegate OnTakeAnyDamage; // 0x260(0x10)
	struct FMulticastDelegate OnActorBeginOverlap; // 0x270(0x10)
	char pad_280[0x8]; // 0x280(0x08)
	struct FMulticastDelegate OnTakePointDamage; // 0x288(0x10)
	struct USceneComponent* RootComponent; // 0x298(0x08)
	char pad_2A0[0x8]; // 0x2a0(0x08)
	struct FMulticastDelegate OnActorHit; // 0x2a8(0x10)
	struct FMulticastDelegate OnBeginCursorOver; // 0x2b8(0x10)
	char pad_2C8[0x4]; // 0x2c8(0x04)
	struct AActor* ParentComponentActor; // 0x2cc(0x08)
	enum class EInputConsumeOptions InputConsumeOption; // 0x2d4(0x01)
	char pad_2D5[0x3]; // 0x2d5(0x03)
	struct FMulticastDelegate OnActorEndOverlap; // 0x2d8(0x10)
	struct TArray<struct UActorComponent*> BlueprintCreatedComponents; // 0x2e8(0x10)
	struct TArray<struct AActor*> Children; // 0x2f8(0x10)
	enum class ESpawnActorCollisionHandlingMethod SpawnCollisionHandlingMethod; // 0x308(0x01)
	char pad_309[0x3]; // 0x309(0x03)
	float NetCullDistanceSquared; // 0x30c(0x04)
	float NetPriority; // 0x310(0x04)
	char pad_314[0x58]; // 0x314(0x58)
	float NetUpdateFrequency; // 0x36c(0x04)
	uint64 HiddenEditorViews; // 0x370(0x08)
	struct FMulticastDelegate OnInputTouchEnd; // 0x378(0x10)
	struct TArray<struct UActorComponent*> InstanceComponents; // 0x388(0x10)
	char pad_398[0x4]; // 0x398(0x04)
	int32 NetTag; // 0x39c(0x04)
	char pad_3A0[0x10]; // 0x3a0(0x10)
	struct FMulticastDelegate OnDestroyed; // 0x3b0(0x10)
	struct FMulticastDelegate OnEndPlay; // 0x3c0(0x10)
	char pad_3D0[0x4]; // 0x3d0(0x04)
	float InitialLifeSpan; // 0x3d4(0x04)
	struct TArray<struct FName> Layers; // 0x3d8(0x10)
	char pad_3E8[0x8]; // 0x3e8(0x08)

	bool WasRecentlyRendered(float Tolerance); // Function Engine.Actor.WasRecentlyRendered // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b058ec
	void UserConstructionScript(); // Function Engine.Actor.UserConstructionScript // Event|Public|BlueprintEvent // @ game+0x33e45c
	void TearOff(); // Function Engine.Actor.TearOff // Native|Public|BlueprintCallable // @ game+0x5b0520c
	void SnapRootComponentTo(struct AActor* InParentActor, struct FName InSocketName); // Function Engine.Actor.SnapRootComponentTo // Final|Native|Public|BlueprintCallable // @ game+0x5b044ec
	void SetTickGroup(enum class ETickingGroup NewTickGroup); // Function Engine.Actor.SetTickGroup // Final|Native|Public|BlueprintCallable // @ game+0x5b03304
	void SetTickableWhenPaused(bool bTickableWhenPaused); // Function Engine.Actor.SetTickableWhenPaused // Final|Native|Public|BlueprintCallable // @ game+0x5b03390
	void SetReplicates(bool bInReplicates); // Function Engine.Actor.SetReplicates // Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable // @ game+0x5b02da0
	void SetReplicateMovement(bool bInReplicateMovement); // Function Engine.Actor.SetReplicateMovement // Native|Public|BlueprintCallable // @ game+0x5b02d08
	void SetOwner(struct AActor* NewOwner); // Function Engine.Actor.SetOwner // Native|Public|BlueprintCallable // @ game+0x5b02184
	void SetLifeSpan(float InLifespan); // Function Engine.Actor.SetLifeSpan // Native|Public|BlueprintCallable // @ game+0xce8680
	void SetActorTickInterval(float TickInterval); // Function Engine.Actor.SetActorTickInterval // Final|Native|Public|BlueprintCallable // @ game+0x5afdb74
	void SetActorTickEnabled(bool bEnabled); // Function Engine.Actor.SetActorTickEnabled // Final|Native|Public|BlueprintCallable // @ game+0x5afdae0
	void SetActorScale3D(struct FVector NewScale3D); // Function Engine.Actor.SetActorScale3D // Final|Native|Public|HasDefaults|BlueprintCallable // @ game+0x5afda40
	void SetActorRelativeScale3D(struct FVector NewRelativeScale); // Function Engine.Actor.SetActorRelativeScale3D // Final|Native|Public|HasDefaults|BlueprintCallable // @ game+0x5afd9a0
	void SetActorHiddenInGame(bool bNewHidden); // Function Engine.Actor.SetActorHiddenInGame // Native|Public|BlueprintCallable // @ game+0x5afd73c
	void SetActorEnableCollision(bool bNewActorEnableCollision); // Function Engine.Actor.SetActorEnableCollision // Final|Native|Public|BlueprintCallable // @ game+0x5afd6a8
	void RemoveTickPrerequisiteComponent(struct UActorComponent* PrerequisiteComponent); // Function Engine.Actor.RemoveTickPrerequisiteComponent // Native|Public|BlueprintCallable // @ game+0x5afa554
	void RemoveTickPrerequisiteActor(struct AActor* PrerequisiteActor); // Function Engine.Actor.RemoveTickPrerequisiteActor // Native|Public|BlueprintCallable // @ game+0x5afa42c
	void ReceiveTick(float DeltaSeconds); // Function Engine.Actor.ReceiveTick // Event|Public|BlueprintEvent // @ game+0x33e45c
	void ReceiveRadialDamage(float DamageReceived, struct UDamageType* DamageType, struct FVector Origin, struct FHitResult HitInfo, struct AController* InstigatedBy, struct AActor* DamageCauser); // Function Engine.Actor.ReceiveRadialDamage // BlueprintAuthorityOnly|Event|Public|HasOutParms|HasDefaults|BlueprintEvent // @ game+0x33e45c
	void ReceivePointDamage(float Damage, struct UDamageType* DamageType, struct FVector HitLocation, struct FVector HitNormal, struct UPrimitiveComponent* HitComponent, struct FName BoneName, struct FVector ShotFromDirection, struct AController* InstigatedBy, struct AActor* DamageCauser, struct FHitResult HitInfo); // Function Engine.Actor.ReceivePointDamage // BlueprintAuthorityOnly|Event|Public|HasOutParms|HasDefaults|BlueprintEvent // @ game+0x33e45c
	void ReceiveHit(struct UPrimitiveComponent* MyComp, struct AActor* Other, struct UPrimitiveComponent* OtherComp, bool bSelfMoved, struct FVector HitLocation, struct FVector HitNormal, struct FVector NormalImpulse, struct FHitResult Hit); // Function Engine.Actor.ReceiveHit // Event|Public|HasOutParms|HasDefaults|BlueprintEvent // @ game+0x33e45c
	void ReceiveEndPlay(enum class EEndPlayReason EndPlayReason); // Function Engine.Actor.ReceiveEndPlay // Event|Public|BlueprintEvent // @ game+0x33e45c
	void ReceiveDestroyed(); // Function Engine.Actor.ReceiveDestroyed // Event|Public|BlueprintEvent // @ game+0x33e45c
	void ReceiveBeginPlay(); // Function Engine.Actor.ReceiveBeginPlay // Event|Protected|BlueprintEvent // @ game+0x33e45c
	void ReceiveAnyDamage(float Damage, struct UDamageType* DamageType, struct AController* InstigatedBy, struct AActor* DamageCauser); // Function Engine.Actor.ReceiveAnyDamage // BlueprintAuthorityOnly|Event|Public|BlueprintEvent // @ game+0x33e45c
	void ReceiveActorOnReleased(struct FKey ButtonReleased); // Function Engine.Actor.ReceiveActorOnReleased // Event|Public|BlueprintEvent // @ game+0x33e45c
	void ReceiveActorOnInputTouchLeave(enum class ETouchIndex FingerIndex); // Function Engine.Actor.ReceiveActorOnInputTouchLeave // Event|Public|BlueprintEvent // @ game+0x33e45c
	void ReceiveActorOnInputTouchEnter(enum class ETouchIndex FingerIndex); // Function Engine.Actor.ReceiveActorOnInputTouchEnter // Event|Public|BlueprintEvent // @ game+0x33e45c
	void ReceiveActorOnInputTouchEnd(enum class ETouchIndex FingerIndex); // Function Engine.Actor.ReceiveActorOnInputTouchEnd // Event|Public|BlueprintEvent // @ game+0x33e45c
	void ReceiveActorOnInputTouchBegin(enum class ETouchIndex FingerIndex); // Function Engine.Actor.ReceiveActorOnInputTouchBegin // Event|Public|BlueprintEvent // @ game+0x33e45c
	void ReceiveActorOnClicked(struct FKey ButtonPressed); // Function Engine.Actor.ReceiveActorOnClicked // Event|Public|BlueprintEvent // @ game+0x33e45c
	void ReceiveActorEndOverlap(struct AActor* OtherActor); // Function Engine.Actor.ReceiveActorEndOverlap // Event|Public|BlueprintEvent // @ game+0x33e45c
	void ReceiveActorEndCursorOver(); // Function Engine.Actor.ReceiveActorEndCursorOver // Event|Public|BlueprintEvent // @ game+0x33e45c
	void ReceiveActorBeginOverlap(struct AActor* OtherActor); // Function Engine.Actor.ReceiveActorBeginOverlap // Event|Public|BlueprintEvent // @ game+0x33e45c
	void ReceiveActorBeginCursorOver(); // Function Engine.Actor.ReceiveActorBeginCursorOver // Event|Public|BlueprintEvent // @ game+0x33e45c
	void OnRep_Role(); // Function Engine.Actor.OnRep_Role // Native|Public // @ game+0xc01838
	void OnRep_ReplicateMovement(); // Function Engine.Actor.OnRep_ReplicateMovement // Native|Public // @ game+0xc421a8
	void OnRep_ReplicatedMovement(); // Function Engine.Actor.OnRep_ReplicatedMovement // Native|Public // @ game+0x2645e4
	void OnRep_Owner(); // Function Engine.Actor.OnRep_Owner // Native|Protected // @ game+0x3c3640
	void OnRep_Instigator(); // Function Engine.Actor.OnRep_Instigator // Native|Public // @ game+0xc2bd74
	void OnRep_AttachmentReplication(); // Function Engine.Actor.OnRep_AttachmentReplication // Native|Public // @ game+0x847688
	void MakeNoise(float Loudness, struct APawn* NoiseInstigator, struct FVector NoiseLocation, float MaxRange, struct FName Tag); // Function Engine.Actor.MakeNoise // Final|BlueprintAuthorityOnly|Native|Public|HasDefaults|BlueprintCallable // @ game+0x5af864c
	struct UMaterialInstanceDynamic* MakeMIDForMaterial(struct UMaterialInterface* Parent); // Function Engine.Actor.MakeMIDForMaterial // Final|Native|Public|BlueprintCallable // @ game+0x5af85d0
	bool K2_TeleportTo(struct FVector DestLocation, struct FRotator DestRotation); // Function Engine.Actor.K2_TeleportTo // Final|Native|Public|HasDefaults|BlueprintCallable // @ game+0x5af7ed0
	bool K2_SetActorTransform(struct FTransform NewTransform, bool bSweep, struct FHitResult SweepHitResult, bool bTeleport); // Function Engine.Actor.K2_SetActorTransform // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0xc73a14
	bool K2_SetActorRotation(struct FRotator NewRotation, bool bTeleportPhysics); // Function Engine.Actor.K2_SetActorRotation // Final|Native|Public|HasDefaults|BlueprintCallable // @ game+0x5af6dc4
	void K2_SetActorRelativeTransform(struct FTransform NewRelativeTransform, bool bSweep, struct FHitResult SweepHitResult, bool bTeleport); // Function Engine.Actor.K2_SetActorRelativeTransform // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5af6b98
	void K2_SetActorRelativeRotation(struct FRotator NewRelativeRotation, bool bSweep, struct FHitResult SweepHitResult, bool bTeleport); // Function Engine.Actor.K2_SetActorRelativeRotation // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5af69c0
	void K2_SetActorRelativeLocation(struct FVector NewRelativeLocation, bool bSweep, struct FHitResult SweepHitResult, bool bTeleport); // Function Engine.Actor.K2_SetActorRelativeLocation // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5af67e8
	bool K2_SetActorLocationAndRotation(struct FVector NewLocation, struct FRotator NewRotation, bool bSweep, struct FHitResult SweepHitResult, bool bTeleport); // Function Engine.Actor.K2_SetActorLocationAndRotation // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5af65b0
	bool K2_SetActorLocation(struct FVector NewLocation, bool bSweep, struct FHitResult SweepHitResult, bool bTeleport); // Function Engine.Actor.K2_SetActorLocation // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5af63cc
	void K2_OnReset(); // Function Engine.Actor.K2_OnReset // Event|Public|BlueprintEvent // @ game+0x33e45c
	void K2_OnEndViewTarget(struct APlayerController* PC); // Function Engine.Actor.K2_OnEndViewTarget // Event|Public|BlueprintEvent // @ game+0x33e45c
	void K2_OnBecomeViewTarget(struct APlayerController* PC); // Function Engine.Actor.K2_OnBecomeViewTarget // Event|Public|BlueprintEvent // @ game+0x33e45c
	struct USceneComponent* K2_GetRootComponent(); // Function Engine.Actor.K2_GetRootComponent // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5aecbdc
	struct FRotator K2_GetActorRotation(); // Function Engine.Actor.K2_GetActorRotation // Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5af5950
	struct FVector K2_GetActorLocation(); // Function Engine.Actor.K2_GetActorLocation // Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5af5878
	void K2_DetachFromActor(enum class EDetachmentRule LocationRule, enum class EDetachmentRule RotationRule, enum class EDetachmentRule ScaleRule); // Function Engine.Actor.K2_DetachFromActor // Final|Native|Public|BlueprintCallable // @ game+0x5af5508
	void K2_DestroyComponent(struct UActorComponent* Component); // Function Engine.Actor.K2_DestroyComponent // Final|Native|Public|BlueprintCallable // @ game+0x5af53b8
	void K2_DestroyActor(); // Function Engine.Actor.K2_DestroyActor // Native|Public|BlueprintCallable // @ game+0xd5ba40
	void K2_AttachToComponent(struct USceneComponent* Parent, struct FName SocketName, enum class EAttachmentRule LocationRule, enum class EAttachmentRule RotationRule, enum class EAttachmentRule ScaleRule, bool bWeldSimulatedBodies); // Function Engine.Actor.K2_AttachToComponent // Final|Native|Public|BlueprintCallable // @ game+0x8e7030
	void K2_AttachToActor(struct AActor* ParentActor, struct FName SocketName, enum class EAttachmentRule LocationRule, enum class EAttachmentRule RotationRule, enum class EAttachmentRule ScaleRule, bool bWeldSimulatedBodies); // Function Engine.Actor.K2_AttachToActor // Final|Native|Public|BlueprintCallable // @ game+0x5af4d78
	void K2_AttachRootComponentToActor(struct AActor* InParentActor, struct FName InSocketName, enum class EAttachLocation AttachLocationType, bool bWeldSimulatedBodies); // Function Engine.Actor.K2_AttachRootComponentToActor // Final|Native|Public|BlueprintCallable // @ game+0x5af4a78
	void K2_AttachRootComponentTo(struct USceneComponent* InParent, struct FName InSocketName, enum class EAttachLocation AttachLocationType, bool bWeldSimulatedBodies); // Function Engine.Actor.K2_AttachRootComponentTo // Final|Native|Public|BlueprintCallable // @ game+0x5af48f8
	void K2_AddActorWorldTransform(struct FTransform DeltaTransform, bool bSweep, struct FHitResult SweepHitResult, bool bTeleport); // Function Engine.Actor.K2_AddActorWorldTransform // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5af377c
	void K2_AddActorWorldRotation(struct FRotator DeltaRotation, bool bSweep, struct FHitResult SweepHitResult, bool bTeleport); // Function Engine.Actor.K2_AddActorWorldRotation // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5af35a4
	void K2_AddActorWorldOffset(struct FVector DeltaLocation, bool bSweep, struct FHitResult SweepHitResult, bool bTeleport); // Function Engine.Actor.K2_AddActorWorldOffset // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5af33cc
	void K2_AddActorLocalTransform(struct FTransform NewTransform, bool bSweep, struct FHitResult SweepHitResult, bool bTeleport); // Function Engine.Actor.K2_AddActorLocalTransform // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5af31a0
	void K2_AddActorLocalRotation(struct FRotator DeltaRotation, bool bSweep, struct FHitResult SweepHitResult, bool bTeleport); // Function Engine.Actor.K2_AddActorLocalRotation // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5af2fc8
	void K2_AddActorLocalOffset(struct FVector DeltaLocation, bool bSweep, struct FHitResult SweepHitResult, bool bTeleport); // Function Engine.Actor.K2_AddActorLocalOffset // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5af2df0
	bool IsOverlappingActor(struct AActor* Other); // Function Engine.Actor.IsOverlappingActor // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5af280c
	bool IsChildActor(); // Function Engine.Actor.IsChildActor // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5af20c4
	bool IsActorTickEnabled(); // Function Engine.Actor.IsActorTickEnabled // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5af202c
	bool IsActorBeingDestroyed(); // Function Engine.Actor.IsActorBeingDestroyed // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5af2010
	bool HasAuthority(); // Function Engine.Actor.HasAuthority // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0xae20c0
	float GetVerticalDistanceTo(struct AActor* OtherActor); // Function Engine.Actor.GetVerticalDistanceTo // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5af19b0
	struct FVector GetVelocity(); // Function Engine.Actor.GetVelocity // Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5af1978
	struct FTransform GetTransform(); // Function Engine.Actor.GetTransform // Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0xc0ee8c
	bool GetTickableWhenPaused(); // Function Engine.Actor.GetTickableWhenPaused // Final|Native|Public|BlueprintCallable // @ game+0x5af1530
	float GetSquaredDistanceTo(struct AActor* OtherActor); // Function Engine.Actor.GetSquaredDistanceTo // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5af1264
	enum class ENetRole GetRemoteRole(); // Function Engine.Actor.GetRemoteRole // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5af0d78
	struct UChildActorComponent* GetParentComponent(); // Function Engine.Actor.GetParentComponent // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5af063c
	struct AActor* GetParentActor(); // Function Engine.Actor.GetParentActor // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5af0618
	struct AActor* GetOwner(); // Function Engine.Actor.GetOwner // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x4d4bb1c
	void GetOverlappingComponents(struct TArray<struct UPrimitiveComponent*> OverlappingComponents); // Function Engine.Actor.GetOverlappingComponents // Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const // @ game+0x5af0464
	void GetOverlappingActors(struct TArray<struct AActor*> OverlappingActors, struct UClass* ClassFilter); // Function Engine.Actor.GetOverlappingActors // Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const // @ game+0x5af0204
	float GetLifeSpan(); // Function Engine.Actor.GetLifeSpan // Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5aef554
	struct AController* GetInstigatorController(); // Function Engine.Actor.GetInstigatorController // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5aef4a4
	struct APawn* GetInstigator(); // Function Engine.Actor.GetInstigator // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5aef48c
	struct FVector GetInputVectorAxisValue(struct FKey InputAxisKey); // Function Engine.Actor.GetInputVectorAxisValue // Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5aef284
	float GetInputAxisValue(struct FName InputAxisName); // Function Engine.Actor.GetInputAxisValue // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5aeec68
	float GetInputAxisKeyValue(struct FKey InputAxisKey); // Function Engine.Actor.GetInputAxisKeyValue // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5aeeb74
	float GetHorizontalDotProductTo(struct AActor* OtherActor); // Function Engine.Actor.GetHorizontalDotProductTo // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5aee6f0
	float GetHorizontalDistanceTo(struct AActor* OtherActor); // Function Engine.Actor.GetHorizontalDistanceTo // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5aee650
	float GetGameTimeSinceCreation(); // Function Engine.Actor.GetGameTimeSinceCreation // Final|Native|Public|BlueprintCallable|BlueprintPure // @ game+0x5aedbfc
	float GetDotProductTo(struct AActor* OtherActor); // Function Engine.Actor.GetDotProductTo // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5aeda54
	float GetDistanceTo(struct AActor* OtherActor); // Function Engine.Actor.GetDistanceTo // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5aed9b4
	struct TArray<struct UActorComponent*> GetComponentsByTag(struct UClass* ComponentClass, struct FName Tag); // Function Engine.Actor.GetComponentsByTag // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5aed294
	struct TArray<struct UActorComponent*> GetComponentsByClass(struct UClass* ComponentClass); // Function Engine.Actor.GetComponentsByClass // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5aed1a4
	struct UActorComponent* GetComponentByClass(struct UClass* ComponentClass); // Function Engine.Actor.GetComponentByClass // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5aed0c4
	struct FName GetAttachParentSocketName(); // Function Engine.Actor.GetAttachParentSocketName // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5aebf14
	struct AActor* GetAttachParentActor(); // Function Engine.Actor.GetAttachParentActor // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5aebef0
	void GetAttachedActors(struct TArray<struct AActor*> OutActors); // Function Engine.Actor.GetAttachedActors // Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const // @ game+0x5aebf58
	void GetAllChildActors(struct TArray<struct AActor*> ChildActors, bool bIncludeDescendants); // Function Engine.Actor.GetAllChildActors // Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const // @ game+0x5aebcdc
	struct FVector GetActorUpVector(); // Function Engine.Actor.GetActorUpVector // Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5aeb91c
	float GetActorTimeDilation(); // Function Engine.Actor.GetActorTimeDilation // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5aeb8f4
	float GetActorTickInterval(); // Function Engine.Actor.GetActorTickInterval // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5aeb8dc
	struct FVector GetActorScale3D(); // Function Engine.Actor.GetActorScale3D // Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5aeb8a8
	struct FVector GetActorRightVector(); // Function Engine.Actor.GetActorRightVector // Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5aeb770
	struct FVector GetActorRelativeScale3D(); // Function Engine.Actor.GetActorRelativeScale3D // Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5aeb73c
	struct FVector GetActorForwardVector(); // Function Engine.Actor.GetActorForwardVector // Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5aeb604
	void GetActorEyesViewPoint(struct FVector OutLocation, struct FRotator OutRotation); // Function Engine.Actor.GetActorEyesViewPoint // Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5aeb4f8
	bool GetActorEnableCollision(); // Function Engine.Actor.GetActorEnableCollision // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5aeb4dc
	void GetActorBounds(bool bOnlyCollidingComponents, struct FVector Origin, struct FVector BoxExtent, bool bIncludeFromChildActors); // Function Engine.Actor.GetActorBounds // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5aeb334
	void ForceNetUpdate(); // Function Engine.Actor.ForceNetUpdate // BlueprintAuthorityOnly|Native|Public|BlueprintCallable // @ game+0x5aeb134
	void FlushNetDormancy(); // Function Engine.Actor.FlushNetDormancy // Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable // @ game+0x5aeb120
	void EnableInput(struct APlayerController* PlayerController); // Function Engine.Actor.EnableInput // Native|Public|BlueprintCallable // @ game+0x5aeab98
	void DisableInput(struct APlayerController* PlayerController); // Function Engine.Actor.DisableInput // Native|Public|BlueprintCallable // @ game+0x5ae90d8
	void DetachRootComponentFromParent(bool bMaintainWorldPosition); // Function Engine.Actor.DetachRootComponentFromParent // Final|Native|Public|BlueprintCallable // @ game+0x5ae9044
	void AddTickPrerequisiteComponent(struct UActorComponent* PrerequisiteComponent); // Function Engine.Actor.AddTickPrerequisiteComponent // Native|Public|BlueprintCallable // @ game+0x5ae4cd4
	void AddTickPrerequisiteActor(struct AActor* PrerequisiteActor); // Function Engine.Actor.AddTickPrerequisiteActor // Native|Public|BlueprintCallable // @ game+0x5ae4bac
	struct UActorComponent* AddComponent(struct FName TemplateName, bool bManualAttachment, struct FTransform RelativeTransform, struct UObject* ComponentTemplateContext); // Function Engine.Actor.AddComponent // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0xba269c
	bool ActorHasTag(struct FName Tag); // Function Engine.Actor.ActorHasTag // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5ae2f14
};

// Class Engine.AnimInstance
// Size: 0x3a8 (Inherited: 0x38)
struct UAnimInstance : UObject {
	float DeltaTime; // 0x38(0x04)
	char pad_3C[0x4]; // 0x3c(0x04)
	struct USkeleton* CurrentSkeleton; // 0x40(0x08)
	enum class ERootMotionMode RootMotionMode; // 0x48(0x01)
	bool bRunUpdatesInWorkerThreads; // 0x49(0x01)
	bool bCanUseParallelUpdateAnimation; // 0x4a(0x01)
	bool bUseMultiThreadedAnimationUpdate; // 0x4b(0x01)
	bool bWarnAboutBlueprintUsage; // 0x4c(0x01)
	char pad_4D[0x3]; // 0x4d(0x03)
	struct FMulticastDelegate OnMontageBlendingOut; // 0x50(0x10)
	struct FMulticastDelegate OnMontageStarted; // 0x60(0x10)
	struct FMulticastDelegate OnMontageEnded; // 0x70(0x10)
	struct FMulticastDelegate OnMontageInterrupted; // 0x80(0x10)
	struct FMulticastDelegate OnAllMontageInstancesEnded; // 0x90(0x10)
	char pad_A0[0x60]; // 0xa0(0x60)
	bool bQueueMontageEvents; // 0x100(0x01)
	char pad_101[0x9f]; // 0x101(0x9f)
	struct TArray<struct FAnimNotifyEvent> ActiveAnimNotifyState; // 0x1a0(0x10)
	char pad_1B0[0x1f8]; // 0x1b0(0x1f8)

	void UnlockAIResources(bool bUnlockMovement, bool UnlockAILogic); // Function Engine.AnimInstance.UnlockAIResources // Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable // @ game+0x5b35a8c
	struct APawn* TryGetPawnOwner(); // Function Engine.AnimInstance.TryGetPawnOwner // Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b5bc7c
	void StopSlotAnimation(float inBlendOutTime, struct FName SlotNodeName); // Function Engine.AnimInstance.StopSlotAnimation // Final|Native|Public|BlueprintCallable // @ game+0x5b5a004
	void SnapshotPose(struct FPoseSnapshot Snapshot); // Function Engine.AnimInstance.SnapshotPose // Native|Public|HasOutParms|BlueprintCallable // @ game+0x5b55110
	void SetRootMotionMode(enum class ERootMotionMode Value); // Function Engine.AnimInstance.SetRootMotionMode // Final|Native|Public|BlueprintCallable // @ game+0x5b4f3ec
	void SetMorphTarget(struct FName MorphTargetName, float Value); // Function Engine.AnimInstance.SetMorphTarget // Final|Native|Public|BlueprintCallable // @ game+0x5b4d534
	void SavePoseSnapshot(struct FName SnapshotName); // Function Engine.AnimInstance.SavePoseSnapshot // Native|Public|BlueprintCallable // @ game+0x5b42a38
	struct UAnimMontage* PlaySlotAnimationAsDynamicMontage(struct UAnimSequenceBase* Asset, struct FName SlotNodeName, float BlendInTime, float BlendOutTime, float InPlayRate, int32 LoopCount, float BlendOutTriggerTime, float InTimeToStartMontageAt); // Function Engine.AnimInstance.PlaySlotAnimationAsDynamicMontage // Final|Native|Public|BlueprintCallable // @ game+0x5b3dea8
	float PlaySlotAnimation(struct UAnimSequenceBase* Asset, struct FName SlotNodeName, float BlendInTime, float BlendOutTime, float InPlayRate, int32 LoopCount); // Function Engine.AnimInstance.PlaySlotAnimation // Final|Native|Public|BlueprintCallable // @ game+0x5b3dc84
	void Montage_Stop(float inBlendOutTime, struct UAnimMontage* Montage); // Function Engine.AnimInstance.Montage_Stop // Native|Public|BlueprintCallable // @ game+0xc2b818
	void Montage_SetPosition(struct UAnimMontage* Montage, float NewPosition); // Function Engine.AnimInstance.Montage_SetPosition // Final|Native|Public|BlueprintCallable // @ game+0x5b3a4e4
	void Montage_SetPlayRate(struct UAnimMontage* Montage, float NewPlayRate); // Function Engine.AnimInstance.Montage_SetPlayRate // Final|Native|Public|BlueprintCallable // @ game+0x5b3a404
	void Montage_SetNextSection(struct FName SectionNameToChange, struct FName NextSection, struct UAnimMontage* Montage); // Function Engine.AnimInstance.Montage_SetNextSection // Native|Public|BlueprintCallable // @ game+0xd4d538
	void Montage_Resume(struct UAnimMontage* Montage); // Function Engine.AnimInstance.Montage_Resume // Final|Native|Public|BlueprintCallable // @ game+0x5b3a374
	float Montage_Play(struct UAnimMontage* MontageToPlay, float InPlayRate, enum class EMontagePlayReturnType ReturnValueType, float InTimeToStartMontageAt); // Function Engine.AnimInstance.Montage_Play // Native|Public|BlueprintCallable // @ game+0x8e72e0
	void Montage_Pause(struct UAnimMontage* Montage); // Function Engine.AnimInstance.Montage_Pause // Final|Native|Public|BlueprintCallable // @ game+0x5b3a2e4
	void Montage_JumpToSectionsEnd(struct FName SectionName, struct UAnimMontage* Montage); // Function Engine.AnimInstance.Montage_JumpToSectionsEnd // Final|Native|Public|BlueprintCallable // @ game+0x5b3a208
	void Montage_JumpToSection(struct FName SectionName, struct UAnimMontage* Montage); // Function Engine.AnimInstance.Montage_JumpToSection // Native|Public|BlueprintCallable // @ game+0x8e7978
	bool Montage_IsPlaying(struct UAnimMontage* Montage); // Function Engine.AnimInstance.Montage_IsPlaying // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0xcdf714
	bool Montage_IsActive(struct UAnimMontage* Montage); // Function Engine.AnimInstance.Montage_IsActive // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b3a168
	float Montage_GetPosition(struct UAnimMontage* Montage); // Function Engine.AnimInstance.Montage_GetPosition // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b3a0c8
	float Montage_GetPlayRate(struct UAnimMontage* Montage); // Function Engine.AnimInstance.Montage_GetPlayRate // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b3a028
	bool Montage_GetIsStopped(struct UAnimMontage* Montage); // Function Engine.AnimInstance.Montage_GetIsStopped // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b39f88
	struct FName Montage_GetCurrentSection(struct UAnimMontage* Montage); // Function Engine.AnimInstance.Montage_GetCurrentSection // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b39eec
	float Montage_GetBlendTime(struct UAnimMontage* Montage); // Function Engine.AnimInstance.Montage_GetBlendTime // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b39e4c
	void LockAIResources(bool bLockMovement, bool LockAILogic); // Function Engine.AnimInstance.LockAIResources // Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable // @ game+0x5b35a8c
	bool IsSyncGroupBetweenMarkers(struct FName InSyncGroupName, struct FName PreviousMarker, struct FName NextMarker, bool bRespectMarkerOrder); // Function Engine.AnimInstance.IsSyncGroupBetweenMarkers // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b3049c
	bool IsPlayingSlotAnimation(struct UAnimSequenceBase* Asset, struct FName SlotNodeName); // Function Engine.AnimInstance.IsPlayingSlotAnimation // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b2ff14
	bool IsAnyMontagePlaying(); // Function Engine.AnimInstance.IsAnyMontagePlaying // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b2f7f0
	bool HasMarkerBeenHitThisFrame(struct FName SyncGroup, struct FName MarkerName); // Function Engine.AnimInstance.HasMarkerBeenHitThisFrame // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b2deb4
	bool GetTimeToClosestMarker(struct FName SyncGroup, struct FName MarkerName, float OutMarkerTime); // Function Engine.AnimInstance.GetTimeToClosestMarker // Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const // @ game+0x5b2ac54
	struct FMarkerSyncAnimPosition GetSyncGroupPosition(struct FName InSyncGroupName); // Function Engine.AnimInstance.GetSyncGroupPosition // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b2a5a4
	float GetStateWeight(int32 MachineIndex, int32 StateIndex); // Function Engine.AnimInstance.GetStateWeight // Final|Native|Public|BlueprintCallable|BlueprintPure // @ game+0x5b2a108
	float GetRelevantAnimTimeRemainingFraction(int32 MachineIndex, int32 StateIndex); // Function Engine.AnimInstance.GetRelevantAnimTimeRemainingFraction // Final|Native|Public|BlueprintCallable|BlueprintPure // @ game+0x852a6c
	float GetRelevantAnimTimeRemaining(int32 MachineIndex, int32 StateIndex); // Function Engine.AnimInstance.GetRelevantAnimTimeRemaining // Final|Native|Public|BlueprintCallable|BlueprintPure // @ game+0x8531b4
	float GetRelevantAnimTimeFraction(int32 MachineIndex, int32 StateIndex); // Function Engine.AnimInstance.GetRelevantAnimTimeFraction // Final|Native|Public|BlueprintCallable|BlueprintPure // @ game+0x5b28988
	float GetRelevantAnimTime(int32 MachineIndex, int32 StateIndex); // Function Engine.AnimInstance.GetRelevantAnimTime // Final|Native|Public|BlueprintCallable|BlueprintPure // @ game+0x5b287f4
	float GetRelevantAnimLength(int32 MachineIndex, int32 StateIndex); // Function Engine.AnimInstance.GetRelevantAnimLength // Final|Native|Public|BlueprintCallable|BlueprintPure // @ game+0x5b28674
	struct USkeletalMeshComponent* GetOwningComponent(); // Function Engine.AnimInstance.GetOwningComponent // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b27964
	struct AActor* GetOwningActor(); // Function Engine.AnimInstance.GetOwningActor // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0xc1a2e8
	float GetInstanceTransitionTimeElapsedFraction(int32 MachineIndex, int32 TransitionIndex); // Function Engine.AnimInstance.GetInstanceTransitionTimeElapsedFraction // Final|Native|Public|BlueprintCallable|BlueprintPure // @ game+0x5b25d50
	float GetInstanceTransitionTimeElapsed(int32 MachineIndex, int32 TransitionIndex); // Function Engine.AnimInstance.GetInstanceTransitionTimeElapsed // Final|Native|Public|BlueprintCallable|BlueprintPure // @ game+0x5b25bc4
	float GetInstanceTransitionCrossfadeDuration(int32 MachineIndex, int32 TransitionIndex); // Function Engine.AnimInstance.GetInstanceTransitionCrossfadeDuration // Final|Native|Public|BlueprintCallable|BlueprintPure // @ game+0x5b25a44
	float GetInstanceStateWeight(int32 MachineIndex, int32 StateIndex); // Function Engine.AnimInstance.GetInstanceStateWeight // Final|Native|Public|BlueprintCallable|BlueprintPure // @ game+0x2d2fa0
	float GetInstanceMachineWeight(int32 MachineIndex); // Function Engine.AnimInstance.GetInstanceMachineWeight // Final|Native|Public|BlueprintCallable|BlueprintPure // @ game+0x5b255e8
	float GetInstanceCurrentStateElapsedTime(int32 MachineIndex); // Function Engine.AnimInstance.GetInstanceCurrentStateElapsedTime // Final|Native|Public|BlueprintCallable|BlueprintPure // @ game+0x5b25384
	float GetInstanceAssetPlayerTimeFromEndFraction(int32 AssetPlayerIndex); // Function Engine.AnimInstance.GetInstanceAssetPlayerTimeFromEndFraction // Final|Native|Public|BlueprintCallable|BlueprintPure // @ game+0x855354
	float GetInstanceAssetPlayerTimeFromEnd(int32 AssetPlayerIndex); // Function Engine.AnimInstance.GetInstanceAssetPlayerTimeFromEnd // Final|Native|Public|BlueprintCallable|BlueprintPure // @ game+0x5b25250
	float GetInstanceAssetPlayerTimeFraction(int32 AssetPlayerIndex); // Function Engine.AnimInstance.GetInstanceAssetPlayerTimeFraction // Final|Native|Public|BlueprintCallable|BlueprintPure // @ game+0x5b2511c
	float GetInstanceAssetPlayerTime(int32 AssetPlayerIndex); // Function Engine.AnimInstance.GetInstanceAssetPlayerTime // Final|Native|Public|BlueprintCallable|BlueprintPure // @ game+0x5b24fd0
	float GetInstanceAssetPlayerLength(int32 AssetPlayerIndex); // Function Engine.AnimInstance.GetInstanceAssetPlayerLength // Final|Native|Public|BlueprintCallable|BlueprintPure // @ game+0x5b24e84
	float GetCurveValue(struct FName CurveName); // Function Engine.AnimInstance.GetCurveValue // Final|Native|Public|BlueprintCallable|BlueprintPure // @ game+0x2d2920
	struct FName GetCurrentStateName(int32 MachineIndex); // Function Engine.AnimInstance.GetCurrentStateName // Final|Native|Public|BlueprintCallable|BlueprintPure // @ game+0x5b237e4
	float GetCurrentStateElapsedTime(int32 MachineIndex); // Function Engine.AnimInstance.GetCurrentStateElapsedTime // Final|Native|Public|BlueprintCallable|BlueprintPure // @ game+0x5b23744
	struct UAnimMontage* GetCurrentActiveMontage(); // Function Engine.AnimInstance.GetCurrentActiveMontage // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b2335c
	float GetAnimAssetPlayerTimeFromEndFraction(struct UAnimationAsset* AnimAsset, float CurrentTime); // Function Engine.AnimInstance.GetAnimAssetPlayerTimeFromEndFraction // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b21d24
	float GetAnimAssetPlayerTimeFromEnd(struct UAnimationAsset* AnimAsset, float CurrentTime); // Function Engine.AnimInstance.GetAnimAssetPlayerTimeFromEnd // Final|Native|Public|BlueprintCallable|BlueprintPure // @ game+0x5b21c20
	float GetAnimAssetPlayerTimeFraction(struct UAnimationAsset* AnimAsset, float CurrentTime); // Function Engine.AnimInstance.GetAnimAssetPlayerTimeFraction // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b21b40
	float GetAnimAssetPlayerLength(struct UAnimationAsset* AnimAsset); // Function Engine.AnimInstance.GetAnimAssetPlayerLength // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b21aac
	void ClearMorphTargets(); // Function Engine.AnimInstance.ClearMorphTargets // Final|Native|Public|BlueprintCallable // @ game+0x5b16bfc
	float CalculateDirection(struct FVector Velocity, struct FRotator BaseRotation); // Function Engine.AnimInstance.CalculateDirection // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b13954
	void BlueprintUpdateAnimation(float DeltaTimeX); // Function Engine.AnimInstance.BlueprintUpdateAnimation // Event|Public|BlueprintEvent // @ game+0x33e45c
	void BlueprintPostEvaluateAnimation(); // Function Engine.AnimInstance.BlueprintPostEvaluateAnimation // Event|Public|BlueprintEvent // @ game+0x33e45c
	void BlueprintInitializeAnimation(); // Function Engine.AnimInstance.BlueprintInitializeAnimation // Event|Public|BlueprintEvent // @ game+0x33e45c
};

// Class Engine.DataAsset
// Size: 0x40 (Inherited: 0x38)
struct UDataAsset : UObject {
	struct UClass* NativeClass; // 0x38(0x08)
};

// Class Engine.DamageType
// Size: 0x50 (Inherited: 0x38)
struct UDamageType : UObject {
	char bCausedByWorld : 1; // 0x38(0x01)
	char bScaleMomentumByMass : 1; // 0x38(0x01)
	char bRadialDamageVelChange : 1; // 0x38(0x01)
	char pad_38_3 : 5; // 0x38(0x01)
	char pad_39[0x3]; // 0x39(0x03)
	float DamageImpulse; // 0x3c(0x04)
	float DestructibleImpulse; // 0x40(0x04)
	float DestructibleDamageSpreadScale; // 0x44(0x04)
	float DamageFalloff; // 0x48(0x04)
	char pad_4C[0x4]; // 0x4c(0x04)
};

// Class Engine.ActorComponent
// Size: 0x200 (Inherited: 0x38)
struct UActorComponent : UObject {
	char pad_38[0xe8]; // 0x38(0xe8)
	struct FActorComponentTickFunction PrimaryComponentTick; // 0x120(0x58)
	struct TArray<struct FName> ComponentTags; // 0x178(0x10)
	struct TArray<struct UAssetUserData*> AssetUserData; // 0x188(0x10)
	char pad_198_0 : 3; // 0x198(0x01)
	char bReplicates : 1; // 0x198(0x01)
	char bNetAddressable : 1; // 0x198(0x01)
	char bNetRemappable : 1; // 0x198(0x01)
	char pad_198_6 : 2; // 0x198(0x01)
	char pad_199[0x1]; // 0x199(0x01)
	char pad_19A_0 : 2; // 0x19a(0x01)
	char bCreatedByConstructionScript : 1; // 0x19a(0x01)
	char bInstanceComponent : 1; // 0x19a(0x01)
	char bAutoActivate : 1; // 0x19a(0x01)
	char bIsActive : 1; // 0x19a(0x01)
	char bEditableWhenInherited : 1; // 0x19a(0x01)
	char pad_19A_7 : 1; // 0x19a(0x01)
	char pad_19B[0x1]; // 0x19b(0x01)
	struct FGuid DestructibleId; // 0x19c(0x10)
	bool bIsDestroyedVersion; // 0x1ac(0x01)
	char pad_1AD[0x3]; // 0x1ad(0x03)
	char bCanEverAffectNavigation : 1; // 0x1b0(0x01)
	char pad_1B0_1 : 2; // 0x1b0(0x01)
	char bIsEditorOnly : 1; // 0x1b0(0x01)
	char pad_1B0_4 : 4; // 0x1b0(0x01)
	char pad_1B1[0x4]; // 0x1b1(0x04)
	enum class EComponentCreationMethod CreationMethod; // 0x1b5(0x01)
	char pad_1B6[0xa]; // 0x1b6(0x0a)
	struct TArray<struct FSimpleMemberReference> UCSModifiedProperties; // 0x1c0(0x10)
	struct FMulticastDelegate OnComponentActivated; // 0x1d0(0x10)
	struct FMulticastDelegate OnComponentDeactivated; // 0x1e0(0x10)
	char pad_1F0[0x9]; // 0x1f0(0x09)
	char bReplayRewindable : 1; // 0x1f9(0x01)
	char pad_1F9_1 : 7; // 0x1f9(0x01)
	char pad_1FA[0x6]; // 0x1fa(0x06)

	void ToggleActive(); // Function Engine.ActorComponent.ToggleActive // Native|Public|BlueprintCallable // @ game+0x548b34c
	void SetTickGroup(enum class ETickingGroup NewTickGroup); // Function Engine.ActorComponent.SetTickGroup // Final|Native|Public|BlueprintCallable // @ game+0x5b03304
	void SetTickableWhenPaused(bool bTickableWhenPaused); // Function Engine.ActorComponent.SetTickableWhenPaused // Final|Native|Public|BlueprintCallable // @ game+0x5b03390
	void SetIsReplicated(bool ShouldReplicate); // Function Engine.ActorComponent.SetIsReplicated // Final|Native|Public|BlueprintCallable // @ game+0x5b01258
	void SetComponentTickInterval(float TickInterval); // Function Engine.ActorComponent.SetComponentTickInterval // Final|Native|Public|BlueprintCallable // @ game+0x5afdb74
	void SetComponentTickEnabled(bool bEnabled); // Function Engine.ActorComponent.SetComponentTickEnabled // Native|Public|BlueprintCallable // @ game+0x5affdf8
	void SetAutoActivate(bool bNewAutoActivate); // Function Engine.ActorComponent.SetAutoActivate // Native|Public|BlueprintCallable // @ game+0x5afe244
	void SetActive(bool bNewActive, bool bReset); // Function Engine.ActorComponent.SetActive // Native|Public|BlueprintCallable // @ game+0x5afd5b4
	void RemoveTickPrerequisiteComponent(struct UActorComponent* PrerequisiteComponent); // Function Engine.ActorComponent.RemoveTickPrerequisiteComponent // Native|Public|BlueprintCallable // @ game+0x5afa5e8
	void RemoveTickPrerequisiteActor(struct AActor* PrerequisiteActor); // Function Engine.ActorComponent.RemoveTickPrerequisiteActor // Native|Public|BlueprintCallable // @ game+0x5afa4c0
	void ReceiveTick(float DeltaSeconds); // Function Engine.ActorComponent.ReceiveTick // Event|Public|BlueprintEvent // @ game+0x33e45c
	void ReceiveEndPlay(enum class EEndPlayReason EndPlayReason); // Function Engine.ActorComponent.ReceiveEndPlay // Event|Public|BlueprintEvent // @ game+0x33e45c
	void ReceiveBeginPlay(); // Function Engine.ActorComponent.ReceiveBeginPlay // Event|Public|BlueprintEvent // @ game+0x33e45c
	void OnRep_IsActive(); // Function Engine.ActorComponent.OnRep_IsActive // Final|Native|Public // @ game+0x5af8bdc
	void K2_DestroyComponent(struct UObject* Object); // Function Engine.ActorComponent.K2_DestroyComponent // Final|Native|Public|BlueprintCallable // @ game+0x5af5450
	bool IsComponentTickEnabled(); // Function Engine.ActorComponent.IsComponentTickEnabled // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5af202c
	bool IsBeingDestroyed(); // Function Engine.ActorComponent.IsBeingDestroyed // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5af20a8
	bool IsActive(); // Function Engine.ActorComponent.IsActive // Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5af1fe8
	struct AActor* GetOwner(); // Function Engine.ActorComponent.GetOwner // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0xc045e0
	float GetComponentTickInterval(); // Function Engine.ActorComponent.GetComponentTickInterval // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5aeb8dc
	void Deactivate(); // Function Engine.ActorComponent.Deactivate // Native|Public|BlueprintCallable // @ game+0xc64df0
	bool ComponentHasTag(struct FName Tag); // Function Engine.ActorComponent.ComponentHasTag // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5ae80a8
	void AddTickPrerequisiteComponent(struct UActorComponent* PrerequisiteComponent); // Function Engine.ActorComponent.AddTickPrerequisiteComponent // Native|Public|BlueprintCallable // @ game+0x5ae4d68
	void AddTickPrerequisiteActor(struct AActor* PrerequisiteActor); // Function Engine.ActorComponent.AddTickPrerequisiteActor // Native|Public|BlueprintCallable // @ game+0x5ae4c40
	void Activate(bool bReset); // Function Engine.ActorComponent.Activate // Native|Public|BlueprintCallable // @ game+0xa6e994
};

// Class Engine.SceneComponent
// Size: 0x4b0 (Inherited: 0x200)
struct USceneComponent : UActorComponent {
	struct FVector ComponentVelocity; // 0x200(0x0c)
	struct FVector RelativeLocation; // 0x20c(0x0c)
	struct TArray<struct USceneComponent*> AttachChildren; // 0x218(0x10)
	char pad_228[0x1c]; // 0x228(0x1c)
	char pad_244_0 : 1; // 0x244(0x01)
	char bReplicatesAttachmentReference : 1; // 0x244(0x01)
	char bReplicatesAttachment : 1; // 0x244(0x01)
	char bWorldToComponentUpdated : 1; // 0x244(0x01)
	char pad_244_4 : 1; // 0x244(0x01)
	char bAbsoluteLocation : 1; // 0x244(0x01)
	char bAbsoluteRotation : 1; // 0x244(0x01)
	char bAbsoluteScale : 1; // 0x244(0x01)
	char bVisible : 1; // 0x245(0x01)
	char bHiddenInGame : 1; // 0x245(0x01)
	char bShouldUpdatePhysicsVolume : 1; // 0x245(0x01)
	char bBoundsChangeTriggersStreamingDataRebuild : 1; // 0x245(0x01)
	char bUseAttachParentBound : 1; // 0x245(0x01)
	char bEnableInsensitiveUpdate : 1; // 0x245(0x01)
	char pad_245_6 : 2; // 0x245(0x01)
	char pad_246_0 : 3; // 0x246(0x01)
	char bAbsoluteTranslation : 1; // 0x246(0x01)
	char pad_246_4 : 4; // 0x246(0x01)
	char pad_247[0x1]; // 0x247(0x01)
	struct APhysicsVolume* PhysicsVolume; // 0x248(0x08)
	struct FRotator RelativeRotation; // 0x250(0x0c)
	char pad_25C[0x64]; // 0x25c(0x64)
	struct FVector RelativeScale3D; // 0x2c0(0x0c)
	char pad_2CC[0x4]; // 0x2cc(0x04)
	struct FName AttachSocketName; // 0x2d0(0x08)
	char pad_2D8[0x28]; // 0x2d8(0x28)
	SetProperty ClientAttachedChildren; // 0x300(0x50)
	struct FVector RelativeTranslation; // 0x350(0x0c)
	enum class EComponentMobility Mobility; // 0x35c(0x01)
	char pad_35D[0x1c]; // 0x35d(0x1c)
	enum class EDetailMode DetailMode; // 0x379(0x01)
	char pad_37A[0x6]; // 0x37a(0x06)
	struct USceneComponent* AttachParent; // 0x380(0x08)
	struct FMulticastDelegate PhysicsVolumeChangedDelegate; // 0x388(0x10)
	struct FMulticastDelegate AttachmentChangedDelegate; // 0x398(0x10)
	char pad_3A8[0x108]; // 0x3a8(0x108)

	void ToggleVisibility(bool bPropagateToChildren); // Function Engine.SceneComponent.ToggleVisibility // Final|Native|Public|BlueprintCallable // @ game+0x5b05370
	bool SnapTo(struct USceneComponent* InParent, struct FName InSocketName); // Function Engine.SceneComponent.SnapTo // Final|Native|Public|BlueprintCallable // @ game+0x5b045c8
	void SetWorldScale3D(struct FVector NewScale); // Function Engine.SceneComponent.SetWorldScale3D // Final|Native|Public|HasDefaults|BlueprintCallable // @ game+0x5b041bc
	void SetVisibility(bool bNewVisibility, bool bPropagateToChildren); // Function Engine.SceneComponent.SetVisibility // Final|Native|Public|BlueprintCallable // @ game+0xc35d60
	void SetRelativeScale3D(struct FVector NewScale3D); // Function Engine.SceneComponent.SetRelativeScale3D // Native|Public|HasDefaults|BlueprintCallable // @ game+0x5b02a84
	void SetIsAttachmentReplicated(bool ShouldReplicate); // Function Engine.SceneComponent.SetIsAttachmentReplicated // Final|Native|Public|BlueprintCallable // @ game+0x5b011bc
	void SetIsAttachmentReferenceReplicated(bool ShouldReplicate); // Function Engine.SceneComponent.SetIsAttachmentReferenceReplicated // Final|Native|Public|BlueprintCallable // @ game+0x5b01120
	void SetHiddenInGame(bool NewHidden, bool bPropagateToChildren); // Function Engine.SceneComponent.SetHiddenInGame // Final|Native|Public|BlueprintCallable // @ game+0xdf4934
	void SetAbsolute(bool bNewAbsoluteLocation, bool bNewAbsoluteRotation, bool bNewAbsoluteScale); // Function Engine.SceneComponent.SetAbsolute // Final|Native|Public|BlueprintCallable // @ game+0x5afd470
	void ResetRelativeTransform(); // Function Engine.SceneComponent.ResetRelativeTransform // Final|Native|Public|BlueprintCallable // @ game+0x5afa6c4
	void OnRep_Visibility(bool OldValue); // Function Engine.SceneComponent.OnRep_Visibility // Final|Native|Private // @ game+0x5af8cd0
	void OnRep_Transform(); // Function Engine.SceneComponent.OnRep_Transform // Final|Native|Private // @ game+0xb524c0
	void OnRep_AttachSocketName(); // Function Engine.SceneComponent.OnRep_AttachSocketName // Final|Native|Private // @ game+0xb8229c
	void OnRep_AttachParent(); // Function Engine.SceneComponent.OnRep_AttachParent // Final|Native|Private // @ game+0xb8229c
	void OnRep_AttachChildren(); // Function Engine.SceneComponent.OnRep_AttachChildren // Final|Native|Private // @ game+0xbc593c
	void K2_SetWorldTransform(struct FTransform NewTransform, bool bSweep, struct FHitResult SweepHitResult, bool bTeleport); // Function Engine.SceneComponent.K2_SetWorldTransform // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5af7ca4
	void K2_SetWorldRotation(struct FRotator NewRotation, bool bSweep, struct FHitResult SweepHitResult, bool bTeleport); // Function Engine.SceneComponent.K2_SetWorldRotation // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5af7acc
	void K2_SetWorldLocationAndRotation(struct FVector NewLocation, struct FRotator NewRotation, bool bSweep, struct FHitResult SweepHitResult, bool bTeleport); // Function Engine.SceneComponent.K2_SetWorldLocationAndRotation // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5af789c
	void K2_SetWorldLocation(struct FVector NewLocation, bool bSweep, struct FHitResult SweepHitResult, bool bTeleport); // Function Engine.SceneComponent.K2_SetWorldLocation // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5af76c4
	void K2_SetRelativeTransform(struct FTransform NewTransform, bool bSweep, struct FHitResult SweepHitResult, bool bTeleport); // Function Engine.SceneComponent.K2_SetRelativeTransform // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5af7498
	void K2_SetRelativeRotation(struct FRotator NewRotation, bool bSweep, struct FHitResult SweepHitResult, bool bTeleport); // Function Engine.SceneComponent.K2_SetRelativeRotation // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5af72c0
	void K2_SetRelativeLocationAndRotation(struct FVector NewLocation, struct FRotator NewRotation, bool bSweep, struct FHitResult SweepHitResult, bool bTeleport); // Function Engine.SceneComponent.K2_SetRelativeLocationAndRotation // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5af7090
	void K2_SetRelativeLocation(struct FVector NewLocation, bool bSweep, struct FHitResult SweepHitResult, bool bTeleport); // Function Engine.SceneComponent.K2_SetRelativeLocation // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5af6ec4
	struct FTransform K2_GetComponentToWorld(); // Function Engine.SceneComponent.K2_GetComponentToWorld // Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5af5b34
	struct FVector K2_GetComponentScale(); // Function Engine.SceneComponent.K2_GetComponentScale // Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5af5af0
	struct FRotator K2_GetComponentRotation(); // Function Engine.SceneComponent.K2_GetComponentRotation // Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5af5a6c
	struct FVector K2_GetComponentLocation(); // Function Engine.SceneComponent.K2_GetComponentLocation // Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0xc10fb4
	void K2_DetachFromComponent(enum class EDetachmentRule LocationRule, enum class EDetachmentRule RotationRule, enum class EDetachmentRule ScaleRule, bool bCallModify); // Function Engine.SceneComponent.K2_DetachFromComponent // Final|Native|Public|BlueprintCallable // @ game+0xc11d80
	bool K2_AttachToComponent(struct USceneComponent* Parent, struct FName SocketName, enum class EAttachmentRule LocationRule, enum class EAttachmentRule RotationRule, enum class EAttachmentRule ScaleRule, bool bWeldSimulatedBodies); // Function Engine.SceneComponent.K2_AttachToComponent // Final|Native|Public|BlueprintCallable // @ game+0x5af4f98
	bool K2_AttachTo(struct USceneComponent* InParent, struct FName InSocketName, enum class EAttachLocation AttachType, bool bWeldSimulatedBodies); // Function Engine.SceneComponent.K2_AttachTo // Final|Native|Public|BlueprintCallable // @ game+0x5af4bf8
	void K2_AddWorldTransform(struct FTransform DeltaTransform, bool bSweep, struct FHitResult SweepHitResult, bool bTeleport); // Function Engine.SceneComponent.K2_AddWorldTransform // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5af46cc
	void K2_AddWorldRotation(struct FRotator DeltaRotation, bool bSweep, struct FHitResult SweepHitResult, bool bTeleport); // Function Engine.SceneComponent.K2_AddWorldRotation // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5af44f4
	void K2_AddWorldOffset(struct FVector DeltaLocation, bool bSweep, struct FHitResult SweepHitResult, bool bTeleport); // Function Engine.SceneComponent.K2_AddWorldOffset // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5af431c
	void K2_AddRelativeRotation(struct FRotator DeltaRotation, bool bSweep, struct FHitResult SweepHitResult, bool bTeleport); // Function Engine.SceneComponent.K2_AddRelativeRotation // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5af4150
	void K2_AddRelativeLocation(struct FVector DeltaLocation, bool bSweep, struct FHitResult SweepHitResult, bool bTeleport); // Function Engine.SceneComponent.K2_AddRelativeLocation // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5af3f84
	void K2_AddLocalTransform(struct FTransform DeltaTransform, bool bSweep, struct FHitResult SweepHitResult, bool bTeleport); // Function Engine.SceneComponent.K2_AddLocalTransform // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5af3d58
	void K2_AddLocalRotation(struct FRotator DeltaRotation, bool bSweep, struct FHitResult SweepHitResult, bool bTeleport); // Function Engine.SceneComponent.K2_AddLocalRotation // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5af3b80
	void K2_AddLocalOffset(struct FVector DeltaLocation, bool bSweep, struct FHitResult SweepHitResult, bool bTeleport); // Function Engine.SceneComponent.K2_AddLocalOffset // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5af39a8
	bool IsVisible(); // Function Engine.SceneComponent.IsVisible // Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5af2cd8
	bool IsSimulatingPhysics(struct FName BoneName); // Function Engine.SceneComponent.IsSimulatingPhysics // Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5af2b94
	bool IsAnySimulatingPhysics(); // Function Engine.SceneComponent.IsAnySimulatingPhysics // Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5af2080
	struct FVector GetUpVector(); // Function Engine.SceneComponent.GetUpVector // Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5af17a8
	struct FTransform GetSocketTransform(struct FName InSocketName, enum class ERelativeTransformSpace TransformSpace); // Function Engine.SceneComponent.GetSocketTransform // Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5af1134
	struct FRotator GetSocketRotation(struct FName InSocketName); // Function Engine.SceneComponent.GetSocketRotation // Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5af107c
	struct FQuat GetSocketQuaternion(struct FName InSocketName); // Function Engine.SceneComponent.GetSocketQuaternion // Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5af0fcc
	struct FVector GetSocketLocation(struct FName InSocketName); // Function Engine.SceneComponent.GetSocketLocation // Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5af0f14
	struct FVector GetRightVector(); // Function Engine.SceneComponent.GetRightVector // Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5af0db8
	struct FTransform GetRelativeTransform(); // Function Engine.SceneComponent.GetRelativeTransform // Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5af0d20
	struct APhysicsVolume* GetPhysicsVolume(); // Function Engine.SceneComponent.GetPhysicsVolume // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5af0b18
	void GetParentComponents(struct TArray<struct USceneComponent*> Parents); // Function Engine.SceneComponent.GetParentComponents // Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const // @ game+0x5af07ac
	int32 GetNumChildrenComponents(); // Function Engine.SceneComponent.GetNumChildrenComponents // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5af0020
	struct FVector GetForwardVector(); // Function Engine.SceneComponent.GetForwardVector // Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5aedb58
	struct FVector GetComponentVelocity(); // Function Engine.SceneComponent.GetComponentVelocity // Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5aed16c
	void GetChildrenComponents(bool bIncludeAllDescendants, struct TArray<struct USceneComponent*> Children); // Function Engine.SceneComponent.GetChildrenComponents // Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const // @ game+0x5aecd04
	struct USceneComponent* GetChildComponent(int32 ChildIndex); // Function Engine.SceneComponent.GetChildComponent // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5aecc64
	struct FName GetAttachSocketName(); // Function Engine.SceneComponent.GetAttachSocketName // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5aebf40
	struct USceneComponent* GetAttachParent(); // Function Engine.SceneComponent.GetAttachParent // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0xce1a84
	struct TArray<struct FName> GetAllSocketNames(); // Function Engine.SceneComponent.GetAllSocketNames // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5aebe0c
	bool DoesSocketExist(struct FName InSocketName); // Function Engine.SceneComponent.DoesSocketExist // Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5ae9184
	void DetachFromParent(bool bMaintainWorldPosition, bool bCallModify); // Function Engine.SceneComponent.DetachFromParent // Native|Public|BlueprintCallable // @ game+0x5ae8f50
};

// Class Engine.PrimitiveComponent
// Size: 0x9d0 (Inherited: 0x4b0)
struct UPrimitiveComponent : USceneComponent {
	char pad_4B0[0x8]; // 0x4b0(0x08)
	float MinDrawDistance; // 0x4b8(0x04)
	float LDMaxDrawDistance; // 0x4bc(0x04)
	float CachedMaxDrawDistance; // 0x4c0(0x04)
	enum class ESceneDepthPriorityGroup DepthPriorityGroup; // 0x4c4(0x01)
	enum class ESceneDepthPriorityGroup ViewOwnerDepthPriorityGroup; // 0x4c5(0x01)
	char pad_4C6[0x2]; // 0x4c6(0x02)
	char pad_4C8_0 : 3; // 0x4c8(0x01)
	char bAlwaysCreatePhysicsState : 1; // 0x4c8(0x01)
	char bGenerateOverlapEvents : 1; // 0x4c8(0x01)
	char bMultiBodyOverlap : 1; // 0x4c8(0x01)
	char bCheckAsyncSceneOnMove : 1; // 0x4c8(0x01)
	char bTraceComplexOnMove : 1; // 0x4c8(0x01)
	char bDisableForceFromCharacter : 1; // 0x4c9(0x01)
	char bReturnMaterialOnMove : 1; // 0x4c9(0x01)
	char bUseViewOwnerDepthPriorityGroup : 1; // 0x4c9(0x01)
	char bAllowCullDistanceVolume : 1; // 0x4c9(0x01)
	char bImportantMesh : 1; // 0x4c9(0x01)
	char bOverrideCullingDistances : 1; // 0x4c9(0x01)
	char pad_4C9_6 : 2; // 0x4c9(0x01)
	char pad_4CA[0x2]; // 0x4ca(0x02)
	float HLODScreenSize; // 0x4cc(0x04)
	char bHasMotionBlurVelocityMeshes : 1; // 0x4d0(0x01)
	char bVisibleInReflectionCaptures : 1; // 0x4d0(0x01)
	char bRenderInMainPass : 1; // 0x4d0(0x01)
	char bRenderInMono : 1; // 0x4d0(0x01)
	char bOwnerNoSee : 1; // 0x4d0(0x01)
	char bOnlyOwnerSee : 1; // 0x4d0(0x01)
	char bTreatAsBackgroundForOcclusion : 1; // 0x4d0(0x01)
	char bUseAsOccluder : 1; // 0x4d0(0x01)
	char bForceAsOccluder : 1; // 0x4d1(0x01)
	char bForceOcclusionQuerying : 1; // 0x4d1(0x01)
	char bForceDisableOcclusionQuerying : 1; // 0x4d1(0x01)
	char bSelectable : 1; // 0x4d1(0x01)
	char bForceMipStreaming : 1; // 0x4d1(0x01)
	char bHasPerInstanceHitProxies : 1; // 0x4d1(0x01)
	char pad_4D1_6 : 1; // 0x4d1(0x01)
	char CastShadow : 1; // 0x4d1(0x01)
	char bAffectDynamicIndirectLighting : 1; // 0x4d2(0x01)
	char bAffectDistanceFieldLighting : 1; // 0x4d2(0x01)
	char bCastDynamicShadow : 1; // 0x4d2(0x01)
	char bCastStaticShadow : 1; // 0x4d2(0x01)
	char bCastVolumetricTranslucentShadow : 1; // 0x4d2(0x01)
	char bSelfShadowOnly : 1; // 0x4d2(0x01)
	char bCastFarShadow : 1; // 0x4d2(0x01)
	char bCastInsetShadow : 1; // 0x4d2(0x01)
	char bCastCinematicShadow : 1; // 0x4d3(0x01)
	char bCastHiddenShadow : 1; // 0x4d3(0x01)
	char bCastShadowAsTwoSided : 1; // 0x4d3(0x01)
	char bLightAsIfStatic : 1; // 0x4d3(0x01)
	char bLightAttachmentsAsGroup : 1; // 0x4d3(0x01)
	char bReceiveCombinedCSMAndStaticShadowsFromStationaryLights : 1; // 0x4d3(0x01)
	char bSingleSampleShadowFromStationaryLights : 1; // 0x4d3(0x01)
	char bIgnoreRadialImpulse : 1; // 0x4d3(0x01)
	char bIgnoreRadialForce : 1; // 0x4d4(0x01)
	char bApplyImpulseOnDamage : 1; // 0x4d4(0x01)
	char bSyncBodySleep : 1; // 0x4d4(0x01)
	char AlwaysLoadOnClient : 1; // 0x4d4(0x01)
	char AlwaysLoadOnServer : 1; // 0x4d4(0x01)
	char bUseEditorCompositing : 1; // 0x4d4(0x01)
	char bRenderCustomDepth : 1; // 0x4d4(0x01)
	char pad_4D4_7 : 1; // 0x4d4(0x01)
	char pad_4D5_0 : 7; // 0x4d5(0x01)
	char bReceivesDecals : 1; // 0x4d5(0x01)
	char bReceivesDecalsEx : 1; // 0x4d6(0x01)
	char bDecalChannelValid : 1; // 0x4d6(0x01)
	char pad_4D6_2 : 6; // 0x4d6(0x01)
	char pad_4D7[0x1]; // 0x4d7(0x01)
	enum class EDecalChannel DecalChannel; // 0x4d8(0x01)
	enum class EIndoorOutdoorMask IndoorOutdoorMask; // 0x4d9(0x01)
	struct FLightingChannels LightingChannels; // 0x4da(0x03)
	enum class EIndirectLightingCacheQuality IndirectLightingCacheQuality; // 0x4dd(0x01)
	bool CustomDepthStencilValue; // 0x4de(0x01)
	enum class ERendererStencilMask CustomDepthStencilWriteMask; // 0x4df(0x01)
	struct TArray<enum class ECollisionChannel> IgnoreCollisionMaskOnSweep; // 0x4e0(0x10)
	int32 TranslucencySortPriority; // 0x4f0(0x04)
	int32 VisibilityId; // 0x4f4(0x04)
	char pad_4F8[0x4]; // 0x4f8(0x04)
	float LpvBiasMultiplier; // 0x4fc(0x04)
	struct FBodyInstance BodyInstance; // 0x500(0x230)
	char pad_730[0x8]; // 0x730(0x08)
	enum class EHasCustomNavigableGeometry bHasCustomNavigableGeometry; // 0x738(0x01)
	char pad_739[0x3b]; // 0x739(0x3b)
	float BoundsScale; // 0x774(0x04)
	float LastSubmitTime; // 0x778(0x04)
	float LastRenderTime; // 0x77c(0x04)
	float LastRenderTimeOnScreen; // 0x780(0x04)
	enum class ECanBeCharacterBase CanBeCharacterBase; // 0x784(0x01)
	char pad_785[0x1]; // 0x785(0x01)
	enum class ECanBeCharacterBase CanCharacterStepUpOn; // 0x786(0x01)
	char pad_787[0x1]; // 0x787(0x01)
	struct TArray<struct AActor*> MoveIgnoreActors; // 0x788(0x10)
	struct TArray<struct UPrimitiveComponent*> MoveIgnoreComponents; // 0x798(0x10)
	char pad_7A8[0xb8]; // 0x7a8(0xb8)
	struct FMulticastDelegate OnComponentHit; // 0x860(0x10)
	struct FMulticastDelegate OnComponentBeginOverlap; // 0x870(0x10)
	struct FMulticastDelegate OnComponentEndOverlap; // 0x880(0x10)
	struct FMulticastDelegate OnComponentWake; // 0x890(0x10)
	struct FMulticastDelegate OnComponentSleep; // 0x8a0(0x10)
	char pad_8B0[0x10]; // 0x8b0(0x10)
	struct FMulticastDelegate OnBeginCursorOver; // 0x8c0(0x10)
	struct FMulticastDelegate OnEndCursorOver; // 0x8d0(0x10)
	struct FMulticastDelegate OnClicked; // 0x8e0(0x10)
	struct FMulticastDelegate OnReleased; // 0x8f0(0x10)
	struct FMulticastDelegate OnInputTouchBegin; // 0x900(0x10)
	struct FMulticastDelegate OnInputTouchEnd; // 0x910(0x10)
	struct FMulticastDelegate OnInputTouchEnter; // 0x920(0x10)
	struct FMulticastDelegate OnInputTouchLeave; // 0x930(0x10)
	char pad_940[0x28]; // 0x940(0x28)
	struct UPrimitiveComponent* LODParentPrimitive; // 0x968(0x08)
	struct UPrimitiveComponent* SubstitutionBoundsPrimitive; // 0x970(0x08)
	struct FPrimitiveComponentPostPhysicsTickFunction PostPhysicsComponentTick; // 0x978(0x58)

	void WakeRigidBody(struct FName BoneName); // Function Engine.PrimitiveComponent.WakeRigidBody // Native|Public|BlueprintCallable // @ game+0x5b05670
	void WakeAllRigidBodies(); // Function Engine.PrimitiveComponent.WakeAllRigidBodies // Native|Public|BlueprintCallable // @ game+0x5b05658
	void SetWalkableSlopeOverride(struct FWalkableSlopeOverride NewOverride); // Function Engine.PrimitiveComponent.SetWalkableSlopeOverride // Final|Native|Public|HasOutParms|BlueprintCallable // @ game+0x5b040e8
	void SetUseCCD(bool InUseCCD, struct FName BoneName); // Function Engine.PrimitiveComponent.SetUseCCD // Native|Public|BlueprintCallable // @ game+0x5b03854
	void SetTranslucentSortPriority(int32 NewTranslucentSortPriority); // Function Engine.PrimitiveComponent.SetTranslucentSortPriority // Final|Native|Public|BlueprintCallable // @ game+0x5b035b0
	void SetSimulatePhysics(bool bSimulate); // Function Engine.PrimitiveComponent.SetSimulatePhysics // Native|Public|BlueprintCallable // @ game+0xc200b4
	void SetRenderInMono(bool bValue); // Function Engine.PrimitiveComponent.SetRenderInMono // Final|Native|Public|BlueprintCallable // @ game+0x5b02c50
	void SetRenderInMainPass(bool bValue); // Function Engine.PrimitiveComponent.SetRenderInMainPass // Final|Native|Public|BlueprintCallable // @ game+0x5b02bbc
	void SetRenderCustomDepth(bool bValue); // Function Engine.PrimitiveComponent.SetRenderCustomDepth // Final|Native|Public|BlueprintCallable // @ game+0x5b02b28
	void SetPhysMaterialOverride(struct UPhysicalMaterial* NewPhysMaterial); // Function Engine.PrimitiveComponent.SetPhysMaterialOverride // Native|Public|BlueprintCallable // @ game+0x5b02370
	void SetPhysicsMaxAngularVelocity(float NewMaxAngVel, bool bAddToCurrent, struct FName BoneName); // Function Engine.PrimitiveComponent.SetPhysicsMaxAngularVelocity // Final|Native|Public|BlueprintCallable // @ game+0x5b02404
	void SetPhysicsLinearVelocity(struct FVector NewVel, bool bAddToCurrent, struct FName BoneName); // Function Engine.PrimitiveComponent.SetPhysicsLinearVelocity // Final|Native|Public|HasDefaults|BlueprintCallable // @ game+0x4916d4
	void SetPhysicsAngularVelocity(struct FVector NewAngVel, bool bAddToCurrent, struct FName BoneName); // Function Engine.PrimitiveComponent.SetPhysicsAngularVelocity // Final|Native|Public|HasDefaults|BlueprintCallable // @ game+0xc0ba98
	void SetOwnerNoSee(bool bNewOwnerNoSee); // Function Engine.PrimitiveComponent.SetOwnerNoSee // Final|Native|Public|BlueprintCallable // @ game+0x5b02218
	void SetOnlyOwnerSee(bool bNewOnlyOwnerSee); // Function Engine.PrimitiveComponent.SetOnlyOwnerSee // Final|Native|Public|BlueprintCallable // @ game+0x5b02034
	void SetNotifyRigidBodyCollision(bool bNewNotifyRigidBodyCollision); // Function Engine.PrimitiveComponent.SetNotifyRigidBodyCollision // Native|Public|BlueprintCallable // @ game+0x5b01f9c
	void SetMaterialByName(struct FName MaterialSlotName, struct UMaterialInterface* Material); // Function Engine.PrimitiveComponent.SetMaterialByName // Native|Public|BlueprintCallable // @ game+0x5b019dc
	void SetMaterial(int32 ElementIndex, struct UMaterialInterface* Material); // Function Engine.PrimitiveComponent.SetMaterial // Native|Public|BlueprintCallable // @ game+0xcb8a04
	void SetMassScale(struct FName BoneName, float InMassScale); // Function Engine.PrimitiveComponent.SetMassScale // Native|Public|BlueprintCallable // @ game+0x5b018f8
	void SetMassOverrideInKg(struct FName BoneName, float MassInKg, bool bOverrideMass); // Function Engine.PrimitiveComponent.SetMassOverrideInKg // Native|Public|BlueprintCallable // @ game+0x5b017cc
	void SetLockedAxis(enum class EDOFMode LockedAxis); // Function Engine.PrimitiveComponent.SetLockedAxis // Native|Public|BlueprintCallable // @ game+0x5b015f4
	void SetLinearDamping(float InDamping); // Function Engine.PrimitiveComponent.SetLinearDamping // Native|Public|BlueprintCallable // @ game+0x5af89d4
	void SetEnableGravity(bool bGravityEnabled); // Function Engine.PrimitiveComponent.SetEnableGravity // Native|Public|BlueprintCallable // @ game+0x5b003fc
	void SetCustomDepthStencilWriteMask(enum class ERendererStencilMask WriteMaskBit); // Function Engine.PrimitiveComponent.SetCustomDepthStencilWriteMask // Final|Native|Public|BlueprintCallable // @ game+0x5b00150
	void SetCustomDepthStencilValue(int32 Value); // Function Engine.PrimitiveComponent.SetCustomDepthStencilValue // Final|Native|Public|BlueprintCallable // @ game+0x5b000c0
	void SetCullDistance(float NewCullDistance); // Function Engine.PrimitiveComponent.SetCullDistance // Final|Native|Public|BlueprintCallable // @ game+0x5b00028
	void SetConstraintMode(enum class EDOFMode ConstraintMode); // Function Engine.PrimitiveComponent.SetConstraintMode // Native|Public|BlueprintCallable // @ game+0x5affe90
	void SetCollisionResponseToChannel(enum class ECollisionChannel Channel, enum class ECollisionResponse NewResponse); // Function Engine.PrimitiveComponent.SetCollisionResponseToChannel // Native|Public|BlueprintCallable // @ game+0x5affa50
	void SetCollisionResponseToAllChannels(enum class ECollisionResponse NewResponse); // Function Engine.PrimitiveComponent.SetCollisionResponseToAllChannels // Native|Public|BlueprintCallable // @ game+0x5aff9b8
	void SetCollisionProfileName(struct FName InCollisionProfileName); // Function Engine.PrimitiveComponent.SetCollisionProfileName // Native|Public|BlueprintCallable // @ game+0x5aff924
	void SetCollisionObjectType(enum class ECollisionChannel Channel); // Function Engine.PrimitiveComponent.SetCollisionObjectType // Native|Public|BlueprintCallable // @ game+0x5aff88c
	void SetCollisionEnabled(enum class ECollisionEnabled NewType); // Function Engine.PrimitiveComponent.SetCollisionEnabled // Native|Public|BlueprintCallable // @ game+0xc45208
	void SetCenterOfMass(struct FVector CenterOfMassOffset, struct FName BoneName); // Function Engine.PrimitiveComponent.SetCenterOfMass // Final|Native|Public|HasDefaults|BlueprintCallable // @ game+0x5aff51c
	void SetCastShadow(bool NewCastShadow); // Function Engine.PrimitiveComponent.SetCastShadow // Final|Native|Public|BlueprintCallable // @ game+0x5aff3f0
	void SetBoundsScale(float NewBoundsScale); // Function Engine.PrimitiveComponent.SetBoundsScale // Final|Native|Public|BlueprintCallable // @ game+0x5aff198
	void SetAngularDamping(float InDamping); // Function Engine.PrimitiveComponent.SetAngularDamping // Native|Public|BlueprintCallable // @ game+0x5afdfd0
	void SetAllUseCCD(bool InUseCCD); // Function Engine.PrimitiveComponent.SetAllUseCCD // Native|Public|BlueprintCallable // @ game+0x5afdf38
	void SetAllPhysicsLinearVelocity(struct FVector NewVel, bool bAddToCurrent); // Function Engine.PrimitiveComponent.SetAllPhysicsLinearVelocity // Native|Public|HasDefaults|BlueprintCallable // @ game+0x5afde38
	void SetAllPhysicsAngularVelocity(struct FVector NewAngVel, bool bAddToCurrent); // Function Engine.PrimitiveComponent.SetAllPhysicsAngularVelocity // Native|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5afdd40
	void SetAllMassScale(float InMassScale); // Function Engine.PrimitiveComponent.SetAllMassScale // Native|Public|BlueprintCallable // @ game+0x5afdca4
	struct FVector ScaleByMomentOfInertia(struct FVector InputVector, struct FName BoneName); // Function Engine.PrimitiveComponent.ScaleByMomentOfInertia // Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5afab88
	void PutRigidBodyToSleep(struct FName BoneName); // Function Engine.PrimitiveComponent.PutRigidBodyToSleep // Final|Native|Public|BlueprintCallable // @ game+0x5af9ff4
	bool K2_LineTraceComponent(struct FVector TraceStart, struct FVector TraceEnd, bool bTraceComplex, bool bShowTrace, struct FVector HitLocation, struct FVector HitNormal, struct FName BoneName, struct FHitResult OutHit); // Function Engine.PrimitiveComponent.K2_LineTraceComponent // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5af5e14
	bool K2_IsQueryCollisionEnabled(); // Function Engine.PrimitiveComponent.K2_IsQueryCollisionEnabled // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5af5de0
	bool K2_IsPhysicsCollisionEnabled(); // Function Engine.PrimitiveComponent.K2_IsPhysicsCollisionEnabled // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5af5db0
	bool K2_IsCollisionEnabled(); // Function Engine.PrimitiveComponent.K2_IsCollisionEnabled // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5af5d84
	bool IsOverlappingComponent(struct UPrimitiveComponent* OtherComp); // Function Engine.PrimitiveComponent.IsOverlappingComponent // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5af294c
	bool IsOverlappingActor(struct AActor* Other); // Function Engine.PrimitiveComponent.IsOverlappingActor // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5af28ac
	bool IsGravityEnabled(); // Function Engine.PrimitiveComponent.IsGravityEnabled // Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5af24a4
	bool IsAnyRigidBodyAwake(); // Function Engine.PrimitiveComponent.IsAnyRigidBodyAwake // Native|Public|BlueprintCallable // @ game+0x5af2058
	void IgnoreComponentWhenMoving(struct UPrimitiveComponent* Component, bool bShouldIgnore); // Function Engine.PrimitiveComponent.IgnoreComponentWhenMoving // Final|Native|Public|BlueprintCallable // @ game+0x5af1d40
	void IgnoreActorWhenMoving(struct AActor* Actor, bool bShouldIgnore); // Function Engine.PrimitiveComponent.IgnoreActorWhenMoving // Final|Native|Public|BlueprintCallable // @ game+0x5af1c60
	struct FWalkableSlopeOverride GetWalkableSlopeOverride(); // Function Engine.PrimitiveComponent.GetWalkableSlopeOverride // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5af1b7c
	struct FVector GetPhysicsLinearVelocityAtPoint(struct FVector Point, struct FName BoneName); // Function Engine.PrimitiveComponent.GetPhysicsLinearVelocityAtPoint // Final|Native|Public|HasDefaults|BlueprintCallable // @ game+0x5af09e0
	struct FVector GetPhysicsLinearVelocity(struct FName BoneName); // Function Engine.PrimitiveComponent.GetPhysicsLinearVelocity // Final|Native|Public|HasDefaults|BlueprintCallable // @ game+0x8438dc
	struct FVector GetPhysicsAngularVelocity(struct FName BoneName); // Function Engine.PrimitiveComponent.GetPhysicsAngularVelocity // Final|Native|Public|HasDefaults|BlueprintCallable // @ game+0x5af0930
	void GetOverlappingComponents(struct TArray<struct UPrimitiveComponent*> InOverlappingComponents); // Function Engine.PrimitiveComponent.GetOverlappingComponents // Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const // @ game+0x5af052c
	void GetOverlappingActors(struct TArray<struct AActor*> OverlappingActors, struct UClass* ClassFilter); // Function Engine.PrimitiveComponent.GetOverlappingActors // Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const // @ game+0x5af0334
	struct TArray<struct FOverlapInfo> GetOverlapInfos(); // Function Engine.PrimitiveComponent.GetOverlapInfos // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5af018c
	int32 GetNumMaterials(); // Function Engine.PrimitiveComponent.GetNumMaterials // Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5af0058
	struct UMaterialInterface* GetMaterialFromCollisionFaceIndex(int32 FaceIndex); // Function Engine.PrimitiveComponent.GetMaterialFromCollisionFaceIndex // Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5aef870
	struct UMaterialInterface* GetMaterial(int32 ElementIndex); // Function Engine.PrimitiveComponent.GetMaterial // Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5aef7cc
	float GetMassScale(struct FName BoneName); // Function Engine.PrimitiveComponent.GetMassScale // Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5aef70c
	float GetMass(); // Function Engine.PrimitiveComponent.GetMass // Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5aef6e0
	float GetLinearDamping(); // Function Engine.PrimitiveComponent.GetLinearDamping // Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5aef5ac
	struct FVector GetInertiaTensor(struct FName BoneName); // Function Engine.PrimitiveComponent.GetInertiaTensor // Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x54881b8
	enum class ECollisionResponse GetCollisionResponseToChannel(enum class ECollisionChannel Channel); // Function Engine.PrimitiveComponent.GetCollisionResponseToChannel // Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5aed01c
	struct FName GetCollisionProfileName(); // Function Engine.PrimitiveComponent.GetCollisionProfileName // Final|Native|Public|BlueprintCallable // @ game+0x5aecfe4
	enum class ECollisionChannel GetCollisionObjectType(); // Function Engine.PrimitiveComponent.GetCollisionObjectType // Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5aecfbc
	enum class ECollisionEnabled GetCollisionEnabled(); // Function Engine.PrimitiveComponent.GetCollisionEnabled // Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5aecf94
	float GetClosestPointOnCollision(struct FVector Point, struct FVector OutPointOnBody, struct FName BoneName); // Function Engine.PrimitiveComponent.GetClosestPointOnCollision // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5aece38
	struct FVector GetCenterOfMass(struct FName BoneName); // Function Engine.PrimitiveComponent.GetCenterOfMass // Final|Native|Public|HasDefaults|BlueprintCallable // @ game+0x5aecb2c
	float GetAngularDamping(); // Function Engine.PrimitiveComponent.GetAngularDamping // Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5aebeac
	struct UMaterialInstanceDynamic* CreateDynamicMaterialInstance(int32 ElementIndex, struct UMaterialInterface* SourceMaterial); // Function Engine.PrimitiveComponent.CreateDynamicMaterialInstance // Native|Public|BlueprintCallable // @ game+0x5ae883c
	struct UMaterialInstanceDynamic* CreateAndSetMaterialInstanceDynamicFromMaterial(int32 ElementIndex, struct UMaterialInterface* Parent); // Function Engine.PrimitiveComponent.CreateAndSetMaterialInstanceDynamicFromMaterial // Native|Public|BlueprintCallable // @ game+0x5ae874c
	struct UMaterialInstanceDynamic* CreateAndSetMaterialInstanceDynamic(int32 ElementIndex); // Function Engine.PrimitiveComponent.CreateAndSetMaterialInstanceDynamic // Native|Public|BlueprintCallable // @ game+0x5ae86a8
	struct TArray<struct UPrimitiveComponent*> CopyArrayOfMoveIgnoreComponents(); // Function Engine.PrimitiveComponent.CopyArrayOfMoveIgnoreComponents // Final|Native|Public|BlueprintCallable // @ game+0x5ae8620
	struct TArray<struct AActor*> CopyArrayOfMoveIgnoreActors(); // Function Engine.PrimitiveComponent.CopyArrayOfMoveIgnoreActors // Final|Native|Public|BlueprintCallable // @ game+0x5ae8598
	void ClearMoveIgnoreComponents(); // Function Engine.PrimitiveComponent.ClearMoveIgnoreComponents // Final|Native|Public|BlueprintCallable // @ game+0x5ae597c
	void ClearMoveIgnoreActors(); // Function Engine.PrimitiveComponent.ClearMoveIgnoreActors // Final|Native|Public|BlueprintCallable // @ game+0x5ae5960
	bool CanCharacterStepUp(struct APawn* Pawn); // Function Engine.PrimitiveComponent.CanCharacterStepUp // Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5ae5574
	void AddTorque(struct FVector Torque, struct FName BoneName, bool bAccelChange); // Function Engine.PrimitiveComponent.AddTorque // Final|Native|Public|HasDefaults|BlueprintCallable // @ game+0x5ae4dfc
	void AddRadialImpulse(struct FVector Origin, float Radius, float Strength, enum class ERadialImpulseFalloff Falloff, bool bVelChange); // Function Engine.PrimitiveComponent.AddRadialImpulse // Native|Public|HasDefaults|BlueprintCallable // @ game+0x5ae493c
	void AddRadialForce(struct FVector Origin, float Radius, float Strength, enum class ERadialImpulseFalloff Falloff, bool bAccelChange); // Function Engine.PrimitiveComponent.AddRadialForce // Native|Public|HasDefaults|BlueprintCallable // @ game+0x5ae4768
	void AddImpulseAtLocation(struct FVector Impulse, struct FVector Location, struct FName BoneName); // Function Engine.PrimitiveComponent.AddImpulseAtLocation // Native|Public|HasDefaults|BlueprintCallable // @ game+0x5ae4068
	void AddImpulse(struct FVector Impulse, struct FName BoneName, bool bVelChange); // Function Engine.PrimitiveComponent.AddImpulse // Native|Public|HasDefaults|BlueprintCallable // @ game+0x5ae3f28
	void AddForceAtLocationLocal(struct FVector force, struct FVector Location, struct FName BoneName); // Function Engine.PrimitiveComponent.AddForceAtLocationLocal // Native|Public|HasDefaults|BlueprintCallable // @ game+0x5ae3b14
	void AddForceAtLocation(struct FVector force, struct FVector Location, struct FName BoneName); // Function Engine.PrimitiveComponent.AddForceAtLocation // Native|Public|HasDefaults|BlueprintCallable // @ game+0x5ae39c8
	void AddForce(struct FVector force, struct FName BoneName, bool bAccelChange); // Function Engine.PrimitiveComponent.AddForce // Native|Public|HasDefaults|BlueprintCallable // @ game+0x5ae3888
	void AddAngularImpulse(struct FVector Impulse, struct FName BoneName, bool bVelChange); // Function Engine.PrimitiveComponent.AddAngularImpulse // Native|Public|HasDefaults|BlueprintCallable // @ game+0x5ae2fb4
};

// Class Engine.MeshComponent
// Size: 0xae0 (Inherited: 0x9d0)
struct UMeshComponent : UPrimitiveComponent {
	struct TArray<struct UMaterialInterface*> OverrideMaterials; // 0x9d0(0x10)
	char pad_9E0[0x100]; // 0x9e0(0x100)

	void SetVectorParameterValueOnMaterials(struct FName ParameterName, struct FVector ParameterValue); // Function Engine.MeshComponent.SetVectorParameterValueOnMaterials // Final|Native|Public|HasDefaults|BlueprintCallable // @ game+0x5b03bc4
	void SetScalarParameterValueOnMaterials(struct FName ParameterName, float ParameterValue); // Function Engine.MeshComponent.SetScalarParameterValueOnMaterials // Final|Native|Public|BlueprintCallable // @ game+0xc17910
	bool IsMaterialSlotNameValid(struct FName MaterialSlotName); // Function Engine.MeshComponent.IsMaterialSlotNameValid // Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5af26c4
	struct TArray<struct FName> GetMaterialSlotNames(); // Function Engine.MeshComponent.GetMaterialSlotNames // Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5aef9bc
	struct TArray<struct UMaterialInterface*> GetMaterials(); // Function Engine.MeshComponent.GetMaterials // Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5aefa48
	int32 GetMaterialIndex(struct FName MaterialSlotName); // Function Engine.MeshComponent.GetMaterialIndex // Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5aef914
};

// Class Engine.SkinnedMeshComponent
// Size: 0xc80 (Inherited: 0xae0)
struct USkinnedMeshComponent : UMeshComponent {
	struct USkeletalMesh* SkeletalMesh; // 0xad8(0x08)
	struct USkinnedMeshComponent* MasterPoseComponent; // 0xae0(0x08)
	char pad_AF0[0x58]; // 0xaf0(0x58)
	char bUseBoundsFromMasterPoseComponent : 1; // 0xb48(0x01)
	char pad_B48_1 : 7; // 0xb48(0x01)
	char pad_B49[0x7]; // 0xb49(0x07)
	struct TArray<struct FBoxSphereBounds> ExtendedBoundsArray; // 0xb50(0x10)
	char pad_B60[0x20]; // 0xb60(0x20)
	struct UPhysicsAsset* PhysicsAssetOverride; // 0xb80(0x08)
	int32 ForcedLodModel; // 0xb88(0x04)
	int32 MinLodModel; // 0xb8c(0x04)
	char pad_B90[0x10]; // 0xb90(0x10)
	struct TArray<struct FSkelMeshComponentLODInfo> LODInfo; // 0xba0(0x10)
	float StreamingDistanceMultiplier; // 0xbb0(0x04)
	struct FColor WireframeColor; // 0xbb4(0x04)
	char bForceWireframe : 1; // 0xbb8(0x01)
	char bDisplayBones : 1; // 0xbb8(0x01)
	char bDisableMorphTarget : 1; // 0xbb8(0x01)
	char bHideSkin : 1; // 0xbb8(0x01)
	char pad_BB8_4 : 4; // 0xbb8(0x01)
	char pad_BB9[0x17]; // 0xbb9(0x17)
	char bPerBoneMotionBlur : 1; // 0xbd0(0x01)
	char bComponentUseFixedSkelBounds : 1; // 0xbd0(0x01)
	char bConsiderAllBodiesForBounds : 1; // 0xbd0(0x01)
	char bSyncAttachParentLOD : 1; // 0xbd0(0x01)
	char pad_BD0_4 : 4; // 0xbd0(0x01)
	char pad_BD1[0x3]; // 0xbd1(0x03)
	enum class EMeshComponentUpdateFlag MeshComponentUpdateFlag; // 0xbd4(0x01)
	char pad_BD5[0x3]; // 0xbd5(0x03)
	char bForceMeshObjectUpdate : 1; // 0xbd8(0x01)
	char bCanHighlightSelectedSections : 1; // 0xbd8(0x01)
	char bRecentlyRendered : 1; // 0xbd8(0x01)
	char pad_BD8_3 : 5; // 0xbd8(0x01)
	char pad_BD9[0x3]; // 0xbd9(0x03)
	bool CustomSortAlternateIndexMode; // 0xbdc(0x01)
	char pad_BDD[0x3]; // 0xbdd(0x03)
	char bCastCapsuleDirectShadow : 1; // 0xbe0(0x01)
	char bCastCapsuleIndirectShadow : 1; // 0xbe0(0x01)
	char pad_BE0_2 : 6; // 0xbe0(0x01)
	char pad_BE1[0x3]; // 0xbe1(0x03)
	char bRenderStatic : 1; // 0xbe4(0x01)
	char pad_BE4_1 : 7; // 0xbe4(0x01)
	char pad_BE5[0x3]; // 0xbe5(0x03)
	float CapsuleIndirectShadowMinVisibility; // 0xbe8(0x04)
	char bCPUSkinning : 1; // 0xbec(0x01)
	char pad_BEC_1 : 7; // 0xbec(0x01)
	char pad_BED[0xf]; // 0xbed(0x0f)
	struct FBoxSphereBounds CachedLocalBounds; // 0xbfc(0x1c)
	bool bCachedLocalBoundsUpToDate; // 0xc18(0x01)
	bool bEnableUpdateRateOptimizations; // 0xc19(0x01)
	bool bDisplayDebugUpdateRateOptimizations; // 0xc1a(0x01)
	char pad_C1B[0x56]; // 0xc1b(0x56)
	bool bShouldRefreshTransformOnce; // 0xc71(0x01)
	bool bSkipEvaluationAndFinalization; // 0xc72(0x01)
	char pad_C73[0xd]; // 0xc73(0x0d)

	void UnHideBoneByName(struct FName BoneName); // Function Engine.SkinnedMeshComponent.UnHideBoneByName // Final|Native|Public|BlueprintCallable // @ game+0x5b5bca4
	void TransformToBoneSpace(struct FName BoneName, struct FVector InPosition, struct FRotator InRotation, struct FVector OutPosition, struct FRotator OutRotation); // Function Engine.SkinnedMeshComponent.TransformToBoneSpace // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5b5ba6c
	void TransformFromBoneSpace(struct FName BoneName, struct FVector InPosition, struct FRotator InRotation, struct FVector OutPosition, struct FRotator OutRotation); // Function Engine.SkinnedMeshComponent.TransformFromBoneSpace // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b5b698
	void SetVertexColorOverride_LinearColor(int32 LODIndex, struct TArray<struct FLinearColor> VertexColors); // Function Engine.SkinnedMeshComponent.SetVertexColorOverride_LinearColor // Final|Native|Public|HasOutParms|BlueprintCallable // @ game+0x5b52724
	void SetSkinWeightOverride(int32 LODIndex, struct TArray<struct FSkelMeshSkinWeightInfo> SkinWeights); // Function Engine.SkinnedMeshComponent.SetSkinWeightOverride // Final|Native|Public|HasOutParms|BlueprintCallable // @ game+0x5b4f7b4
	void SetSkeletalMesh(struct USkeletalMesh* NewMesh, bool bReinitPose); // Function Engine.SkinnedMeshComponent.SetSkeletalMesh // Native|Public|BlueprintCallable // @ game+0x5b4f640
	void SetRenderStatic(bool bNewValue); // Function Engine.SkinnedMeshComponent.SetRenderStatic // Final|Native|Public|BlueprintCallable // @ game+0x5b4f1a8
	void SetPhysicsAsset(struct UPhysicsAsset* NewPhysicsAsset, bool bForceReInit); // Function Engine.SkinnedMeshComponent.SetPhysicsAsset // Native|Public|BlueprintCallable // @ game+0x5b4e278
	void SetMinLOD(int32 InNewMinLOD); // Function Engine.SkinnedMeshComponent.SetMinLOD // Final|Native|Public|BlueprintCallable // @ game+0x5b4d348
	void SetMasterPoseComponent(struct USkinnedMeshComponent* NewMasterBoneComponent); // Function Engine.SkinnedMeshComponent.SetMasterPoseComponent // Final|Native|Public|BlueprintCallable // @ game+0x5b4d218
	void SetForcedLOD(int32 InNewForcedLOD); // Function Engine.SkinnedMeshComponent.SetForcedLOD // Final|Native|Public|BlueprintCallable // @ game+0x5b4a74c
	void SetCastCapsuleIndirectShadow(bool bNewValue); // Function Engine.SkinnedMeshComponent.SetCastCapsuleIndirectShadow // Final|Native|Public|BlueprintCallable // @ game+0x5b46fa0
	void SetCastCapsuleDirectShadow(bool bNewValue); // Function Engine.SkinnedMeshComponent.SetCastCapsuleDirectShadow // Final|Native|Public|BlueprintCallable // @ game+0x5b46ef0
	void SetCapsuleIndirectShadowMinVisibility(float NewValue); // Function Engine.SkinnedMeshComponent.SetCapsuleIndirectShadowMinVisibility // Final|Native|Public|BlueprintCallable // @ game+0x5b46a4c
	bool IsBoneHiddenByName(struct FName BoneName); // Function Engine.SkinnedMeshComponent.IsBoneHiddenByName // Final|Native|Public|BlueprintCallable // @ game+0x5b2f8bc
	void HideBoneByName(struct FName BoneName, enum class EPhysBodyOp PhysBodyOption); // Function Engine.SkinnedMeshComponent.HideBoneByName // Final|Native|Public|BlueprintCallable // @ game+0x5b2e404
	struct FName GetSocketBoneName(struct FName InSocketName); // Function Engine.SkinnedMeshComponent.GetSocketBoneName // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b29dd0
	struct FName GetParentBone(struct FName BoneName); // Function Engine.SkinnedMeshComponent.GetParentBone // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b279bc
	int32 GetNumBones(); // Function Engine.SkinnedMeshComponent.GetNumBones // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b275f8
	struct FName GetBoneName(int32 BoneIndex); // Function Engine.SkinnedMeshComponent.GetBoneName // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b2281c
	int32 GetBoneIndex(struct FName BoneName); // Function Engine.SkinnedMeshComponent.GetBoneIndex // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b22560
	struct FName FindClosestBone_K2(struct FVector TestLocation, struct FVector BoneLocation, float IgnoreScale, bool bRequirePhysicsAsset); // Function Engine.SkinnedMeshComponent.FindClosestBone_K2 // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5b1f26c
	void ClearVertexColorOverride(int32 LODIndex); // Function Engine.SkinnedMeshComponent.ClearVertexColorOverride // Final|Native|Public|BlueprintCallable // @ game+0x5b17024
	void ClearSkinWeightOverride(int32 LODIndex); // Function Engine.SkinnedMeshComponent.ClearSkinWeightOverride // Final|Native|Public|BlueprintCallable // @ game+0x5b16cc0
	bool BoneIsChildOf(struct FName BoneName, struct FName ParentBoneName); // Function Engine.SkinnedMeshComponent.BoneIsChildOf // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b0fac4
};

// Class Engine.SkeletalMeshComponent
// Size: 0x1170 (Inherited: 0xc80)
struct USkeletalMeshComponent : USkinnedMeshComponent {
	struct UAnimBlueprintGeneratedClass* AnimBlueprintGeneratedClass; // 0xc80(0x08)
	struct UClass* AnimClass; // 0xc88(0x08)
	struct UAnimInstance* AnimScriptInstance; // 0xc90(0x08)
	struct TArray<struct UAnimInstance*> SubInstances; // 0xc98(0x10)
	struct UAnimInstance* PostProcessAnimInstance; // 0xca8(0x08)
	struct FSingleAnimationPlayData AnimationData; // 0xcb0(0x18)
	char pad_CC8[0x30]; // 0xcc8(0x30)
	struct TArray<struct FTransform> CachedBoneSpaceTransforms; // 0xcf8(0x10)
	struct TArray<struct FTransform> CachedComponentSpaceTransforms; // 0xd08(0x10)
	char pad_D18[0x20]; // 0xd18(0x20)
	float GlobalAnimRateScale; // 0xd38(0x04)
	enum class EKinematicBonesUpdateToPhysics KinematicBonesUpdateType; // 0xd3c(0x01)
	enum class EPhysicsTransformUpdateMode PhysicsTransformUpdateMode; // 0xd3d(0x01)
	char pad_D3E[0x1]; // 0xd3e(0x01)
	enum class EAnimationMode AnimationMode; // 0xd3f(0x01)
	char pad_D40[0x4]; // 0xd40(0x04)
	char pad_D44_0 : 1; // 0xd44(0x01)
	char bHasValidBodies : 1; // 0xd44(0x01)
	char pad_D44_2 : 1; // 0xd44(0x01)
	char bBlendPhysics : 1; // 0xd44(0x01)
	char pad_D44_4 : 2; // 0xd44(0x01)
	char bEnablePhysicsOnDedicatedServer : 1; // 0xd44(0x01)
	char bUpdateJointsFromAnimation : 1; // 0xd44(0x01)
	char bDisableClothSimulation : 1; // 0xd45(0x01)
	char pad_D45_1 : 2; // 0xd45(0x01)
	char bCollideWithEnvironment : 1; // 0xd45(0x01)
	char bCollideWithAttachedChildren : 1; // 0xd45(0x01)
	char bLocalSpaceSimulation : 1; // 0xd45(0x01)
	char bClothMorphTarget : 1; // 0xd45(0x01)
	char bResetAfterTeleport : 1; // 0xd45(0x01)
	char pad_D46_0 : 1; // 0xd46(0x01)
	char bNoSkeletonUpdate : 1; // 0xd46(0x01)
	char bPauseAnims : 1; // 0xd46(0x01)
	char bUseRefPoseOnInitAnim : 1; // 0xd46(0x01)
	char bEnablePerPolyCollision : 1; // 0xd46(0x01)
	char bOnlyAllowAutonomousTickPose : 1; // 0xd46(0x01)
	char bIsAutonomousTickPose : 1; // 0xd46(0x01)
	char bForceRefpose : 1; // 0xd46(0x01)
	char bOldForceRefPose : 1; // 0xd47(0x01)
	char bShowPrePhysBones : 1; // 0xd47(0x01)
	char bRequiredBonesUpToDate : 1; // 0xd47(0x01)
	char bAnimTreeInitialised : 1; // 0xd47(0x01)
	char bIncludeComponentLocationIntoBounds : 1; // 0xd47(0x01)
	char bEnableLineCheckWithBounds : 1; // 0xd47(0x01)
	char pad_D47_6 : 2; // 0xd47(0x01)
	char bNeedsQueuedAnimEventsDispatched : 1; // 0xd48(0x01)
	char pad_D48_1 : 7; // 0xd48(0x01)
	char pad_D49_0 : 2; // 0xd49(0x01)
	char bDefaultLooping : 1; // 0xd49(0x01)
	char bDefaultPlaying : 1; // 0xd49(0x01)
	char pad_D49_4 : 4; // 0xd49(0x01)
	uint16 CachedAnimCurveUidVersion; // 0xd4a(0x02)
	float ClothBlendWeight; // 0xd4c(0x04)
	struct FVector RootBoneTranslation; // 0xd50(0x0c)
	char pad_D5C[0x4]; // 0xd5c(0x04)
	struct UBodySetup* BodySetup; // 0xd60(0x08)
	float TeleportDistanceThreshold; // 0xd68(0x04)
	float TeleportRotationThreshold; // 0xd6c(0x04)
	struct FVector LineCheckBoundsScale; // 0xd70(0x0c)
	char pad_D7C[0x4]; // 0xd7c(0x04)
	struct FMulticastDelegate OnConstraintBroken; // 0xd80(0x10)
	char pad_D90[0xe0]; // 0xd90(0xe0)
	struct UClass* ClothingSimulationFactory; // 0xe70(0x08)
	char pad_E78[0x1e8]; // 0xe78(0x1e8)
	struct UAnimSequence* SequenceToPlay; // 0x1060(0x08)
	struct UAnimationAsset* AnimToPlay; // 0x1068(0x08)
	float DefaultPosition; // 0x1070(0x04)
	float DefaultPlayRate; // 0x1074(0x04)
	uint32 LastPoseTickFrame; // 0x1078(0x04)
	float LastPoseTickTime; // 0x107c(0x04)
	char pad_1080[0xf0]; // 0x1080(0xf0)

	void UnbindClothFromMasterPoseComponent(bool bRestoreSimulationSpace); // Function Engine.SkeletalMeshComponent.UnbindClothFromMasterPoseComponent // Final|Native|Public|BlueprintCallable // @ game+0x5b5bd34
	void SuspendClothingSimulation(); // Function Engine.SkeletalMeshComponent.SuspendClothingSimulation // Final|Native|Public|BlueprintCallable // @ game+0x5b5a9e0
	void Stop(); // Function Engine.SkeletalMeshComponent.Stop // Final|Native|Public|BlueprintCallable // @ game+0x3c1f08
	void SnapshotPose(struct FPoseSnapshot Snapshot); // Function Engine.SkeletalMeshComponent.SnapshotPose // Final|Native|Public|HasOutParms|BlueprintCallable // @ game+0x5b55208
	void SetUpdateAnimationInEditor(bool NewUpdateState); // Function Engine.SkeletalMeshComponent.SetUpdateAnimationInEditor // Final|Native|Public|BlueprintCallable // @ game+0x4d09aac
	void SetPosition(float InPos, bool bFireNotifies); // Function Engine.SkeletalMeshComponent.SetPosition // Final|Native|Public|BlueprintCallable // @ game+0x5b4e944
	void SetPlayRate(float Rate); // Function Engine.SkeletalMeshComponent.SetPlayRate // Final|Native|Public|BlueprintCallable // @ game+0x3c20bc
	void SetPhysicsBlendWeight(float PhysicsBlendWeight); // Function Engine.SkeletalMeshComponent.SetPhysicsBlendWeight // Final|Native|Public|BlueprintCallable // @ game+0x5b4e35c
	void SetNotifyRigidBodyCollisionBelow(bool bNewNotifyRigidBodyCollision, struct FName BoneName, bool bIncludeSelf); // Function Engine.SkeletalMeshComponent.SetNotifyRigidBodyCollisionBelow // Native|Public|BlueprintCallable // @ game+0x5b4da9c
	void SetMorphTarget(struct FName MorphTargetName, float Value, bool bRemoveZeroWeight); // Function Engine.SkeletalMeshComponent.SetMorphTarget // Final|Native|Public|BlueprintCallable // @ game+0x5b4d614
	void SetEnablePhysicsBlending(bool bNewBlendPhysics); // Function Engine.SkeletalMeshComponent.SetEnablePhysicsBlending // Final|Native|Public|BlueprintCallable // @ game+0x5b4957c
	void SetEnableGravityOnAllBodiesBelow(bool bEnableGravity, struct FName BoneName, bool bIncludeSelf); // Function Engine.SkeletalMeshComponent.SetEnableGravityOnAllBodiesBelow // Final|Native|Public|BlueprintCallable // @ game+0x5b492b8
	void SetEnableBodyGravity(bool bEnableGravity, struct FName BoneName); // Function Engine.SkeletalMeshComponent.SetEnableBodyGravity // Final|Native|Public|BlueprintCallable // @ game+0x5b491cc
	void SetConstraintProfileForAll(struct FName ProfileName, bool bDefaultIfNotFound); // Function Engine.SkeletalMeshComponent.SetConstraintProfileForAll // Final|Native|Public|BlueprintCallable // @ game+0x5b47b4c
	void SetConstraintProfile(struct FName JointName, struct FName ProfileName, bool bDefaultIfNotFound); // Function Engine.SkeletalMeshComponent.SetConstraintProfile // Final|Native|Public|BlueprintCallable // @ game+0x5b47a1c
	void SetClothMaxDistanceScale(float Scale); // Function Engine.SkeletalMeshComponent.SetClothMaxDistanceScale // Final|Native|Public|BlueprintCallable // @ game+0x5b475bc
	void SetBodyNotifyRigidBodyCollision(bool bNewNotifyRigidBodyCollision, struct FName BoneName); // Function Engine.SkeletalMeshComponent.SetBodyNotifyRigidBodyCollision // Native|Public|BlueprintCallable // @ game+0x5b45b00
	void SetAnimInstanceClass(struct UClass* NewClass); // Function Engine.SkeletalMeshComponent.SetAnimInstanceClass // Final|Native|Public|BlueprintCallable // @ game+0x5b44e70
	void SetAnimationMode(enum class EAnimationMode InAnimationMode); // Function Engine.SkeletalMeshComponent.SetAnimationMode // Final|Native|Public|BlueprintCallable // @ game+0x3c2cbc
	void SetAnimation(struct UAnimationAsset* NewAnimToPlay); // Function Engine.SkeletalMeshComponent.SetAnimation // Final|Native|Public|BlueprintCallable // @ game+0x3c21d0
	void SetAngularLimits(struct FName InBoneName, float Swing1LimitAngle, float TwistLimitAngle, float Swing2LimitAngle); // Function Engine.SkeletalMeshComponent.SetAngularLimits // Final|Native|Public|BlueprintCallable // @ game+0x5b44410
	void SetAllMotorsAngularVelocityDrive(bool bEnableSwingDrive, bool bEnableTwistDrive, bool bSkipCustomPhysicsType); // Function Engine.SkeletalMeshComponent.SetAllMotorsAngularVelocityDrive // Final|Native|Public|BlueprintCallable // @ game+0x5b43f94
	void SetAllMotorsAngularPositionDrive(bool bEnableSwingDrive, bool bEnableTwistDrive, bool bSkipCustomPhysicsType); // Function Engine.SkeletalMeshComponent.SetAllMotorsAngularPositionDrive // Final|Native|Public|BlueprintCallable // @ game+0x5b43e50
	void SetAllMotorsAngularDriveParams(float InSpring, float InDamping, float InForceLimit, bool bSkipCustomPhysicsType); // Function Engine.SkeletalMeshComponent.SetAllMotorsAngularDriveParams // Final|Native|Public|BlueprintCallable // @ game+0x5b43cd0
	void SetAllBodiesSimulatePhysics(bool bNewSimulate); // Function Engine.SkeletalMeshComponent.SetAllBodiesSimulatePhysics // Final|Native|Public|BlueprintCallable // @ game+0x5b43c3c
	void SetAllBodiesPhysicsBlendWeight(float PhysicsBlendWeight, bool bSkipCustomPhysicsType); // Function Engine.SkeletalMeshComponent.SetAllBodiesPhysicsBlendWeight // Final|Native|Public|BlueprintCallable // @ game+0xc207e8
	void SetAllBodiesBelowSimulatePhysics(struct FName InBoneName, bool bNewSimulate, bool bIncludeSelf); // Function Engine.SkeletalMeshComponent.SetAllBodiesBelowSimulatePhysics // Final|Native|Public|HasOutParms|BlueprintCallable // @ game+0x9a7544
	void SetAllBodiesBelowPhysicsBlendWeight(struct FName InBoneName, float PhysicsBlendWeight, bool bSkipCustomPhysicsType, bool bIncludeSelf); // Function Engine.SkeletalMeshComponent.SetAllBodiesBelowPhysicsBlendWeight // Final|Native|Public|HasOutParms|BlueprintCallable // @ game+0x5b43a98
	void ResumeClothingSimulation(); // Function Engine.SkeletalMeshComponent.ResumeClothingSimulation // Final|Native|Public|BlueprintCallable // @ game+0x5b42544
	void ResetClothTeleportMode(); // Function Engine.SkeletalMeshComponent.ResetClothTeleportMode // Final|Native|Public|BlueprintCallable // @ game+0x5b42270
	void ResetAllBodiesSimulatePhysics(); // Function Engine.SkeletalMeshComponent.ResetAllBodiesSimulatePhysics // Final|Native|Public|BlueprintCallable // @ game+0x5b421cc
	void PlayAnimation(struct UAnimationAsset* NewAnimToPlay, bool bLooping); // Function Engine.SkeletalMeshComponent.PlayAnimation // Final|Native|Public|BlueprintCallable // @ game+0x5b3d5e8
	void Play(bool bLooping); // Function Engine.SkeletalMeshComponent.Play // Final|Native|Public|BlueprintCallable // @ game+0x3c1fa8
	void OverrideAnimationData(struct UAnimationAsset* InAnimToPlay, bool bIsLooping, bool bIsPlaying, float Position, float PlayRate); // Function Engine.SkeletalMeshComponent.OverrideAnimationData // Final|Native|Public|BlueprintCallable // @ game+0x5b3cae4
	bool K2_GetClosestPointOnPhysicsAsset(struct FVector WorldPosition, struct FVector ClosestWorldPosition, struct FVector Normal, struct FName BoneName, float Distance); // Function Engine.SkeletalMeshComponent.K2_GetClosestPointOnPhysicsAsset // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5b30a9c
	bool IsPlaying(); // Function Engine.SkeletalMeshComponent.IsPlaying // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b2fed4
	bool IsClothingSimulationSuspended(); // Function Engine.SkeletalMeshComponent.IsClothingSimulationSuspended // Final|Native|Public|BlueprintCallable // @ game+0x5b2f988
	bool IsBodyGravityEnabled(struct FName BoneName); // Function Engine.SkeletalMeshComponent.IsBodyGravityEnabled // Final|Native|Public|BlueprintCallable // @ game+0x5b2f80c
	bool HasValidAnimationInstance(); // Function Engine.SkeletalMeshComponent.HasValidAnimationInstance // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b2e2bc
	struct FVector GetSkeletalCenterOfMass(); // Function Engine.SkeletalMeshComponent.GetSkeletalCenterOfMass // Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5b29d9c
	struct UAnimInstance* GetPostProcessInstance(); // Function Engine.SkeletalMeshComponent.GetPostProcessInstance // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b284b4
	float GetPosition(); // Function Engine.SkeletalMeshComponent.GetPosition // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b28170
	float GetPlayRate(); // Function Engine.SkeletalMeshComponent.GetPlayRate // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b27c18
	float GetMorphTarget(struct FName MorphTargetName); // Function Engine.SkeletalMeshComponent.GetMorphTarget // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b274fc
	void GetCurrentJointAngles(struct FName InBoneName, float Swing1Angle, float TwistAngle, float Swing2Angle); // Function Engine.SkeletalMeshComponent.GetCurrentJointAngles // Final|Native|Public|HasOutParms|BlueprintCallable // @ game+0x5b23380
	float GetClothMaxDistanceScale(); // Function Engine.SkeletalMeshComponent.GetClothMaxDistanceScale // Final|Native|Public|BlueprintCallable // @ game+0x5b22eac
	float GetBoneMass(struct FName BoneName, bool bScaleMass); // Function Engine.SkeletalMeshComponent.GetBoneMass // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b22730
	struct UAnimInstance* GetAnimInstance(); // Function Engine.SkeletalMeshComponent.GetAnimInstance // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0xc4b730
	enum class EAnimationMode GetAnimationMode(); // Function Engine.SkeletalMeshComponent.GetAnimationMode // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b21e04
	void ForceClothNextUpdateTeleportAndReset(); // Function Engine.SkeletalMeshComponent.ForceClothNextUpdateTeleportAndReset // Final|Native|Public|BlueprintCallable // @ game+0x5b20c44
	void ForceClothNextUpdateTeleport(); // Function Engine.SkeletalMeshComponent.ForceClothNextUpdateTeleport // Final|Native|Public|BlueprintCallable // @ game+0x5b20c2c
	struct FName FindConstraintBoneName(int32 ConstraintIndex); // Function Engine.SkeletalMeshComponent.FindConstraintBoneName // Final|Native|Public|BlueprintCallable // @ game+0x5b1f874
	void ClearMorphTargets(); // Function Engine.SkeletalMeshComponent.ClearMorphTargets // Final|Native|Public|BlueprintCallable // @ game+0x5b16c10
	void BreakConstraint(struct FVector Impulse, struct FVector HitLocation, struct FName InBoneName); // Function Engine.SkeletalMeshComponent.BreakConstraint // Final|Native|Public|HasDefaults|BlueprintCallable // @ game+0x5b127d0
	void BindClothToMasterPoseComponent(); // Function Engine.SkeletalMeshComponent.BindClothToMasterPoseComponent // Final|Native|Public|BlueprintCallable // @ game+0x5b0e810
	void AddImpulseToAllBodiesBelow(struct FVector Impulse, struct FName BoneName, bool bVelChange, bool bIncludeSelf); // Function Engine.SkeletalMeshComponent.AddImpulseToAllBodiesBelow // Native|Public|HasDefaults|BlueprintCallable // @ game+0x5b09b74
	void AddForceToAllBodiesBelow(struct FVector force, struct FName BoneName, bool bAccelChange, bool bIncludeSelf); // Function Engine.SkeletalMeshComponent.AddForceToAllBodiesBelow // Native|Public|HasDefaults|BlueprintCallable // @ game+0x5b099e0
	void AccumulateAllBodiesBelowPhysicsBlendWeight(struct FName InBoneName, float AddPhysicsBlendWeight, bool bSkipCustomPhysicsType); // Function Engine.SkeletalMeshComponent.AccumulateAllBodiesBelowPhysicsBlendWeight // Final|Native|Public|HasOutParms|BlueprintCallable // @ game+0x5b0925c
};

// Class Engine.MovementComponent
// Size: 0x250 (Inherited: 0x200)
struct UMovementComponent : UActorComponent {
	struct USceneComponent* UpdatedComponent; // 0x200(0x08)
	struct UPrimitiveComponent* UpdatedPrimitive; // 0x208(0x08)
	char pad_210[0x4]; // 0x210(0x04)
	struct FVector Velocity; // 0x214(0x0c)
	char bConstrainToPlane : 1; // 0x220(0x01)
	char bSnapToPlaneAtStart : 1; // 0x220(0x01)
	char pad_220_2 : 6; // 0x220(0x01)
	char pad_221[0x3]; // 0x221(0x03)
	enum class EPlaneConstraintAxisSetting PlaneConstraintAxisSetting; // 0x224(0x01)
	char pad_225[0x3]; // 0x225(0x03)
	struct FVector PlaneConstraintNormal; // 0x228(0x0c)
	struct FVector PlaneConstraintOrigin; // 0x234(0x0c)
	char bUpdateOnlyIfRendered : 1; // 0x240(0x01)
	char bAutoUpdateTickRegistration : 1; // 0x240(0x01)
	char bTickBeforeOwner : 1; // 0x240(0x01)
	char bAutoRegisterUpdatedComponent : 1; // 0x240(0x01)
	char pad_240_4 : 4; // 0x240(0x01)
	char pad_241[0xf]; // 0x241(0x0f)

	void StopMovementImmediately(); // Function Engine.MovementComponent.StopMovementImmediately // Native|Public|BlueprintCallable // @ game+0x5b04f70
	void SnapUpdatedComponentToPlane(); // Function Engine.MovementComponent.SnapUpdatedComponentToPlane // Native|Public|BlueprintCallable // @ game+0x5b046b8
	void SetUpdatedComponent(struct USceneComponent* NewUpdatedComponent); // Function Engine.MovementComponent.SetUpdatedComponent // Native|Public|BlueprintCallable // @ game+0x5b037c0
	void SetPlaneConstraintOrigin(struct FVector PlaneOrigin); // Function Engine.MovementComponent.SetPlaneConstraintOrigin // Native|Public|HasDefaults|BlueprintCallable // @ game+0x5b02814
	void SetPlaneConstraintNormal(struct FVector PlaneNormal); // Function Engine.MovementComponent.SetPlaneConstraintNormal // Native|Public|HasDefaults|BlueprintCallable // @ game+0x5b02770
	void SetPlaneConstraintFromVectors(struct FVector Forward, struct FVector Up); // Function Engine.MovementComponent.SetPlaneConstraintFromVectors // Native|Public|HasDefaults|BlueprintCallable // @ game+0x5b02664
	void SetPlaneConstraintEnabled(bool bEnabled); // Function Engine.MovementComponent.SetPlaneConstraintEnabled // Native|Public|BlueprintCallable // @ game+0x5b025cc
	void SetPlaneConstraintAxisSetting(enum class EPlaneConstraintAxisSetting NewAxisSetting); // Function Engine.MovementComponent.SetPlaneConstraintAxisSetting // Native|Public|BlueprintCallable // @ game+0x5b02538
	void PhysicsVolumeChanged(struct APhysicsVolume* NewVolume); // Function Engine.MovementComponent.PhysicsVolumeChanged // Native|Public // @ game+0xbb3c10
	bool K2_MoveUpdatedComponent(struct FVector Delta, struct FRotator NewRotation, struct FHitResult OutHit, bool bSweep, bool bTeleport); // Function Engine.MovementComponent.K2_MoveUpdatedComponent // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5af6180
	float K2_GetModifiedMaxSpeed(); // Function Engine.MovementComponent.K2_GetModifiedMaxSpeed // Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5af5bf4
	float K2_GetMaxSpeedModifier(); // Function Engine.MovementComponent.K2_GetMaxSpeedModifier // Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5af5b9c
	bool IsExceedingMaxSpeed(float MaxSpeed); // Function Engine.MovementComponent.IsExceedingMaxSpeed // Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5af23a8
	struct FVector GetPlaneConstraintOrigin(); // Function Engine.MovementComponent.GetPlaneConstraintOrigin // Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5af0b7c
	struct FVector GetPlaneConstraintNormal(); // Function Engine.MovementComponent.GetPlaneConstraintNormal // Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5af0b54
	enum class EPlaneConstraintAxisSetting GetPlaneConstraintAxisSetting(); // Function Engine.MovementComponent.GetPlaneConstraintAxisSetting // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5af0b3c
	struct APhysicsVolume* GetPhysicsVolume(); // Function Engine.MovementComponent.GetPhysicsVolume // Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5af0af0
	float GetMaxSpeed(); // Function Engine.MovementComponent.GetMaxSpeed // Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5aefb84
	float GetGravityZ(); // Function Engine.MovementComponent.GetGravityZ // Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5aedc24
	struct FVector ConstrainNormalToPlane(struct FVector Normal); // Function Engine.MovementComponent.ConstrainNormalToPlane // Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5ae83c0
	struct FVector ConstrainLocationToPlane(struct FVector Location); // Function Engine.MovementComponent.ConstrainLocationToPlane // Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5ae82f8
	struct FVector ConstrainDirectionToPlane(struct FVector Direction); // Function Engine.MovementComponent.ConstrainDirectionToPlane // Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5ae8230
};

// Class Engine.NavMovementComponent
// Size: 0x280 (Inherited: 0x250)
struct UNavMovementComponent : UMovementComponent {
	struct FNavAgentProperties NavAgentProps; // 0x248(0x20)
	float FixedPathBrakingDistance; // 0x268(0x04)
	char bUpdateNavAgentWithOwnersCollision : 1; // 0x26c(0x01)
	char bUseAccelerationForPaths : 1; // 0x26c(0x01)
	char bUseFixedBrakingDistanceForPaths : 1; // 0x26c(0x01)
	struct FMovementProperties MovementState; // 0x270(0x04)
	char pad_278_3 : 5; // 0x278(0x01)
	char pad_279[0x7]; // 0x279(0x07)

	void StopMovementKeepPathing(); // Function Engine.NavMovementComponent.StopMovementKeepPathing // Final|Native|Public|BlueprintCallable // @ game+0x5b04f88
	void StopActiveMovement(); // Function Engine.NavMovementComponent.StopActiveMovement // Native|Public|BlueprintCallable // @ game+0x5b049d4
	bool IsSwimming(); // Function Engine.NavMovementComponent.IsSwimming // Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5af2c60
	bool IsMovingOnGround(); // Function Engine.NavMovementComponent.IsMovingOnGround // Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5af27e4
	bool IsFlying(); // Function Engine.NavMovementComponent.IsFlying // Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5af247c
	bool IsFalling(); // Function Engine.NavMovementComponent.IsFalling // Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5af2454
	bool IsCrouching(); // Function Engine.NavMovementComponent.IsCrouching // Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5af2350
};

// Class Engine.PawnMovementComponent
// Size: 0x290 (Inherited: 0x280)
struct UPawnMovementComponent : UNavMovementComponent {
	struct APawn* PawnOwner; // 0x280(0x08)
	char pad_288[0x8]; // 0x288(0x08)

	struct FVector K2_GetInputVector(); // Function Engine.PawnMovementComponent.K2_GetInputVector // Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5af5b68
	bool IsMoveInputIgnored(); // Function Engine.PawnMovementComponent.IsMoveInputIgnored // Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5af27bc
	struct FVector GetPendingInputVector(); // Function Engine.PawnMovementComponent.GetPendingInputVector // Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5af088c
	struct APawn* GetPawnOwner(); // Function Engine.PawnMovementComponent.GetPawnOwner // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5af0874
	struct FVector GetLastInputVector(); // Function Engine.PawnMovementComponent.GetLastInputVector // Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5aef4cc
	struct FVector ConsumeInputVector(); // Function Engine.PawnMovementComponent.ConsumeInputVector // Native|Public|HasDefaults|BlueprintCallable // @ game+0x5ae8488
	void AddInputVector(struct FVector WorldVector, bool bForce); // Function Engine.PawnMovementComponent.AddInputVector // Native|Public|HasDefaults|BlueprintCallable // @ game+0x5ae41b4
};

// Class Engine.CharacterMovementComponent
// Size: 0x930 (Inherited: 0x290)
struct UCharacterMovementComponent : UPawnMovementComponent {
	char pad_290[0x8]; // 0x290(0x08)
	struct ACharacter* CharacterOwner; // 0x298(0x08)
	char bApplyGravityWhileJumping : 1; // 0x2a0(0x01)
	char pad_2A0_1 : 7; // 0x2a0(0x01)
	char pad_2A1[0x3]; // 0x2a1(0x03)
	float GravityScale; // 0x2a4(0x04)
	float MaxStepHeight; // 0x2a8(0x04)
	float JumpZVelocity; // 0x2ac(0x04)
	float JumpOffJumpZFactor; // 0x2b0(0x04)
	float WalkableFloorAngle; // 0x2b4(0x04)
	float WalkableFloorZ; // 0x2b8(0x04)
	char pad_2BC[0x4]; // 0x2bc(0x04)
	float ProneWalkableFloorAngle; // 0x2c0(0x04)
	float ProneWalkableFloorZ; // 0x2c4(0x04)
	char pad_2C8[0x8]; // 0x2c8(0x08)
	enum class EMovementMode MovementMode; // 0x2d0(0x01)
	bool CustomMovementMode; // 0x2d1(0x01)
	char pad_2D2[0x1e]; // 0x2d2(0x1e)
	float GroundFriction; // 0x2f0(0x04)
	float MaxWalkSpeed; // 0x2f4(0x04)
	float MaxWalkSpeedCrouched; // 0x2f8(0x04)
	float MaxSwimSpeed; // 0x2fc(0x04)
	float MaxFlySpeed; // 0x300(0x04)
	float MaxCustomMovementSpeed; // 0x304(0x04)
	float MaxAcceleration; // 0x308(0x04)
	float BrakingFrictionFactor; // 0x30c(0x04)
	float BrakingFriction; // 0x310(0x04)
	char bUseSeparateBrakingFriction : 1; // 0x314(0x01)
	char pad_314_1 : 7; // 0x314(0x01)
	char pad_315[0x3]; // 0x315(0x03)
	float BrakingDecelerationWalking; // 0x318(0x04)
	float BrakingDecelerationFalling; // 0x31c(0x04)
	float BrakingDecelerationSwimming; // 0x320(0x04)
	float BrakingDecelerationFlying; // 0x324(0x04)
	float AirControl; // 0x328(0x04)
	float AirControlBoostMultiplier; // 0x32c(0x04)
	float AirControlBoostVelocityThreshold; // 0x330(0x04)
	float FallingLateralFriction; // 0x334(0x04)
	float CrouchedHalfHeight; // 0x338(0x04)
	float PronedHalfHeight; // 0x33c(0x04)
	float PronedRadius; // 0x340(0x04)
	float Buoyancy; // 0x344(0x04)
	float PerchRadiusThreshold; // 0x348(0x04)
	float PerchAdditionalHeight; // 0x34c(0x04)
	struct FRotator RotationRate; // 0x350(0x0c)
	char bUseControllerDesiredRotation : 1; // 0x35c(0x01)
	char bOrientRotationToMovement : 1; // 0x35c(0x01)
	char bSweepWhileNavWalking : 1; // 0x35c(0x01)
	char pad_35C_3 : 2; // 0x35c(0x01)
	char bMovementInProgress : 1; // 0x35c(0x01)
	char bEnableScopedMovementUpdates : 1; // 0x35c(0x01)
	char bForceMaxAccel : 1; // 0x35c(0x01)
	char bRunPhysicsWithNoController : 1; // 0x35d(0x01)
	char bForceNextFloorCheck : 1; // 0x35d(0x01)
	char bShrinkProxyCapsule : 1; // 0x35d(0x01)
	char bCanWalkOffLedges : 1; // 0x35d(0x01)
	char bCanWalkOffLedgesWhenCrouching : 1; // 0x35d(0x01)
	char pad_35D_5 : 2; // 0x35d(0x01)
	char bNetworkSkipProxyPredictionOnNetUpdate : 1; // 0x35d(0x01)
	char bDeferUpdateMoveComponent : 1; // 0x35e(0x01)
	char pad_35E_1 : 7; // 0x35e(0x01)
	char pad_35F[0x1]; // 0x35f(0x01)
	struct USceneComponent* DeferredUpdatedMoveComponent; // 0x360(0x08)
	float MaxOutOfWaterStepHeight; // 0x368(0x04)
	float OutofWaterZ; // 0x36c(0x04)
	float Mass; // 0x370(0x04)
	bool bEnablePhysicsInteraction; // 0x374(0x01)
	bool bTouchForceScaledToMass; // 0x375(0x01)
	bool bPushForceScaledToMass; // 0x376(0x01)
	bool bPushForceUsingZOffset; // 0x377(0x01)
	bool bScalePushForceToVelocity; // 0x378(0x01)
	char pad_379[0x3]; // 0x379(0x03)
	float StandingDownwardForceScale; // 0x37c(0x04)
	float InitialPushForceFactor; // 0x380(0x04)
	float PushForceFactor; // 0x384(0x04)
	float PushForcePointZOffsetFactor; // 0x388(0x04)
	float TouchForceFactor; // 0x38c(0x04)
	float MinTouchForce; // 0x390(0x04)
	float MaxTouchForce; // 0x394(0x04)
	float RepulsionForce; // 0x398(0x04)
	char bForceBraking : 1; // 0x39c(0x01)
	char pad_39C_1 : 7; // 0x39c(0x01)
	char pad_39D[0x3]; // 0x39d(0x03)
	float CrouchedSpeedMultiplier; // 0x3a0(0x04)
	float UpperImpactNormalScale; // 0x3a4(0x04)
	struct FVector Acceleration; // 0x3a8(0x0c)
	struct FVector LastUpdateLocation; // 0x3b4(0x0c)
	struct FQuat LastUpdateRotation; // 0x3c0(0x10)
	struct FVector LastUpdateVelocity; // 0x3d0(0x0c)
	float ServerLastTransformUpdateTimeStamp; // 0x3dc(0x04)
	float ServerLastClientGoodMoveAckTime; // 0x3e0(0x04)
	float ServerLastClientAdjustmentTime; // 0x3e4(0x04)
	struct FVector PendingImpulseToApply; // 0x3e8(0x0c)
	struct FVector PendingForceToApply; // 0x3f4(0x0c)
	float AnalogInputModifier; // 0x400(0x04)
	char pad_404[0x8]; // 0x404(0x08)
	float MaxSimulationTimeStep; // 0x40c(0x04)
	int32 MaxSimulationIterations; // 0x410(0x04)
	float MaxDepenetrationWithGeometry; // 0x414(0x04)
	float MaxDepenetrationWithGeometryAsProxy; // 0x418(0x04)
	float MaxDepenetrationWithPawn; // 0x41c(0x04)
	float MaxDepenetrationWithPawnAsProxy; // 0x420(0x04)
	float NetworkSimulatedSmoothLocationTime; // 0x424(0x04)
	float NetworkSimulatedSmoothRotationTime; // 0x428(0x04)
	float ListenServerNetworkSimulatedSmoothLocationTime; // 0x42c(0x04)
	float ListenServerNetworkSimulatedSmoothRotationTime; // 0x430(0x04)
	float NetProxyShrinkRadius; // 0x434(0x04)
	float NetProxyShrinkHalfHeight; // 0x438(0x04)
	float NetworkMaxSmoothUpdateDistance; // 0x43c(0x04)
	float NetworkNoSmoothUpdateDistance; // 0x440(0x04)
	enum class ENetworkSmoothingMode NetworkSmoothingMode; // 0x444(0x01)
	char pad_445[0x3]; // 0x445(0x03)
	float NetworkMinTimeBetweenClientAckGoodMoves; // 0x448(0x04)
	float NetworkMinTimeBetweenClientAdjustments; // 0x44c(0x04)
	float NetworkMinTimeBetweenClientAdjustmentsLargeCorrection; // 0x450(0x04)
	float NetworkLargeClientCorrectionDistance; // 0x454(0x04)
	float LedgeCheckThreshold; // 0x458(0x04)
	float JumpOutOfWaterPitch; // 0x45c(0x04)
	struct FFindFloorResult CurrentFloor; // 0x460(0x98)
	enum class EMovementMode DefaultLandMovementMode; // 0x4f8(0x01)
	enum class EMovementMode DefaultWaterMovementMode; // 0x4f9(0x01)
	enum class EMovementMode GroundMovementMode; // 0x4fa(0x01)
	char pad_4FB[0x1]; // 0x4fb(0x01)
	char bMaintainHorizontalGroundVelocity : 1; // 0x4fc(0x01)
	char bImpartBaseVelocityX : 1; // 0x4fc(0x01)
	char bImpartBaseVelocityY : 1; // 0x4fc(0x01)
	char bImpartBaseVelocityZ : 1; // 0x4fc(0x01)
	char bImpartBaseAngularVelocity : 1; // 0x4fc(0x01)
	char bJustTeleported : 1; // 0x4fc(0x01)
	char bNetworkUpdateReceived : 1; // 0x4fc(0x01)
	char bNetworkMovementModeChanged : 1; // 0x4fc(0x01)
	char bIgnoreClientMovementErrorChecksAndCorrection : 1; // 0x4fd(0x01)
	char bNotifyApex : 1; // 0x4fd(0x01)
	char bCheatFlying : 1; // 0x4fd(0x01)
	char bWantsToCrouch : 1; // 0x4fd(0x01)
	char bCrouchMaintainsBaseLocation : 1; // 0x4fd(0x01)
	char pad_4FD_5 : 3; // 0x4fd(0x01)
	char pad_4FE[0x2]; // 0x4fe(0x02)
	enum class EStanceMode StanceMode; // 0x500(0x01)
	enum class EStanceMode WantsToStanceMode; // 0x501(0x01)
	char pad_502[0x2]; // 0x502(0x02)
	char bIgnoreBaseRotation : 1; // 0x504(0x01)
	char bFastAttachedMove : 1; // 0x504(0x01)
	char bAlwaysCheckFloor : 1; // 0x504(0x01)
	char bUseFlatBaseForFloorChecks : 1; // 0x504(0x01)
	char bPerformingJumpOff : 1; // 0x504(0x01)
	char bWantsToLeaveNavWalking : 1; // 0x504(0x01)
	char bUseRVOAvoidance : 1; // 0x504(0x01)
	char bRequestedMoveUseAcceleration : 1; // 0x504(0x01)
	char pad_505[0xf]; // 0x505(0x0f)
	char bHasRequestedVelocity : 1; // 0x514(0x01)
	char bRequestedMoveWithMaxSpeed : 1; // 0x514(0x01)
	char bWasAvoidanceUpdated : 1; // 0x514(0x01)
	char pad_514_3 : 2; // 0x514(0x01)
	char bProjectNavMeshWalking : 1; // 0x514(0x01)
	char bProjectNavMeshOnBothWorldChannels : 1; // 0x514(0x01)
	char pad_514_7 : 1; // 0x514(0x01)
	char pad_515[0x13]; // 0x515(0x13)
	float AvoidanceConsiderationRadius; // 0x528(0x04)
	struct FVector RequestedVelocity; // 0x52c(0x0c)
	int32 AvoidanceUID; // 0x538(0x04)
	struct FNavAvoidanceMask AvoidanceGroup; // 0x53c(0x04)
	struct FNavAvoidanceMask GroupsToAvoid; // 0x540(0x04)
	struct FNavAvoidanceMask GroupsToIgnore; // 0x544(0x04)
	float AvoidanceWeight; // 0x548(0x04)
	struct FVector PendingLaunchVelocity; // 0x54c(0x0c)
	char pad_558[0xa8]; // 0x558(0xa8)
	float NavMeshProjectionInterval; // 0x600(0x04)
	float NavMeshProjectionTimer; // 0x604(0x04)
	float NavMeshProjectionInterpSpeed; // 0x608(0x04)
	float NavMeshProjectionHeightScaleUp; // 0x60c(0x04)
	float NavMeshProjectionHeightScaleDown; // 0x610(0x04)
	float NavWalkingFloorDistTolerance; // 0x614(0x04)
	char pad_618[0xb0]; // 0x618(0xb0)
	struct FCharacterMovementComponentPostPhysicsTickFunction PostPhysicsTickFunction; // 0x6c8(0x58)
	char pad_720[0x10]; // 0x720(0x10)
	float MinTimeBetweenTimeStampResets; // 0x730(0x04)
	char pad_734[0x4]; // 0x734(0x04)
	struct FRootMotionSourceGroup CurrentRootMotion; // 0x738(0x100)
	char pad_838[0x98]; // 0x838(0x98)
	struct FRootMotionMovementParams RootMotionParams; // 0x8d0(0x40)
	struct FVector AnimRootMotionVelocity; // 0x910(0x0c)
	bool bWasSimulatingRootMotion; // 0x91c(0x01)
	char pad_91D[0x3]; // 0x91d(0x03)
	char bAllowPhysicsRotationDuringAnimRootMotion : 1; // 0x920(0x01)
	char pad_920_1 : 7; // 0x920(0x01)
	char pad_921[0xf]; // 0x921(0x0f)

	void SeverAddRotationVelocity(struct FVector RotationVelocity); // Function Engine.CharacterMovementComponent.SeverAddRotationVelocity // Net|Native|Event|Protected|NetServer|HasDefaults|NetValidate // @ game+0x5b0425c
	void SetWalkableFloorZ(float InWalkableFloorZ); // Function Engine.CharacterMovementComponent.SetWalkableFloorZ // Final|Native|Public|BlueprintCallable // @ game+0x5b04050
	void SetWalkableFloorAngle(float InWalkableFloorAngle); // Function Engine.CharacterMovementComponent.SetWalkableFloorAngle // Final|Native|Public|BlueprintCallable // @ game+0x5b03fb8
	void SetProneWalkableFloorAngle(float InWalkableFloorAngle); // Function Engine.CharacterMovementComponent.SetProneWalkableFloorAngle // Final|Native|Public|BlueprintCallable // @ game+0x5b02950
	void SetMovementMode(enum class EMovementMode NewMovementMode, bool NewCustomMode); // Function Engine.CharacterMovementComponent.SetMovementMode // Native|Public|BlueprintCallable // @ game+0x5b01df8
	void SetGroupsToIgnoreMask(struct FNavAvoidanceMask GroupMask); // Function Engine.CharacterMovementComponent.SetGroupsToIgnoreMask // Final|Native|Public|HasOutParms|BlueprintCallable // @ game+0x5b00cd8
	void SetGroupsToIgnore(int32 GroupFlags); // Function Engine.CharacterMovementComponent.SetGroupsToIgnore // Final|Native|Public|BlueprintCallable // @ game+0x5b00c4c
	void SetGroupsToAvoidMask(struct FNavAvoidanceMask GroupMask); // Function Engine.CharacterMovementComponent.SetGroupsToAvoidMask // Final|Native|Public|HasOutParms|BlueprintCallable // @ game+0x5b00bb0
	void SetGroupsToAvoid(int32 GroupFlags); // Function Engine.CharacterMovementComponent.SetGroupsToAvoid // Final|Native|Public|BlueprintCallable // @ game+0x5b00b24
	void SetAvoidanceGroupMask(struct FNavAvoidanceMask GroupMask); // Function Engine.CharacterMovementComponent.SetAvoidanceGroupMask // Final|Native|Public|HasOutParms|BlueprintCallable // @ game+0x5afe724
	void SetAvoidanceGroup(int32 GroupFlags); // Function Engine.CharacterMovementComponent.SetAvoidanceGroup // Final|Native|Public|BlueprintCallable // @ game+0x5afe698
	void SetAvoidanceEnabled(bool bEnable); // Function Engine.CharacterMovementComponent.SetAvoidanceEnabled // Final|Native|Public|BlueprintCallable // @ game+0x5afe604
	float K2_GetWalkableFloorZ(); // Function Engine.CharacterMovementComponent.K2_GetWalkableFloorZ // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5af5d6c
	float K2_GetWalkableFloorAngle(); // Function Engine.CharacterMovementComponent.K2_GetWalkableFloorAngle // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5af5d54
	float K2_GetModifiedMaxAcceleration(); // Function Engine.CharacterMovementComponent.K2_GetModifiedMaxAcceleration // Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5af5bc8
	void K2_FindFloor(struct FVector CapsuleLocation, struct FFindFloorResult FloorResult); // Function Engine.CharacterMovementComponent.K2_FindFloor // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5af5644
	void K2_ComputeFloorDist(struct FVector CapsuleLocation, float LineDistance, float SweepDistance, float SweepRadius, struct FFindFloorResult FloorResult); // Function Engine.CharacterMovementComponent.K2_ComputeFloorDist // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5af51b8
	bool IsWalking(); // Function Engine.CharacterMovementComponent.IsWalking // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5af27e4
	bool IsWalkable(struct FHitResult Hit); // Function Engine.CharacterMovementComponent.IsWalkable // Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const // @ game+0x5af2d00
	float GetValidPerchRadius(); // Function Engine.CharacterMovementComponent.GetValidPerchRadius // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5af184c
	float GetPerchRadiusThreshold(); // Function Engine.CharacterMovementComponent.GetPerchRadiusThreshold // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5af08e4
	struct UPrimitiveComponent* GetMovementBase(); // Function Engine.CharacterMovementComponent.GetMovementBase // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5aefcb8
	float GetMaxJumpHeightWithJumpTime(); // Function Engine.CharacterMovementComponent.GetMaxJumpHeightWithJumpTime // Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5aefb58
	float GetMaxJumpHeight(); // Function Engine.CharacterMovementComponent.GetMaxJumpHeight // Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5aefb2c
	float GetMaxBrakingDeceleration(); // Function Engine.CharacterMovementComponent.GetMaxBrakingDeceleration // Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5aefb00
	float GetMaxAcceleration(); // Function Engine.CharacterMovementComponent.GetMaxAcceleration // Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5aefad4
	struct FVector GetImpartedMovementBaseVelocity(); // Function Engine.CharacterMovementComponent.GetImpartedMovementBaseVelocity // Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5aee790
	struct FVector GetCurrentAcceleration(); // Function Engine.CharacterMovementComponent.GetCurrentAcceleration // Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5aed860
	struct ACharacter* GetCharacterOwner(); // Function Engine.CharacterMovementComponent.GetCharacterOwner // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5aecbdc
	float GetAnalogInputModifier(); // Function Engine.CharacterMovementComponent.GetAnalogInputModifier // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5aebe94
	void DisableMovement(); // Function Engine.CharacterMovementComponent.DisableMovement // Native|Public|BlueprintCallable // @ game+0x5ae916c
	void ClearAccumulatedForces(); // Function Engine.CharacterMovementComponent.ClearAccumulatedForces // Native|Public|BlueprintCallable // @ game+0x5ae5924
	void CapsuleTouched(struct UPrimitiveComponent* OverlappedComp, struct AActor* Other, struct UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, struct FHitResult SweepResult); // Function Engine.CharacterMovementComponent.CapsuleTouched // Native|Protected|HasOutParms // @ game+0xaa909c
	void CalcVelocity(float DeltaTime, float Friction, bool bFluid, float BrakingDeceleration); // Function Engine.CharacterMovementComponent.CalcVelocity // Native|Public|BlueprintCallable // @ game+0x5ae5354
	void AddImpulse(struct FVector Impulse, bool bVelocityChange); // Function Engine.CharacterMovementComponent.AddImpulse // Native|Public|HasDefaults|BlueprintCallable // @ game+0x5ae3e28
	void AddForce(struct FVector force); // Function Engine.CharacterMovementComponent.AddForce // Native|Public|HasDefaults|BlueprintCallable // @ game+0x5ae37e4
};

// Class Engine.BlueprintFunctionLibrary
// Size: 0x38 (Inherited: 0x38)
struct UBlueprintFunctionLibrary : UObject {

	struct FStringAssetReference MakeStringAssetReference(struct FString AssetLongPathname); // Function Engine.BlueprintFunctionLibrary.MakeStringAssetReference // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b37988
};

// Class Engine.StaticMeshActor
// Size: 0x400 (Inherited: 0x3f0)
struct AStaticMeshActor : AActor {
	struct UStaticMeshComponent* StaticMeshComponent; // 0x3f0(0x08)
	bool bStaticMeshReplicateMovement; // 0x3f8(0x01)
	enum class ENavDataGatheringMode NavigationGeometryGatheringMode; // 0x3f9(0x01)
	char pad_3FA[0x6]; // 0x3fa(0x06)
};

// Class Engine.HUD
// Size: 0x4d8 (Inherited: 0x3f0)
struct AHUD : AActor {
	struct APlayerController* PlayerOwner; // 0x3f0(0x08)
	char bLostFocusPaused : 1; // 0x3f8(0x01)
	char bShowHUD : 1; // 0x3f8(0x01)
	char bShowDebugInfo : 1; // 0x3f8(0x01)
	char bShowHitBoxDebugInfo : 1; // 0x3f8(0x01)
	char bShowOverlays : 1; // 0x3f8(0x01)
	char bEnableDebugTextShadow : 1; // 0x3f8(0x01)
	char pad_3F8_6 : 2; // 0x3f8(0x01)
	char pad_3F9[0x7]; // 0x3f9(0x07)
	struct TArray<struct AActor*> PostRenderedActors; // 0x400(0x10)
	char pad_410[0x8]; // 0x410(0x08)
	struct TArray<struct FName> DebugDisplay; // 0x418(0x10)
	struct TArray<struct FName> ToggledDebugCategories; // 0x428(0x10)
	struct UCanvas* Canvas; // 0x438(0x08)
	struct UCanvas* DebugCanvas; // 0x440(0x08)
	struct TArray<struct FDebugTextInfo> DebugTextList; // 0x448(0x10)
	struct UClass* ShowDebugTargetDesiredClass; // 0x458(0x08)
	struct AActor* ShowDebugTargetActor; // 0x460(0x08)
	char pad_468[0x70]; // 0x468(0x70)

	void ShowHUD(); // Function Engine.HUD.ShowHUD // Exec|Native|Public // @ game+0xe3d10c
	void ShowDebugToggleSubCategory(struct FName Category); // Function Engine.HUD.ShowDebugToggleSubCategory // Final|Exec|Native|Public // @ game+0x5b0445c
	void ShowDebugForReticleTargetToggle(struct UClass* DesiredClass); // Function Engine.HUD.ShowDebugForReticleTargetToggle // Final|Exec|Native|Public // @ game+0x5b0439c
	void ShowDebug(struct FName DebugType); // Function Engine.HUD.ShowDebug // Exec|Native|Public // @ game+0x5b04308
	void RemoveDebugText(struct AActor* SrcActor, bool bLeaveDurationText); // Function Engine.HUD.RemoveDebugText // Final|Net|NetReliableNative|Event|Public|NetClient // @ game+0x5afa2ec
	void RemoveAllDebugStrings(); // Function Engine.HUD.RemoveAllDebugStrings // Final|Net|NetReliableNative|Event|Public|NetClient // @ game+0x5afa12c
	void ReceiveHitBoxRelease(struct FName BoxName); // Function Engine.HUD.ReceiveHitBoxRelease // BlueprintCosmetic|Event|Public|BlueprintEvent // @ game+0x33e45c
	void ReceiveHitBoxEndCursorOver(struct FName BoxName); // Function Engine.HUD.ReceiveHitBoxEndCursorOver // BlueprintCosmetic|Event|Public|BlueprintEvent // @ game+0x33e45c
	void ReceiveHitBoxClick(struct FName BoxName); // Function Engine.HUD.ReceiveHitBoxClick // BlueprintCosmetic|Event|Public|BlueprintEvent // @ game+0x33e45c
	void ReceiveHitBoxBeginCursorOver(struct FName BoxName); // Function Engine.HUD.ReceiveHitBoxBeginCursorOver // BlueprintCosmetic|Event|Public|BlueprintEvent // @ game+0x33e45c
	void ReceiveDrawHUD(int32 SizeX, int32 SizeY); // Function Engine.HUD.ReceiveDrawHUD // BlueprintCosmetic|Event|Public|BlueprintEvent // @ game+0x33e45c
	struct FVector Project(struct FVector Location); // Function Engine.HUD.Project // Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5af9ddc
	void GetTextSize(struct FString Text, float OutWidth, float OutHeight, struct UFont* Font, float Scale); // Function Engine.HUD.GetTextSize // Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const // @ game+0x5af1304
	struct APlayerController* GetOwningPlayerController(); // Function Engine.HUD.GetOwningPlayerController // Final|Native|Protected|BlueprintCallable|BlueprintPure|Const // @ game+0x4d8dc30
	struct APawn* GetOwningPawn(); // Function Engine.HUD.GetOwningPawn // Final|Native|Protected|BlueprintCallable|BlueprintPure|Const // @ game+0x5af05f4
	void GetActorsInSelectionRectangle(struct UClass* ClassFilter, struct FVector2D FirstPoint, struct FVector2D SecondPoint, struct TArray<struct AActor*> OutActors, bool bIncludeNonCollidingComponents, bool bActorMustBeFullyEnclosed); // Function Engine.HUD.GetActorsInSelectionRectangle // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5aeba54
	void DrawTextureSimple(struct UTexture* Texture, float ScreenX, float ScreenY, float Scale, bool bScalePosition); // Function Engine.HUD.DrawTextureSimple // Final|Native|Public|BlueprintCallable // @ game+0x5aea84c
	void DrawTexture(struct UTexture* Texture, float ScreenX, float ScreenY, float ScreenW, float ScreenH, float TextureU, float TextureV, float TextureUWidth, float TextureVHeight, struct FLinearColor TintColor, enum class EBlendMode BlendMode, float Scale, bool bScalePosition, float Rotation, struct FVector2D RotPivot); // Function Engine.HUD.DrawTexture // Final|Native|Public|HasDefaults|BlueprintCallable // @ game+0x5aea33c
	void DrawText(struct FString Text, struct FLinearColor TextColor, float ScreenX, float ScreenY, struct UFont* Font, float Scale, bool bScalePosition); // Function Engine.HUD.DrawText // Final|Native|Public|HasDefaults|BlueprintCallable // @ game+0x5aea084
	void DrawRect(struct FLinearColor RectColor, float ScreenX, float ScreenY, float ScreenW, float ScreenH); // Function Engine.HUD.DrawRect // Final|Native|Public|HasDefaults|BlueprintCallable // @ game+0x5ae9ea8
	void DrawMaterialTriangle(struct UMaterialInterface* Material, struct FVector2D V0_Pos, struct FVector2D V1_Pos, struct FVector2D V2_Pos, struct FVector2D V0_UV, struct FVector2D V1_UV, struct FVector2D V2_UV, struct FLinearColor V0_Color, struct FLinearColor V1_Color, struct FLinearColor V2_Color); // Function Engine.HUD.DrawMaterialTriangle // Final|Native|Public|HasDefaults|BlueprintCallable // @ game+0x5ae9b38
	void DrawMaterialSimple(struct UMaterialInterface* Material, float ScreenX, float ScreenY, float ScreenW, float ScreenH, float Scale, bool bScalePosition); // Function Engine.HUD.DrawMaterialSimple // Final|Native|Public|BlueprintCallable // @ game+0x5ae98c0
	void DrawMaterial(struct UMaterialInterface* Material, float ScreenX, float ScreenY, float ScreenW, float ScreenH, float MaterialU, float MaterialV, float MaterialUWidth, float MaterialVHeight, float Scale, bool bScalePosition, float Rotation, struct FVector2D RotPivot); // Function Engine.HUD.DrawMaterial // Final|Native|Public|HasDefaults|BlueprintCallable // @ game+0x5ae9458
	void DrawLine(float StartScreenX, float StartScreenY, float EndScreenX, float EndScreenY, struct FLinearColor LineColor, float LineThickness); // Function Engine.HUD.DrawLine // Final|Native|Public|HasDefaults|BlueprintCallable // @ game+0x5ae922c
	void Deproject(float ScreenX, float ScreenY, struct FVector WorldPosition, struct FVector WorldDirection); // Function Engine.HUD.Deproject // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5ae8b00
	void AddHitBox(struct FVector2D Position, struct FVector2D Size, struct FName InName, bool bConsumesInput, int32 Priority); // Function Engine.HUD.AddHitBox // Final|Native|Public|HasDefaults|BlueprintCallable // @ game+0x5ae3c60
	void AddDebugText(struct FString DebugText, struct AActor* SrcActor, float Duration, struct FVector Offset, struct FVector DesiredOffset, struct FColor TextColor, bool bSkipOverwriteCheck, bool bAbsoluteLocation, bool bKeepAttachedToActor, struct UFont* InFont, float FontScale, bool bDrawShadow); // Function Engine.HUD.AddDebugText // Final|Net|NetReliableNative|Event|Public|HasDefaults|NetClient // @ game+0x5ae3370
};

// Class Engine.Brush
// Size: 0x428 (Inherited: 0x3f0)
struct ABrush : AActor {
	enum class EBrushType BrushType; // 0x3f0(0x01)
	char pad_3F1[0x3]; // 0x3f1(0x03)
	struct FColor BrushColor; // 0x3f4(0x04)
	int32 PolyFlags; // 0x3f8(0x04)
	char bColored : 1; // 0x3fc(0x01)
	char bSolidWhenSelected : 1; // 0x3fc(0x01)
	char bPlaceableFromClassBrowser : 1; // 0x3fc(0x01)
	char bNotForClientOrServer : 1; // 0x3fc(0x01)
	char pad_3FC_4 : 4; // 0x3fc(0x01)
	char pad_3FD[0x3]; // 0x3fd(0x03)
	struct UModel* Brush; // 0x400(0x08)
	struct UBrushComponent* BrushComponent; // 0x408(0x08)
	char bInManipulation : 1; // 0x410(0x01)
	char pad_410_1 : 7; // 0x410(0x01)
	char pad_411[0x7]; // 0x411(0x07)
	struct TArray<struct FGeomSelection> SavedSelections; // 0x418(0x10)
};

// Class Engine.Volume
// Size: 0x428 (Inherited: 0x428)
struct AVolume : ABrush {
};

// Class Engine.Pawn
// Size: 0x450 (Inherited: 0x3f0)
struct APawn : AActor {
	char pad_3F0[0x8]; // 0x3f0(0x08)
	char bUseControllerRotationPitch : 1; // 0x3f8(0x01)
	char bUseControllerRotationYaw : 1; // 0x3f8(0x01)
	char bUseControllerRotationRoll : 1; // 0x3f8(0x01)
	char bCanAffectNavigationGeneration : 1; // 0x3f8(0x01)
	char pad_3F8_4 : 4; // 0x3f8(0x01)
	char pad_3F9[0x3]; // 0x3f9(0x03)
	float BaseEyeHeight; // 0x3fc(0x04)
	enum class EAutoReceiveInput AutoPossessPlayer; // 0x400(0x01)
	enum class EAutoPossessAI AutoPossessAI; // 0x401(0x01)
	char pad_402[0x6]; // 0x402(0x06)
	struct UClass* AIControllerClass; // 0x408(0x08)
	struct AController* LastHitBy; // 0x410(0x08)
	char pad_418[0x4]; // 0x418(0x04)
	uint16 RemoteViewPitch; // 0x41c(0x02)
	char pad_41E[0x2]; // 0x41e(0x02)
	struct APlayerState* PlayerState; // 0x420(0x08)
	struct AController* Controller; // 0x428(0x08)
	char pad_430[0x4]; // 0x430(0x04)
	struct FVector ControlInputVector; // 0x434(0x0c)
	struct FVector LastControlInputVector; // 0x440(0x0c)
	char pad_44C[0x4]; // 0x44c(0x04)

	void SpawnDefaultController(); // Function Engine.Pawn.SpawnDefaultController // Native|Public|BlueprintCallable // @ game+0x5b046d0
	void SetCanAffectNavigationGeneration(bool bNewValue, bool bForceUpdate); // Function Engine.Pawn.SetCanAffectNavigationGeneration // Final|Native|Public|BlueprintCallable // @ game+0x5aff2d4
	void ReceiveUnpossessed(struct AController* OldController); // Function Engine.Pawn.ReceiveUnpossessed // Event|Public|BlueprintEvent // @ game+0x33e45c
	void ReceivePossessed(struct AController* NewController); // Function Engine.Pawn.ReceivePossessed // Event|Public|BlueprintEvent // @ game+0x33e45c
	void PawnMakeNoise(float Loudness, struct FVector NoiseLocation, bool bUseNoiseMakerLocation, struct AActor* NoiseMaker); // Function Engine.Pawn.PawnMakeNoise // Final|BlueprintAuthorityOnly|Native|Public|HasDefaults|BlueprintCallable // @ game+0x5af9000
	void OnRep_PlayerState(); // Function Engine.Pawn.OnRep_PlayerState // Native|Public // @ game+0x9848f0
	void OnRep_Controller(); // Function Engine.Pawn.OnRep_Controller // Native|Public // @ game+0x9cf98c
	void LaunchPawn(struct FVector LaunchVelocity, bool bXYOverride, bool bZOverride); // Function Engine.Pawn.LaunchPawn // Final|Native|Public|HasDefaults|BlueprintCallable // @ game+0x5af8128
	struct FVector K2_GetMovementInputVector(); // Function Engine.Pawn.K2_GetMovementInputVector // Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5af08bc
	bool IsPlayerControlled(); // Function Engine.Pawn.IsPlayerControlled // Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x4d26b6c
	bool IsMoveInputIgnored(); // Function Engine.Pawn.IsMoveInputIgnored // Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5af2794
	bool IsLocallyControlled(); // Function Engine.Pawn.IsLocallyControlled // Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0xc588b4
	bool IsControlled(); // Function Engine.Pawn.IsControlled // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5af21ac
	struct FVector GetPendingMovementInputVector(); // Function Engine.Pawn.GetPendingMovementInputVector // Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5af08bc
	struct FVector GetNavAgentLocation(); // Function Engine.Pawn.GetNavAgentLocation // Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5aefe14
	struct UPawnMovementComponent* GetMovementComponent(); // Function Engine.Pawn.GetMovementComponent // Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x4d25038
	struct AActor* GetMovementBaseActor(struct APawn* Pawn); // Function Engine.Pawn.GetMovementBaseActor // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5aefcdc
	struct FVector GetLastMovementInputVector(); // Function Engine.Pawn.GetLastMovementInputVector // Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5aef52c
	struct FRotator GetControlRotation(); // Function Engine.Pawn.GetControlRotation // Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5aed40c
	struct AController* GetController(); // Function Engine.Pawn.GetController // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5aed440
	struct FRotator GetBaseAimRotation(); // Function Engine.Pawn.GetBaseAimRotation // Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5aec040
	void DetachFromControllerPendingDestroy(); // Function Engine.Pawn.DetachFromControllerPendingDestroy // Native|Public|BlueprintCallable // @ game+0x5ae8f38
	struct FVector ConsumeMovementInputVector(); // Function Engine.Pawn.ConsumeMovementInputVector // Native|Public|HasDefaults|BlueprintCallable // @ game+0x5ae84c0
	void AddMovementInput(struct FVector WorldDirection, float ScaleValue, bool bForce); // Function Engine.Pawn.AddMovementInput // Native|Public|HasDefaults|BlueprintCallable // @ game+0x5ae43c8
	void AddControllerYawInput(float Val); // Function Engine.Pawn.AddControllerYawInput // Native|Public|BlueprintCallable // @ game+0x5ae32d4
	void AddControllerRollInput(float Val); // Function Engine.Pawn.AddControllerRollInput // Native|Public|BlueprintCallable // @ game+0x5ae3238
	void AddControllerPitchInput(float Val); // Function Engine.Pawn.AddControllerPitchInput // Native|Public|BlueprintCallable // @ game+0x5ae319c
};

// Class Engine.Character
// Size: 0x850 (Inherited: 0x450)
struct ACharacter : APawn {
	int32 JumpCurrentCount; // 0x450(0x04)
	float AnimRootMotionTranslationScale; // 0x454(0x04)
	struct UCapsuleComponent* ProneCapsuleComponent; // 0x458(0x08)
	struct FVector BaseTranslationOffset; // 0x460(0x0c)
	char pad_46C[0x4]; // 0x46c(0x04)
	struct FBasedMovementInfo ReplicatedBasedMovement; // 0x470(0x48)
	float JumpKeyHoldTime; // 0x4b8(0x04)
	char pad_4BC[0x4]; // 0x4bc(0x04)
	struct FQuat BaseRotationOffset; // 0x4c0(0x10)
	struct UCapsuleComponent* CapsuleComponent; // 0x4d0(0x08)
	struct UCharacterMovementComponent* CharacterMovement; // 0x4d8(0x08)
	int32 JumpMaxCount; // 0x4e0(0x04)
	float ReplicatedServerLastTransformUpdateTimeStamp; // 0x4e4(0x04)
	float JumpMaxHoldTime; // 0x4e8(0x04)
	float CrouchedEyeHeight; // 0x4ec(0x04)
	char bIsCrouched : 1; // 0x4f0(0x01)
	char pad_4F0_1 : 7; // 0x4f0(0x01)
	char pad_4F1[0x7]; // 0x4f1(0x07)
	struct FBasedMovementInfo BasedMovement; // 0x4f8(0x48)
	char bPressedJump : 1; // 0x540(0x01)
	char bClientUpdating : 1; // 0x540(0x01)
	char bClientWasFalling : 1; // 0x540(0x01)
	char bClientResimulateRootMotion : 1; // 0x540(0x01)
	char bClientResimulateRootMotionSources : 1; // 0x540(0x01)
	char bSimGravityDisabled : 1; // 0x540(0x01)
	char bClientCheckEncroachmentOnNetUpdate : 1; // 0x540(0x01)
	char bServerMoveIgnoreRootMotion : 1; // 0x540(0x01)
	char bWasJumping : 1; // 0x541(0x01)
	char pad_541_1 : 7; // 0x541(0x01)
	char pad_542[0x2]; // 0x542(0x02)
	bool bInBaseReplication; // 0x544(0x01)
	bool ReplicatedMovementMode; // 0x545(0x01)
	char pad_546[0x2]; // 0x546(0x02)
	struct USkeletalMeshComponent* Mesh; // 0x548(0x08)
	struct FMulticastDelegate OnReachedJumpApex; // 0x550(0x10)
	char pad_560[0x10]; // 0x560(0x10)
	struct FMulticastDelegate MovementModeChangedDelegate; // 0x570(0x10)
	struct FMulticastDelegate OnCharacterMovementUpdated; // 0x580(0x10)
	struct FRootMotionSourceGroup SavedRootMotion; // 0x590(0x100)
	struct FRootMotionMovementParams ClientRootMotionParams; // 0x690(0x40)
	struct TArray<struct FSimulatedRootMotionReplicatedMove> RootMotionRepMoves; // 0x6d0(0x10)
	struct FRepRootMotionMontage RepRootMotion; // 0x6e0(0x160)
	char pad_840[0x10]; // 0x840(0x10)

	void UnCrouch(bool bClientSimulation); // Function Engine.Character.UnCrouch // Native|Public|BlueprintCallable // @ game+0x5b054ac
	void StopJumping(); // Function Engine.Character.StopJumping // Native|Public|BlueprintCallable // @ game+0x5b04f40
	void StopAnimMontage(struct UAnimMontage* AnimMontage); // Function Engine.Character.StopAnimMontage // Native|Public|BlueprintCallable // @ game+0x5b04c4c
	void SetReplicateMovement(bool bInReplicateMovement); // Function Engine.Character.SetReplicateMovement // Native|Public|BlueprintCallable // @ game+0x5b02d08
	void ServerMoveOld(float OldTimeStamp, struct FVector_NetQuantize10 OldAccel, bool OldMoveFlags); // Function Engine.Character.ServerMoveOld // Net|Native|Event|Public|NetServer|NetValidate // @ game+0x5afc69c
	void ServerMoveNoBase(float Timestamp, struct FVector_NetQuantize10 InAccel, struct FVector_NetQuantize100 ClientLoc, bool CompressedMoveFlags, bool ClientRoll, uint32 View, bool ClientMovementMode, bool ClientStanceMode); // Function Engine.Character.ServerMoveNoBase // Net|Native|Event|Public|NetServer|NetValidate // @ game+0x5afc358
	void ServerMoveDualNoBase(float TimeStamp0, struct FVector_NetQuantize10 InAccel0, bool PendingFlags, uint32 View0, float Timestamp, struct FVector_NetQuantize10 InAccel, struct FVector_NetQuantize100 ClientLoc, bool NewFlags, bool ClientRoll, uint32 View, bool ClientMovementMode, bool ClientStanceMode); // Function Engine.Character.ServerMoveDualNoBase // Net|Native|Event|Public|NetServer|NetValidate // @ game+0x5afbe90
	void ServerMoveDualHybridRootMotion(float TimeStamp0, struct FVector_NetQuantize10 InAccel0, bool PendingFlags, uint32 View0, float Timestamp, struct FVector_NetQuantize10 InAccel, struct FVector_NetQuantize100 ClientLoc, bool NewFlags, bool ClientRoll, uint32 View, struct UPrimitiveComponent* ClientMovementBase, struct FName ClientBaseBoneName, bool ClientMovementMode, bool ClientStanceMode); // Function Engine.Character.ServerMoveDualHybridRootMotion // Net|Native|Event|Public|NetServer|NetValidate // @ game+0x5afb910
	void ServerMoveDual(float TimeStamp0, struct FVector_NetQuantize10 InAccel0, bool PendingFlags, uint32 View0, float Timestamp, struct FVector_NetQuantize10 InAccel, struct FVector_NetQuantize100 ClientLoc, bool NewFlags, bool ClientRoll, uint32 View, struct UPrimitiveComponent* ClientMovementBase, struct FName ClientBaseBoneName, bool ClientMovementMode, bool ClientStanceMode); // Function Engine.Character.ServerMoveDual // Net|Native|Event|Public|NetServer|NetValidate // @ game+0x5afb390
	void ServerMove(float Timestamp, struct FVector_NetQuantize10 InAccel, struct FVector_NetQuantize100 ClientLoc, bool CompressedMoveFlags, bool ClientRoll, uint32 View, struct UPrimitiveComponent* ClientMovementBase, struct FName ClientBaseBoneName, bool ClientMovementMode, bool ClientStanceMode); // Function Engine.Character.ServerMove // Net|Native|Event|Public|NetServer|NetValidate // @ game+0x5afaf94
	float PlayAnimMontage(struct UAnimMontage* AnimMontage, float InPlayRate, struct FName StartSectionName); // Function Engine.Character.PlayAnimMontage // Native|Public|BlueprintCallable // @ game+0x5af93f0
	void OnWalkingOffLedge(struct FVector PreviousFloorImpactNormal, struct FVector PreviousFloorContactNormal, struct FVector PreviousLocation, float TimeDelta); // Function Engine.Character.OnWalkingOffLedge // Native|Event|Public|HasOutParms|HasDefaults|BlueprintEvent // @ game+0x5af8e20
	void OnRep_RootMotion(); // Function Engine.Character.OnRep_RootMotion // Final|Native|Public // @ game+0x5af8c14
	void OnRep_ReplicatedBasedMovement(); // Function Engine.Character.OnRep_ReplicatedBasedMovement // Native|Public // @ game+0x60cd44
	void OnRep_IsCrouched(); // Function Engine.Character.OnRep_IsCrouched // Native|Public // @ game+0xe3f660
	void OnLaunched(struct FVector LaunchVelocity, bool bXYOverride, bool bZOverride); // Function Engine.Character.OnLaunched // Event|Public|HasDefaults|BlueprintEvent // @ game+0x33e45c
	void OnLanded(struct FHitResult Hit); // Function Engine.Character.OnLanded // Event|Public|HasOutParms|BlueprintEvent // @ game+0x33e45c
	void OnJumped(); // Function Engine.Character.OnJumped // Native|Event|Public|BlueprintEvent // @ game+0xe35d30
	void LaunchCharacter(struct FVector LaunchVelocity, bool bXYOverride, bool bZOverride); // Function Engine.Character.LaunchCharacter // Native|Public|HasDefaults|BlueprintCallable // @ game+0x5af7fe4
	void K2_UpdateCustomMovement(float DeltaTime); // Function Engine.Character.K2_UpdateCustomMovement // Event|Public|BlueprintEvent // @ game+0x33e45c
	void K2_OnStartCrouch(float HalfHeightAdjust, float ScaledHalfHeightAdjust); // Function Engine.Character.K2_OnStartCrouch // Event|Public|BlueprintEvent // @ game+0x33e45c
	void K2_OnMovementModeChanged(enum class EMovementMode PrevMovementMode, enum class EMovementMode NewMovementMode, bool PrevCustomMode, bool NewCustomMode); // Function Engine.Character.K2_OnMovementModeChanged // Event|Public|BlueprintEvent // @ game+0x33e45c
	void K2_OnEndCrouch(float HalfHeightAdjust, float ScaledHalfHeightAdjust); // Function Engine.Character.K2_OnEndCrouch // Event|Public|BlueprintEvent // @ game+0x33e45c
	void Jump(); // Function Engine.Character.Jump // Native|Public|BlueprintCallable // @ game+0x5af2dd8
	bool IsPlayingRootMotion(); // Function Engine.Character.IsPlayingRootMotion // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5af2a2c
	bool IsPlayingNetworkedRootMotionMontage(); // Function Engine.Character.IsPlayingNetworkedRootMotionMontage // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5af2a08
	bool IsJumpProvidingForce(); // Function Engine.Character.IsJumpProvidingForce // Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5af25e0
	struct UAnimMontage* GetCurrentMontage(); // Function Engine.Character.GetCurrentMontage // Final|Native|Public|BlueprintCallable // @ game+0x5aed888
	struct FVector GetBaseTranslationOffset(); // Function Engine.Character.GetBaseTranslationOffset // Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5aec0e8
	struct FRotator GetBaseRotationOffsetRotator(); // Function Engine.Character.GetBaseRotationOffsetRotator // Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5aec0a0
	float GetAnimRootMotionTranslationScale(); // Function Engine.Character.GetAnimRootMotionTranslationScale // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5aebed8
	void Crouch(bool bClientSimulation); // Function Engine.Character.Crouch // Native|Public|BlueprintCallable // @ game+0x5ae8a1c
	void ClientVeryShortAdjustPosition(float Timestamp, struct FVector NewLoc, float NewRotationPitch, struct UPrimitiveComponent* NewBase, struct FName NewBaseBoneName, bool bHasBase, bool bBaseRelativePosition, bool ServerMovementMode); // Function Engine.Character.ClientVeryShortAdjustPosition // Net|Native|Event|Public|HasDefaults|NetClient // @ game+0xc7c7ac
	void ClientCheatWalk(); // Function Engine.Character.ClientCheatWalk // Net|NetReliableNative|Event|Public|NetClient // @ game+0xd090fc
	void ClientCheatGhost(); // Function Engine.Character.ClientCheatGhost // Net|NetReliableNative|Event|Public|NetClient // @ game+0x5ae6380
	void ClientCheatFly(); // Function Engine.Character.ClientCheatFly // Net|NetReliableNative|Event|Public|NetClient // @ game+0x974db0
	void ClientAdjustRootMotionSourcePosition(float Timestamp, struct FRootMotionSourceGroup ServerRootMotion, bool bHasAnimRootMotion, float ServerMontageTrackPosition, struct FVector ServerLoc, struct FVector_NetQuantizeNormal ServerRotation, float ServerVelZ, struct UPrimitiveComponent* ServerBase, struct FName ServerBoneName, bool bHasBase, bool bBaseRelativePosition, bool ServerMovementMode); // Function Engine.Character.ClientAdjustRootMotionSourcePosition // Net|Native|Event|Public|HasDefaults|NetClient // @ game+0x5ae5e84
	void ClientAdjustRootMotionPosition(float Timestamp, float ServerMontageTrackPosition, struct FVector ServerLoc, struct FVector_NetQuantizeNormal ServerRotation, float ServerVelZ, struct UPrimitiveComponent* ServerBase, struct FName ServerBoneName, bool bHasBase, bool bBaseRelativePosition, bool ServerMovementMode); // Function Engine.Character.ClientAdjustRootMotionPosition // Net|Native|Event|Public|HasDefaults|NetClient // @ game+0x5ae5af0
	void ClientAdjustPosition(float Timestamp, struct FVector NewLoc, float NewRotationPitch, struct FVector NewVel, struct UPrimitiveComponent* NewBase, struct FName NewBaseBoneName, bool bHasBase, bool bBaseRelativePosition, bool ServerMovementMode); // Function Engine.Character.ClientAdjustPosition // Net|Native|Event|Public|HasDefaults|NetClient // @ game+0x91b190
	void ClientAckGoodMove(float Timestamp); // Function Engine.Character.ClientAckGoodMove // Net|Native|Event|Public|NetClient // @ game+0x91a904
	bool CanJumpInternal(); // Function Engine.Character.CanJumpInternal // Native|Event|Protected|BlueprintEvent|Const // @ game+0xc8f9f0
	bool CanJump(); // Function Engine.Character.CanJump // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5ae561c
	void CacheInitialMeshOffset(struct FVector MeshRelativeLocation, struct FRotator MeshRelativeRotation); // Function Engine.Character.CacheInitialMeshOffset // Native|Public|HasDefaults|BlueprintCallable // @ game+0x5ae5248
};

// Class Engine.SpringArmComponent
// Size: 0x540 (Inherited: 0x4b0)
struct USpringArmComponent : USceneComponent {
	float TargetArmLength; // 0x4b0(0x04)
	struct FVector SocketOffset; // 0x4b4(0x0c)
	struct FVector TargetOffset; // 0x4c0(0x0c)
	float ProbeSize; // 0x4cc(0x04)
	enum class ECollisionChannel ProbeChannel; // 0x4d0(0x01)
	char pad_4D1[0x3]; // 0x4d1(0x03)
	char bDoCollisionTest : 1; // 0x4d4(0x01)
	char bUsePawnControlRotation : 1; // 0x4d4(0x01)
	char bInheritPitch : 1; // 0x4d4(0x01)
	char bInheritYaw : 1; // 0x4d4(0x01)
	char bInheritRoll : 1; // 0x4d4(0x01)
	char bLockPitchLag : 1; // 0x4d4(0x01)
	char bLockYawLag : 1; // 0x4d4(0x01)
	char bLockRollLag : 1; // 0x4d4(0x01)
	char bEnableCameraLag : 1; // 0x4d5(0x01)
	char bEnableCameraRotationLag : 1; // 0x4d5(0x01)
	char bUseCameraLagSubstepping : 1; // 0x4d5(0x01)
	char bDrawDebugLagMarkers : 1; // 0x4d5(0x01)
	char pad_4D5_4 : 4; // 0x4d5(0x01)
	char pad_4D6[0x2]; // 0x4d6(0x02)
	float CameraLagSpeed; // 0x4d8(0x04)
	float CameraRotationLagSpeed; // 0x4dc(0x04)
	float CameraLagMaxTimeStep; // 0x4e0(0x04)
	float CameraLagMaxDistance; // 0x4e4(0x04)
	char pad_4E8[0x58]; // 0x4e8(0x58)
};

// Class Engine.LevelBlockResourceContainer
// Size: 0x38 (Inherited: 0x38)
struct ULevelBlockResourceContainer : UObject {
};

// Class Engine.AnimNotify
// Size: 0x48 (Inherited: 0x38)
struct UAnimNotify : UObject {
	char pad_38[0x10]; // 0x38(0x10)

	bool Received_Notify(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Function Engine.AnimNotify.Received_Notify // Event|Public|BlueprintEvent|Const // @ game+0x33e45c
	struct FString GetNotifyName(); // Function Engine.AnimNotify.GetNotifyName // Native|Event|Public|BlueprintEvent|Const // @ game+0x5aeff28
};

// Class Engine.AnimNotify_PlayParticleEffect
// Size: 0x90 (Inherited: 0x48)
struct UAnimNotify_PlayParticleEffect : UAnimNotify {
	struct UParticleSystem* PSTemplate; // 0x48(0x08)
	struct FVector LocationOffset; // 0x50(0x0c)
	struct FRotator RotationOffset; // 0x5c(0x0c)
	char pad_68[0x18]; // 0x68(0x18)
	char Attached : 1; // 0x80(0x01)
	char pad_80_1 : 7; // 0x80(0x01)
	char pad_81[0x7]; // 0x81(0x07)
	struct FName SocketName; // 0x88(0x08)
};

// Class Engine.Controller
// Size: 0x478 (Inherited: 0x3f0)
struct AController : AActor {
	char pad_3F0[0x10]; // 0x3f0(0x10)
	struct FRotator ControlRotation; // 0x400(0x0c)
	char pad_40C[0xc]; // 0x40c(0x0c)
	struct USceneComponent* TransformComponent; // 0x418(0x08)
	char bAttachToPawn : 1; // 0x420(0x01)
	char bIsPlayerController : 1; // 0x420(0x01)
	char pad_420_2 : 6; // 0x420(0x01)
	char pad_421[0x7]; // 0x421(0x07)
	struct APlayerState* PlayerState; // 0x428(0x08)
	struct ACharacter* Character; // 0x430(0x08)
	char pad_438[0x8]; // 0x438(0x08)
	struct FName StateName; // 0x440(0x08)
	char pad_448[0x18]; // 0x448(0x18)
	struct APawn* Pawn; // 0x460(0x08)
	struct FMulticastDelegate OnInstigatedAnyDamage; // 0x468(0x10)

	void UnPossess(); // Function Engine.Controller.UnPossess // Native|Public|BlueprintCallable // @ game+0x5b05544
	void StopMovement(); // Function Engine.Controller.StopMovement // Native|Public|BlueprintCallable // @ game+0x5b04f58
	void SetIgnoreMoveInput(bool bNewMoveInput); // Function Engine.Controller.SetIgnoreMoveInput // Native|Public|BlueprintCallable // @ game+0x5b00f3c
	void SetIgnoreLookInput(bool bNewLookInput); // Function Engine.Controller.SetIgnoreLookInput // Native|Public|BlueprintCallable // @ game+0x5b00ea4
	void SetControlRotationBP(struct FRotator NewRotation); // Function Engine.Controller.SetControlRotationBP // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5afff28
	void ResetIgnoreMoveInput(); // Function Engine.Controller.ResetIgnoreMoveInput // Native|Public|BlueprintCallable // @ game+0x5afa694
	void ResetIgnoreLookInput(); // Function Engine.Controller.ResetIgnoreLookInput // Native|Public|BlueprintCallable // @ game+0x4d18b80
	void ResetIgnoreInputFlags(); // Function Engine.Controller.ResetIgnoreInputFlags // Native|Public|BlueprintCallable // @ game+0x5afa67c
	void ReceiveInstigatedAnyDamage(float Damage, struct UDamageType* DamageType, struct AActor* DamagedActor, struct AActor* DamageCauser); // Function Engine.Controller.ReceiveInstigatedAnyDamage // BlueprintAuthorityOnly|Event|Protected|BlueprintEvent // @ game+0x33e45c
	void Possess(struct APawn* InPawn); // Function Engine.Controller.Possess // BlueprintAuthorityOnly|Native|Public|BlueprintCallable // @ game+0x5af9d48
	void OnRep_PlayerState(); // Function Engine.Controller.OnRep_PlayerState // Native|Public // @ game+0x967ffc
	void OnRep_Pawn(); // Function Engine.Controller.OnRep_Pawn // Native|Public // @ game+0x92b3cc
	bool LineOfSightTo(struct AActor* Other, struct FVector ViewPoint, bool bAlternateChecks); // Function Engine.Controller.LineOfSightTo // Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5af8330
	struct APawn* K2_GetPawn(); // Function Engine.Controller.K2_GetPawn // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5af5c20
	bool IsPlayerController(); // Function Engine.Controller.IsPlayerController // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5af29ec
	bool IsMoveInputIgnored(); // Function Engine.Controller.IsMoveInputIgnored // Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5af276c
	bool IsLookInputIgnored(); // Function Engine.Controller.IsLookInputIgnored // Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5af2674
	bool IsLocalPlayerController(); // Function Engine.Controller.IsLocalPlayerController // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5af2630
	bool IsLocalController(); // Function Engine.Controller.IsLocalController // Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5af2608
	struct AActor* GetViewTarget(); // Function Engine.Controller.GetViewTarget // Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5af1a50
	struct FRotator GetDesiredRotation(); // Function Engine.Controller.GetDesiredRotation // Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5aed97c
	struct FRotator GetControlRotation(); // Function Engine.Controller.GetControlRotation // Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5aed3d4
	void ClientSetRotation(struct FRotator NewRotation, bool bResetCamera); // Function Engine.Controller.ClientSetRotation // Net|NetReliableNative|Event|Public|HasDefaults|NetClient // @ game+0xa9c124
	void ClientSetLocation(struct FVector NewLocation, struct FRotator NewRotation); // Function Engine.Controller.ClientSetLocation // Net|NetReliableNative|Event|Public|HasDefaults|NetClient // @ game+0x5ae74e8
	struct APlayerController* CastToPlayerController(); // Function Engine.Controller.CastToPlayerController // Final|Native|Public|BlueprintCallable // @ game+0x5ae5730
};

// Class Engine.PlayerController
// Size: 0x768 (Inherited: 0x478)
struct APlayerController : AController {
	struct UPlayer* Player; // 0x478(0x08)
	char pad_480[0x8]; // 0x480(0x08)
	struct APawn* AcknowledgedPawn; // 0x488(0x08)
	struct UInterpTrackInstDirector* ControllingDirTrackInst; // 0x490(0x08)
	char pad_498[0x8]; // 0x498(0x08)
	struct AHUD* MyHUD; // 0x4a0(0x08)
	struct APlayerCameraManager* PlayerCameraManager; // 0x4a8(0x08)
	struct UClass* PlayerCameraManagerClass; // 0x4b0(0x08)
	bool bAutoManageActiveCameraTarget; // 0x4b8(0x01)
	char pad_4B9[0x3]; // 0x4b9(0x03)
	struct FRotator TargetViewRotation; // 0x4bc(0x0c)
	char pad_4C8[0xc]; // 0x4c8(0x0c)
	float SmoothTargetViewRotationSpeed; // 0x4d4(0x04)
	struct TArray<struct AActor*> HiddenActors; // 0x4d8(0x10)
	char pad_4E8[0x4]; // 0x4e8(0x04)
	float LastSpectatorStateSynchTime; // 0x4ec(0x04)
	struct FVector LastSpectatorSyncLocation; // 0x4f0(0x0c)
	struct FRotator LastSpectatorSyncRotation; // 0x4fc(0x0c)
	int32 ClientCap; // 0x508(0x04)
	char pad_50C[0x4]; // 0x50c(0x04)
	struct UCheatManager* CheatManager; // 0x510(0x08)
	struct UClass* CheatClass; // 0x518(0x08)
	struct UPlayerInput* PlayerInput; // 0x520(0x08)
	struct TArray<struct FActiveForceFeedbackEffect> ActiveForceFeedbackEffects; // 0x528(0x10)
	char pad_538[0x90]; // 0x538(0x90)
	char pad_5C8_0 : 3; // 0x5c8(0x01)
	char bPlayerIsWaiting : 1; // 0x5c8(0x01)
	char pad_5C8_4 : 4; // 0x5c8(0x01)
	char pad_5C9[0x3]; // 0x5c9(0x03)
	bool NetPlayerIndex; // 0x5cc(0x01)
	char pad_5CD[0x3b]; // 0x5cd(0x3b)
	struct UNetConnection* PendingSwapConnection; // 0x608(0x08)
	struct UNetConnection* NetConnection; // 0x610(0x08)
	char pad_618[0xc]; // 0x618(0x0c)
	float InputYawScale; // 0x624(0x04)
	float InputPitchScale; // 0x628(0x04)
	float InputRollScale; // 0x62c(0x04)
	char bShowMouseCursor : 1; // 0x630(0x01)
	char bEnableClickEvents : 1; // 0x630(0x01)
	char bEnableTouchEvents : 1; // 0x630(0x01)
	char bEnableMouseOverEvents : 1; // 0x630(0x01)
	char bEnableTouchOverEvents : 1; // 0x630(0x01)
	char bForceFeedbackEnabled : 1; // 0x630(0x01)
	char pad_630_6 : 2; // 0x630(0x01)
	char pad_631[0x7]; // 0x631(0x07)
	struct TArray<struct FKey> ClickEventKeys; // 0x638(0x10)
	enum class EMouseCursor DefaultMouseCursor; // 0x648(0x01)
	enum class EMouseCursor CurrentMouseCursor; // 0x649(0x01)
	enum class ECollisionChannel DefaultClickTraceChannel; // 0x64a(0x01)
	enum class ECollisionChannel CurrentClickTraceChannel; // 0x64b(0x01)
	float HitResultTraceDistance; // 0x64c(0x04)
	char pad_650[0x80]; // 0x650(0x80)
	struct UInputComponent* InactiveStateInputComponent; // 0x6d0(0x08)
	char pad_6D8_0 : 3; // 0x6d8(0x01)
	char bShouldPerformFullTickWhenPaused : 1; // 0x6d8(0x01)
	char pad_6D8_4 : 4; // 0x6d8(0x01)
	char pad_6D9[0x17]; // 0x6d9(0x17)
	struct UTouchInterface* CurrentTouchInterface; // 0x6f0(0x08)
	char pad_6F8[0x40]; // 0x6f8(0x40)
	struct ASpectatorPawn* SpectatorPawn; // 0x738(0x08)
	struct FVector SpawnLocation; // 0x740(0x0c)
	char pad_74C[0x4]; // 0x74c(0x04)
	bool bIsLocalPlayerController; // 0x750(0x01)
	char pad_751[0x1]; // 0x751(0x01)
	uint16 SeamlessTravelCount; // 0x752(0x02)
	uint16 LastCompletedSeamlessTravelCount; // 0x754(0x02)
	char pad_756[0x2]; // 0x756(0x02)
	struct AActor* ViewTargetOnServer; // 0x758(0x08)
	struct AActor* ViewTargetPSOnServer; // 0x760(0x08)

	bool WasInputKeyJustReleased(struct FKey Key); // Function Engine.PlayerController.WasInputKeyJustReleased // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b057f8
	bool WasInputKeyJustPressed(struct FKey Key); // Function Engine.PlayerController.WasInputKeyJustPressed // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b05704
	void ToggleSpeaking(bool bInSpeaking); // Function Engine.PlayerController.ToggleSpeaking // Exec|Native|Public // @ game+0x5b052d8
	void SwitchLevel(struct FString URL); // Function Engine.PlayerController.SwitchLevel // Exec|Native|Public // @ game+0x5b05148
	void StopHapticEffect(enum class EControllerHand Hand); // Function Engine.PlayerController.StopHapticEffect // Final|Native|Public|BlueprintCallable // @ game+0x5b04ea8
	void StartFire(bool FireModeNum); // Function Engine.PlayerController.StartFire // Exec|Native|Public // @ game+0x5b04914
	void SetVirtualJoystickVisibility(bool bVisible); // Function Engine.PlayerController.SetVirtualJoystickVisibility // Native|Public|BlueprintCallable // @ game+0x5b03f20
	void SetViewTargetWithBlend(struct AActor* NewViewTarget, float BlendTime, enum class EViewTargetBlendFunction BlendFunc, float BlendExp, bool bLockOutgoing); // Function Engine.PlayerController.SetViewTargetWithBlend // Native|Public|BlueprintCallable // @ game+0x5b03d58
	void SetName(struct FString S); // Function Engine.PlayerController.SetName // Exec|Native|Public // @ game+0x5b01ed8
	void SetMouseLocation(int32 X, int32 Y); // Function Engine.PlayerController.SetMouseLocation // Final|Native|Public|BlueprintCallable // @ game+0x5b01c88
	void SetHapticsByValue(float Frequency, float Amplitude, enum class EControllerHand Hand); // Function Engine.PlayerController.SetHapticsByValue // Final|Native|Public|BlueprintCallable // @ game+0x5b00d74
	void SetControllerLightColor(struct FColor Color); // Function Engine.PlayerController.SetControllerLightColor // Final|Native|Public|HasDefaults|BlueprintCallable // @ game+0x5afff9c
	void SetCinematicMode(bool bInCinematicMode, bool bHidePlayer, bool bAffectsHUD, bool bAffectsMovement, bool bAffectsTurning); // Function Engine.PlayerController.SetCinematicMode // Native|Public|BlueprintCallable // @ game+0x5aff69c
	void SetAudioListenerOverride(struct USceneComponent* AttachToComponent, struct FVector Location, struct FRotator Rotation); // Function Engine.PlayerController.SetAudioListenerOverride // Final|Native|Public|HasDefaults|BlueprintCallable // @ game+0x5afe0fc
	void ServerViewSelf(struct FViewTargetTransitionParams TransitionParams); // Function Engine.PlayerController.ServerViewSelf // Net|Native|Event|Public|NetServer|NetValidate // @ game+0x5afd34c
	void ServerViewPrevPlayer(); // Function Engine.PlayerController.ServerViewPrevPlayer // Net|Native|Event|Public|NetServer|NetValidate // @ game+0x5afd300
	void ServerViewNextPlayer(); // Function Engine.PlayerController.ServerViewNextPlayer // Net|Native|Event|Public|NetServer|NetValidate // @ game+0x5afd2b4
	void ServerVerifyViewTarget(); // Function Engine.PlayerController.ServerVerifyViewTarget // Net|NetReliableNative|Event|Public|NetServer|NetValidate // @ game+0x5afd268
	void ServerUpdateMultipleLevelsVisibility(struct TArray<struct FUpdateLevelVisibilityLevelInfo> LevelVisibilities); // Function Engine.PlayerController.ServerUpdateMultipleLevelsVisibility // Final|Net|NetReliableNative|Event|Public|NetServer|NetValidate // @ game+0x5afd170
	void ServerUpdateLevelVisibility(struct FName PackageName, bool bIsVisible); // Function Engine.PlayerController.ServerUpdateLevelVisibility // Final|Net|NetReliableNative|Event|Public|NetServer|NetValidate // @ game+0xbd0dd4
	void ServerUpdateCamera(struct FVector_NetQuantize CamLoc, int32 CamPitchAndYaw); // Function Engine.PlayerController.ServerUpdateCamera // Net|Native|Event|Public|NetServer|NetValidate // @ game+0x5afd044
	void ServerUnmutePlayer(struct FUniqueNetIdRepl PlayerId); // Function Engine.PlayerController.ServerUnmutePlayer // Net|NetReliableNative|Event|Public|NetServer|NetValidate // @ game+0x5afcee4
	void ServerToggleAILogging(); // Function Engine.PlayerController.ServerToggleAILogging // Net|NetReliableNative|Event|Public|NetServer|NetValidate // @ game+0x5afce98
	void ServerShortTimeout(); // Function Engine.PlayerController.ServerShortTimeout // Net|NetReliableNative|Event|Public|NetServer|NetValidate // @ game+0xe2b7dc
	void ServerSetSpectatorWaiting(bool bWaiting); // Function Engine.PlayerController.ServerSetSpectatorWaiting // Net|NetReliableNative|Event|Public|NetServer|NetValidate // @ game+0x5afcdd8
	void ServerSetSpectatorLocation(struct FVector NewLoc, struct FRotator NewRot); // Function Engine.PlayerController.ServerSetSpectatorLocation // Net|Native|Event|Public|NetServer|HasDefaults|NetValidate // @ game+0x5afcc90
	void ServerRestartPlayer(); // Function Engine.PlayerController.ServerRestartPlayer // Net|NetReliableNative|Event|Public|NetServer|NetValidate // @ game+0x5afcc44
	void ServerPause(); // Function Engine.PlayerController.ServerPause // Net|NetReliableNative|Event|Public|NetServer|NetValidate // @ game+0x5afcbf8
	void ServerNotifyLoadedWorld(struct FName WorldPackageName); // Function Engine.PlayerController.ServerNotifyLoadedWorld // Final|Net|NetReliableNative|Event|Public|NetServer|NetValidate // @ game+0x5afc964
	void ServerMutePlayer(struct FUniqueNetIdRepl PlayerId); // Function Engine.PlayerController.ServerMutePlayer // Net|NetReliableNative|Event|Public|NetServer|NetValidate // @ game+0x5afc804
	void ServerCheckClientPossessionReliable(); // Function Engine.PlayerController.ServerCheckClientPossessionReliable // Net|NetReliableNative|Event|Public|NetServer|NetValidate // @ game+0x5afaf48
	void ServerCheckClientPossession(); // Function Engine.PlayerController.ServerCheckClientPossession // Net|Native|Event|Public|NetServer|NetValidate // @ game+0x5afaefc
	void ServerChangeName(struct FString S); // Function Engine.PlayerController.ServerChangeName // Net|NetReliableNative|Event|Public|NetServer|NetValidate // @ game+0x5afae14
	void ServerCamera(struct FName NewMode); // Function Engine.PlayerController.ServerCamera // Net|NetReliableNative|Event|Public|NetServer|NetValidate // @ game+0x5afad60
	void ServerAcknowledgePossession(struct APawn* P); // Function Engine.PlayerController.ServerAcknowledgePossession // Net|NetReliableNative|Event|Public|NetServer|NetValidate // @ game+0xd23d28
	void SendToConsole(struct FString Command); // Function Engine.PlayerController.SendToConsole // Exec|Native|Public // @ game+0x5afac9c
	void RestartLevel(); // Function Engine.PlayerController.RestartLevel // Exec|Native|Public // @ game+0x5afa6d8
	bool ProjectWorldLocationToScreen(struct FVector WorldLocation, struct FVector2D ScreenLocation, bool bPlayerViewportRelative); // Function Engine.PlayerController.ProjectWorldLocationToScreen // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5af9e9c
	void PlayHapticEffect(struct UHapticFeedbackEffect_Base* HapticEffect, enum class EControllerHand Hand, float Scale, bool bLoop); // Function Engine.PlayerController.PlayHapticEffect // Final|Native|Public|BlueprintCallable // @ game+0x5af9bc4
	void PlayDynamicForceFeedback(float Intensity, float Duration, bool bAffectsLeftLarge, bool bAffectsLeftSmall, bool bAffectsRightLarge, bool bAffectsRightSmall, enum class EDynamicForceFeedbackAction Action, struct FLatentActionInfo LatentInfo); // Function Engine.PlayerController.PlayDynamicForceFeedback // Final|Native|Public|BlueprintCallable // @ game+0x5af98b8
	void Pause(); // Function Engine.PlayerController.Pause // Exec|Native|Public // @ game+0x5af8fe8
	void OnServerStartedVisualLogger(bool bIsLogging); // Function Engine.PlayerController.OnServerStartedVisualLogger // Net|NetReliableNative|Event|Public|NetClient // @ game+0x5af8d88
	void OnRep_TargetViewRotation(); // Function Engine.PlayerController.OnRep_TargetViewRotation // Native|Public // @ game+0x4d2a8f0
	void LocalTravel(struct FString URL); // Function Engine.PlayerController.LocalTravel // Exec|Native|Public // @ game+0x5af8474
	bool IsInputKeyDown(struct FKey Key); // Function Engine.PlayerController.IsInputKeyDown // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5af24cc
	void IncDISPSharpness(); // Function Engine.PlayerController.IncDISPSharpness // Exec|Native|Public // @ game+0x5af1e20
	void GetViewportSize(int32 SizeX, int32 SizeY); // Function Engine.PlayerController.GetViewportSize // Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const // @ game+0x5af1a78
	struct ASpectatorPawn* GetSpectatorPawn(); // Function Engine.PlayerController.GetSpectatorPawn // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5af124c
	bool GetMousePosition(float LocationX, float LocationY); // Function Engine.PlayerController.GetMousePosition // Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const // @ game+0x5aefbb0
	struct FVector GetInputVectorKeyState(struct FKey Key); // Function Engine.PlayerController.GetInputVectorKeyState // Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5aef388
	void GetInputTouchState(enum class ETouchIndex FingerIndex, float LocationX, float LocationY, bool bIsCurrentlyPressed); // Function Engine.PlayerController.GetInputTouchState // Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const // @ game+0x5aef0d0
	void GetInputMouseDelta(float DeltaX, float DeltaY); // Function Engine.PlayerController.GetInputMouseDelta // Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const // @ game+0x5aeefcc
	void GetInputMotionState(struct FVector Tilt, struct FVector RotationRate, struct FVector Gravity, struct FVector Acceleration); // Function Engine.PlayerController.GetInputMotionState // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5aeee04
	float GetInputKeyTimeDown(struct FKey Key); // Function Engine.PlayerController.GetInputKeyTimeDown // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5aeed10
	void GetInputAnalogStickStateRaw(enum class EControllerAnalogStick WhichStick, float StickX, float StickY); // Function Engine.PlayerController.GetInputAnalogStickStateRaw // Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const // @ game+0x5aeea2c
	void GetInputAnalogStickState(enum class EControllerAnalogStick WhichStick, float StickX, float StickY); // Function Engine.PlayerController.GetInputAnalogStickState // Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const // @ game+0x5aee8e4
	float GetInputAnalogKeyState(struct FKey Key); // Function Engine.PlayerController.GetInputAnalogKeyState // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5aee7f0
	struct AHUD* GetHUD(); // Function Engine.PlayerController.GetHUD // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0xd4bfc0
	bool GetHitResultUnderFingerForObjects(enum class ETouchIndex FingerIndex, struct TArray<enum class EObjectTypeQuery> ObjectTypes, bool bTraceComplex, struct FHitResult HitResult); // Function Engine.PlayerController.GetHitResultUnderFingerForObjects // Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const // @ game+0x5aee448
	bool GetHitResultUnderFingerByChannel(enum class ETouchIndex FingerIndex, enum class ETraceTypeQuery TraceChannel, bool bTraceComplex, struct FHitResult HitResult); // Function Engine.PlayerController.GetHitResultUnderFingerByChannel // Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const // @ game+0x5aee298
	bool GetHitResultUnderFinger(enum class ETouchIndex FingerIndex, enum class ECollisionChannel TraceChannel, bool bTraceComplex, struct FHitResult HitResult); // Function Engine.PlayerController.GetHitResultUnderFinger // Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const // @ game+0x5aee0e8
	bool GetHitResultUnderCursorForObjects(struct TArray<enum class EObjectTypeQuery> ObjectTypes, bool bTraceComplex, struct FHitResult HitResult); // Function Engine.PlayerController.GetHitResultUnderCursorForObjects // Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const // @ game+0x5aedf30
	bool GetHitResultUnderCursorByChannel(enum class ETraceTypeQuery TraceChannel, bool bTraceComplex, struct FHitResult HitResult); // Function Engine.PlayerController.GetHitResultUnderCursorByChannel // Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const // @ game+0x5aeddc0
	bool GetHitResultUnderCursor(enum class ECollisionChannel TraceChannel, bool bTraceComplex, struct FHitResult HitResult); // Function Engine.PlayerController.GetHitResultUnderCursor // Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const // @ game+0x5aedc50
	struct FVector GetFocalLocation(); // Function Engine.PlayerController.GetFocalLocation // Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5aedb20
	void FOV(float NewFOV); // Function Engine.PlayerController.FOV // Exec|Native|Public // @ game+0x5aeac58
	void EnableTAA(); // Function Engine.PlayerController.EnableTAA // Exec|Native|Public // @ game+0x5aeac2c
	void EnableDLSS(); // Function Engine.PlayerController.EnableDLSS // Exec|Native|Public // @ game+0x5aeaa38
	void EnableCheats(); // Function Engine.PlayerController.EnableCheats // Exec|Native|Public // @ game+0x5aeaa20
	bool DeprojectScreenPositionToWorld(float ScreenX, float ScreenY, struct FVector WorldLocation, struct FVector WorldDirection); // Function Engine.PlayerController.DeprojectScreenPositionToWorld // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5ae8d9c
	bool DeprojectMousePositionToWorld(struct FVector WorldLocation, struct FVector WorldDirection); // Function Engine.PlayerController.DeprojectMousePositionToWorld // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5ae8c94
	void DecDISPSharpness(); // Function Engine.PlayerController.DecDISPSharpness // Exec|Native|Public // @ game+0x5ae8ae8
	void ConsoleKey(struct FKey Key); // Function Engine.PlayerController.ConsoleKey // Exec|Native|Public // @ game+0x5ae8148
	void ClientWasKicked(struct FText KickReason); // Function Engine.PlayerController.ClientWasKicked // Net|NetReliableNative|Event|Public|NetClient // @ game+0x5ae7fd4
	void ClientVoiceHandshakeComplete(); // Function Engine.PlayerController.ClientVoiceHandshakeComplete // Net|NetReliableNative|Event|Public|NetClient // @ game+0xe32ed4
	void ClientUpdateMultipleLevelsStreamingStatus(struct TArray<struct FUpdateLevelStreamingLevelStatus> LevelStatuses); // Function Engine.PlayerController.ClientUpdateMultipleLevelsStreamingStatus // Net|NetReliableNative|Event|Public|NetClient // @ game+0x5ae7f18
	void ClientUpdateLevelStreamingStatus(struct FName PackageName, bool bNewShouldBeLoaded, bool bNewShouldBeVisible, bool bNewShouldBlockOnLoad, int32 LODIndex); // Function Engine.PlayerController.ClientUpdateLevelStreamingStatus // Net|NetReliableNative|Event|Public|NetClient // @ game+0xb312b0
	void ClientUnmutePlayer(struct FUniqueNetIdRepl PlayerId); // Function Engine.PlayerController.ClientUnmutePlayer // Net|NetReliableNative|Event|Public|NetClient // @ game+0x5ae7dfc
	void ClientTravelInternal(struct FString URL, enum class ETravelType TravelType, bool bSeamless, struct FGuid MapPackageGuid); // Function Engine.PlayerController.ClientTravelInternal // Net|NetReliableNative|Event|Public|HasDefaults|NetClient // @ game+0x5ae7c24
	void ClientTravel(struct FString URL, enum class ETravelType TravelType, bool bSeamless, struct FGuid MapPackageGuid); // Function Engine.PlayerController.ClientTravel // Final|Native|Public|HasDefaults // @ game+0x5ae7a50
	void ClientTeamMessage(struct APlayerState* SenderPlayerState, struct FString S, struct FName Type, float MsgLifeTime); // Function Engine.PlayerController.ClientTeamMessage // Net|NetReliableNative|Event|Public|NetClient // @ game+0x5ae7894
	void ClientStopForceFeedback(struct UForceFeedbackEffect* ForceFeedbackEffect, struct FName Tag); // Function Engine.PlayerController.ClientStopForceFeedback // Net|NetReliableNative|Event|Public|NetClient|BlueprintCallable // @ game+0x5ae77b4
	void ClientStopCameraShake(struct UClass* Shake, bool bImmediately); // Function Engine.PlayerController.ClientStopCameraShake // Net|NetReliableNative|Event|Public|NetClient|BlueprintCallable // @ game+0x4db005c
	void ClientStopCameraAnim(struct UCameraAnim* AnimToStop); // Function Engine.PlayerController.ClientStopCameraAnim // Net|NetReliableNative|Event|Public|NetClient // @ game+0x5ae7720
	void ClientStartOnlineSession(); // Function Engine.PlayerController.ClientStartOnlineSession // Net|NetReliableNative|Event|Public|NetClient // @ game+0x6e0f64
	void ClientSpawnCameraLensEffect(struct UClass* LensEffectEmitterClass); // Function Engine.PlayerController.ClientSpawnCameraLensEffect // Net|Native|Event|Public|NetClient|BlueprintCallable // @ game+0x5ae768c
	void ClientSetViewTarget(struct AActor* A, struct FViewTargetTransitionParams TransitionParams); // Function Engine.PlayerController.ClientSetViewTarget // Net|NetReliableNative|Event|Public|NetClient // @ game+0xca86d4
	void ClientSetSpectatorWaiting(bool bWaiting); // Function Engine.PlayerController.ClientSetSpectatorWaiting // Net|NetReliableNative|Event|Public|NetClient // @ game+0x5ae75f4
	void ClientSetHUD(struct FString InHUDClass); // Function Engine.PlayerController.ClientSetHUD // Net|NetReliableNative|Event|Public|NetClient|BlueprintCallable // @ game+0xab8ffc
	void ClientSetForceMipLevelsToBeResident(struct UMaterialInterface* Material, float ForceDuration, int32 CinematicTextureGroups); // Function Engine.PlayerController.ClientSetForceMipLevelsToBeResident // Net|NetReliableNative|Event|Public|NetClient // @ game+0x5ae73c0
	void ClientSetCinematicMode(bool bInCinematicMode, bool bAffectsMovement, bool bAffectsTurning, bool bAffectsHUD); // Function Engine.PlayerController.ClientSetCinematicMode // Net|NetReliableNative|Event|Public|NetClient // @ game+0x4ee1e8
	void ClientSetCameraMode(struct FName NewCamMode); // Function Engine.PlayerController.ClientSetCameraMode // Net|NetReliableNative|Event|Public|NetClient // @ game+0xde73b8
	void ClientSetCameraFade(bool bEnableFading, struct FColor FadeColor, struct FVector2D FadeAlpha, float FadeTime, bool bFadeAudio); // Function Engine.PlayerController.ClientSetCameraFade // Net|NetReliableNative|Event|Public|HasDefaults|NetClient // @ game+0x5ae71e8
	void ClientSetBlockOnAsyncLoading(); // Function Engine.PlayerController.ClientSetBlockOnAsyncLoading // Net|NetReliableNative|Event|Public|NetClient // @ game+0x4d2a908
	void ClientReturnToMainMenu(struct FString ReturnReason); // Function Engine.PlayerController.ClientReturnToMainMenu // Net|NetReliableNative|Event|Public|NetClient // @ game+0x5ae7124
	void ClientRetryClientRestart(struct APawn* NewPawn); // Function Engine.PlayerController.ClientRetryClientRestart // Net|NetReliableNative|Event|Public|NetClient // @ game+0xce361c
	void ClientRestart(struct APawn* NewPawn); // Function Engine.PlayerController.ClientRestart // Net|NetReliableNative|Event|Public|NetClient // @ game+0x9d05e0
	void ClientReset(); // Function Engine.PlayerController.ClientReset // Net|NetReliableNative|Event|Public|NetClient // @ game+0x4d1a57c
	void ClientRepObjRef(struct UObject* Object); // Function Engine.PlayerController.ClientRepObjRef // Net|NetReliableNative|Event|Public|NetClient // @ game+0x5ae7090
	void ClientReceiveLocalizedMessage(struct UClass* Message, int32 Switch, struct APlayerState* RelatedPlayerState_2, struct APlayerState* RelatedPlayerState_3, struct UObject* OptionalObject); // Function Engine.PlayerController.ClientReceiveLocalizedMessage // Net|NetReliableNative|Event|Public|NetClient // @ game+0x8b220c
	void ClientPrestreamTextures(struct AActor* ForcedActor, float ForceDuration, bool bEnableStreaming, int32 CinematicTextureGroups); // Function Engine.PlayerController.ClientPrestreamTextures // Net|NetReliableNative|Event|Public|NetClient // @ game+0x5ae6f04
	void ClientPrepareMapChange(struct FName LevelName, bool bFirst, bool bLast); // Function Engine.PlayerController.ClientPrepareMapChange // Net|NetReliableNative|Event|Public|NetClient // @ game+0x5ae6dcc
	void ClientPlaySoundAtLocation(struct USoundBase* Sound, struct FVector Location, float VolumeMultiplier, float PitchMultiplier); // Function Engine.PlayerController.ClientPlaySoundAtLocation // Net|Native|Event|Public|HasDefaults|NetClient // @ game+0x5ae6c48
	void ClientPlaySound(struct USoundBase* Sound, float VolumeMultiplier, float PitchMultiplier); // Function Engine.PlayerController.ClientPlaySound // Net|Native|Event|Public|NetClient // @ game+0x5ae6b24
	void ClientPlayForceFeedback(struct UForceFeedbackEffect* ForceFeedbackEffect, bool bLooping, struct FName Tag); // Function Engine.PlayerController.ClientPlayForceFeedback // Net|Native|Event|Public|NetClient|BlueprintCallable // @ game+0xba4518
	void ClientPlayCameraShake(struct UClass* Shake, float Scale, enum class ECameraAnimPlaySpace PlaySpace, struct FRotator UserPlaySpaceRot); // Function Engine.PlayerController.ClientPlayCameraShake // Net|Native|Event|Public|HasDefaults|NetClient|BlueprintCallable // @ game+0xae8ed8
	void ClientPlayCameraAnim(struct UCameraAnim* AnimToPlay, float Scale, float Rate, float BlendInTime, float BlendOutTime, bool bLoop, bool bRandomStartTime, enum class ECameraAnimPlaySpace Space, struct FRotator CustomPlaySpace); // Function Engine.PlayerController.ClientPlayCameraAnim // Net|Native|Event|Public|HasDefaults|NetClient|BlueprintCallable // @ game+0x5ae67f8
	void ClientMutePlayer(struct FUniqueNetIdRepl PlayerId); // Function Engine.PlayerController.ClientMutePlayer // Net|NetReliableNative|Event|Public|NetClient // @ game+0x5ae66dc
	void ClientMessage(struct FString S, struct FName Type, float MsgLifeTime); // Function Engine.PlayerController.ClientMessage // Net|NetReliableNative|Event|Public|NetClient // @ game+0x5ae6574
	void ClientIgnoreMoveInput(bool bIgnore); // Function Engine.PlayerController.ClientIgnoreMoveInput // Net|NetReliableNative|Event|Public|NetClient // @ game+0x5ae64dc
	void ClientIgnoreLookInput(bool bIgnore); // Function Engine.PlayerController.ClientIgnoreLookInput // Net|NetReliableNative|Event|Public|NetClient // @ game+0x5ae6444
	void ClientGotoState(struct FName NewState); // Function Engine.PlayerController.ClientGotoState // Net|NetReliableNative|Event|Public|NetClient // @ game+0x5ae63b0
	void ClientGameEnded(struct AActor* EndGameFocus, bool bIsWinner); // Function Engine.PlayerController.ClientGameEnded // Net|NetReliableNative|Event|Public|NetClient // @ game+0x9e8244
	void ClientForceGarbageCollection(); // Function Engine.PlayerController.ClientForceGarbageCollection // Net|NetReliableNative|Event|Public|NetClient // @ game+0x5ae6398
	void ClientFlushLevelStreaming(); // Function Engine.PlayerController.ClientFlushLevelStreaming // Final|Net|NetReliableNative|Event|Public|NetClient // @ game+0xc6f020
	void ClientEndOnlineSession(); // Function Engine.PlayerController.ClientEndOnlineSession // Net|NetReliableNative|Event|Public|NetClient // @ game+0x6e0974
	void ClientEnableNetworkVoice(bool bEnable); // Function Engine.PlayerController.ClientEnableNetworkVoice // Net|NetReliableNative|Event|Public|NetClient // @ game+0xcd5cbc
	void ClientCommitMapChange(); // Function Engine.PlayerController.ClientCommitMapChange // Net|NetReliableNative|Event|Public|NetClient // @ game+0x4cf2378
	void ClientClearCameraLensEffects(); // Function Engine.PlayerController.ClientClearCameraLensEffects // Net|NetReliableNative|Event|Public|NetClient|BlueprintCallable // @ game+0x4d8b798
	void ClientCapBandwidth(int32 Cap); // Function Engine.PlayerController.ClientCapBandwidth // Net|NetReliableNative|Event|Public|NetClient // @ game+0xd24e1c
	void ClientCancelPendingMapChange(); // Function Engine.PlayerController.ClientCancelPendingMapChange // Net|NetReliableNative|Event|Public|NetClient // @ game+0x5ae6368
	void ClientAddTextureStreamingLoc(struct FVector InLoc, float Duration, bool bOverrideLocation); // Function Engine.PlayerController.ClientAddTextureStreamingLoc // Final|Net|NetReliableNative|Event|Public|HasDefaults|NetClient // @ game+0x5ae59ac
	void ClearAudioListenerOverride(); // Function Engine.PlayerController.ClearAudioListenerOverride // Final|Native|Public|BlueprintCallable // @ game+0x5ae593c
	void Camera(struct FName NewMode); // Function Engine.PlayerController.Camera // Exec|Native|Public // @ game+0x5ae54e0
	void AddYawInput(float Val); // Function Engine.PlayerController.AddYawInput // Native|Public|BlueprintCallable // @ game+0x5ae4f38
	void AddRollInput(float Val); // Function Engine.PlayerController.AddRollInput // Native|Public|BlueprintCallable // @ game+0x5ae4b10
	void AddPitchInput(float Val); // Function Engine.PlayerController.AddPitchInput // Native|Public|BlueprintCallable // @ game+0x5ae46cc
	void ActivateTouchInterface(struct UTouchInterface* NewTouchInterface); // Function Engine.PlayerController.ActivateTouchInterface // Native|Public|BlueprintCallable // @ game+0x5ae2e80
};

// Class Engine.StaticMeshComponent
// Size: 0xb80 (Inherited: 0xae0)
struct UStaticMeshComponent : UMeshComponent {
	int32 ForcedLodModel; // 0xad8(0x04)
	int32 PreviousLODLevel; // 0xadc(0x04)
	bool bOverrideMinLOD; // 0xae0(0x01)
	int32 MinLOD; // 0xae4(0x04)
	struct UStaticMesh* StaticMesh; // 0xae8(0x08)
	bool bOverrideWireframeColor; // 0xaf0(0x01)
	struct FColor WireframeColorOverride; // 0xaf4(0x04)
	struct FLinearColor PerInstanceCustomData; // 0xaf8(0x10)
	char bOverrideNavigationExport : 1; // 0xb08(0x01)
	char bForceNavigationObstacle : 1; // 0xb08(0x01)
	char bDisallowMeshPaintPerInstance : 1; // 0xb08(0x01)
	char bIgnoreInstanceForTextureStreaming : 1; // 0xb08(0x01)
	char bOverrideLightMapRes : 1; // 0xb08(0x01)
	char pad_B0A_5 : 3; // 0xb0a(0x01)
	char pad_B0B[0x1]; // 0xb0b(0x01)
	int32 OverriddenLightMapRes; // 0xb0c(0x04)
	char bCastDistanceFieldIndirectShadow : 1; // 0xb10(0x01)
	char pad_B10_1 : 7; // 0xb10(0x01)
	char pad_B11[0x3]; // 0xb11(0x03)
	float DistanceFieldIndirectShadowMinVisibility; // 0xb14(0x04)
	float StreamingDistanceMultiplier; // 0xb18(0x04)
	int32 SubDivisionStepSize; // 0xb1c(0x04)
	char bUseSubDivisions : 1; // 0xb20(0x01)
	char pad_B20_1 : 7; // 0xb20(0x01)
	char pad_B21[0x7]; // 0xb21(0x07)
	struct TArray<struct FGuid> IrrelevantLights; // 0xb28(0x10)
	struct TArray<struct FStaticMeshComponentLODInfo> LODData; // 0xb38(0x10)
	struct TArray<struct FStreamingTextureBuildInfo> StreamingTextureData; // 0xb48(0x10)
	bool bUseDefaultCollision; // 0xb58(0x01)
	char pad_B59[0x3]; // 0xb59(0x03)
	struct FLightmassPrimitiveSettings LightmassSettings; // 0xb5c(0x18)
	char pad_B74[0xc]; // 0xb74(0x0c)

	bool SetStaticMesh(struct UStaticMesh* NewMesh); // Function Engine.StaticMeshComponent.SetStaticMesh // Native|Public|BlueprintCallable // @ game+0x549a9e8
	void SetForcedLodModel(int32 NewForcedLodModel); // Function Engine.StaticMeshComponent.SetForcedLodModel // Final|Native|Public|BlueprintCallable // @ game+0x5b006dc
	void OnRep_StaticMesh(struct UStaticMesh* OldStaticMesh); // Function Engine.StaticMeshComponent.OnRep_StaticMesh // Final|Native|Public // @ game+0x5af8c28
	void GetLocalBounds(struct FVector Min, struct FVector Max); // Function Engine.StaticMeshComponent.GetLocalBounds // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5aef5d8
};

// Class Engine.SkeletalMeshActor
// Size: 0x478 (Inherited: 0x3f0)
struct ASkeletalMeshActor : AActor {
	char pad_3F0[0x8]; // 0x3f0(0x08)
	char bShouldDoAnimNotifies : 1; // 0x3f8(0x01)
	char bWakeOnLevelStart : 1; // 0x3f8(0x01)
	char pad_3F8_2 : 6; // 0x3f8(0x01)
	char pad_3F9[0x7]; // 0x3f9(0x07)
	struct USkeletalMeshComponent* SkeletalMeshComponent; // 0x400(0x08)
	struct USkeletalMesh* ReplicatedMesh; // 0x408(0x08)
	struct UPhysicsAsset* ReplicatedPhysAsset; // 0x410(0x08)
	struct UMaterialInterface* ReplicatedMaterial0; // 0x418(0x08)
	struct UMaterialInterface* ReplicatedMaterial1; // 0x420(0x08)
	char pad_428[0x50]; // 0x428(0x50)

	void OnRep_ReplicatedPhysAsset(); // Function Engine.SkeletalMeshActor.OnRep_ReplicatedPhysAsset // Native|Public // @ game+0x815b50
	void OnRep_ReplicatedMesh(); // Function Engine.SkeletalMeshActor.OnRep_ReplicatedMesh // Native|Public // @ game+0xe3d10c
	void OnRep_ReplicatedMaterial1(); // Function Engine.SkeletalMeshActor.OnRep_ReplicatedMaterial1 // Native|Public // @ game+0x769f14
	void OnRep_ReplicatedMaterial0(); // Function Engine.SkeletalMeshActor.OnRep_ReplicatedMaterial0 // Native|Public // @ game+0x815938
};

// Class Engine.SaveGame
// Size: 0x38 (Inherited: 0x38)
struct USaveGame : UObject {
};

// Class Engine.ShapeComponent
// Size: 0x9f0 (Inherited: 0x9d0)
struct UShapeComponent : UPrimitiveComponent {
	struct FColor ShapeColor; // 0x9d0(0x04)
	char pad_9D4[0x4]; // 0x9d4(0x04)
	struct UBodySetup* ShapeBodySetup; // 0x9d8(0x08)
	char bDrawOnlyIfSelected : 1; // 0x9e0(0x01)
	char bShouldCollideWhenPlacing : 1; // 0x9e0(0x01)
	char bDynamicObstacle : 1; // 0x9e0(0x01)
	char pad_9E0_3 : 5; // 0x9e0(0x01)
	char pad_9E1[0x7]; // 0x9e1(0x07)
	struct UClass* AreaClass; // 0x9e8(0x08)
};

// Class Engine.Info
// Size: 0x3f0 (Inherited: 0x3f0)
struct AInfo : AActor {
};

// Class Engine.GameStateBase
// Size: 0x430 (Inherited: 0x3f0)
struct AGameStateBase : AInfo {
	struct UClass* GameModeClass; // 0x3f0(0x08)
	struct AGameModeBase* AuthorityGameMode; // 0x3f8(0x08)
	struct UClass* SpectatorClass; // 0x400(0x08)
	struct TArray<struct APlayerState*> PlayerArray; // 0x408(0x10)
	bool bReplicatedHasBegunPlay; // 0x418(0x01)
	char pad_419[0x3]; // 0x419(0x03)
	float ReplicatedWorldTimeSeconds; // 0x41c(0x04)
	float ServerWorldTimeSecondsDelta; // 0x420(0x04)
	float ServerWorldTimeSecondsUpdateFrequency; // 0x424(0x04)
	char pad_428[0x8]; // 0x428(0x08)

	void OnRep_SpectatorClass(); // Function Engine.GameStateBase.OnRep_SpectatorClass // Native|Protected // @ game+0xcbf6c0
	void OnRep_ReplicatedWorldTimeSeconds(); // Function Engine.GameStateBase.OnRep_ReplicatedWorldTimeSeconds // Native|Protected // @ game+0xbe5670
	void OnRep_ReplicatedHasBegunPlay(); // Function Engine.GameStateBase.OnRep_ReplicatedHasBegunPlay // Native|Protected // @ game+0xe38538
	void OnRep_GameModeClass(); // Function Engine.GameStateBase.OnRep_GameModeClass // Native|Protected // @ game+0xab7ee8
	bool HasMatchStarted(); // Function Engine.GameStateBase.HasMatchStarted // Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5af1c0c
	bool HasBegunPlay(); // Function Engine.GameStateBase.HasBegunPlay // Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5af1bbc
	float GetServerWorldTimeSecondsDelta(); // Function Engine.GameStateBase.GetServerWorldTimeSecondsDelta // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x4da9828
	float GetServerWorldTimeSeconds(); // Function Engine.GameStateBase.GetServerWorldTimeSeconds // Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x4d23e70
	float GetReplicatedRealTimeSeconds(); // Function Engine.GameStateBase.GetReplicatedRealTimeSeconds // Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5af0d8c
	float GetPlayerStartTime(struct AController* Controller); // Function Engine.GameStateBase.GetPlayerStartTime // Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5af0c78
	float GetPlayerRespawnDelay(struct AController* Controller); // Function Engine.GameStateBase.GetPlayerRespawnDelay // Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5af0bd0
};

// Class Engine.GameState
// Size: 0x450 (Inherited: 0x430)
struct AGameState : AGameStateBase {
	struct FName MatchState; // 0x430(0x08)
	struct FName PreviousMatchState; // 0x438(0x08)
	int32 ElapsedTime; // 0x440(0x04)
	char pad_444[0xc]; // 0x444(0x0c)

	void OnRep_MatchState(); // Function Engine.GameState.OnRep_MatchState // Native|Public // @ game+0xb2b840
	void OnRep_ElapsedTime(); // Function Engine.GameState.OnRep_ElapsedTime // Native|Public // @ game+0x5ae8f38
};

// Class Engine.BoxComponent
// Size: 0xa00 (Inherited: 0x9f0)
struct UBoxComponent : UShapeComponent {
	struct FVector BoxExtent; // 0x9f0(0x0c)
	char pad_9FC[0x4]; // 0x9fc(0x04)

	void SetBoxExtent(struct FVector InBoxExtent, bool bUpdateOverlaps); // Function Engine.BoxComponent.SetBoxExtent // Final|Native|Public|HasDefaults|BlueprintCallable // @ game+0x5b4674c
	struct FVector GetUnscaledBoxExtent(); // Function Engine.BoxComponent.GetUnscaledBoxExtent // Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5b2bbe4
	struct FVector GetScaledBoxExtent(); // Function Engine.BoxComponent.GetScaledBoxExtent // Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5b298a8
};

// Class Engine.ProjectileMovementComponent
// Size: 0x310 (Inherited: 0x250)
struct UProjectileMovementComponent : UMovementComponent {
	float InitialSpeed; // 0x248(0x04)
	float MaxSpeed; // 0x24c(0x04)
	char bRotationFollowsVelocity : 1; // 0x250(0x01)
	char bShouldBounce : 1; // 0x250(0x01)
	char bInitialVelocityInLocalSpace : 1; // 0x250(0x01)
	char bForceSubStepping : 1; // 0x250(0x01)
	char bSimulationEnabled : 1; // 0x250(0x01)
	char bSweepCollision : 1; // 0x250(0x01)
	char bIsHomingProjectile : 1; // 0x250(0x01)
	char bBounceAngleAffectsFriction : 1; // 0x250(0x01)
	char bIsSliding : 1; // 0x251(0x01)
	char bInterpMovement : 1; // 0x251(0x01)
	char bInterpRotation : 1; // 0x251(0x01)
	float PreviousHitTime; // 0x254(0x04)
	struct FVector PreviousHitNormal; // 0x258(0x0c)
	float ProjectileGravityScale; // 0x264(0x04)
	float Buoyancy; // 0x268(0x04)
	float Bounciness; // 0x26c(0x04)
	float Friction; // 0x270(0x04)
	float BounceVelocityStopSimulatingThreshold; // 0x274(0x04)
	float MinFrictionFraction; // 0x278(0x04)
	struct FMulticastDelegate OnProjectileBounce; // 0x280(0x10)
	struct FMulticastDelegate OnProjectileStop; // 0x290(0x10)
	float HomingAccelerationMagnitude; // 0x2a0(0x04)
	struct USceneComponent* HomingTargetComponent; // 0x2a4(0x08)
	float MaxSimulationTimeStep; // 0x2ac(0x04)
	int32 MaxSimulationIterations; // 0x2b0(0x04)
	int32 BounceAdditionalIterations; // 0x2b4(0x04)
	float InterpLocationTime; // 0x2b8(0x04)
	float InterpRotationTime; // 0x2bc(0x04)
	float InterpLocationMaxLagDistance; // 0x2c0(0x04)
	float InterpLocationSnapToTargetDistance; // 0x2c4(0x04)
	char pad_2C9[0x47]; // 0x2c9(0x47)

	void StopSimulating(struct FHitResult HitResult); // Function Engine.ProjectileMovementComponent.StopSimulating // Native|Public|HasOutParms|BlueprintCallable // @ game+0x5b05080
	void SetVelocityInLocalSpace(struct FVector NewVelocity); // Function Engine.ProjectileMovementComponent.SetVelocityInLocalSpace // Native|Public|HasDefaults|BlueprintCallable // @ game+0x5b03cb4
	void SetInterpolatedComponent(struct USceneComponent* Component); // Function Engine.ProjectileMovementComponent.SetInterpolatedComponent // Native|Public|BlueprintCallable // @ game+0x4dcc594
	void ResetInterpolation(); // Function Engine.ProjectileMovementComponent.ResetInterpolation // Native|Public|BlueprintCallable // @ game+0x4d2c57c
	void OnProjectileStopDelegate__DelegateSignature(struct FHitResult ImpactResult); // DelegateFunction Engine.ProjectileMovementComponent.OnProjectileStopDelegate__DelegateSignature // MulticastDelegate|Public|Delegate|HasOutParms // @ game+0x33e45c
	void OnProjectileBounceDelegate__DelegateSignature(struct FHitResult ImpactResult, struct FVector ImpactVelocity); // DelegateFunction Engine.ProjectileMovementComponent.OnProjectileBounceDelegate__DelegateSignature // MulticastDelegate|Public|Delegate|HasOutParms|HasDefaults // @ game+0x33e45c
	void MoveInterpolationTarget(struct FVector NewLocation, struct FRotator NewRotation); // Function Engine.ProjectileMovementComponent.MoveInterpolationTarget // Native|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5af88c8
	struct FVector LimitVelocity(struct FVector NewVelocity); // Function Engine.ProjectileMovementComponent.LimitVelocity // Native|Protected|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5af8268
	bool IsVelocityUnderSimulationThreshold(); // Function Engine.ProjectileMovementComponent.IsVelocityUnderSimulationThreshold // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5af2c88
	bool IsInterpolationComplete(); // Function Engine.ProjectileMovementComponent.IsInterpolationComplete // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5af25c0
};

// Class Engine.CurveBase
// Size: 0x40 (Inherited: 0x38)
struct UCurveBase : UObject {
	char pad_38[0x8]; // 0x38(0x08)

	void GetValueRange(float MinValue, float MaxValue); // Function Engine.CurveBase.GetValueRange // Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const // @ game+0x5af1874
	void GetTimeRange(float MinTime, float MaxTime); // Function Engine.CurveBase.GetTimeRange // Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const // @ game+0x5af154c
};

// Class Engine.GameModeBase
// Size: 0x490 (Inherited: 0x3f0)
struct AGameModeBase : AInfo {
	struct FString OptionsString; // 0x3f0(0x10)
	struct UClass* GameSessionClass; // 0x400(0x08)
	struct UClass* GameStateClass; // 0x408(0x08)
	struct UClass* PlayerControllerClass; // 0x410(0x08)
	struct UClass* PlayerStateClass; // 0x418(0x08)
	struct FStringClassReference HUDClass; // 0x420(0x10)
	struct UClass* DefaultPawnClass; // 0x430(0x08)
	struct FStringClassReference SpectatorClass; // 0x438(0x10)
	struct UClass* ReplaySpectatorPlayerControllerClass; // 0x448(0x08)
	struct AGameSession* GameSession; // 0x450(0x08)
	struct AGameStateBase* GameState; // 0x458(0x08)
	struct FText DefaultPlayerName; // 0x460(0x18)
	char bUseSeamlessTravel : 1; // 0x478(0x01)
	char bStartPlayersAsSpectators : 1; // 0x478(0x01)
	char bPauseable : 1; // 0x478(0x01)
	char pad_478_3 : 5; // 0x478(0x01)
	char pad_479[0x17]; // 0x479(0x17)

	void StartPlay(); // Function Engine.GameModeBase.StartPlay // Native|Public|BlueprintCallable // @ game+0xbe5670
	struct APawn* SpawnDefaultPawnFor(struct AController* NewPlayer, struct AActor* StartSpot); // Function Engine.GameModeBase.SpawnDefaultPawnFor // Native|Event|Public|BlueprintEvent // @ game+0xd00034
	struct APawn* SpawnDefaultPawnAtTransform(struct AController* NewPlayer, struct FTransform SpawnTransform); // Function Engine.GameModeBase.SpawnDefaultPawnAtTransform // Native|Event|Public|HasOutParms|HasDefaults|BlueprintEvent // @ game+0xd39e4c
	bool ShouldReset(struct AActor* ActorToReset); // Function Engine.GameModeBase.ShouldReset // Native|Event|Public|BlueprintEvent // @ game+0x5afa244
	void ReturnToMainMenuHost(); // Function Engine.GameModeBase.ReturnToMainMenuHost // Native|Public|BlueprintCallable // @ game+0xb2b840
	void RestartPlayerAtTransform(struct AController* NewPlayer, struct FTransform SpawnTransform); // Function Engine.GameModeBase.RestartPlayerAtTransform // Native|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5afa900
	void RestartPlayerAtPlayerStart(struct AController* NewPlayer, struct AActor* StartSpot); // Function Engine.GameModeBase.RestartPlayerAtPlayerStart // Native|Public|BlueprintCallable // @ game+0x5afa820
	void RestartPlayer(struct AController* NewPlayer); // Function Engine.GameModeBase.RestartPlayer // Native|Public|BlueprintCallable // @ game+0x5afa78c
	void ResetLevel(); // Function Engine.GameModeBase.ResetLevel // Native|Public|BlueprintCallable // @ game+0x5afa6ac
	bool PlayerCanRestart(struct APlayerController* Player); // Function Engine.GameModeBase.PlayerCanRestart // Native|Event|Public|BlueprintEvent // @ game+0x95c0b8
	bool MustSpectate(struct APlayerController* NewPlayerController); // Function Engine.GameModeBase.MustSpectate // Native|Event|Public|BlueprintEvent|Const // @ game+0xcbb4f0
	void K2_PostLogin(struct APlayerController* NewPlayer); // Function Engine.GameModeBase.K2_PostLogin // Event|Public|BlueprintEvent // @ game+0x33e45c
	void K2_OnSwapPlayerControllers(struct APlayerController* OldPC, struct APlayerController* NewPC); // Function Engine.GameModeBase.K2_OnSwapPlayerControllers // Event|Protected|BlueprintEvent // @ game+0x33e45c
	void K2_OnRestartPlayer(struct AController* NewPlayer); // Function Engine.GameModeBase.K2_OnRestartPlayer // Event|Public|BlueprintEvent // @ game+0x33e45c
	void K2_OnLogout(struct AController* ExitingController); // Function Engine.GameModeBase.K2_OnLogout // Event|Public|BlueprintEvent // @ game+0x33e45c
	void K2_OnChangeName(struct AController* Other, struct FString NewName, bool bNameChange); // Function Engine.GameModeBase.K2_OnChangeName // Event|Public|BlueprintEvent // @ game+0x33e45c
	struct AActor* K2_FindPlayerStart(struct AController* Player, struct FString IncomingName); // Function Engine.GameModeBase.K2_FindPlayerStart // Final|Native|Public|BlueprintCallable|BlueprintPure // @ game+0x5af575c
	void InitStartSpot(struct AActor* StartSpot, struct AController* NewPlayer); // Function Engine.GameModeBase.InitStartSpot // Native|Event|Public|BlueprintEvent // @ game+0xdf39e0
	void InitializeHUDForPlayer(struct APlayerController* NewPlayer); // Function Engine.GameModeBase.InitializeHUDForPlayer // Native|Event|Protected|BlueprintEvent // @ game+0xe02710
	bool HasMatchStarted(); // Function Engine.GameModeBase.HasMatchStarted // Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x4d26b6c
	void HandleStartingNewPlayer(struct APlayerController* NewPlayer); // Function Engine.GameModeBase.HandleStartingNewPlayer // Native|Event|Public|BlueprintEvent // @ game+0x95c178
	int32 GetNumSpectators(); // Function Engine.GameModeBase.GetNumSpectators // Native|Public|BlueprintCallable // @ game+0x5af0164
	int32 GetNumPlayers(); // Function Engine.GameModeBase.GetNumPlayers // Native|Public|BlueprintCallable // @ game+0x5af0080
	struct UClass* GetDefaultPawnClassForController(struct AController* InController); // Function Engine.GameModeBase.GetDefaultPawnClassForController // Native|Event|Public|BlueprintEvent // @ game+0xd02c54
	struct AActor* FindPlayerStart(struct AController* Player, struct FString IncomingName); // Function Engine.GameModeBase.FindPlayerStart // Native|Event|Public|BlueprintEvent // @ game+0xc8ff74
	struct AActor* ChoosePlayerStart(struct AController* Player); // Function Engine.GameModeBase.ChoosePlayerStart // Native|Event|Public|BlueprintEvent // @ game+0xcea0c4
	void ChangeName(struct AController* Controller, struct FString NewName, bool bNameChange); // Function Engine.GameModeBase.ChangeName // Native|Public|BlueprintCallable // @ game+0x5ae57c0
	bool CanSpectate(struct APlayerController* Viewer, struct APlayerState* ViewTarget); // Function Engine.GameModeBase.CanSpectate // Native|Event|Public|BlueprintEvent // @ game+0x5ae5640
};

// Class Engine.GameMode
// Size: 0x4d0 (Inherited: 0x490)
struct AGameMode : AGameModeBase {
	struct FName MatchState; // 0x490(0x08)
	char bDelayedStart : 1; // 0x498(0x01)
	char pad_498_1 : 7; // 0x498(0x01)
	char pad_499[0x3]; // 0x499(0x03)
	int32 NumSpectators; // 0x49c(0x04)
	int32 NumPlayers; // 0x4a0(0x04)
	int32 NumBots; // 0x4a4(0x04)
	float MinRespawnDelay; // 0x4a8(0x04)
	int32 NumTravellingPlayers; // 0x4ac(0x04)
	struct UClass* EngineMessageClass; // 0x4b0(0x08)
	struct TArray<struct APlayerState*> InactivePlayerArray; // 0x4b8(0x10)
	float InactivePlayerStateLifeSpan; // 0x4c8(0x04)
	bool bHandleDedicatedServerReplays; // 0x4cc(0x01)
	char pad_4CD[0x3]; // 0x4cd(0x03)

	void StartMatch(); // Function Engine.GameMode.StartMatch // Native|Public|BlueprintCallable // @ game+0x4d60eb0
	void SetBandwidthLimit(float AsyncIOBandwidthLimit); // Function Engine.GameMode.SetBandwidthLimit // Exec|Native|Public // @ game+0x5afe7c0
	void Say(struct FString Msg); // Function Engine.GameMode.Say // Exec|Native|Public|BlueprintCallable // @ game+0x5afaac4
	void RestartGame(); // Function Engine.GameMode.RestartGame // Native|Public|BlueprintCallable // @ game+0x4d4464c
	bool ReadyToStartMatch(); // Function Engine.GameMode.ReadyToStartMatch // Native|Event|Protected|BlueprintEvent // @ game+0xd47da0
	bool ReadyToEndMatch(); // Function Engine.GameMode.ReadyToEndMatch // Native|Event|Protected|BlueprintEvent // @ game+0xb04d40
	void K2_OnSetMatchState(struct FName NewState); // Function Engine.GameMode.K2_OnSetMatchState // Event|Protected|BlueprintEvent // @ game+0x33e45c
	bool IsMatchInProgress(); // Function Engine.GameMode.IsMatchInProgress // Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5af269c
	bool HasMatchEnded(); // Function Engine.GameMode.HasMatchEnded // Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5af1be4
	struct FName GetMatchState(); // Function Engine.GameMode.GetMatchState // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5aef7b4
	void EndMatch(); // Function Engine.GameMode.EndMatch // Native|Public|BlueprintCallable // @ game+0x4d78464
	void AbortMatch(); // Function Engine.GameMode.AbortMatch // Native|Public|BlueprintCallable // @ game+0x4d44fe4
};

// Class Engine.DataTable
// Size: 0x90 (Inherited: 0x38)
struct UDataTable : UObject {
	struct UScriptStruct* RowStruct; // 0x38(0x08)
	char pad_40[0x50]; // 0x40(0x50)
};

// Class Engine.PlayerState
// Size: 0x480 (Inherited: 0x3f0)
struct APlayerState : AInfo {
	struct UClass* EngineMessageClass; // 0x3f0(0x08)
	bool Ping; // 0x3f8(0x01)
	char pad_3F9[0x3]; // 0x3f9(0x03)
	int32 PlayerId; // 0x3fc(0x04)
	char pad_400[0x4]; // 0x400(0x04)
	int32 StartTime; // 0x404(0x04)
	struct FString SavedNetworkAddress; // 0x408(0x10)
	char pad_418[0x10]; // 0x418(0x10)
	struct FString PlayerName; // 0x428(0x10)
	struct FUniqueNetIdRepl UniqueId; // 0x438(0x18)
	char pad_450[0x8]; // 0x450(0x08)
	char bIsSpectator : 1; // 0x458(0x01)
	char bOnlySpectator : 1; // 0x458(0x01)
	char bIsABot : 1; // 0x458(0x01)
	char pad_458_3 : 1; // 0x458(0x01)
	char bIsInactive : 1; // 0x458(0x01)
	char bFromPreviousLevel : 1; // 0x458(0x01)
	char pad_458_6 : 2; // 0x458(0x01)
	char pad_459[0x3]; // 0x459(0x03)
	float Score; // 0x45c(0x04)
	char pad_460[0x18]; // 0x460(0x18)
	bool bShouldUpdateReplicatedPing; // 0x478(0x01)
	char pad_479[0x7]; // 0x479(0x07)

	void ReceiveOverrideWith(struct APlayerState* OldPlayerState); // Function Engine.PlayerState.ReceiveOverrideWith // Event|Protected|BlueprintEvent // @ game+0x33e45c
	void ReceiveCopyProperties(struct APlayerState* NewPlayerState); // Function Engine.PlayerState.ReceiveCopyProperties // Event|Protected|BlueprintEvent // @ game+0x33e45c
	void OnRep_UniqueId(); // Function Engine.PlayerState.OnRep_UniqueId // Native|Public // @ game+0x769f14
	void OnRep_Score(); // Function Engine.PlayerState.OnRep_Score // Native|Public // @ game+0xe3d10c
	void OnRep_PlayerName(); // Function Engine.PlayerState.OnRep_PlayerName // Native|Public // @ game+0x815b50
	void OnRep_bIsInactive(); // Function Engine.PlayerState.OnRep_bIsInactive // Native|Public // @ game+0x815938
};

// Class Engine.GameUserSettings
// Size: 0x118 (Inherited: 0x38)
struct UGameUserSettings : UObject {
	bool bUseVSync; // 0x38(0x01)
	bool bUseDynamicResolution; // 0x39(0x01)
	char pad_3A[0x4e]; // 0x3a(0x4e)
	uint32 ResolutionSizeX; // 0x88(0x04)
	uint32 ResolutionSizeY; // 0x8c(0x04)
	uint32 LastUserConfirmedResolutionSizeX; // 0x90(0x04)
	uint32 LastUserConfirmedResolutionSizeY; // 0x94(0x04)
	int32 WindowPosX; // 0x98(0x04)
	int32 WindowPosY; // 0x9c(0x04)
	int32 FullscreenMode; // 0xa0(0x04)
	int32 LastConfirmedFullscreenMode; // 0xa4(0x04)
	int32 PreferredFullscreenMode; // 0xa8(0x04)
	uint32 Version; // 0xac(0x04)
	int32 AudioQualityLevel; // 0xb0(0x04)
	float FrameRateLimit; // 0xb4(0x04)
	char pad_B8[0x4]; // 0xb8(0x04)
	int32 DesiredScreenWidth; // 0xbc(0x04)
	bool bUseDesiredScreenHeight; // 0xc0(0x01)
	char pad_C1[0x3]; // 0xc1(0x03)
	int32 DesiredScreenHeight; // 0xc4(0x04)
	float LastRecommendedScreenWidth; // 0xc8(0x04)
	float LastRecommendedScreenHeight; // 0xcc(0x04)
	float LastCPUBenchmarkResult; // 0xd0(0x04)
	float LastGPUBenchmarkResult; // 0xd4(0x04)
	struct TArray<float> LastCPUBenchmarkSteps; // 0xd8(0x10)
	struct TArray<float> LastGPUBenchmarkSteps; // 0xe8(0x10)
	float LastGPUBenchmarkMultiplier; // 0xf8(0x04)
	bool bUseHDRDisplayOutput; // 0xfc(0x01)
	char pad_FD[0x3]; // 0xfd(0x03)
	int32 HDRDisplayOutputNits; // 0x100(0x04)
	enum class EGraphicsAPIType GraphicsAPI; // 0x104(0x01)
	char pad_105[0x3]; // 0x105(0x03)
	struct FMulticastDelegate OnGameUserSettingsUINeedsUpdate; // 0x108(0x10)

	void ValidateSettings(); // Function Engine.GameUserSettings.ValidateSettings // Native|Public|BlueprintCallable // @ game+0x548b34c
	bool SupportsHDRDisplayOutput(); // Function Engine.GameUserSettings.SupportsHDRDisplayOutput // Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b76aac
	void SetVSyncEnabled(bool bEnable); // Function Engine.GameUserSettings.SetVSyncEnabled // Final|Native|Public|BlueprintCallable // @ game+0x5b75b2c
	void SetVisualEffectQuality(int32 Value); // Function Engine.GameUserSettings.SetVisualEffectQuality // Final|Native|Public|BlueprintCallable // @ game+0x4d36434
	void SetViewDistanceQuality(int32 Value); // Function Engine.GameUserSettings.SetViewDistanceQuality // Final|Native|Public|BlueprintCallable // @ game+0x5b75ca8
	void SetToDefaults(); // Function Engine.GameUserSettings.SetToDefaults // Native|Public|BlueprintCallable // @ game+0x3c3640
	void SetTextureQuality(int32 Value); // Function Engine.GameUserSettings.SetTextureQuality // Final|Native|Public|BlueprintCallable // @ game+0x5b75aa0
	void SetShadowQuality(int32 Value); // Function Engine.GameUserSettings.SetShadowQuality // Final|Native|Public|BlueprintCallable // @ game+0x5b75850
	void SetScreenResolution(struct FIntPoint Resolution); // Function Engine.GameUserSettings.SetScreenResolution // Final|Native|Public|HasDefaults|BlueprintCallable // @ game+0x5b757c4
	void SetResolutionScaleValueEx(float NewScaleValue); // Function Engine.GameUserSettings.SetResolutionScaleValueEx // Final|Native|Public|BlueprintCallable // @ game+0x5b755b8
	void SetResolutionScaleValue(int32 NewScaleValue); // Function Engine.GameUserSettings.SetResolutionScaleValue // Final|Native|Public|BlueprintCallable // @ game+0x5b75524
	void SetResolutionScaleNormalized(float NewScaleNormalized); // Function Engine.GameUserSettings.SetResolutionScaleNormalized // Final|Native|Public|BlueprintCallable // @ game+0x5b75474
	void SetPostProcessingQuality(int32 Value); // Function Engine.GameUserSettings.SetPostProcessingQuality // Final|Native|Public|BlueprintCallable // @ game+0x5b753e8
	void SetOverallScalabilityLevel(int32 Value); // Function Engine.GameUserSettings.SetOverallScalabilityLevel // Native|Public|BlueprintCallable // @ game+0x5b75354
	void SetFullscreenMode(enum class EWindowMode InFullscreenMode); // Function Engine.GameUserSettings.SetFullscreenMode // Final|Native|Public|BlueprintCallable // @ game+0x5b750ec
	void SetFrameRateLimit(float NewLimit); // Function Engine.GameUserSettings.SetFrameRateLimit // Final|Native|Public|BlueprintCallable // @ game+0x5b75054
	void SetFoliageQuality(int32 Value); // Function Engine.GameUserSettings.SetFoliageQuality // Final|Native|Public|BlueprintCallable // @ game+0x5b74fb8
	void SetDynamicResolutionEnabled(bool bEnable); // Function Engine.GameUserSettings.SetDynamicResolutionEnabled // Final|Native|Public|BlueprintCallable // @ game+0x5b74f2c
	void SetBenchmarkFallbackValues(); // Function Engine.GameUserSettings.SetBenchmarkFallbackValues // Final|Native|Public|BlueprintCallable // @ game+0x5b74e7c
	void SetAudioQualityLevel(int32 QualityLevel); // Function Engine.GameUserSettings.SetAudioQualityLevel // Final|Native|Public|BlueprintCallable // @ game+0x5b74df0
	void SetAntiAliasingQuality(int32 Value); // Function Engine.GameUserSettings.SetAntiAliasingQuality // Final|Native|Public|BlueprintCallable // @ game+0x5b74d64
	void SaveSettings(); // Function Engine.GameUserSettings.SaveSettings // Native|Public|BlueprintCallable // @ game+0x5b6a8c8
	void RunHardwareBenchmark(int32 WorkScale, float CPUMultiplier, float GPUMultiplier); // Function Engine.GameUserSettings.RunHardwareBenchmark // Native|Public|BlueprintCallable // @ game+0x5b74bf4
	void RevertVideoMode(); // Function Engine.GameUserSettings.RevertVideoMode // Final|Native|Public|BlueprintCallable // @ game+0x5b74680
	void ResetToCurrentSettings(); // Function Engine.GameUserSettings.ResetToCurrentSettings // Native|Public|BlueprintCallable // @ game+0x4d6143c
	void LoadSettings(bool bForceReload); // Function Engine.GameUserSettings.LoadSettings // Native|Public|BlueprintCallable // @ game+0x5b6a440
	bool IsVSyncEnabled(); // Function Engine.GameUserSettings.IsVSyncEnabled // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b6f760
	bool IsVSyncDirty(); // Function Engine.GameUserSettings.IsVSyncDirty // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b6f73c
	bool IsScreenResolutionDirty(); // Function Engine.GameUserSettings.IsScreenResolutionDirty // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b6f6f8
	bool IsHDREnabled(); // Function Engine.GameUserSettings.IsHDREnabled // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b6f234
	bool IsFullscreenModeDirty(); // Function Engine.GameUserSettings.IsFullscreenModeDirty // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b6f210
	bool IsDynamicResolutionEnabled(); // Function Engine.GameUserSettings.IsDynamicResolutionEnabled // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b6f1fc
	bool IsDynamicResolutionDirty(); // Function Engine.GameUserSettings.IsDynamicResolutionDirty // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b6f1d8
	bool IsDirty(); // Function Engine.GameUserSettings.IsDirty // Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b67954
	bool IsConsole4K(); // Function Engine.GameUserSettings.IsConsole4K // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x2d3490
	int32 GetVisualEffectQuality(); // Function Engine.GameUserSettings.GetVisualEffectQuality // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b6ed00
	int32 GetViewDistanceQuality(); // Function Engine.GameUserSettings.GetViewDistanceQuality // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b6ecec
	int32 GetTextureQuality(); // Function Engine.GameUserSettings.GetTextureQuality // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b6e9a8
	int32 GetShadowQuality(); // Function Engine.GameUserSettings.GetShadowQuality // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b6e220
	struct FIntPoint GetScreenResolution(); // Function Engine.GameUserSettings.GetScreenResolution // Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5b6e1fc
	void GetResolutionScaleInformationEx(float CurrentScaleNormalized, float CurrentScaleValue, float MinScaleValue, float MaxScaleValue); // Function Engine.GameUserSettings.GetResolutionScaleInformationEx // Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const // @ game+0x5b6e01c
	void GetResolutionScaleInformation(float CurrentScaleNormalized, int32 CurrentScaleValue, int32 MinScaleValue, int32 MaxScaleValue); // Function Engine.GameUserSettings.GetResolutionScaleInformation // Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const // @ game+0x5b6de24
	float GetRecommendedResolutionScale(); // Function Engine.GameUserSettings.GetRecommendedResolutionScale // Native|Public|BlueprintCallable // @ game+0x5b6dd14
	enum class EWindowMode GetPreferredFullscreenMode(); // Function Engine.GameUserSettings.GetPreferredFullscreenMode // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b6d800
	int32 GetPostProcessingQuality(); // Function Engine.GameUserSettings.GetPostProcessingQuality // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b6d7ec
	int32 GetOverallScalabilityLevel(); // Function Engine.GameUserSettings.GetOverallScalabilityLevel // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b6d278
	struct FIntPoint GetLastConfirmedScreenResolution(); // Function Engine.GameUserSettings.GetLastConfirmedScreenResolution // Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5b6cd78
	enum class EWindowMode GetLastConfirmedFullscreenMode(); // Function Engine.GameUserSettings.GetLastConfirmedFullscreenMode // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b6cd54
	struct UGameUserSettings* GetGameUserSettings(); // Function Engine.GameUserSettings.GetGameUserSettings // Final|Native|Static|Public|BlueprintCallable // @ game+0x5b6c97c
	enum class EWindowMode GetFullscreenMode(); // Function Engine.GameUserSettings.GetFullscreenMode // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b6c87c
	float GetFrameRateLimit(); // Function Engine.GameUserSettings.GetFrameRateLimit // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b6c864
	int32 GetFoliageQuality(); // Function Engine.GameUserSettings.GetFoliageQuality // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b6c850
	struct FIntPoint GetDesktopResolution(); // Function Engine.GameUserSettings.GetDesktopResolution // Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5b6c2c0
	struct FIntPoint GetDefaultWindowPosition(); // Function Engine.GameUserSettings.GetDefaultWindowPosition // Final|Native|Static|Public|HasDefaults|BlueprintCallable // @ game+0x5b6c2a8
	enum class EWindowMode GetDefaultWindowMode(); // Function Engine.GameUserSettings.GetDefaultWindowMode // Final|Native|Static|Public|BlueprintCallable // @ game+0xc52118
	float GetDefaultResolutionScale(); // Function Engine.GameUserSettings.GetDefaultResolutionScale // Native|Public|BlueprintCallable // @ game+0x5b6c27c
	struct FIntPoint GetDefaultResolution(); // Function Engine.GameUserSettings.GetDefaultResolution // Final|Native|Static|Public|HasDefaults|BlueprintCallable // @ game+0x5b6c25c
	int32 GetCurrentHDRDisplayNits(); // Function Engine.GameUserSettings.GetCurrentHDRDisplayNits // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b6c040
	int32 GetAudioQualityLevel(); // Function Engine.GameUserSettings.GetAudioQualityLevel // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b6be14
	int32 GetAntiAliasingQuality(); // Function Engine.GameUserSettings.GetAntiAliasingQuality // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b6be00
	void EnableHDRDisplayOutput(bool bEnable, int32 DisplayNits); // Function Engine.GameUserSettings.EnableHDRDisplayOutput // Final|Native|Public|BlueprintCallable // @ game+0x5b6a7dc
	void ConfirmVideoMode(); // Function Engine.GameUserSettings.ConfirmVideoMode // Final|Native|Public|BlueprintCallable // @ game+0x5b67d98
	void ApplySettings(bool bCheckForCommandLineOverrides); // Function Engine.GameUserSettings.ApplySettings // Native|Public|BlueprintCallable // @ game+0x4d3922c
	void ApplyResolutionSettings(bool bCheckForCommandLineOverrides); // Function Engine.GameUserSettings.ApplyResolutionSettings // Final|Native|Public|BlueprintCallable // @ game+0x5b6426c
	void ApplyNonResolutionSettings(); // Function Engine.GameUserSettings.ApplyNonResolutionSettings // Native|Public|BlueprintCallable // @ game+0xa18960
	void ApplyHardwareBenchmarkResults(); // Function Engine.GameUserSettings.ApplyHardwareBenchmarkResults // Native|Public|BlueprintCallable // @ game+0x5b64254
};

// Class Engine.GameInstance
// Size: 0x1e0 (Inherited: 0x38)
struct UGameInstance : UObject {
	char pad_38[0x10]; // 0x38(0x10)
	struct UReplayCustomEventManager* ReplayCustomEventManager; // 0x48(0x08)
	char pad_50[0x90]; // 0x50(0x90)
	struct UOnlineSession* OnlineSession; // 0xe0(0x08)
	char pad_E8[0x18]; // 0xe8(0x18)
	struct FMulticastDelegate OnKillcamLoadingFinished; // 0x100(0x10)
	char pad_110[0xd0]; // 0x110(0xd0)

	void ReceiveShutdown(); // Function Engine.GameInstance.ReceiveShutdown // Event|Public|BlueprintEvent // @ game+0x33e45c
	void ReceiveInit(); // Function Engine.GameInstance.ReceiveInit // Event|Public|BlueprintEvent // @ game+0x33e45c
	void KillcamLoadingFinishedDelegate__DelegateSignature(); // DelegateFunction Engine.GameInstance.KillcamLoadingFinishedDelegate__DelegateSignature // MulticastDelegate|Public|Delegate // @ game+0x33e45c
	void HandleTravelError(enum class ETravelFailure FailureType); // Function Engine.GameInstance.HandleTravelError // Event|Public|BlueprintEvent // @ game+0x33e45c
	void HandleNetworkError(enum class ENetworkFailure FailureType, bool bIsServer); // Function Engine.GameInstance.HandleNetworkError // Event|Public|BlueprintEvent // @ game+0x33e45c
	void DebugRemovePlayer(int32 ControllerId); // Function Engine.GameInstance.DebugRemovePlayer // Exec|Native|Public // @ game+0x5b1a3f0
	void DebugCreatePlayer(int32 ControllerId); // Function Engine.GameInstance.DebugCreatePlayer // Exec|Native|Public // @ game+0x5b1a35c
};

// Class Engine.Subsystem
// Size: 0x40 (Inherited: 0x38)
struct USubsystem : UObject {
	char pad_38[0x8]; // 0x38(0x08)
};

// Class Engine.WorldSubsystem
// Size: 0x40 (Inherited: 0x40)
struct UWorldSubsystem : USubsystem {
};

// Class Engine.TriggerBase
// Size: 0x3f8 (Inherited: 0x3f0)
struct ATriggerBase : AActor {
	struct UShapeComponent* CollisionComponent; // 0x3f0(0x08)
};

// Class Engine.TriggerBox
// Size: 0x3f8 (Inherited: 0x3f8)
struct ATriggerBox : ATriggerBase {
};

// Class Engine.TargetPoint
// Size: 0x3f0 (Inherited: 0x3f0)
struct ATargetPoint : AActor {
};

// Class Engine.CapsuleComponent
// Size: 0xa00 (Inherited: 0x9f0)
struct UCapsuleComponent : UShapeComponent {
	float CapsuleHalfHeight; // 0x9f0(0x04)
	float CapsuleRadius; // 0x9f4(0x04)
	float CapsuleHeight; // 0x9f8(0x04)
	char pad_9FC[0x4]; // 0x9fc(0x04)

	void SetCapsuleSize(float InRadius, float InHalfHeight, bool bUpdateOverlaps); // Function Engine.CapsuleComponent.SetCapsuleSize // Final|Native|Public|BlueprintCallable // @ game+0x5b46be0
	void SetCapsuleRadius(float Radius, bool bUpdateOverlaps); // Function Engine.CapsuleComponent.SetCapsuleRadius // Final|Native|Public|BlueprintCallable // @ game+0x5b46af4
	void SetCapsuleHalfHeight(float HalfHeight, bool bUpdateOverlaps); // Function Engine.CapsuleComponent.SetCapsuleHalfHeight // Final|Native|Public|BlueprintCallable // @ game+0x5b46960
	void GetUnscaledCapsuleSize_WithoutHemisphere(float OutRadius, float OutHalfHeightWithoutHemisphere); // Function Engine.CapsuleComponent.GetUnscaledCapsuleSize_WithoutHemisphere // Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const // @ game+0x5b2bd68
	void GetUnscaledCapsuleSize(float OutRadius, float OutHalfHeight); // Function Engine.CapsuleComponent.GetUnscaledCapsuleSize // Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const // @ game+0x5b2bc60
	float GetUnscaledCapsuleRadius(); // Function Engine.CapsuleComponent.GetUnscaledCapsuleRadius // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b2bc48
	float GetUnscaledCapsuleHalfHeight_WithoutHemisphere(); // Function Engine.CapsuleComponent.GetUnscaledCapsuleHalfHeight_WithoutHemisphere // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b2bc24
	float GetUnscaledCapsuleHalfHeight(); // Function Engine.CapsuleComponent.GetUnscaledCapsuleHalfHeight // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b2bc0c
	float GetShapeScale(); // Function Engine.CapsuleComponent.GetShapeScale // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b29d58
	void GetScaledCapsuleSize_WithoutHemisphere(float OutRadius, float OutHalfHeightWithoutHemisphere); // Function Engine.CapsuleComponent.GetScaledCapsuleSize_WithoutHemisphere // Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const // @ game+0x5b29b24
	void GetScaledCapsuleSize(float OutRadius, float OutHalfHeight); // Function Engine.CapsuleComponent.GetScaledCapsuleSize // Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const // @ game+0x5b299f0
	float GetScaledCapsuleRadius(); // Function Engine.CapsuleComponent.GetScaledCapsuleRadius // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b299a4
	float GetScaledCapsuleHalfHeight_WithoutHemisphere(); // Function Engine.CapsuleComponent.GetScaledCapsuleHalfHeight_WithoutHemisphere // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b29950
	float GetScaledCapsuleHalfHeight(); // Function Engine.CapsuleComponent.GetScaledCapsuleHalfHeight // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b29904
};

// Class Engine.PhysicsVolume
// Size: 0x440 (Inherited: 0x428)
struct APhysicsVolume : AVolume {
	float TerminalVelocity; // 0x428(0x04)
	int32 Priority; // 0x42c(0x04)
	float FluidFriction; // 0x430(0x04)
	char bWaterVolume : 1; // 0x434(0x01)
	char bPhysicsOnContact : 1; // 0x434(0x01)
	char pad_434_2 : 6; // 0x434(0x01)
	char pad_435[0x3]; // 0x435(0x03)
	bool bIsIncorrectVolumeSize; // 0x438(0x01)
	char pad_439[0x7]; // 0x439(0x07)
};

// Class Engine.DebugCameraController
// Size: 0x7b0 (Inherited: 0x768)
struct ADebugCameraController : APlayerController {
	char bShowSelectedInfo : 1; // 0x768(0x01)
	char bIsFrozenRendering : 1; // 0x768(0x01)
	char pad_768_2 : 6; // 0x768(0x01)
	char pad_769[0x7]; // 0x769(0x07)
	struct UDrawFrustumComponent* DrawFrustum; // 0x770(0x08)
	char pad_778[0x20]; // 0x778(0x20)
	float SpeedScale; // 0x798(0x04)
	float InitialMaxSpeed; // 0x79c(0x04)
	float InitialAccel; // 0x7a0(0x04)
	float InitialDecel; // 0x7a4(0x04)
	char pad_7A8[0x8]; // 0x7a8(0x08)

	void ToggleDisplay(); // Function Engine.DebugCameraController.ToggleDisplay // Final|Native|Public|BlueprintCallable // @ game+0x5b05274
	void ShowDebugSelectedInfo(); // Function Engine.DebugCameraController.ShowDebugSelectedInfo // Exec|Native|Public // @ game+0x5b04444
	void SetPawnMovementSpeedScale(float NewSpeedScale); // Function Engine.DebugCameraController.SetPawnMovementSpeedScale // Final|Native|Public|BlueprintCallable // @ game+0x5b022cc
	void ReceiveOnDeactivate(struct APlayerController* RestoredPC); // Function Engine.DebugCameraController.ReceiveOnDeactivate // Event|Public|BlueprintEvent // @ game+0x33e45c
	void ReceiveOnActorSelected(struct AActor* NewSelectedActor, struct FVector SelectHitLocation, struct FVector SelectHitNormal, struct FHitResult Hit); // Function Engine.DebugCameraController.ReceiveOnActorSelected // Event|Protected|HasOutParms|HasDefaults|BlueprintEvent // @ game+0x33e45c
	void ReceiveOnActivate(struct APlayerController* OriginalPC); // Function Engine.DebugCameraController.ReceiveOnActivate // Event|Public|BlueprintEvent // @ game+0x33e45c
	struct AActor* GetSelectedActor(); // Function Engine.DebugCameraController.GetSelectedActor // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5af0e5c
};

// Class Engine.Channel
// Size: 0x78 (Inherited: 0x38)
struct UChannel : UObject {
	struct UNetConnection* Connection; // 0x38(0x08)
	char pad_40[0x38]; // 0x40(0x38)
};

// Class Engine.ActorChannel
// Size: 0x320 (Inherited: 0x78)
struct UActorChannel : UChannel {
	struct AActor* Actor; // 0x78(0x08)
	char pad_80[0x2a0]; // 0x80(0x2a0)
};

// Class Engine.DemoActorChannel
// Size: 0x340 (Inherited: 0x320)
struct UDemoActorChannel : UActorChannel {
	char pad_320[0x20]; // 0x320(0x20)
};

// Class Engine.NavigationObjectBase
// Size: 0x418 (Inherited: 0x3f0)
struct ANavigationObjectBase : AActor {
	char pad_3F0[0x8]; // 0x3f0(0x08)
	struct UCapsuleComponent* CapsuleComponent; // 0x3f8(0x08)
	struct UBillboardComponent* GoodSprite; // 0x400(0x08)
	struct UBillboardComponent* BadSprite; // 0x408(0x08)
	char bIsPIEPlayerStart : 1; // 0x410(0x01)
	char pad_410_1 : 7; // 0x410(0x01)
	char pad_411[0x7]; // 0x411(0x07)
};

// Class Engine.PlayerStart
// Size: 0x420 (Inherited: 0x418)
struct APlayerStart : ANavigationObjectBase {
	struct FName PlayerStartTag; // 0x418(0x08)
};

// Class Engine.CheatManager
// Size: 0x88 (Inherited: 0x38)
struct UCheatManager : UObject {
	struct ADebugCameraController* DebugCameraControllerRef; // 0x38(0x08)
	struct UClass* DebugCameraControllerClass; // 0x40(0x08)
	char pad_48[0x40]; // 0x48(0x40)

	void Walk(); // Function Engine.CheatManager.Walk // Exec|Native|Public|BlueprintCallable // @ game+0x5b6a8c8
	void ViewSelf(); // Function Engine.CheatManager.ViewSelf // Exec|Native|Public // @ game+0x5b78110
	void ViewPlayer(struct FString S); // Function Engine.CheatManager.ViewPlayer // Exec|Native|Public // @ game+0x5b7804c
	void ViewClass(struct UClass* DesiredClass); // Function Engine.CheatManager.ViewClass // Exec|Native|Public // @ game+0x4d02d00
	void ViewActor(struct FName ActorName); // Function Engine.CheatManager.ViewActor // Exec|Native|Public // @ game+0x5b77fb8
	void ToggleDebugCamera(); // Function Engine.CheatManager.ToggleDebugCamera // Exec|Native|Public // @ game+0xd5ba40
	void ToggleAILogging(); // Function Engine.CheatManager.ToggleAILogging // Exec|Native|Public // @ game+0x5b77880
	void TestCollisionDistance(); // Function Engine.CheatManager.TestCollisionDistance // Exec|Native|Public // @ game+0x5b76ad4
	void Teleport(); // Function Engine.CheatManager.Teleport // Exec|Native|Public|BlueprintCallable // @ game+0x4d80f54
	void Summon(struct FString ClassName); // Function Engine.CheatManager.Summon // Exec|Native|Public // @ game+0x5b769e8
	void StreamLevelOut(struct FName PackageName); // Function Engine.CheatManager.StreamLevelOut // Exec|Native|Public // @ game+0x5b7672c
	void StreamLevelIn(struct FName PackageName); // Function Engine.CheatManager.StreamLevelIn // Exec|Native|Public // @ game+0x5b76698
	void Slomo(float NewTimeDilation); // Function Engine.CheatManager.Slomo // Exec|Native|Public|BlueprintCallable // @ game+0x5b76100
	void SetWorldOrigin(); // Function Engine.CheatManager.SetWorldOrigin // Final|Exec|Native|Public // @ game+0x5b75d34
	void SetNavDrawDistance(float DrawDistance); // Function Engine.CheatManager.SetNavDrawDistance // Final|Exec|Native|Public // @ game+0x5b752bc
	void SetMouseSensitivityToDefault(); // Function Engine.CheatManager.SetMouseSensitivityToDefault // Final|Exec|Native|Public // @ game+0x5b752a8
	void ServerToggleAILogging(); // Function Engine.CheatManager.ServerToggleAILogging // Net|NetReliableNative|Event|Public|NetServer|NetValidate // @ game+0x5b74d18
	void ReceiveInitCheatManager(); // Function Engine.CheatManager.ReceiveInitCheatManager // Event|Public|BlueprintEvent // @ game+0x33e45c
	void ReceiveEndPlay(); // Function Engine.CheatManager.ReceiveEndPlay // Event|Public|BlueprintEvent // @ game+0x33e45c
	void RebuildNavigation(); // Function Engine.CheatManager.RebuildNavigation // Exec|Native|Public // @ game+0x4d52b14
	void PlayersOnly(); // Function Engine.CheatManager.PlayersOnly // Exec|Native|Public|BlueprintCallable // @ game+0x5b73f44
	void OnlyLoadLevel(struct FName PackageName); // Function Engine.CheatManager.OnlyLoadLevel // Exec|Native|Public // @ game+0x5b739c4
	void LogLoc(); // Function Engine.CheatManager.LogLoc // Exec|Native|Public // @ game+0x5b72840
	void InvertMouse(); // Function Engine.CheatManager.InvertMouse // Final|Exec|Native|Public // @ game+0x5b6f16c
	void God(); // Function Engine.CheatManager.God // Exec|Native|Public|BlueprintCallable // @ game+0x5b6ee08
	void Ghost(); // Function Engine.CheatManager.Ghost // Exec|Native|Public|BlueprintCallable // @ game+0x4d6143c
	void FreezeFrame(float Delay); // Function Engine.CheatManager.FreezeFrame // Exec|Native|Public|BlueprintCallable // @ game+0x5b6bc70
	void Fly(); // Function Engine.CheatManager.Fly // Exec|Native|Public|BlueprintCallable // @ game+0x4d81004
	void FlushLog(); // Function Engine.CheatManager.FlushLog // Exec|Native|Public // @ game+0x5b6bc58
	void EnableDebugCamera(); // Function Engine.CheatManager.EnableDebugCamera // Native|Protected|BlueprintCallable // @ game+0x5b6a6d0
	void DumpVoiceMutingState(); // Function Engine.CheatManager.DumpVoiceMutingState // Exec|Native|Public // @ game+0x5b6a638
	void DumpPartyState(); // Function Engine.CheatManager.DumpPartyState // Exec|Native|Public // @ game+0x5b6a620
	void DumpOnlineSessionState(); // Function Engine.CheatManager.DumpOnlineSessionState // Exec|Native|Public // @ game+0x5b6a608
	void DumpChatState(); // Function Engine.CheatManager.DumpChatState // Exec|Native|Public // @ game+0x5b6a5f0
	void DisableDebugCamera(); // Function Engine.CheatManager.DisableDebugCamera // Native|Protected|BlueprintCallable // @ game+0x5b6a428
	void DestroyTarget(); // Function Engine.CheatManager.DestroyTarget // Exec|Native|Public|BlueprintCallable // @ game+0x5b6a410
	void DestroyPawns(struct UClass* aClass); // Function Engine.CheatManager.DestroyPawns // Exec|Native|Public // @ game+0x53b136c
	void DestroyAllPawnsExceptTarget(); // Function Engine.CheatManager.DestroyAllPawnsExceptTarget // Exec|Native|Public // @ game+0xc01838
	void DestroyAll(struct UClass* aClass); // Function Engine.CheatManager.DestroyAll // Exec|Native|Public // @ game+0x5b6a37c
	void DebugCapsuleSweepSize(float HalfHeight, float Radius); // Function Engine.CheatManager.DebugCapsuleSweepSize // Exec|Native|Public // @ game+0x5b6a29c
	void DebugCapsuleSweepPawn(); // Function Engine.CheatManager.DebugCapsuleSweepPawn // Exec|Native|Public // @ game+0x5b6a284
	void DebugCapsuleSweepComplex(bool bTraceComplex); // Function Engine.CheatManager.DebugCapsuleSweepComplex // Exec|Native|Public // @ game+0x5b6a1ec
	void DebugCapsuleSweepClear(); // Function Engine.CheatManager.DebugCapsuleSweepClear // Exec|Native|Public // @ game+0x5b6a1d4
	void DebugCapsuleSweepChannel(enum class ECollisionChannel Channel); // Function Engine.CheatManager.DebugCapsuleSweepChannel // Exec|Native|Public // @ game+0x5b6a13c
	void DebugCapsuleSweepCapture(); // Function Engine.CheatManager.DebugCapsuleSweepCapture // Exec|Native|Public // @ game+0xc2bd74
	void DebugCapsuleSweep(); // Function Engine.CheatManager.DebugCapsuleSweep // Exec|Native|Public // @ game+0xe40de0
	void DamageTarget(float DamageAmount); // Function Engine.CheatManager.DamageTarget // Exec|Native|Public|BlueprintCallable // @ game+0x5b6a0a0
	void CheatScript(struct FString ScriptName); // Function Engine.CheatManager.CheatScript // Final|Exec|Native|Public // @ game+0x5b67a18
	void ChangeSize(float F); // Function Engine.CheatManager.ChangeSize // Exec|Native|Public|BlueprintCallable // @ game+0x5b6797c
	void BugItStringCreator(struct FVector ViewLocation, struct FRotator ViewRotation, struct FString GoString, struct FString LocString); // Function Engine.CheatManager.BugItStringCreator // Exec|Native|Public|HasOutParms|HasDefaults // @ game+0x5b66068
	void BugItGo(float X, float Y, float Z, float Pitch, float Yaw, float Roll); // Function Engine.CheatManager.BugItGo // Exec|Native|Public // @ game+0x5b65e4c
	void BugIt(struct FString ScreenShotDescription); // Function Engine.CheatManager.BugIt // Exec|Native|Public // @ game+0x5b65d88
};

// Class Engine.AnimNotifyState
// Size: 0x40 (Inherited: 0x38)
struct UAnimNotifyState : UObject {
	char pad_38[0x8]; // 0x38(0x08)

	bool Received_NotifyTick(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation, float FrameDeltaTime); // Function Engine.AnimNotifyState.Received_NotifyTick // Event|Public|BlueprintEvent|Const // @ game+0x33e45c
	bool Received_NotifyEnd(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Function Engine.AnimNotifyState.Received_NotifyEnd // Event|Public|BlueprintEvent|Const // @ game+0x33e45c
	bool Received_NotifyBegin(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation, float TotalDuration); // Function Engine.AnimNotifyState.Received_NotifyBegin // Event|Public|BlueprintEvent|Const // @ game+0x33e45c
	struct FString GetNotifyName(); // Function Engine.AnimNotifyState.GetNotifyName // Native|Event|Public|BlueprintEvent|Const // @ game+0x5aeff28
};

// Class Engine.LevelScriptActor
// Size: 0x3f8 (Inherited: 0x3f0)
struct ALevelScriptActor : AActor {
	char bInputEnabled : 1; // 0x3f0(0x01)
	char pad_3F0_1 : 7; // 0x3f0(0x01)
	char pad_3F1[0x7]; // 0x3f1(0x07)

	void WorldOriginLocationChanged(struct FIntVector OldOriginLocation, struct FIntVector NewOriginLocation); // Function Engine.LevelScriptActor.WorldOriginLocationChanged // Event|Public|HasDefaults|BlueprintEvent // @ game+0x33e45c
	void SetCinematicMode(bool bCinematicMode, bool bHidePlayer, bool bAffectsHUD, bool bAffectsMovement, bool bAffectsTurning); // Function Engine.LevelScriptActor.SetCinematicMode // Native|Public|BlueprintCallable // @ game+0x4edad4
	bool RemoteEvent(struct FName EventName); // Function Engine.LevelScriptActor.RemoteEvent // Native|Public|BlueprintCallable // @ game+0x5afa084
	void LevelReset(); // Function Engine.LevelScriptActor.LevelReset // BlueprintAuthorityOnly|Event|Public|BlueprintEvent // @ game+0x33e45c
};

// Class Engine.CameraComponent
// Size: 0xaa0 (Inherited: 0x4b0)
struct UCameraComponent : USceneComponent {
	float FieldOfView; // 0x4b0(0x04)
	float OrthoWidth; // 0x4b4(0x04)
	float OrthoNearClipPlane; // 0x4b8(0x04)
	float OrthoFarClipPlane; // 0x4bc(0x04)
	float AspectRatio; // 0x4c0(0x04)
	char bConstrainAspectRatio : 1; // 0x4c4(0x01)
	char bUseFieldOfViewForLOD : 1; // 0x4c4(0x01)
	char bLockToHmd : 1; // 0x4c4(0x01)
	char bUsePawnControlRotation : 1; // 0x4c4(0x01)
	char pad_4C4_4 : 4; // 0x4c4(0x01)
	char pad_4C5[0x3]; // 0x4c5(0x03)
	enum class ECameraProjectionMode ProjectionMode; // 0x4c8(0x01)
	char pad_4C9[0x3]; // 0x4c9(0x03)
	float PostProcessBlendWeight; // 0x4cc(0x04)
	struct FPostProcessSettings PostProcessSettings; // 0x4d0(0x570)
	char pad_A40[0x58]; // 0xa40(0x58)
	char bUseControllerViewRotation : 1; // 0xa98(0x01)
	char pad_A98_1 : 7; // 0xa98(0x01)
	char pad_A99[0x7]; // 0xa99(0x07)

	void SetUseFieldOfViewForLOD(bool bInUseFieldOfViewForLOD); // Function Engine.CameraComponent.SetUseFieldOfViewForLOD // Final|Native|Public|BlueprintCallable // @ game+0x5b522a8
	void SetProjectionMode(enum class ECameraProjectionMode InProjectionMode); // Function Engine.CameraComponent.SetProjectionMode // Final|Native|Public|BlueprintCallable // @ game+0x5b4eee8
	void SetPostProcessBlendWeight(float InPostProcessBlendWeight); // Function Engine.CameraComponent.SetPostProcessBlendWeight // Final|Native|Public|BlueprintCallable // @ game+0x5b4eb5c
	void SetOrthoWidth(float InOrthoWidth); // Function Engine.CameraComponent.SetOrthoWidth // Final|Native|Public|BlueprintCallable // @ game+0x5b4e0b4
	void SetOrthoNearClipPlane(float InOrthoNearClipPlane); // Function Engine.CameraComponent.SetOrthoNearClipPlane // Final|Native|Public|BlueprintCallable // @ game+0x5b4e01c
	void SetOrthoFarClipPlane(float InOrthoFarClipPlane); // Function Engine.CameraComponent.SetOrthoFarClipPlane // Final|Native|Public|BlueprintCallable // @ game+0x5b4bb34
	void SetFieldOfView(float InFieldOfView); // Function Engine.CameraComponent.SetFieldOfView // Final|Native|Public|BlueprintCallable // @ game+0x5b49f88
	void SetConstraintAspectRatio(bool bInConstrainAspectRatio); // Function Engine.CameraComponent.SetConstraintAspectRatio // Final|Native|Public|BlueprintCallable // @ game+0x5b47984
	void SetAspectRatio(float InAspectRatio); // Function Engine.CameraComponent.SetAspectRatio // Final|Native|Public|BlueprintCallable // @ game+0x5b45164
	void GetCameraView(float DeltaTime, struct FMinimalViewInfo DesiredView); // Function Engine.CameraComponent.GetCameraView // Native|Public|HasOutParms|BlueprintCallable // @ game+0x5b22c88
	void AddOrUpdateBlendable(TScriptInterface<struct UBlendableInterface> InBlendableObject, float InWeight); // Function Engine.CameraComponent.AddOrUpdateBlendable // Final|Native|Public|BlueprintCallable // @ game+0x5b0a62c
};

// Class Engine.Engine
// Size: 0xf40 (Inherited: 0x38)
struct UEngine : UObject {
	char pad_38[0x8]; // 0x38(0x08)
	struct UFont* TinyFont; // 0x40(0x08)
	struct FStringAssetReference TinyFontName; // 0x48(0x10)
	struct UFont* SmallFont; // 0x58(0x08)
	struct FStringAssetReference SmallFontName; // 0x60(0x10)
	struct UFont* MediumFont; // 0x70(0x08)
	struct FStringAssetReference MediumFontName; // 0x78(0x10)
	struct UFont* LargeFont; // 0x88(0x08)
	struct FStringAssetReference LargeFontName; // 0x90(0x10)
	struct UFont* SubtitleFont; // 0xa0(0x08)
	struct FStringAssetReference SubtitleFontName; // 0xa8(0x10)
	struct TArray<struct UFont*> AdditionalFonts; // 0xb8(0x10)
	float NetClientTicksPerSecond; // 0xc8(0x04)
	char pad_CC[0x4]; // 0xcc(0x04)
	struct FStringAssetReference DefaultBSPVertexTextureName; // 0xd0(0x10)
	struct FString LevelColorationUnlitMaterialName; // 0xe0(0x10)
	struct FStringClassReference AIControllerClassName; // 0xf0(0x10)
	struct UMaterial* VertexColorViewModeMaterial_GreenOnly; // 0x100(0x08)
	struct UTexture2D* PreIntegratedSkinBRDFTexture; // 0x108(0x08)
	struct UMaterialInstanceDynamic* ConstraintLimitMaterialZ; // 0x110(0x08)
	struct UMaterial* ShadedLevelColorationUnlitMaterial; // 0x118(0x08)
	struct FStringAssetReference LightMapDensityTextureName; // 0x120(0x10)
	struct FLinearColor LightingOnlyBrightness; // 0x130(0x10)
	struct FLinearColor LightingOnlySpecular; // 0x140(0x10)
	struct FStringClassReference LevelScriptActorClassName; // 0x150(0x10)
	struct TArray<struct FLinearColor> LightComplexityColors; // 0x160(0x10)
	struct FString VertexColorViewModeMaterialName_BlueOnly; // 0x170(0x10)
	struct TArray<struct FLinearColor> HLODColorationColors; // 0x180(0x10)
	struct UAssetManager* AssetManager; // 0x190(0x08)
	float CameraTranslationThreshold; // 0x198(0x04)
	char pad_19C[0x4]; // 0x19c(0x04)
	struct FStringClassReference LocalPlayerClassName; // 0x1a0(0x10)
	struct UMaterial* PreviewShadowsIndicatorMaterial; // 0x1b0(0x08)
	enum class ETransitionType TransitionType; // 0x1b8(0x01)
	char pad_1B9[0x3]; // 0x1b9(0x03)
	char bSubtitlesEnabled : 1; // 0x1bc(0x01)
	char pad_1BC_1 : 7; // 0x1bc(0x01)
	char pad_1BD[0x3]; // 0x1bd(0x03)
	int32 GameCycles; // 0x1c0(0x04)
	char pad_1C4[0x4]; // 0x1c4(0x04)
	struct TArray<struct FString> AdditionalFontNames; // 0x1c8(0x10)
	struct FString LightingTexelDensityName; // 0x1d8(0x10)
	struct UTexture2D* DefaultBSPVertexTexture; // 0x1e8(0x08)
	struct FStringAssetReference InvalidLightmapSettingsMaterialName; // 0x1f0(0x10)
	int32 MaxParticleResizeWarn; // 0x200(0x04)
	struct FColor C_WireBackground; // 0x204(0x04)
	struct FColor C_ScaleBoxHi; // 0x208(0x04)
	char pad_20C[0x4]; // 0x20c(0x04)
	struct UClass* GameViewportClientClass; // 0x210(0x08)
	struct UMaterial* DebugMeshMaterial; // 0x218(0x08)
	float NearClipPlane; // 0x220(0x04)
	char pad_224[0x4]; // 0x224(0x04)
	struct UMaterial* LevelColorationLitMaterial; // 0x228(0x08)
	struct UClass* WorldSettingsClass; // 0x230(0x08)
	struct FColor C_NonSolidWire; // 0x238(0x04)
	int32 ClientCycles; // 0x23c(0x04)
	struct FStringAssetReference RemoveSurfaceMaterialName; // 0x240(0x10)
	struct FStringAssetReference DefaultTextureName; // 0x250(0x10)
	float DisplayGamma; // 0x260(0x04)
	char pad_264[0x4]; // 0x264(0x04)
	struct FString LevelColorationLitMaterialName; // 0x268(0x10)
	struct FColor C_AddWire; // 0x278(0x04)
	char bRenderLightMapDensityGrayscale : 1; // 0x27c(0x01)
	char pad_27C_1 : 7; // 0x27c(0x01)
	char pad_27D[0x3]; // 0x27d(0x03)
	struct UMaterial* WireframeMaterial; // 0x280(0x08)
	struct UMaterialInstanceDynamic* ConstraintLimitMaterialYAxis; // 0x288(0x08)
	struct UMaterialInstanceDynamic* ConstraintLimitMaterialX; // 0x290(0x08)
	struct UClass* LocalPlayerClass; // 0x298(0x08)
	struct FStringClassReference PhysicsCollisionHandlerClassName; // 0x2a0(0x10)
	struct FColor C_SubtractWire; // 0x2b0(0x04)
	char pad_2B4[0x4]; // 0x2b4(0x04)
	struct FStringClassReference WorldSettingsClassName; // 0x2b8(0x10)
	struct TArray<struct FStatColorMapping> StatColorMappings; // 0x2c8(0x10)
	struct UMaterial* VertexColorViewModeMaterial_AlphaAsColor; // 0x2d8(0x08)
	int32 MaximumLoopIterationCount; // 0x2e0(0x04)
	struct FLinearColor LightMapDensitySelectedColor; // 0x2e4(0x10)
	char pad_2F4[0x4]; // 0x2f4(0x04)
	struct FString VertexColorViewModeMaterialName_RedOnly; // 0x2f8(0x10)
	struct FString WireframeMaterialName; // 0x308(0x10)
	struct FColor C_VolumeCollision; // 0x318(0x04)
	char pad_31C[0x4]; // 0x31c(0x04)
	struct FStringClassReference ConsoleClassName; // 0x320(0x10)
	struct TArray<struct FDropNoteInfo> PendingDroppedNotes; // 0x330(0x10)
	struct UMaterial* ShadedLevelColorationLitMaterial; // 0x340(0x08)
	char pad_348[0x50]; // 0x348(0x50)
	struct UTexture2D* LightMapDensityTexture; // 0x398(0x08)
	float MaxOcclusionPixelsFraction; // 0x3a0(0x04)
	char pad_3A4[0x4]; // 0x3a4(0x04)
	struct UClass* ConsoleClass; // 0x3a8(0x08)
	struct FStringAssetReference HighFrequencyNoiseTextureName; // 0x3b0(0x10)
	struct TArray<struct FLinearColor> StationaryLightOverlapColors; // 0x3c0(0x10)
	float PrimitiveProbablyVisibleTime; // 0x3d0(0x04)
	char pad_3D4[0x4]; // 0x3d4(0x04)
	struct TArray<struct FClassRedirect> ActiveClassRedirects; // 0x3d8(0x10)
	char bCanBlueprintsTickByDefault : 1; // 0x3e8(0x01)
	char bOptimizeAnimBlueprintMemberVariableAccess : 1; // 0x3e8(0x01)
	char bAllowMultiThreadedAnimationUpdate : 1; // 0x3e8(0x01)
	char bEnableEditorPSysRealtimeLOD : 1; // 0x3e8(0x01)
	char pad_3E8_4 : 1; // 0x3e8(0x01)
	char bSmoothFrameRate : 1; // 0x3e8(0x01)
	char bUseFixedFrameRate : 1; // 0x3e8(0x01)
	char pad_3E8_7 : 1; // 0x3e8(0x01)
	char pad_3E9[0x7]; // 0x3e9(0x07)
	struct TArray<struct FString> DeferredCommands; // 0x3f0(0x10)
	char pad_400[0x18]; // 0x400(0x18)
	struct FStringAssetReference DefaultBokehTextureName; // 0x418(0x10)
	struct FStringClassReference AssetManagerClassName; // 0x428(0x10)
	char bAllowMatureLanguage : 1; // 0x438(0x01)
	char pad_438_1 : 7; // 0x438(0x01)
	char pad_439[0x3]; // 0x439(0x03)
	float CameraRotationThreshold; // 0x43c(0x04)
	struct UClass* LevelScriptActorClass; // 0x440(0x08)
	struct FColor C_WorldBox; // 0x448(0x04)
	char pad_44C[0x4]; // 0x44c(0x04)
	struct TArray<struct FGameNameRedirect> ActiveGameNameRedirects; // 0x450(0x10)
	struct UTexture2D* DefaultBokehTexture; // 0x460(0x08)
	struct UObject* GameSingleton; // 0x468(0x08)
	struct UTexture2D* DefaultTexture; // 0x470(0x08)
	struct UMaterial* LevelColorationUnlitMaterial; // 0x478(0x08)
	float FixedFrameRate; // 0x480(0x04)
	char pad_484[0x4]; // 0x484(0x04)
	struct FString VertexColorViewModeMaterialName_GreenOnly; // 0x488(0x10)
	float MaxPixelShaderAdditiveComplexityCount; // 0x498(0x04)
	char pad_49C[0x4]; // 0x49c(0x04)
	struct FStringAssetReference DefaultBloomKernelTextureName; // 0x4a0(0x10)
	struct UClass* GameUserSettingsClass; // 0x4b0(0x08)
	struct UMaterialInstanceDynamic* ConstraintLimitMaterialY; // 0x4b8(0x08)
	int32 TickCycles; // 0x4c0(0x04)
	char pad_4C4[0x4]; // 0x4c4(0x04)
	struct FStringAssetReference DefaultDiffuseTextureName; // 0x4c8(0x10)
	struct TArray<struct FStructRedirect> ActiveStructRedirects; // 0x4d8(0x10)
	struct FStringClassReference NavigationSystemClassName; // 0x4e8(0x10)
	struct FStringAssetReference PreIntegratedSkinBRDFTextureName; // 0x4f8(0x10)
	struct FColor C_Volume; // 0x508(0x04)
	float MeshLODRange; // 0x50c(0x04)
	struct UTexture2D* DefaultBloomKernelTexture; // 0x510(0x08)
	struct FString TransitionGameMode; // 0x518(0x10)
	struct TArray<struct FLinearColor> QuadComplexityColors; // 0x528(0x10)
	struct FStringAssetReference ArrowMaterialName; // 0x538(0x10)
	struct FString ShadedLevelColorationUnlitMaterialName; // 0x548(0x10)
	struct TArray<struct FLinearColor> ShaderComplexityColors; // 0x558(0x10)
	struct FString VertexColorViewModeMaterialName_ColorOnly; // 0x568(0x10)
	struct FStringClassReference GameSingletonClassName; // 0x578(0x10)
	struct UGameUserSettings* GameUserSettings; // 0x588(0x08)
	struct UTexture* WeightMapPlaceholderTexture; // 0x590(0x08)
	char bSubtitlesForcedOff : 1; // 0x598(0x01)
	char pad_598_1 : 7; // 0x598(0x01)
	char pad_599[0x3]; // 0x599(0x03)
	float MaxLightMapDensity; // 0x59c(0x04)
	struct FStringAssetReference PreviewShadowsIndicatorMaterialName; // 0x5a0(0x10)
	struct UClass* NavigationSystemClass; // 0x5b0(0x08)
	struct TArray<struct FLinearColor> StreamingAccuracyColors; // 0x5b8(0x10)
	struct FRigidBodyErrorCorrection PhysicErrorCorrection; // 0x5c8(0x1c)
	char pad_5E4[0x4]; // 0x5e4(0x04)
	struct UMaterialInstanceDynamic* ConstraintLimitMaterialPrismatic; // 0x5e8(0x08)
	struct FColor C_SemiSolidWire; // 0x5f0(0x04)
	char pad_5F4[0x4]; // 0x5f4(0x04)
	struct FString VertexColorViewModeMaterialName_AlphaAsColor; // 0x5f8(0x10)
	struct FColor C_BrushShape; // 0x608(0x04)
	char pad_60C[0x4]; // 0x60c(0x04)
	struct UGameViewportClient* GameViewport; // 0x610(0x08)
	struct FStringAssetReference MiniFontTextureName; // 0x618(0x10)
	float MinDesiredFrameRate; // 0x628(0x04)
	float StreamingDistanceFactor; // 0x62c(0x04)
	struct FStringClassReference GameUserSettingsClassName; // 0x630(0x10)
	struct TArray<struct FPluginRedirect> ActivePluginRedirects; // 0x640(0x10)
	struct UMaterial* VertexColorMaterial; // 0x650(0x08)
	struct FLinearColor LightMapDensityVertexMappedColor; // 0x658(0x10)
	struct FStringClassReference GameViewportClientClassName; // 0x668(0x10)
	struct UClass* PhysicsCollisionHandlerClass; // 0x678(0x08)
	struct UMaterial* VertexColorViewModeMaterial_ColorOnly; // 0x680(0x08)
	float MaxES2PixelShaderAdditiveComplexityCount; // 0x688(0x04)
	char pad_68C[0x4]; // 0x68c(0x04)
	struct UMaterialInstanceDynamic* ConstraintLimitMaterialZAxis; // 0x690(0x08)
	struct FColor C_BrushWire; // 0x698(0x04)
	char pad_69C[0x4]; // 0x69c(0x04)
	struct UMaterial* InvalidLightmapSettingsMaterial; // 0x6a0(0x08)
	struct UTexture2D* HighFrequencyNoiseTexture; // 0x6a8(0x08)
	struct FFloatRange SmoothedFrameRateRange; // 0x6b0(0x10)
	struct FLinearColor DefaultSelectedMaterialColor; // 0x6c0(0x10)
	struct FLinearColor SelectedMaterialColor; // 0x6d0(0x10)
	struct FLinearColor SelectionOutlineColor; // 0x6e0(0x10)
	struct FLinearColor SubduedSelectionOutlineColor; // 0x6f0(0x10)
	struct FLinearColor SelectedMaterialColorOverride; // 0x700(0x10)
	bool bIsOverridingSelectedColor; // 0x710(0x01)
	char pad_711[0x3]; // 0x711(0x03)
	char bEnableOnScreenDebugMessages : 1; // 0x714(0x01)
	char bEnableOnScreenDebugMessagesDisplay : 1; // 0x714(0x01)
	char bSuppressMapWarnings : 1; // 0x714(0x01)
	char bDisableAILogging : 1; // 0x714(0x01)
	char pad_714_4 : 4; // 0x714(0x01)
	char pad_715[0x3]; // 0x715(0x03)
	uint32 bEnableVisualLogRecordingOnStart; // 0x718(0x04)
	struct FBox StreamingLevelBounds; // 0x71c(0x1c)
	char pad_738[0x4]; // 0x738(0x04)
	int32 ScreenSaverInhibitorSemaphore; // 0x73c(0x04)
	char bLockReadOnlyLevels : 1; // 0x740(0x01)
	char pad_740_1 : 7; // 0x740(0x01)
	char pad_741[0x7]; // 0x741(0x07)
	struct FString ParticleEventManagerClassPath; // 0x748(0x10)
	char pad_758[0x28]; // 0x758(0x28)
	float SelectionHighlightIntensity; // 0x780(0x04)
	float SelectionMeshSectionHighlightIntensity; // 0x784(0x04)
	float BSPSelectionHighlightIntensity; // 0x788(0x04)
	float HoverHighlightIntensity; // 0x78c(0x04)
	float SelectionHighlightIntensityBillboards; // 0x790(0x04)
	float PrimitiveBaseIntensity; // 0x794(0x04)
	float PrimitiveSelectedIntensity; // 0x798(0x04)
	float PrimitiveHoverIntensity; // 0x79c(0x04)
	char pad_7A0[0x290]; // 0x7a0(0x290)
	float RenderLightMapDensityColorScale; // 0xa30(0x04)
	char bPauseOnLossOfFocus : 1; // 0xa34(0x01)
	char pad_A34_1 : 7; // 0xa34(0x01)
	char pad_A35[0x3]; // 0xa35(0x03)
	int32 MaxParticleResize; // 0xa38(0x04)
	char pad_A3C[0x4]; // 0xa3c(0x04)
	struct UMaterial* LightingTexelDensityMaterial; // 0xa40(0x08)
	struct FStringAssetReference DebugMeshMaterialName; // 0xa48(0x10)
	char bHardwareSurveyEnabled : 1; // 0xa58(0x01)
	char pad_A58_1 : 7; // 0xa58(0x01)
	char pad_A59[0x7]; // 0xa59(0x07)
	struct UMaterial* RemoveSurfaceMaterial; // 0xa60(0x08)
	struct FStringAssetReference DefaultPhysMaterialName; // 0xa68(0x10)
	struct FColor C_BSPCollision; // 0xa78(0x04)
	float MinLightMapDensity; // 0xa7c(0x04)
	float RenderLightMapDensityGrayscaleScale; // 0xa80(0x04)
	char pad_A84[0x1dc]; // 0xa84(0x1dc)
	struct TArray<struct FNetDriverDefinition> NetDriverDefinitions; // 0xc60(0x10)
	struct TArray<struct FString> ServerActors; // 0xc70(0x10)
	struct TArray<struct FString> RuntimeServerActors; // 0xc80(0x10)
	char bStartedLoadMapMovie : 1; // 0xc90(0x01)
	char pad_C90_1 : 7; // 0xc90(0x01)
	char pad_C91[0x7]; // 0xc91(0x07)
	struct FString TransitionDescription; // 0xc98(0x10)
	struct UMaterial* ConstraintLimitMaterial; // 0xca8(0x08)
	struct FStringClassReference DefaultBlueprintBaseClassName; // 0xcb0(0x10)
	struct UPhysicalMaterial* DefaultPhysMaterial; // 0xcc0(0x08)
	struct FColor C_OrthoBackground; // 0xcc8(0x04)
	char pad_CCC[0x4]; // 0xccc(0x04)
	struct UMaterial* VertexColorViewModeMaterial_BlueOnly; // 0xcd0(0x08)
	struct FString ShadedLevelColorationLitMaterialName; // 0xcd8(0x10)
	struct FString VertexColorMaterialName; // 0xce8(0x10)
	struct UClass* AvoidanceManagerClass; // 0xcf8(0x08)
	struct FStringClassReference AvoidanceManagerClassName; // 0xd00(0x10)
	char pad_D10[0x8]; // 0xd10(0x08)
	struct UMaterialInstanceDynamic* ConstraintLimitMaterialXAxis; // 0xd18(0x08)
	struct FStringAssetReference WeightMapPlaceholderTextureName; // 0xd20(0x10)
	struct UTexture2D* MiniFontTexture; // 0xd30(0x08)
	struct TArray<struct FLinearColor> LODColorationColors; // 0xd38(0x10)
	float IdealLightMapDensity; // 0xd48(0x04)
	char pad_D4C[0x4]; // 0xd4c(0x04)
	struct UMaterial* ArrowMaterial; // 0xd50(0x08)
	char bCheckForMultiplePawnsSpawnedInAFrame : 1; // 0xd58(0x01)
	char pad_D58_1 : 7; // 0xd58(0x01)
	char pad_D59[0x3]; // 0xd59(0x03)
	int32 NumPawnsAllowedToBeSpawnedInAFrame; // 0xd5c(0x04)
	char bShouldGenerateLowQualityLightmaps : 1; // 0xd60(0x01)
	char pad_D60_1 : 7; // 0xd60(0x01)
	char pad_D61[0x7]; // 0xd61(0x07)
	struct FString PlayOnConsoleSaveDir; // 0xd68(0x10)
	struct UMaterial* VertexColorViewModeMaterial_RedOnly; // 0xd78(0x08)
	struct UTexture* DefaultDiffuseTexture; // 0xd80(0x08)
	char pad_D88[0x18]; // 0xd88(0x18)
	int32 NextWorldContextHandle; // 0xda0(0x04)
	char pad_DA4[0x19c]; // 0xda4(0x19c)
};

// Class Engine.ScriptViewportClient
// Size: 0x48 (Inherited: 0x38)
struct UScriptViewportClient : UObject {
	char pad_38[0x10]; // 0x38(0x10)
};

// Class Engine.GameViewportClient
// Size: 0x680 (Inherited: 0x48)
struct UGameViewportClient : UScriptViewportClient {
	char pad_48[0xe8]; // 0x48(0xe8)
	struct TArray<struct FDebugDisplayProperty> DebugProperties; // 0x130(0x10)
	char pad_140[0x3d0]; // 0x140(0x3d0)
	struct UGameInstance* GameInstance; // 0x510(0x08)
	char pad_518[0x108]; // 0x518(0x108)
	struct UConsole* ViewportConsole; // 0x620(0x08)
	char pad_628[0x58]; // 0x628(0x58)

	void SSSwapControllers(); // Function Engine.GameViewportClient.SSSwapControllers // Exec|Native|Public // @ game+0x4d52e3c
	void ShowTitleSafeArea(); // Function Engine.GameViewportClient.ShowTitleSafeArea // Exec|Native|Public // @ game+0x5b54f14
	void SetConsoleTarget(int32 PlayerIndex); // Function Engine.GameViewportClient.SetConsoleTarget // Exec|Native|Public // @ game+0x5b47770
};

// Class Engine.Console
// Size: 0x140 (Inherited: 0x38)
struct UConsole : UObject {
	char pad_38[0x10]; // 0x38(0x10)
	struct ULocalPlayer* ConsoleTargetPlayer; // 0x48(0x08)
	struct UTexture2D* DefaultTexture_Black; // 0x50(0x08)
	struct UTexture2D* DefaultTexture_White; // 0x58(0x08)
	char pad_60[0x18]; // 0x60(0x18)
	struct TArray<struct FString> HistoryBuffer; // 0x78(0x10)
	char pad_88[0xb8]; // 0x88(0xb8)
};

// Class Engine.DestructibleComponent
// Size: 0xd40 (Inherited: 0xc80)
struct UDestructibleComponent : USkinnedMeshComponent {
	char bFractureEffectOverride : 1; // 0xc78(0x01)
	struct TArray<struct FFractureEffect> FractureEffects; // 0xc80(0x10)
	bool bEnableHardSleeping; // 0xc90(0x01)
	char pad_C91_1 : 7; // 0xc91(0x01)
	char pad_C92[0x2]; // 0xc92(0x02)
	float LargeChunkThreshold; // 0xc94(0x04)
	char pad_C98[0x10]; // 0xc98(0x10)
	struct FMulticastDelegate OnComponentFracture; // 0xca8(0x10)
	char pad_CB8[0x88]; // 0xcb8(0x88)

	void SetDestructibleMesh(struct UDestructibleMesh* NewMesh); // Function Engine.DestructibleComponent.SetDestructibleMesh // Final|Native|Public|BlueprintCallable // @ game+0x5b488d8
	struct UDestructibleMesh* GetDestructibleMesh(); // Function Engine.DestructibleComponent.GetDestructibleMesh // Final|Native|Public|BlueprintCallable // @ game+0x5b23e58
	void ApplyRadiusDamage(float BaseDamage, struct FVector HurtOrigin, float DamageRadius, float ImpulseStrength, bool bFullDamage); // Function Engine.DestructibleComponent.ApplyRadiusDamage // Native|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b0cb08
	void ApplyDamage(float DamageAmount, struct FVector HitLocation, struct FVector ImpulseDir, float ImpulseStrength); // Function Engine.DestructibleComponent.ApplyDamage // Native|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b0b90c
};

// Class Engine.GameEngine
// Size: 0xfa0 (Inherited: 0xf40)
struct UGameEngine : UEngine {
	float MaxDeltaTime; // 0xf38(0x04)
	float ServerFlushLogInterval; // 0xf3c(0x04)
	struct UGameInstance* GameInstance; // 0xf40(0x08)
	char pad_F50[0x38]; // 0xf50(0x38)
	struct TArray<struct UWorld*> PendingDestroyWorldList; // 0xf88(0x10)
	char pad_F98[0x8]; // 0xf98(0x08)
};

// Class Engine.Player
// Size: 0x58 (Inherited: 0x38)
struct UPlayer : UObject {
	char pad_38[0x10]; // 0x38(0x10)
	int32 CurrentNetSpeed; // 0x48(0x04)
	int32 ConfiguredInternetSpeed; // 0x4c(0x04)
	int32 ConfiguredLanSpeed; // 0x50(0x04)
	char pad_54[0x4]; // 0x54(0x04)
};

// Class Engine.NetConnection
// Size: 0x65848 (Inherited: 0x58)
struct UNetConnection : UPlayer {
	struct TArray<struct UChildConnection*> Children; // 0x58(0x10)
	struct UNetDriver* Driver; // 0x68(0x08)
	struct UClass* PackageMapClass; // 0x70(0x08)
	struct UPackageMap* PackageMap; // 0x78(0x08)
	struct TArray<struct UChannel*> OpenChannels; // 0x80(0x10)
	struct TArray<struct AActor*> SentTemporaries; // 0x90(0x10)
	struct AActor* ViewTarget; // 0xa0(0x08)
	struct AActor* OwningActor; // 0xa8(0x08)
	int32 MaxPacket; // 0xb0(0x04)
	char InternalAck : 1; // 0xb4(0x01)
	char pad_B4_1 : 1; // 0xb4(0x01)
	char IgnoreInvalidSubObjects : 1; // 0xb4(0x01)
	char pad_B4_3 : 5; // 0xb4(0x01)
	char pad_B5[0x8b]; // 0xb5(0x8b)
	struct TArray<struct UChannel*> UnackedChannels; // 0x140(0x10)
	char pad_150[0x28]; // 0x150(0x28)
	struct FUniqueNetIdRepl PlayerId; // 0x178(0x18)
	char pad_190[0x68]; // 0x190(0x68)
	double LastReceiveTime; // 0x1f8(0x08)
	char pad_200[0x65538]; // 0x200(0x65538)
	struct TArray<struct UChannel*> ChannelsToTick; // 0x65738(0x10)
	char pad_65748[0x100]; // 0x65748(0x100)
};

// Class Engine.ForceFeedbackEffect
// Size: 0x50 (Inherited: 0x38)
struct UForceFeedbackEffect : UObject {
	struct TArray<struct FForceFeedbackChannelDetails> ChannelDetails; // 0x38(0x10)
	float Duration; // 0x48(0x04)
	char pad_4C[0x4]; // 0x4c(0x04)
};

// Class Engine.GameSession
// Size: 0x408 (Inherited: 0x3f0)
struct AGameSession : AInfo {
	int32 MaxSpectators; // 0x3f0(0x04)
	int32 MaxPlayers; // 0x3f4(0x04)
	int32 MaxPartySize; // 0x3f8(0x04)
	bool MaxSplitscreensPerConnection; // 0x3fc(0x01)
	bool bRequiresPushToTalk; // 0x3fd(0x01)
	char pad_3FE[0x2]; // 0x3fe(0x02)
	struct FName SessionName; // 0x400(0x08)
};

// Class Engine.InstancedStaticMeshComponent
// Size: 0xc60 (Inherited: 0xb80)
struct UInstancedStaticMeshComponent : UStaticMeshComponent {
	struct TArray<struct FInstancedStaticMeshInstanceData> PerInstanceSMData; // 0xb78(0x10)
	int32 InstancingRandomSeed; // 0xb88(0x04)
	int32 InstanceStartCullDistance; // 0xb8c(0x04)
	int32 InstanceEndCullDistance; // 0xb90(0x04)
	struct TArray<int32> InstanceReorderTable; // 0xb98(0x10)
	struct TArray<int32> RemovedInstances; // 0xba8(0x10)
	char pad_BBC[0x74]; // 0xbbc(0x74)
	struct UPhysicsSerializer* PhysicsSerializer; // 0xc30(0x08)
	bool bUseWorldTransformHashAsRandom; // 0xc38(0x01)
	char pad_C39[0x3]; // 0xc39(0x03)
	int32 NumPendingLightmaps; // 0xc3c(0x04)
	struct TArray<struct FInstancedStaticMeshMappingInfo> CachedMappings; // 0xc40(0x10)
	char pad_C50[0x10]; // 0xc50(0x10)

	bool UpdateInstanceTransform(int32 InstanceIndex, struct FTransform NewInstanceTransform, bool bWorldSpace, bool bMarkRenderStateDirty, bool bTeleport); // Function Engine.InstancedStaticMeshComponent.UpdateInstanceTransform // Native|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b5befc
	bool SetInstanceCustomData(int32 InstanceIndex, struct FVector4 InPerInstanceCustomData); // Function Engine.InstancedStaticMeshComponent.SetInstanceCustomData // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b4b6dc
	void SetCullDistances(int32 StartCullDistance, int32 EndCullDistance); // Function Engine.InstancedStaticMeshComponent.SetCullDistances // Final|Native|Public|BlueprintCallable // @ game+0x5b48320
	bool RemoveInstance(int32 InstanceIndex); // Function Engine.InstancedStaticMeshComponent.RemoveInstance // Native|Public|BlueprintCallable // @ game+0x5b41cd0
	bool GetInstanceTransform(int32 InstanceIndex, struct FTransform OutInstanceTransform, bool bWorldSpace); // Function Engine.InstancedStaticMeshComponent.GetInstanceTransform // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5b258c8
	struct TArray<int32> GetInstancesOverlappingSphere(struct FVector Center, float Radius, bool bSphereInWorldSpace); // Function Engine.InstancedStaticMeshComponent.GetInstancesOverlappingSphere // Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5b26038
	struct TArray<int32> GetInstancesOverlappingBox(struct FBox Box, bool bBoxInWorldSpace); // Function Engine.InstancedStaticMeshComponent.GetInstancesOverlappingBox // Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5b25ed0
	bool GetInstanceCustomData(int32 InstanceIndex, struct FVector4 OutPerInstanceCustomData); // Function Engine.InstancedStaticMeshComponent.GetInstanceCustomData // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5b254c8
	int32 GetInstanceCount(); // Function Engine.InstancedStaticMeshComponent.GetInstanceCount // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x4d22598
	void ClearInstances(); // Function Engine.InstancedStaticMeshComponent.ClearInstances // Native|Public|BlueprintCallable // @ game+0x4cf2390
	int32 AddInstanceWorldSpace(struct FTransform WorldTransform, struct FVector4 InPerInstanceCustomData); // Function Engine.InstancedStaticMeshComponent.AddInstanceWorldSpace // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b0a438
	int32 AddInstance(struct FTransform InstanceTransform, struct FVector4 InPerInstanceCustomData); // Function Engine.InstancedStaticMeshComponent.AddInstance // Native|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b09ff8
};

// Class Engine.HierarchicalInstancedStaticMeshComponent
// Size: 0xd80 (Inherited: 0xc60)
struct UHierarchicalInstancedStaticMeshComponent : UInstancedStaticMeshComponent {
	char pad_C60[0x60]; // 0xc60(0x60)
	struct TArray<int32> SortedInstances; // 0xcc0(0x10)
	int32 NumBuiltInstances; // 0xcd0(0x04)
	char pad_CD4[0x4]; // 0xcd4(0x04)
	struct FBox BuiltInstanceBounds; // 0xcd8(0x1c)
	struct FBox UnbuiltInstanceBounds; // 0xcf4(0x1c)
	struct TArray<struct FBox> UnbuiltInstanceBoundsList; // 0xd10(0x10)
	char pad_D20[0x20]; // 0xd20(0x20)
	int32 OcclusionLayerNumNodes; // 0xd40(0x04)
	struct FBoxSphereBounds CacheMeshExtendedBounds; // 0xd44(0x1c)
	char bEnableDensityScaling : 1; // 0xd60(0x01)
	char bDisableCollision : 1; // 0xd60(0x01)
	char pad_D60_2 : 6; // 0xd60(0x01)
	char pad_D61[0x1f]; // 0xd61(0x1f)

	bool RemoveInstances(struct TArray<int32> InstancesToRemove); // Function Engine.HierarchicalInstancedStaticMeshComponent.RemoveInstances // Final|Native|Public|HasOutParms|BlueprintCallable // @ game+0x5b41d74
};

// Class Engine.GridInstancedStaticMeshComponent
// Size: 0xd90 (Inherited: 0xd80)
struct UGridInstancedStaticMeshComponent : UHierarchicalInstancedStaticMeshComponent {
	int32 MinVertsToSplitNodeForGrid; // 0xd80(0x04)
	char pad_D84[0xc]; // 0xd84(0x0c)
};

// Class Engine.LocalPlayer
// Size: 0x298 (Inherited: 0x58)
struct ULocalPlayer : UPlayer {
	char bSentSplitJoin : 1; // 0x58(0x01)
	char pad_58_1 : 7; // 0x58(0x01)
	char pad_59[0x47]; // 0x59(0x47)
	struct UClass* PendingLevelPlayerControllerClass; // 0xa0(0x08)
	char pad_A8[0x1f0]; // 0xa8(0x1f0)
};

// Class Engine.ParticleModuleEventSendToGame
// Size: 0x38 (Inherited: 0x38)
struct UParticleModuleEventSendToGame : UObject {
};

// Class Engine.PlayerCameraManager
// Size: 0x1d00 (Inherited: 0x3f0)
struct APlayerCameraManager : AActor {
	struct APlayerController* PCOwner; // 0x3f0(0x08)
	struct USceneComponent* TransformComponent; // 0x3f8(0x08)
	float FreeCamDistance; // 0x400(0x04)
	char pad_404[0x8]; // 0x404(0x08)
	float ViewYawMin; // 0x40c(0x04)
	char pad_410[0x4]; // 0x410(0x04)
	float DefaultOrthoWidth; // 0x414(0x04)
	char pad_418[0x10]; // 0x418(0x10)
	float DefaultFOV; // 0x428(0x04)
	char pad_42C[0x1c]; // 0x42c(0x1c)
	float ViewRollMax; // 0x448(0x04)
	char pad_44C[0x14]; // 0x44c(0x14)
	float DefaultAspectRatio; // 0x460(0x04)
	float ViewPitchMax; // 0x464(0x04)
	struct FVector ViewTargetOffset; // 0x468(0x0c)
	float ViewPitchMin; // 0x474(0x04)
	float ViewRollMin; // 0x478(0x04)
	char pad_47C[0x4]; // 0x47c(0x04)
	struct TArray<struct UCameraModifier*> ModifierList; // 0x480(0x10)
	struct TArray<struct UClass*> DefaultModifiers; // 0x490(0x10)
	char pad_4A0[0x8]; // 0x4a0(0x08)
	struct FVector FreeCamOffset; // 0x4a8(0x0c)
	char pad_4B4[0xc]; // 0x4b4(0x0c)
	struct FCameraCacheEntry CameraCache; // 0x4c0(0x5d0)
	char pad_A90[0x18]; // 0xa90(0x18)
	struct TArray<struct AEmitterCameraLensEffectBase*> CameraLensEffects; // 0xaa8(0x10)
	struct UCameraModifier_CameraShake* CachedCameraShakeMod; // 0xab8(0x08)
	struct UCameraAnimInst* AnimInstPool[0x08]; // 0xac0(0x40)
	struct TArray<struct FPostProcessSettings> PostProcessBlendCache; // 0xb00(0x10)
	char pad_B10[0x10]; // 0xb10(0x10)
	struct TArray<struct UCameraAnimInst*> ActiveAnims; // 0xb20(0x10)
	struct TArray<struct UCameraAnimInst*> FreeAnims; // 0xb30(0x10)
	struct ACameraActor* AnimCameraActor; // 0xb40(0x08)
	char bIsOrthographic : 1; // 0xb48(0x01)
	char bDefaultConstrainAspectRatio : 1; // 0xb48(0x01)
	char pad_B48_2 : 5; // 0xb48(0x01)
	char bUseClientSideCameraUpdates : 1; // 0xb48(0x01)
	char pad_B49[0x7]; // 0xb49(0x07)
	struct FTViewTarget PendingViewTarget; // 0xb50(0x5e0)
	char pad_1130[0x10]; // 0x1130(0x10)
	struct FTViewTarget ViewTarget; // 0x1140(0x5e0)
	struct FCameraCacheEntry LastFrameCameraCache; // 0x1720(0x5d0)
	char pad_1CF0[0x8]; // 0x1cf0(0x08)
	float ViewYawMax; // 0x1cf8(0x04)
	char pad_1CFC[0x4]; // 0x1cfc(0x04)

	void StopCameraShake(struct UCameraShake* ShakeInstance, bool bImmediately); // Function Engine.PlayerCameraManager.StopCameraShake // Native|Public|BlueprintCallable // @ game+0x5b04dc4
	void StopCameraFade(); // Function Engine.PlayerCameraManager.StopCameraFade // Native|Public|BlueprintCallable // @ game+0x4d8c120
	void StopCameraAnimInst(struct UCameraAnimInst* AnimInst, bool bImmediate); // Function Engine.PlayerCameraManager.StopCameraAnimInst // Native|Public|BlueprintCallable // @ game+0x5b04ce0
	void StopAllInstancesOfCameraShake(struct UClass* Shake, bool bImmediately); // Function Engine.PlayerCameraManager.StopAllInstancesOfCameraShake // Native|Public|BlueprintCallable // @ game+0x5b04b68
	void StopAllInstancesOfCameraAnim(struct UCameraAnim* Anim, bool bImmediate); // Function Engine.PlayerCameraManager.StopAllInstancesOfCameraAnim // Native|Public|BlueprintCallable // @ game+0x5b04a84
	void StopAllCameraShakes(bool bImmediately); // Function Engine.PlayerCameraManager.StopAllCameraShakes // Native|Public|BlueprintCallable // @ game+0x5b003fc
	void StopAllCameraAnims(bool bImmediate); // Function Engine.PlayerCameraManager.StopAllCameraAnims // Native|Public|BlueprintCallable // @ game+0x5b049ec
	void StartCameraFade(float FromAlpha, float ToAlpha, float Duration, struct FLinearColor Color, bool bShouldFadeAudio, bool bHoldWhenFinished); // Function Engine.PlayerCameraManager.StartCameraFade // Native|Public|HasDefaults|BlueprintCallable // @ game+0x5b046e8
	void SetManualCameraFade(float InFadeAmount, struct FLinearColor Color, bool bInFadeAudio); // Function Engine.PlayerCameraManager.SetManualCameraFade // Native|Public|HasDefaults|BlueprintCallable // @ game+0x5b0168c
	bool RemoveCameraModifier(struct UCameraModifier* ModifierToRemove); // Function Engine.PlayerCameraManager.RemoveCameraModifier // Native|Public|BlueprintCallable // @ game+0x5afa244
	void RemoveCameraLensEffect(struct AEmitterCameraLensEffectBase* Emitter); // Function Engine.PlayerCameraManager.RemoveCameraLensEffect // Native|Public|BlueprintCallable // @ game+0x5afa1b0
	struct UCameraShake* PlayCameraShake(struct UClass* ShakeClass, float Scale, enum class ECameraAnimPlaySpace PlaySpace, struct FRotator UserPlaySpaceRot); // Function Engine.PlayerCameraManager.PlayCameraShake // Native|Public|HasDefaults|BlueprintCallable // @ game+0xae8db0
	struct UCameraAnimInst* PlayCameraAnim(struct UCameraAnim* Anim, float Rate, float Scale, float BlendInTime, float BlendOutTime, bool bLoop, bool bRandomStartTime, float Duration, enum class ECameraAnimPlaySpace PlaySpace, struct FRotator UserPlaySpaceRot); // Function Engine.PlayerCameraManager.PlayCameraAnim // Native|Public|HasDefaults|BlueprintCallable // @ game+0x5af9528
	void PhotographyCameraModify(struct FVector NewCameraLocation, struct FVector PreviousCameraLocation, struct FVector OriginalCameraLocation, struct FVector ResultCameraLocation); // Function Engine.PlayerCameraManager.PhotographyCameraModify // BlueprintCosmetic|Native|Event|Public|HasOutParms|HasDefaults|BlueprintEvent // @ game+0x5af9194
	void OnPhotographySessionStart(); // Function Engine.PlayerCameraManager.OnPhotographySessionStart // BlueprintCosmetic|Native|Event|Public|BlueprintEvent // @ game+0x769f14
	void OnPhotographySessionEnd(); // Function Engine.PlayerCameraManager.OnPhotographySessionEnd // BlueprintCosmetic|Native|Event|Public|BlueprintEvent // @ game+0x815938
	void OnPhotographyMultiPartCaptureStart(); // Function Engine.PlayerCameraManager.OnPhotographyMultiPartCaptureStart // BlueprintCosmetic|Native|Event|Public|BlueprintEvent // @ game+0x815b50
	void OnPhotographyMultiPartCaptureEnd(); // Function Engine.PlayerCameraManager.OnPhotographyMultiPartCaptureEnd // BlueprintCosmetic|Native|Event|Public|BlueprintEvent // @ game+0xe3d10c
	struct APlayerController* GetOwningPlayerController(); // Function Engine.PlayerCameraManager.GetOwningPlayerController // Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x4d6e69c
	float GetFOVAngle(); // Function Engine.PlayerCameraManager.GetFOVAngle // Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5aedaf4
	struct FRotator GetCameraRotation(); // Function Engine.PlayerCameraManager.GetCameraRotation // Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5aecb04
	struct FVector GetCameraLocation(); // Function Engine.PlayerCameraManager.GetCameraLocation // Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x2d2508
	struct UCameraModifier* FindCameraModifierByClass(struct UClass* ModifierClass); // Function Engine.PlayerCameraManager.FindCameraModifierByClass // Native|Public|BlueprintCallable // @ game+0x5aeaee8
	void ClearCameraLensEffects(); // Function Engine.PlayerCameraManager.ClearCameraLensEffects // Native|Public|BlueprintCallable // @ game+0x4d1bb20
	bool BlueprintUpdateCamera(struct AActor* CameraTarget, struct FVector NewCameraLocation, struct FRotator NewCameraRotation, float NewCameraFOV); // Function Engine.PlayerCameraManager.BlueprintUpdateCamera // BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintEvent // @ game+0x33e45c
	struct UCameraModifier* AddNewCameraModifier(struct UClass* ModifierClass); // Function Engine.PlayerCameraManager.AddNewCameraModifier // Native|Public|BlueprintCallable // @ game+0x5ae4510
	struct AEmitterCameraLensEffectBase* AddCameraLensEffect(struct UClass* LensEffectEmitterClass); // Function Engine.PlayerCameraManager.AddCameraLensEffect // Native|Public|BlueprintCallable // @ game+0x5ae30f4
};

// Class Engine.PlayerInput
// Size: 0x3d8 (Inherited: 0x38)
struct UPlayerInput : UObject {
	char pad_38[0xf8]; // 0x38(0xf8)
	struct TArray<struct FKeyBind> DebugExecBindings; // 0x130(0x10)
	char pad_140[0x30]; // 0x140(0x30)
	struct TArray<struct FName> InvertedAxis; // 0x170(0x10)
	char pad_180[0x258]; // 0x180(0x258)

	void SetMouseSensitivity(float Sensitivity); // Function Engine.PlayerInput.SetMouseSensitivity // Final|Exec|Native|Public // @ game+0x5b01d60
	void SetGamePadSensitivityOf(struct FKey AxisKey, float Sensitivity); // Function Engine.PlayerInput.SetGamePadSensitivityOf // Final|Exec|Native|Public // @ game+0x5b009e8
	void SetGamePadSensitivity(float Sensitivity); // Function Engine.PlayerInput.SetGamePadSensitivity // Final|Exec|Native|Public // @ game+0x5b00950
	void SetGamePadDeadZoneOf(struct FKey AxisKey, float DEADZONE); // Function Engine.PlayerInput.SetGamePadDeadZoneOf // Final|Exec|Native|Public // @ game+0x5b00814
	void SetGamePadDeadZone(float DEADZONE); // Function Engine.PlayerInput.SetGamePadDeadZone // Final|Exec|Native|Public // @ game+0x5b0077c
	void SetBind(struct FName BindName, struct FString Command); // Function Engine.PlayerInput.SetBind // Final|Exec|Native|Public // @ game+0x5aff098
	void InvertAxisKey(struct FKey AxisKey); // Function Engine.PlayerInput.InvertAxisKey // Final|Exec|Native|Public // @ game+0x5af1ec8
	void InvertAxis(struct FName AxisName); // Function Engine.PlayerInput.InvertAxis // Final|Exec|Native|Public // @ game+0x5af1e38
	void ClearSmoothing(); // Function Engine.PlayerInput.ClearSmoothing // Final|Exec|Native|Public // @ game+0x5ae5998
};

// Class Engine.NavigationData
// Size: 0x598 (Inherited: 0x3f0)
struct ANavigationData : AActor {
	struct UPrimitiveComponent* RenderingComp; // 0x3f0(0x08)
	struct FNavDataConfig NavDataConfig; // 0x3f8(0x50)
	char bEnableDrawing : 1; // 0x448(0x01)
	char bForceRebuildOnLoad : 1; // 0x448(0x01)
	char bCanBeMainNavData : 1; // 0x448(0x01)
	char bCanSpawnOnRebuild : 1; // 0x448(0x01)
	char bRebuildAtRuntime : 1; // 0x448(0x01)
	char pad_448_5 : 3; // 0x448(0x01)
	char pad_449[0x3]; // 0x449(0x03)
	enum class ERuntimeGenerationType RuntimeGeneration; // 0x44c(0x01)
	char pad_44D[0x3]; // 0x44d(0x03)
	float ObservedPathsTickInterval; // 0x450(0x04)
	char bSubNavData : 1; // 0x454(0x01)
	char pad_454_1 : 7; // 0x454(0x01)
	char pad_455[0x3]; // 0x455(0x03)
	uint32 DataVersion; // 0x458(0x04)
	char pad_45C[0xd4]; // 0x45c(0xd4)
	struct TArray<struct FSupportedAreaData> SupportedAreas; // 0x530(0x10)
	char pad_540[0x58]; // 0x540(0x58)
};

// Class Engine.RecastNavMesh
// Size: 0x6b0 (Inherited: 0x598)
struct ARecastNavMesh : ANavigationData {
	char bDrawTriangleEdges : 1; // 0x598(0x01)
	char bDrawPolyEdges : 1; // 0x598(0x01)
	char bDrawFilledPolys : 1; // 0x598(0x01)
	char bDrawNavMeshEdges : 1; // 0x598(0x01)
	char bDrawTileBounds : 1; // 0x598(0x01)
	char bDrawPathCollidingGeometry : 1; // 0x598(0x01)
	char bDrawTileLabels : 1; // 0x598(0x01)
	char bDrawPolygonLabels : 1; // 0x598(0x01)
	char bDrawDefaultPolygonCost : 1; // 0x599(0x01)
	char bDrawLabelsOnPathNodes : 1; // 0x599(0x01)
	char bDrawNavLinks : 1; // 0x599(0x01)
	char bDrawFailedNavLinks : 1; // 0x599(0x01)
	char bDrawClusters : 1; // 0x599(0x01)
	char bDrawOctree : 1; // 0x599(0x01)
	char bDistinctlyDrawTilesBeingBuilt : 1; // 0x599(0x01)
	char bDrawNavMesh : 1; // 0x599(0x01)
	char pad_59A[0x2]; // 0x59a(0x02)
	float DrawOffset; // 0x59c(0x04)
	char bFixedTilePoolSize : 1; // 0x5a0(0x01)
	char pad_5A0_1 : 7; // 0x5a0(0x01)
	char pad_5A1[0x3]; // 0x5a1(0x03)
	int32 TilePoolSize; // 0x5a4(0x04)
	float TileSizeUU; // 0x5a8(0x04)
	float CellSize; // 0x5ac(0x04)
	float CellHeight; // 0x5b0(0x04)
	float AgentRadius; // 0x5b4(0x04)
	float AgentHeight; // 0x5b8(0x04)
	float AgentMaxHeight; // 0x5bc(0x04)
	float AgentMaxSlope; // 0x5c0(0x04)
	float AgentMaxStepHeight; // 0x5c4(0x04)
	float MinRegionArea; // 0x5c8(0x04)
	float MergeRegionSize; // 0x5cc(0x04)
	float MaxSimplificationError; // 0x5d0(0x04)
	int32 MaxSimultaneousTileGenerationJobsCount; // 0x5d4(0x04)
	int32 TileNumberHardLimit; // 0x5d8(0x04)
	int32 PolyRefTileBits; // 0x5dc(0x04)
	int32 PolyRefNavPolyBits; // 0x5e0(0x04)
	int32 PolyRefSaltBits; // 0x5e4(0x04)
	float DefaultDrawDistance; // 0x5e8(0x04)
	float DefaultMaxSearchNodes; // 0x5ec(0x04)
	float DefaultMaxHierarchicalSearchNodes; // 0x5f0(0x04)
	enum class ERecastPartitioning RegionPartitioning; // 0x5f4(0x01)
	enum class ERecastPartitioning LayerPartitioning; // 0x5f5(0x01)
	char pad_5F6[0x2]; // 0x5f6(0x02)
	int32 RegionChunkSplits; // 0x5f8(0x04)
	int32 LayerChunkSplits; // 0x5fc(0x04)
	char bSortNavigationAreasByCost : 1; // 0x600(0x01)
	char bPerformVoxelFiltering : 1; // 0x600(0x01)
	char bMarkLowHeightAreas : 1; // 0x600(0x01)
	char bDoFullyAsyncNavDataGathering : 1; // 0x600(0x01)
	char bUseBetterOffsetsFromCorners : 1; // 0x600(0x01)
	char bStoreEmptyTileLayers : 1; // 0x600(0x01)
	char bUseVirtualFilters : 1; // 0x600(0x01)
	char bAllowNavLinkAsPathEnd : 1; // 0x600(0x01)
	char pad_601[0x3]; // 0x601(0x03)
	bool bOnlySavedOnDS; // 0x604(0x01)
	char pad_605[0x3]; // 0x605(0x03)
	char bUseVoxelCache : 1; // 0x608(0x01)
	char pad_608_1 : 7; // 0x608(0x01)
	char pad_609[0x3]; // 0x609(0x03)
	float TileSetUpdateInterval; // 0x60c(0x04)
	float HeuristicScale; // 0x610(0x04)
	float VerticalDeviationFromGroundCompensation; // 0x614(0x04)
	char pad_618[0x98]; // 0x618(0x98)
};

// Class Engine.ReplayCustomEventManager
// Size: 0x48 (Inherited: 0x38)
struct UReplayCustomEventManager : UObject {
	struct TArray<struct FCustomEventData> PendingCustomEvents; // 0x38(0x10)
};

// Class Engine.SceneCaptureComponent
// Size: 0x530 (Inherited: 0x4b0)
struct USceneCaptureComponent : USceneComponent {
	struct TArray<struct UPrimitiveComponent*> HiddenComponents; // 0x4b0(0x10)
	struct TArray<struct AActor*> HiddenActors; // 0x4c0(0x10)
	struct TArray<struct UPrimitiveComponent*> ShowOnlyComponents; // 0x4d0(0x10)
	struct TArray<struct AActor*> ShowOnlyActors; // 0x4e0(0x10)
	bool bIsLobbyCapture; // 0x4f0(0x01)
	bool bCaptureEveryFrame; // 0x4f1(0x01)
	bool bCaptureOnMovement; // 0x4f2(0x01)
	char pad_4F3[0x1]; // 0x4f3(0x01)
	float LODDistanceFactor; // 0x4f4(0x04)
	float MaxViewDistanceOverride; // 0x4f8(0x04)
	int32 CaptureSortPriority; // 0x4fc(0x04)
	struct TArray<struct FEngineShowFlagsSetting> ShowFlagSettings; // 0x500(0x10)
	char pad_510[0x20]; // 0x510(0x20)

	void ShowOnlyComponent(struct UPrimitiveComponent* InComponent); // Function Engine.SceneCaptureComponent.ShowOnlyComponent // Final|Native|Public|BlueprintCallable // @ game+0x5b54d14
	void ShowOnlyActorComponents(struct AActor* InActor); // Function Engine.SceneCaptureComponent.ShowOnlyActorComponents // Final|Native|Public|BlueprintCallable // @ game+0x5b54c84
	void SetCaptureSortPriority(int32 NewCaptureSortPriority); // Function Engine.SceneCaptureComponent.SetCaptureSortPriority // Final|Native|Public|BlueprintCallable // @ game+0x5b46d14
	void RemoveShowOnlyComponent(struct UPrimitiveComponent* InComponent); // Function Engine.SceneCaptureComponent.RemoveShowOnlyComponent // Final|Native|Public|BlueprintCallable // @ game+0x5b42050
	void RemoveShowOnlyActorComponents(struct AActor* InActor); // Function Engine.SceneCaptureComponent.RemoveShowOnlyActorComponents // Final|Native|Public|BlueprintCallable // @ game+0x5b41fc0
	void HideComponent(struct UPrimitiveComponent* InComponent); // Function Engine.SceneCaptureComponent.HideComponent // Final|Native|Public|BlueprintCallable // @ game+0x5b2e4e0
	void HideActorComponents(struct AActor* InActor); // Function Engine.SceneCaptureComponent.HideActorComponents // Final|Native|Public|BlueprintCallable // @ game+0x5b2e340
	void ClearShowOnlyComponents(struct UPrimitiveComponent* InComponent); // Function Engine.SceneCaptureComponent.ClearShowOnlyComponents // Final|Native|Public|BlueprintCallable // @ game+0x5b16c2c
};

// Class Engine.SceneCaptureComponent2D
// Size: 0xb70 (Inherited: 0x530)
struct USceneCaptureComponent2D : USceneCaptureComponent {
	enum class ECameraProjectionMode ProjectionType; // 0x530(0x01)
	char pad_531[0x3]; // 0x531(0x03)
	float FOVAngle; // 0x534(0x04)
	bool bUseNearClippingValue; // 0x538(0x01)
	char pad_539[0x3]; // 0x539(0x03)
	float NearClippingValue; // 0x53c(0x04)
	float OrthoWidth; // 0x540(0x04)
	char pad_544[0x4]; // 0x544(0x04)
	struct UTextureRenderTarget2D* TextureTarget; // 0x548(0x08)
	enum class ESceneCaptureSource CaptureSource; // 0x550(0x01)
	enum class ESceneCaptureCompositeMode CompositeMode; // 0x551(0x01)
	char pad_552[0x2]; // 0x552(0x02)
	struct FLinearColor LightingOnlyBrightness; // 0x554(0x10)
	struct FLinearColor LightingOnlySpecular; // 0x564(0x10)
	struct FLinearColor LightingOnlyCustomData; // 0x574(0x10)
	float LightingOnlyCustomDataAlpha; // 0x584(0x04)
	char pad_588[0x8]; // 0x588(0x08)
	struct FPostProcessSettings PostProcessSettings; // 0x590(0x570)
	float PostProcessBlendWeight; // 0xb00(0x04)
	bool bUseCustomProjectionMatrix; // 0xb04(0x01)
	char pad_B05[0xb]; // 0xb05(0x0b)
	struct FMatrix CustomProjectionMatrix; // 0xb10(0x40)
	char bIgnoreTemporalJitter : 1; // 0xb50(0x01)
	char pad_B50_1 : 7; // 0xb50(0x01)
	char pad_B51[0x3]; // 0xb51(0x03)
	bool bEnableClipPlane; // 0xb54(0x01)
	char pad_B55[0x3]; // 0xb55(0x03)
	struct FVector ClipPlaneBase; // 0xb58(0x0c)
	struct FVector ClipPlaneNormal; // 0xb64(0x0c)

	void CaptureScene(); // Function Engine.SceneCaptureComponent2D.CaptureScene // Final|Native|Public|BlueprintCallable // @ game+0x5b16530
	void AddOrUpdateBlendable(TScriptInterface<struct UBlendableInterface> InBlendableObject, float InWeight); // Function Engine.SceneCaptureComponent2D.AddOrUpdateBlendable // Final|Native|Public|BlueprintCallable // @ game+0x5b0a854
};

// Class Engine.ArrowComponent
// Size: 0x9f0 (Inherited: 0x9d0)
struct UArrowComponent : UPrimitiveComponent {
	struct FColor ArrowColor; // 0x9d0(0x04)
	float ArrowSize; // 0x9d4(0x04)
	bool bIsScreenSizeScaled; // 0x9d8(0x01)
	char pad_9D9[0x3]; // 0x9d9(0x03)
	float ScreenSize; // 0x9dc(0x04)
	char bTreatAsASprite : 1; // 0x9e0(0x01)
	char pad_9E0_1 : 7; // 0x9e0(0x01)
	char pad_9E1[0xf]; // 0x9e1(0x0f)

	void SetArrowColor(struct FLinearColor NewColor); // Function Engine.ArrowComponent.SetArrowColor // Native|Public|HasDefaults|BlueprintCallable // @ game+0x5b450c8
};

// Class Engine.ParticleSystemComponent
// Size: 0xc30 (Inherited: 0x9d0)
struct UParticleSystemComponent : UPrimitiveComponent {
	struct UParticleSystem* Template; // 0x9d0(0x08)
	struct TArray<struct UMaterialInterface*> EmitterMaterials; // 0x9d8(0x10)
	struct TArray<struct USkeletalMeshComponent*> SkelMeshComponents; // 0x9e8(0x10)
	char pad_9F8_0 : 7; // 0x9f8(0x01)
	char bResetOnDetach : 1; // 0x9f8(0x01)
	char bUpdateOnDedicatedServer : 1; // 0x9f9(0x01)
	char pad_9F9_1 : 2; // 0x9f9(0x01)
	char bAllowRecycling : 1; // 0x9f9(0x01)
	char bAutoManageAttachment : 1; // 0x9f9(0x01)
	char pad_9F9_5 : 2; // 0x9f9(0x01)
	char bWarmingUp : 1; // 0x9f9(0x01)
	char bOverrideLODMethod : 1; // 0x9fa(0x01)
	char bSkipUpdateDynamicDataDuringTick : 1; // 0x9fa(0x01)
	char pad_9FA_2 : 4; // 0x9fa(0x01)
	char bForceEmitterUseLocalSpace : 1; // 0x9fa(0x01)
	char pad_9FA_7 : 1; // 0x9fa(0x01)
	char pad_9FB[0x5]; // 0x9fb(0x05)
	struct TArray<struct FParticleSysParam> InstanceParameters; // 0xa00(0x10)
	struct FMulticastDelegate OnParticleSpawn; // 0xa10(0x10)
	struct FMulticastDelegate OnParticleBurst; // 0xa20(0x10)
	struct FMulticastDelegate OnParticleDeath; // 0xa30(0x10)
	struct FMulticastDelegate OnParticleCollide; // 0xa40(0x10)
	struct FVector OldPosition; // 0xa50(0x0c)
	struct FVector PartSysVelocity; // 0xa5c(0x0c)
	float WarmupTime; // 0xa68(0x04)
	float WarmupTickRate; // 0xa6c(0x04)
	char pad_A70[0x4]; // 0xa70(0x04)
	float SecondsBeforeInactive; // 0xa74(0x04)
	char pad_A78[0x4]; // 0xa78(0x04)
	float MaxTimeBeforeForceUpdateTransform; // 0xa7c(0x04)
	char pad_A80[0x8]; // 0xa80(0x08)
	enum class ParticleSystemLODMethod LODMethod; // 0xa88(0x01)
	enum class EParticleSignificanceLevel RequiredSignificance; // 0xa89(0x01)
	char pad_A8A[0x16]; // 0xa8a(0x16)
	struct TArray<struct UParticleSystemReplay*> ReplayClips; // 0xaa0(0x10)
	char pad_AB0[0x60]; // 0xab0(0x60)
	float CustomTimeDilation; // 0xb10(0x04)
	char pad_B14[0x4]; // 0xb14(0x04)
	struct FMulticastDelegate OnSystemFinished; // 0xb18(0x10)
	struct USceneComponent* AutoAttachParent; // 0xb28(0x08)
	struct FName AutoAttachSocketName; // 0xb30(0x08)
	enum class EAttachLocation AutoAttachLocationType; // 0xb38(0x01)
	enum class EAttachmentRule AutoAttachLocationRule; // 0xb39(0x01)
	enum class EAttachmentRule AutoAttachRotationRule; // 0xb3a(0x01)
	enum class EAttachmentRule AutoAttachScaleRule; // 0xb3b(0x01)
	char pad_B3C[0xf4]; // 0xb3c(0xf4)

	void SetVectorParameter(struct FName ParameterName, struct FVector Param); // Function Engine.ParticleSystemComponent.SetVectorParameter // Final|Native|Public|HasDefaults|BlueprintCallable // @ game+0x5b03ad4
	void SetTrailSourceData(struct FName InFirstSocketName, struct FName InSecondSocketName, enum class ETrailWidthMode InWidthMode, float InWidth); // Function Engine.ParticleSystemComponent.SetTrailSourceData // Final|Native|Public|BlueprintCallable // @ game+0x5b03428
	void SetTemplate(struct UParticleSystem* NewTemplate); // Function Engine.ParticleSystemComponent.SetTemplate // Final|Native|Public|BlueprintCallable // @ game+0x5b03274
	void SetMaterialParameter(struct FName ParameterName, struct UMaterialInterface* Param); // Function Engine.ParticleSystemComponent.SetMaterialParameter // Final|Native|Public|BlueprintCallable // @ game+0x5b01bac
	void SetFloatParameter(struct FName ParameterName, float Param); // Function Engine.ParticleSystemComponent.SetFloatParameter // Final|Native|Public|BlueprintCallable // @ game+0xd4c61c
	void SetEmitterEnable(struct FName EmitterName, bool bNewEnableState); // Function Engine.ParticleSystemComponent.SetEmitterEnable // Native|Public|BlueprintCallable // @ game+0x5b00318
	void SetColorParameter(struct FName ParameterName, struct FLinearColor Param); // Function Engine.ParticleSystemComponent.SetColorParameter // Final|Native|Public|HasDefaults|BlueprintCallable // @ game+0x5affd08
	void SetBeamTargetTangent(int32 emitterIndex, struct FVector NewTangentPoint, int32 TargetIndex); // Function Engine.ParticleSystemComponent.SetBeamTargetTangent // Native|Public|HasDefaults|BlueprintCallable // @ game+0x5afef5c
	void SetBeamTargetStrength(int32 emitterIndex, float NewTargetStrength, int32 TargetIndex); // Function Engine.ParticleSystemComponent.SetBeamTargetStrength // Native|Public|BlueprintCallable // @ game+0x5afee34
	void SetBeamTargetPoint(int32 emitterIndex, struct FVector NewTargetPoint, int32 TargetIndex); // Function Engine.ParticleSystemComponent.SetBeamTargetPoint // Native|Public|HasDefaults|BlueprintCallable // @ game+0x5afecf8
	void SetBeamSourceTangent(int32 emitterIndex, struct FVector NewTangentPoint, int32 SourceIndex); // Function Engine.ParticleSystemComponent.SetBeamSourceTangent // Native|Public|HasDefaults|BlueprintCallable // @ game+0x5afebbc
	void SetBeamSourceStrength(int32 emitterIndex, float NewSourceStrength, int32 SourceIndex); // Function Engine.ParticleSystemComponent.SetBeamSourceStrength // Native|Public|BlueprintCallable // @ game+0x5afea94
	void SetBeamSourcePoint(int32 emitterIndex, struct FVector NewSourcePoint, int32 SourceIndex); // Function Engine.ParticleSystemComponent.SetBeamSourcePoint // Native|Public|HasDefaults|BlueprintCallable // @ game+0x5afe958
	void SetBeamEndPoint(int32 emitterIndex, struct FVector NewEndPoint); // Function Engine.ParticleSystemComponent.SetBeamEndPoint // Native|Public|HasDefaults|BlueprintCallable // @ game+0x5afe85c
	void SetAutoAttachParams(struct USceneComponent* Parent, struct FName SocketName, enum class EAttachLocation LocationType); // Function Engine.ParticleSystemComponent.SetAutoAttachParams // Final|Native|Public|BlueprintCallable // @ game+0x5afe2dc
	void SetAutoAttachmentParameters(struct USceneComponent* Parent, struct FName SocketName, enum class EAttachmentRule LocationRule, enum class EAttachmentRule RotationRule, enum class EAttachmentRule ScaleRule); // Function Engine.ParticleSystemComponent.SetAutoAttachmentParameters // Final|Native|Public|BlueprintCallable // @ game+0x5afe424
	void SetActorParameter(struct FName ParameterName, struct AActor* Param); // Function Engine.ParticleSystemComponent.SetActorParameter // Final|Native|Public|BlueprintCallable // @ game+0x5afd8c4
	int32 GetNumActiveParticles(); // Function Engine.ParticleSystemComponent.GetNumActiveParticles // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5aeffb4
	struct UMaterialInterface* GetNamedMaterial(struct FName InName); // Function Engine.ParticleSystemComponent.GetNamedMaterial // Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5aefd6c
	bool GetBeamTargetTangent(int32 emitterIndex, int32 TargetIndex, struct FVector OutTangentPoint); // Function Engine.ParticleSystemComponent.GetBeamTargetTangent // Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5aec854
	bool GetBeamTargetStrength(int32 emitterIndex, int32 TargetIndex, float OutTargetStrength); // Function Engine.ParticleSystemComponent.GetBeamTargetStrength // Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const // @ game+0x5aec714
	bool GetBeamTargetPoint(int32 emitterIndex, int32 TargetIndex, struct FVector OutTargetPoint); // Function Engine.ParticleSystemComponent.GetBeamTargetPoint // Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5aec5d0
	bool GetBeamSourceTangent(int32 emitterIndex, int32 SourceIndex, struct FVector OutTangentPoint); // Function Engine.ParticleSystemComponent.GetBeamSourceTangent // Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5aec48c
	bool GetBeamSourceStrength(int32 emitterIndex, int32 SourceIndex, float OutSourceStrength); // Function Engine.ParticleSystemComponent.GetBeamSourceStrength // Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const // @ game+0x5aec34c
	bool GetBeamSourcePoint(int32 emitterIndex, int32 SourceIndex, struct FVector OutSourcePoint); // Function Engine.ParticleSystemComponent.GetBeamSourcePoint // Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5aec208
	bool GetBeamEndPoint(int32 emitterIndex, struct FVector OutEndPoint); // Function Engine.ParticleSystemComponent.GetBeamEndPoint // Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5aec110
	void GenerateParticleEvent(struct FName InEventName, float InEmitterTime, struct FVector InLocation, struct FVector InDirection, struct FVector InVelocity); // Function Engine.ParticleSystemComponent.GenerateParticleEvent // Final|Native|Public|HasDefaults|BlueprintCallable // @ game+0x5aeb14c
	void EndTrails(); // Function Engine.ParticleSystemComponent.EndTrails // Final|Native|Public|BlueprintCallable // @ game+0x5aeac44
	struct UMaterialInstanceDynamic* CreateNamedDynamicMaterialInstance(struct FName InName, struct UMaterialInterface* SourceMaterial); // Function Engine.ParticleSystemComponent.CreateNamedDynamicMaterialInstance // Native|Public|BlueprintCallable // @ game+0x5ae892c
	void BeginTrails(struct FName InFirstSocketName, struct FName InSecondSocketName, enum class ETrailWidthMode InWidthMode, float InWidth); // Function Engine.ParticleSystemComponent.BeginTrails // Final|Native|Public|BlueprintCallable // @ game+0x5ae50c0
};

// Class Engine.DefaultPawn
// Size: 0x478 (Inherited: 0x450)
struct ADefaultPawn : APawn {
	float BaseTurnRate; // 0x450(0x04)
	float BaseLookUpRate; // 0x454(0x04)
	struct UPawnMovementComponent* MovementComponent; // 0x458(0x08)
	struct USphereComponent* CollisionComponent; // 0x460(0x08)
	struct UStaticMeshComponent* MeshComponent; // 0x468(0x08)
	char bAddDefaultMovementBindings : 1; // 0x470(0x01)
	char pad_470_1 : 7; // 0x470(0x01)
	char pad_471[0x7]; // 0x471(0x07)

	void TurnAtRate(float Rate); // Function Engine.DefaultPawn.TurnAtRate // Final|Native|Public|BlueprintCallable // @ game+0x5b05414
	void MoveUp_World(float Val); // Function Engine.DefaultPawn.MoveUp_World // Native|Public|BlueprintCallable // @ game+0x5af8a70
	void MoveRight(float Val); // Function Engine.DefaultPawn.MoveRight // Native|Public|BlueprintCallable // @ game+0x5af89d4
	void MoveForward(float Val); // Function Engine.DefaultPawn.MoveForward // Native|Public|BlueprintCallable // @ game+0x5af882c
	void LookUpAtRate(float Rate); // Function Engine.DefaultPawn.LookUpAtRate // Final|Native|Public|BlueprintCallable // @ game+0x5af8538
};

// Class Engine.SpectatorPawn
// Size: 0x478 (Inherited: 0x478)
struct ASpectatorPawn : ADefaultPawn {
};

// Class Engine.FloatingPawnMovement
// Size: 0x2a0 (Inherited: 0x290)
struct UFloatingPawnMovement : UPawnMovementComponent {
	float MaxSpeed; // 0x288(0x04)
	float Acceleration; // 0x28c(0x04)
	float Deceleration; // 0x290(0x04)
	float TurningBoost; // 0x294(0x04)
	char bPositionCorrected : 1; // 0x298(0x01)
};

// Class Engine.SpectatorPawnMovement
// Size: 0x2b0 (Inherited: 0x2a0)
struct USpectatorPawnMovement : UFloatingPawnMovement {
	char bIgnoreTimeDilation : 1; // 0x2a0(0x01)
	char pad_2A0_1 : 7; // 0x2a0(0x01)
	char pad_2A1[0xf]; // 0x2a1(0x0f)
};

// Class Engine.SplineComponent
// Size: 0xac0 (Inherited: 0x9d0)
struct USplineComponent : UPrimitiveComponent {
	struct FSplineCurves SplineCurves; // 0x9d0(0x60)
	struct FInterpCurveVector SplineInfo; // 0xa30(0x18)
	struct FInterpCurveQuat SplineRotInfo; // 0xa48(0x18)
	struct FInterpCurveVector SplineScaleInfo; // 0xa60(0x18)
	struct FInterpCurveFloat SplineReparamTable; // 0xa78(0x18)
	bool bAllowSplineEditingPerInstance; // 0xa90(0x01)
	char pad_A91[0x3]; // 0xa91(0x03)
	int32 ReparamStepsPerSegment; // 0xa94(0x04)
	bool bAutoCurvedReparamTable; // 0xa98(0x01)
	bool bAdaptiveDistanceReparamTable; // 0xa99(0x01)
	char pad_A9A[0x2]; // 0xa9a(0x02)
	float ReparamMaxStepDistance; // 0xa9c(0x04)
	float Duration; // 0xaa0(0x04)
	bool bStationaryEndpoints; // 0xaa4(0x01)
	bool bSplineHasBeenEdited; // 0xaa5(0x01)
	bool bModifiedByConstructionScript; // 0xaa6(0x01)
	bool bInputSplinePointsToConstructionScript; // 0xaa7(0x01)
	bool bDrawDebug; // 0xaa8(0x01)
	bool bClosedLoop; // 0xaa9(0x01)
	bool bLoopPositionOverride; // 0xaaa(0x01)
	char pad_AAB[0x1]; // 0xaab(0x01)
	float LoopPosition; // 0xaac(0x04)
	struct FVector DefaultUpVector; // 0xab0(0x0c)
	char pad_ABC[0x4]; // 0xabc(0x04)

	void UpdateSpline(); // Function Engine.SplineComponent.UpdateSpline // Final|Native|Public|BlueprintCallable // @ game+0x5b5c178
	void SetWorldLocationAtSplinePoint(int32 PointIndex, struct FVector InLocation); // Function Engine.SplineComponent.SetWorldLocationAtSplinePoint // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b5310c
	void SetUpVectorAtSplinePoint(int32 PointIndex, struct FVector InUpVector, enum class ESplineCoordinateSpace CoordinateSpace, bool bUpdateSpline); // Function Engine.SplineComponent.SetUpVectorAtSplinePoint // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b5211c
	void SetUnselectedSplineSegmentColor(struct FLinearColor SegmentColor); // Function Engine.SplineComponent.SetUnselectedSplineSegmentColor // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5afff28
	void SetTangentsAtSplinePoint(int32 PointIndex, struct FVector InArriveTangent, struct FVector InLeaveTangent, enum class ESplineCoordinateSpace CoordinateSpace, bool bUpdateSpline); // Function Engine.SplineComponent.SetTangentsAtSplinePoint // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b513d4
	void SetTangentAtSplinePoint(int32 PointIndex, struct FVector InTangent, enum class ESplineCoordinateSpace CoordinateSpace, bool bUpdateSpline); // Function Engine.SplineComponent.SetTangentAtSplinePoint // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b51248
	void SetSplineWorldPoints(struct TArray<struct FVector> Points); // Function Engine.SplineComponent.SetSplineWorldPoints // Final|Native|Public|HasOutParms|BlueprintCallable // @ game+0x5b5036c
	void SetSplinePointType(int32 PointIndex, enum class ESplinePointType Type, bool bUpdateSpline); // Function Engine.SplineComponent.SetSplinePointType // Final|Native|Public|BlueprintCallable // @ game+0x5b4ffd4
	void SetSplinePoints(struct TArray<struct FVector> Points, enum class ESplineCoordinateSpace CoordinateSpace, bool bUpdateSpline); // Function Engine.SplineComponent.SetSplinePoints // Final|Native|Public|HasOutParms|BlueprintCallable // @ game+0x5b50104
	void SetSplineLocalPoints(struct TArray<struct FVector> Points); // Function Engine.SplineComponent.SetSplineLocalPoints // Final|Native|Public|HasOutParms|BlueprintCallable // @ game+0x5b4ff08
	void SetSelectedSplineSegmentColor(struct FLinearColor SegmentColor); // Function Engine.SplineComponent.SetSelectedSplineSegmentColor // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5afff28
	void SetLocationAtSplinePoint(int32 PointIndex, struct FVector InLocation, enum class ESplineCoordinateSpace CoordinateSpace, bool bUpdateSpline); // Function Engine.SplineComponent.SetLocationAtSplinePoint // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b4cf60
	void SetDrawDebug(bool bShow); // Function Engine.SplineComponent.SetDrawDebug // Final|Native|Public|BlueprintCallable // @ game+0x5b48e60
	void SetDefaultUpVector(struct FVector UpVector, enum class ESplineCoordinateSpace CoordinateSpace); // Function Engine.SplineComponent.SetDefaultUpVector // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b48694
	void SetClosedLoopAtPosition(bool bInClosedLoop, float Key, bool bUpdateSpline); // Function Engine.SplineComponent.SetClosedLoopAtPosition // Final|Native|Public|BlueprintCallable // @ game+0x5b47478
	void SetClosedLoop(bool bInClosedLoop, bool bUpdateSpline); // Function Engine.SplineComponent.SetClosedLoop // Final|Native|Public|BlueprintCallable // @ game+0x5b47380
	void RemoveSplinePoint(int32 Index, bool bUpdateSpline); // Function Engine.SplineComponent.RemoveSplinePoint // Final|Native|Public|BlueprintCallable // @ game+0x5b420f0
	bool IsClosedLoop(); // Function Engine.SplineComponent.IsClosedLoop // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b2f970
	struct FVector GetWorldTangentAtDistanceAlongSpline(float Distance); // Function Engine.SplineComponent.GetWorldTangentAtDistanceAlongSpline // Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5b2ce20
	struct FRotator GetWorldRotationAtTime(float Time, bool bUseConstantVelocity); // Function Engine.SplineComponent.GetWorldRotationAtTime // Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5b2cd10
	struct FRotator GetWorldRotationAtDistanceAlongSpline(float Distance); // Function Engine.SplineComponent.GetWorldRotationAtDistanceAlongSpline // Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5b2cc50
	struct FVector GetWorldLocationAtTime(float Time, bool bUseConstantVelocity); // Function Engine.SplineComponent.GetWorldLocationAtTime // Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5b2caa0
	struct FVector GetWorldLocationAtSplinePoint(int32 PointIndex); // Function Engine.SplineComponent.GetWorldLocationAtSplinePoint // Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5b2c9e8
	struct FVector GetWorldLocationAtDistanceAlongSpline(float Distance); // Function Engine.SplineComponent.GetWorldLocationAtDistanceAlongSpline // Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5b2c928
	struct FVector GetWorldDirectionAtTime(float Time, bool bUseConstantVelocity); // Function Engine.SplineComponent.GetWorldDirectionAtTime // Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5b2c818
	struct FVector GetWorldDirectionAtDistanceAlongSpline(float Distance); // Function Engine.SplineComponent.GetWorldDirectionAtDistanceAlongSpline // Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5b2c758
	struct FVector GetUpVectorAtTime(float Time, enum class ESplineCoordinateSpace CoordinateSpace, bool bUseConstantVelocity); // Function Engine.SplineComponent.GetUpVectorAtTime // Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5b2c160
	struct FVector GetUpVectorAtSplinePoint(int32 PointIndex, enum class ESplineCoordinateSpace CoordinateSpace); // Function Engine.SplineComponent.GetUpVectorAtSplinePoint // Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5b2c02c
	struct FVector GetUpVectorAtDistanceAlongSpline(float Distance, enum class ESplineCoordinateSpace CoordinateSpace); // Function Engine.SplineComponent.GetUpVectorAtDistanceAlongSpline // Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5b2bf2c
	struct FTransform GetTransformAtTime(float Time, enum class ESplineCoordinateSpace CoordinateSpace, bool bUseConstantVelocity, bool bUseScale); // Function Engine.SplineComponent.GetTransformAtTime // Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5b2b86c
	struct FTransform GetTransformAtSplinePoint(int32 PointIndex, enum class ESplineCoordinateSpace CoordinateSpace, bool bUseScale); // Function Engine.SplineComponent.GetTransformAtSplinePoint // Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5b2b6c0
	struct FTransform GetTransformAtDistanceAlongSpline(float Distance, enum class ESplineCoordinateSpace CoordinateSpace, bool bUseScale); // Function Engine.SplineComponent.GetTransformAtDistanceAlongSpline // Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5b2b54c
	struct FVector GetTangentAtTime(float Time, enum class ESplineCoordinateSpace CoordinateSpace, bool bUseConstantVelocity); // Function Engine.SplineComponent.GetTangentAtTime // Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5b2a770
	struct FVector GetTangentAtSplinePoint(int32 PointIndex, enum class ESplineCoordinateSpace CoordinateSpace); // Function Engine.SplineComponent.GetTangentAtSplinePoint // Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5b26848
	struct FVector GetTangentAtDistanceAlongSpline(float Distance, enum class ESplineCoordinateSpace CoordinateSpace); // Function Engine.SplineComponent.GetTangentAtDistanceAlongSpline // Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5b2a670
	enum class ESplinePointType GetSplinePointType(int32 PointIndex); // Function Engine.SplineComponent.GetSplinePointType // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b29e94
	float GetSplineLength(); // Function Engine.SplineComponent.GetSplineLength // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b29e6c
	struct FVector GetScaleAtTime(float Time, bool bUseConstantVelocity); // Function Engine.SplineComponent.GetScaleAtTime // Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5b297a4
	struct FVector GetScaleAtSplinePoint(int32 PointIndex); // Function Engine.SplineComponent.GetScaleAtSplinePoint // Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5b296d0
	struct FVector GetScaleAtDistanceAlongSpline(float Distance); // Function Engine.SplineComponent.GetScaleAtDistanceAlongSpline // Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5b29618
	struct FRotator GetRotationAtTime(float Time, enum class ESplineCoordinateSpace CoordinateSpace, bool bUseConstantVelocity); // Function Engine.SplineComponent.GetRotationAtTime // Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5b294d0
	struct FRotator GetRotationAtSplinePoint(int32 PointIndex, enum class ESplineCoordinateSpace CoordinateSpace); // Function Engine.SplineComponent.GetRotationAtSplinePoint // Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5b29394
	struct FRotator GetRotationAtDistanceAlongSpline(float Distance, enum class ESplineCoordinateSpace CoordinateSpace); // Function Engine.SplineComponent.GetRotationAtDistanceAlongSpline // Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5b29294
	float GetRollAtTime(float Time, enum class ESplineCoordinateSpace CoordinateSpace, bool bUseConstantVelocity); // Function Engine.SplineComponent.GetRollAtTime // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b2915c
	float GetRollAtSplinePoint(int32 PointIndex, enum class ESplineCoordinateSpace CoordinateSpace); // Function Engine.SplineComponent.GetRollAtSplinePoint // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b29070
	float GetRollAtDistanceAlongSpline(float Distance, enum class ESplineCoordinateSpace CoordinateSpace); // Function Engine.SplineComponent.GetRollAtDistanceAlongSpline // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b28f7c
	struct FVector GetRightVectorAtTime(float Time, enum class ESplineCoordinateSpace CoordinateSpace, bool bUseConstantVelocity); // Function Engine.SplineComponent.GetRightVectorAtTime // Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5b28e34
	struct FVector GetRightVectorAtSplinePoint(int32 PointIndex, enum class ESplineCoordinateSpace CoordinateSpace); // Function Engine.SplineComponent.GetRightVectorAtSplinePoint // Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5b28d00
	struct FVector GetRightVectorAtDistanceAlongSpline(float Distance, enum class ESplineCoordinateSpace CoordinateSpace); // Function Engine.SplineComponent.GetRightVectorAtDistanceAlongSpline // Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5b28c00
	int32 GetNumberOfSplinePoints(); // Function Engine.SplineComponent.GetNumberOfSplinePoints // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b27664
	struct FVector GetLocationAtTime(float Time, enum class ESplineCoordinateSpace CoordinateSpace, bool bUseConstantVelocity); // Function Engine.SplineComponent.GetLocationAtTime // Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5b2702c
	struct FVector GetLocationAtSplinePoint(int32 PointIndex, enum class ESplineCoordinateSpace CoordinateSpace); // Function Engine.SplineComponent.GetLocationAtSplinePoint // Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5b26f30
	struct FVector GetLocationAtDistanceAlongSpline(float Distance, enum class ESplineCoordinateSpace CoordinateSpace); // Function Engine.SplineComponent.GetLocationAtDistanceAlongSpline // Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5b26e30
	void GetLocationAndTangentAtSplinePoint(int32 PointIndex, struct FVector Location, struct FVector Tangent, enum class ESplineCoordinateSpace CoordinateSpace); // Function Engine.SplineComponent.GetLocationAndTangentAtSplinePoint // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5b26c90
	void GetLocalLocationAndTangentAtSplinePoint(int32 PointIndex, struct FVector LocalLocation, struct FVector LocalTangent); // Function Engine.SplineComponent.GetLocalLocationAndTangentAtSplinePoint // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5b26b38
	float GetLengthInRange(int32 StartIndex, int32 EndIndex); // Function Engine.SplineComponent.GetLengthInRange // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b2696c
	struct FVector GetLeaveTangentAtSplinePoint(int32 PointIndex, enum class ESplineCoordinateSpace CoordinateSpace); // Function Engine.SplineComponent.GetLeaveTangentAtSplinePoint // Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5b26848
	float GetInputKeyAtDistanceAlongSpline(float Distance); // Function Engine.SplineComponent.GetInputKeyAtDistanceAlongSpline // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b24ddc
	float GetDistanceAlongSplineAtSplinePoint(int32 PointIndex); // Function Engine.SplineComponent.GetDistanceAlongSplineAtSplinePoint // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b24518
	struct FVector GetDirectionAtTime(float Time, enum class ESplineCoordinateSpace CoordinateSpace, bool bUseConstantVelocity); // Function Engine.SplineComponent.GetDirectionAtTime // Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5b241dc
	struct FVector GetDirectionAtSplinePoint(int32 PointIndex, enum class ESplineCoordinateSpace CoordinateSpace); // Function Engine.SplineComponent.GetDirectionAtSplinePoint // Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5b240e0
	struct FVector GetDirectionAtDistanceAlongSpline(float Distance, enum class ESplineCoordinateSpace CoordinateSpace); // Function Engine.SplineComponent.GetDirectionAtDistanceAlongSpline // Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5b23fe0
	struct FVector GetDefaultUpVector(enum class ESplineCoordinateSpace CoordinateSpace); // Function Engine.SplineComponent.GetDefaultUpVector // Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5b23da4
	struct FVector GetArriveTangentAtSplinePoint(int32 PointIndex, enum class ESplineCoordinateSpace CoordinateSpace); // Function Engine.SplineComponent.GetArriveTangentAtSplinePoint // Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5b21e1c
	struct FVector FindUpVectorClosestToWorldLocation(struct FVector WorldLocation, enum class ESplineCoordinateSpace CoordinateSpace); // Function Engine.SplineComponent.FindUpVectorClosestToWorldLocation // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5b206a8
	struct FTransform FindTransformClosestToWorldLocation(struct FVector WorldLocation, enum class ESplineCoordinateSpace CoordinateSpace, bool bUseScale); // Function Engine.SplineComponent.FindTransformClosestToWorldLocation // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5b20520
	struct FVector FindTangentClosestToWorldLocation(struct FVector WorldLocation, enum class ESplineCoordinateSpace CoordinateSpace); // Function Engine.SplineComponent.FindTangentClosestToWorldLocation // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5b203fc
	struct FVector FindScaleClosestToWorldLocation(struct FVector WorldLocation); // Function Engine.SplineComponent.FindScaleClosestToWorldLocation // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5b20334
	struct FRotator FindRotationClosestToWorldLocation(struct FVector WorldLocation, enum class ESplineCoordinateSpace CoordinateSpace); // Function Engine.SplineComponent.FindRotationClosestToWorldLocation // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5b20204
	float FindRollClosestToWorldLocation(struct FVector WorldLocation, enum class ESplineCoordinateSpace CoordinateSpace); // Function Engine.SplineComponent.FindRollClosestToWorldLocation // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5b20100
	struct FVector FindRightVectorClosestToWorldLocation(struct FVector WorldLocation, enum class ESplineCoordinateSpace CoordinateSpace); // Function Engine.SplineComponent.FindRightVectorClosestToWorldLocation // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5b1ffdc
	struct FVector FindLocationClosestToWorldLocation(struct FVector WorldLocation, enum class ESplineCoordinateSpace CoordinateSpace); // Function Engine.SplineComponent.FindLocationClosestToWorldLocation // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5b1fb08
	float FindInputKeyClosestToWorldLocation(struct FVector WorldLocation); // Function Engine.SplineComponent.FindInputKeyClosestToWorldLocation // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5b1fa5c
	struct FVector FindDirectionClosestToWorldLocation(struct FVector WorldLocation, enum class ESplineCoordinateSpace CoordinateSpace); // Function Engine.SplineComponent.FindDirectionClosestToWorldLocation // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5b1f938
	void ClearSplinePoints(bool bUpdateSpline); // Function Engine.SplineComponent.ClearSplinePoints // Final|Native|Public|BlueprintCallable // @ game+0x5b16f90
	void AddSplineWorldPoint(struct FVector Position); // Function Engine.SplineComponent.AddSplineWorldPoint // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b0af28
	void AddSplinePointAtIndex(struct FVector Position, int32 Index, enum class ESplineCoordinateSpace CoordinateSpace, bool bUpdateSpline); // Function Engine.SplineComponent.AddSplinePointAtIndex // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b0ad9c
	void AddSplinePoint(struct FVector Position, enum class ESplineCoordinateSpace CoordinateSpace, bool bUpdateSpline); // Function Engine.SplineComponent.AddSplinePoint // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b0ac54
	void AddSplineLocalPoint(struct FVector Position); // Function Engine.SplineComponent.AddSplineLocalPoint // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b0abb4
	void AddPoints(struct TArray<struct FSplinePoint> Points, bool bUpdateSpline); // Function Engine.SplineComponent.AddPoints // Final|Native|Public|HasOutParms|BlueprintCallable // @ game+0x5b0aa84
	void AddPoint(struct FSplinePoint Point, bool bUpdateSpline); // Function Engine.SplineComponent.AddPoint // Final|Native|Public|HasOutParms|BlueprintCallable // @ game+0x5b0a968
};

// Class Engine.MaterialInterface
// Size: 0x80 (Inherited: 0x38)
struct UMaterialInterface : UObject {
	char pad_38[0x8]; // 0x38(0x08)
	struct USubsurfaceProfile* SubsurfaceProfile; // 0x40(0x08)
	char pad_48[0x8]; // 0x48(0x08)
	struct FLightmassMaterialInterfaceSettings LightmassSettings; // 0x50(0x14)
	char pad_64[0x4]; // 0x64(0x04)
	struct TArray<struct FMaterialTextureInfo> TextureStreamingData; // 0x68(0x10)
	char pad_78[0x8]; // 0x78(0x08)

	struct UPhysicalMaterial* GetPhysicalMaterial(); // Function Engine.MaterialInterface.GetPhysicalMaterial // Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5af0908
	struct UMaterial* GetBaseMaterial(); // Function Engine.MaterialInterface.GetBaseMaterial // Final|RequiredAPI|Native|Public|BlueprintCallable // @ game+0x5aec078
};

// Class Engine.MaterialInstance
// Size: 0x1f0 (Inherited: 0x80)
struct UMaterialInstance : UMaterialInterface {
	struct UPhysicalMaterial* PhysMaterial; // 0x80(0x08)
	struct UMaterialInterface* Parent; // 0x88(0x08)
	char bHasStaticPermutationResource : 1; // 0x90(0x01)
	char bPermutationResourceInBaseMaterial : 1; // 0x90(0x01)
	char pad_90_2 : 1; // 0x90(0x01)
	char bOverrideSubsurfaceProfile : 1; // 0x90(0x01)
	char pad_90_4 : 4; // 0x90(0x01)
	char pad_91[0x7]; // 0x91(0x07)
	struct TArray<struct FFontParameterValue> FontParameterValues; // 0x98(0x10)
	struct TArray<struct FScalarParameterValue> ScalarParameterValues; // 0xa8(0x10)
	struct TArray<struct FTextureParameterValue> TextureParameterValues; // 0xb8(0x10)
	struct TArray<struct FVectorParameterValue> VectorParameterValues; // 0xc8(0x10)
	bool bOverrideBaseProperties; // 0xd8(0x01)
	char pad_D9[0x3]; // 0xd9(0x03)
	struct FMaterialInstanceBasePropertyOverrides BasePropertyOverrides; // 0xdc(0x24)
	char pad_100[0xf0]; // 0x100(0xf0)
};

// Class Engine.MaterialInstanceConstant
// Size: 0x1f0 (Inherited: 0x1f0)
struct UMaterialInstanceConstant : UMaterialInstance {
};

// Class Engine.MaterialExpression
// Size: 0x70 (Inherited: 0x38)
struct UMaterialExpression : UObject {
	struct UMaterial* Material; // 0x38(0x08)
	struct UMaterialFunction* Function; // 0x40(0x08)
	struct FString Desc; // 0x48(0x10)
	struct FColor BorderColor; // 0x58(0x04)
	char bRealtimePreview : 1; // 0x5c(0x01)
	char bNeedToUpdatePreview : 1; // 0x5c(0x01)
	char bIsParameterExpression : 1; // 0x5c(0x01)
	char bCommentBubbleVisible : 1; // 0x5c(0x01)
	char bShowOutputNameOnPin : 1; // 0x5c(0x01)
	char bShowMaskColorsOnPin : 1; // 0x5c(0x01)
	char bHidePreviewWindow : 1; // 0x5c(0x01)
	char bCollapsed : 1; // 0x5c(0x01)
	char bShaderInputData : 1; // 0x5d(0x01)
	char bShowInputs : 1; // 0x5d(0x01)
	char bShowOutputs : 1; // 0x5d(0x01)
	char pad_5D_3 : 5; // 0x5d(0x01)
	char pad_5E[0x2]; // 0x5e(0x02)
	struct TArray<struct FExpressionOutput> Outputs; // 0x60(0x10)
};

// Class Engine.MaterialExpressionTerrainBlendBase
// Size: 0x70 (Inherited: 0x70)
struct UMaterialExpressionTerrainBlendBase : UMaterialExpression {
};

// Class Engine.MaterialExpressionCustomOutput
// Size: 0x70 (Inherited: 0x70)
struct UMaterialExpressionCustomOutput : UMaterialExpression {
};

// Class Engine.BlueprintAsyncActionBase
// Size: 0x38 (Inherited: 0x38)
struct UBlueprintAsyncActionBase : UObject {

	void Activate(); // Function Engine.BlueprintAsyncActionBase.Activate // Native|Public|BlueprintCallable // @ game+0x4d80fd4
};

// Class Engine.BlueprintGeneratedClass
// Size: 0x3f0 (Inherited: 0x2e8)
struct UBlueprintGeneratedClass : UClass {
	int32 NumReplicatedProperties; // 0x2e8(0x04)
	char pad_2EC[0x4]; // 0x2ec(0x04)
	struct TArray<struct UDynamicBlueprintBinding*> DynamicBindingObjects; // 0x2f0(0x10)
	struct TArray<struct UActorComponent*> ComponentTemplates; // 0x300(0x10)
	struct TArray<struct UTimelineTemplate*> Timelines; // 0x310(0x10)
	struct USimpleConstructionScript* SimpleConstructionScript; // 0x320(0x08)
	struct UInheritableComponentHandler* InheritableComponentHandler; // 0x328(0x08)
	struct UStructProperty* UberGraphFramePointerProperty; // 0x330(0x08)
	struct UFunction* UberGraphFunction; // 0x338(0x08)
	struct TArray<struct FEventGraphFastCallPair> FastCallPairs; // 0x340(0x10)
	bool bHasInstrumentation; // 0x350(0x01)
	char pad_351[0x7]; // 0x351(0x07)
	struct TMap<struct FName, struct FBlueprintCookedComponentInstancingData> CookedComponentInstancingData; // 0x358(0x50)
	bool bHasNativizedParent; // 0x3a8(0x01)
	char pad_3A9[0x47]; // 0x3a9(0x47)
};

// Class Engine.CameraActor
// Size: 0x990 (Inherited: 0x3f0)
struct ACameraActor : AActor {
	enum class EAutoReceiveInput AutoActivateForPlayer; // 0x3f0(0x01)
	char pad_3F1[0x7]; // 0x3f1(0x07)
	struct UCameraComponent* CameraComponent; // 0x3f8(0x08)
	struct USceneComponent* SceneComponent; // 0x400(0x08)
	char pad_408[0x8]; // 0x408(0x08)
	char bConstrainAspectRatio : 1; // 0x410(0x01)
	char pad_410_1 : 7; // 0x410(0x01)
	char pad_411[0x3]; // 0x411(0x03)
	float AspectRatio; // 0x414(0x04)
	float FOVAngle; // 0x418(0x04)
	float PostProcessBlendWeight; // 0x41c(0x04)
	struct FPostProcessSettings PostProcessSettings; // 0x420(0x570)

	int32 GetAutoActivatePlayerIndex(); // Function Engine.CameraActor.GetAutoActivatePlayerIndex // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5aec020
};

// Class Engine.UserDefinedStruct
// Size: 0x130 (Inherited: 0x120)
struct UUserDefinedStruct : UScriptStruct {
	struct FGuid Guid; // 0x120(0x10)
};

// Class Engine.AISystemBase
// Size: 0x58 (Inherited: 0x38)
struct UAISystemBase : UObject {
	struct FStringClassReference AISystemClassName; // 0x38(0x10)
	struct FName AISystemModuleName; // 0x48(0x08)
	bool bInstantiateAISystemOnClient; // 0x50(0x01)
	char pad_51[0x7]; // 0x51(0x07)
};

// Class Engine.NavigationQueryFilter
// Size: 0x58 (Inherited: 0x38)
struct UNavigationQueryFilter : UObject {
	struct TArray<struct FNavigationFilterArea> Areas; // 0x38(0x10)
	struct FNavigationFilterFlags IncludeFlags; // 0x48(0x04)
	struct FNavigationFilterFlags ExcludeFlags; // 0x4c(0x04)
	char pad_50[0x8]; // 0x50(0x08)
};

// Class Engine.DeveloperSettings
// Size: 0x48 (Inherited: 0x38)
struct UDeveloperSettings : UObject {
	char pad_38[0x10]; // 0x38(0x10)
};

// Class Engine.Model
// Size: 0x570 (Inherited: 0x38)
struct UModel : UObject {
	char pad_38[0x538]; // 0x38(0x538)
};

// Class Engine.EngineTypes
// Size: 0x38 (Inherited: 0x38)
struct UEngineTypes : UObject {
};

// Class Engine.EngineBaseTypes
// Size: 0x38 (Inherited: 0x38)
struct UEngineBaseTypes : UObject {
};

// Class Engine.EdGraphNode
// Size: 0xb0 (Inherited: 0x38)
struct UEdGraphNode : UObject {
	char pad_38[0x10]; // 0x38(0x10)
	struct TArray<struct UEdGraphPin_Deprecated*> DeprecatedPins; // 0x48(0x10)
	int32 NodePosX; // 0x58(0x04)
	int32 NodePosY; // 0x5c(0x04)
	int32 NodeWidth; // 0x60(0x04)
	int32 NodeHeight; // 0x64(0x04)
	char bHasCompilerMessage : 1; // 0x68(0x01)
	char pad_68_1 : 7; // 0x68(0x01)
	char pad_69[0x7]; // 0x69(0x07)
	struct FString NodeComment; // 0x70(0x10)
	bool bCommentBubblePinned; // 0x80(0x01)
	bool bCommentBubbleVisible; // 0x81(0x01)
	bool bCommentBubbleMakeVisible; // 0x82(0x01)
	char pad_83[0x1]; // 0x83(0x01)
	int32 ErrorType; // 0x84(0x04)
	struct FString ErrorMsg; // 0x88(0x10)
	struct FGuid NodeGuid; // 0x98(0x10)
	enum class ENodeAdvancedPins AdvancedPinDisplay; // 0xa8(0x01)
	enum class ENodeEnabledState EnabledState; // 0xa9(0x01)
	bool bUserSetEnabledState; // 0xaa(0x01)
	bool bIsNodeEnabled; // 0xab(0x01)
	char pad_AC[0x4]; // 0xac(0x04)
};

// Class Engine.EdGraphPin_Deprecated
// Size: 0x150 (Inherited: 0x38)
struct UEdGraphPin_Deprecated : UObject {
	struct FString PinName; // 0x38(0x10)
	struct FString PinToolTip; // 0x48(0x10)
	enum class EEdGraphPinDirection Direction; // 0x58(0x01)
	char pad_59[0x7]; // 0x59(0x07)
	struct FEdGraphPinType PinType; // 0x60(0x80)
	struct FString DefaultValue; // 0xe0(0x10)
	struct FString AutogeneratedDefaultValue; // 0xf0(0x10)
	struct UObject* DefaultObject; // 0x100(0x08)
	struct FText DefaultTextValue; // 0x108(0x18)
	struct TArray<struct UEdGraphPin_Deprecated*> LinkedTo; // 0x120(0x10)
	struct TArray<struct UEdGraphPin_Deprecated*> SubPins; // 0x130(0x10)
	struct UEdGraphPin_Deprecated* ParentPin; // 0x140(0x08)
	struct UEdGraphPin_Deprecated* ReferencePassThroughConnection; // 0x148(0x08)
};

// Class Engine.Interface_AssetUserData
// Size: 0x38 (Inherited: 0x38)
struct UInterface_AssetUserData : UInterface {
};

// Class Engine.ChildActorComponent
// Size: 0x4e0 (Inherited: 0x4b0)
struct UChildActorComponent : USceneComponent {
	struct UClass* ChildActorClass; // 0x4b0(0x08)
	struct AActor* ChildActor; // 0x4b8(0x08)
	struct AActor* ChildActorTemplate; // 0x4c0(0x08)
	char pad_4C8[0x18]; // 0x4c8(0x18)

	void SetChildActorClass(struct UClass* InClass); // Function Engine.ChildActorComponent.SetChildActorClass // Final|Native|Public|BlueprintCallable // @ game+0x5aff60c
};

// Class Engine.Level
// Size: 0x340 (Inherited: 0x38)
struct ULevel : UObject {
	char pad_38[0x10]; // 0x38(0x10)
	struct TArray<struct FGuid> StreamingTextureGuids; // 0x48(0x10)
	char pad_58[0x30]; // 0x58(0x30)
	struct UMapBuildDataRegistry* MapBuildData; // 0x88(0x08)
	struct ULevelActorContainer* ActorCluster; // 0x90(0x08)
	char pad_98[0x8]; // 0x98(0x08)
	struct UWorld* OwningWorld; // 0xa0(0x08)
	struct TArray<struct UModelComponent*> ModelComponents; // 0xa8(0x10)
	float LightmapTotalSize; // 0xb8(0x04)
	int32 NumTextureStreamingUnbuiltComponents; // 0xbc(0x04)
	char pad_C0[0x8]; // 0xc0(0x08)
	struct FGuid LevelBuildDataId; // 0xc8(0x10)
	char pad_D8[0x8]; // 0xd8(0x08)
	bool bIsLightingScenario; // 0xe0(0x01)
	char pad_E1_0 : 2; // 0xe1(0x01)
	char bTextureStreamingRotationChanged : 1; // 0xe1(0x01)
	char bIsVisible : 1; // 0xe1(0x01)
	char bLocked : 1; // 0xe1(0x01)
	char bIgnoreGridShadowDirtyTest : 1; // 0xe1(0x01)
	char pad_E1_6 : 2; // 0xe1(0x01)
	char pad_E2[0x16]; // 0xe2(0x16)
	struct TArray<struct FVector> StaticNavigableGeometry; // 0xf8(0x10)
	char pad_108[0x78]; // 0x108(0x78)
	int32 NumTextureStreamingDirtyResources; // 0x180(0x04)
	char pad_184[0x14]; // 0x184(0x14)
	struct ALevelScriptActor* LevelScriptActor; // 0x198(0x08)
	float ShadowmapTotalSize; // 0x1a0(0x04)
	char pad_1A4[0x4]; // 0x1a4(0x04)
	struct UModel* Model; // 0x1a8(0x08)
	struct TArray<struct UNavigationDataChunk*> NavDataChunks; // 0x1b0(0x10)
	char pad_1C0[0x48]; // 0x1c0(0x48)
	struct ANavigationObjectBase* NavListEnd; // 0x208(0x08)
	struct ANavigationObjectBase* NavListStart; // 0x210(0x08)
	char pad_218[0x70]; // 0x218(0x70)
	struct FIntVector LightBuildLevelOffset; // 0x288(0x0c)
	char pad_294[0x7c]; // 0x294(0x7c)
	struct AWorldSettings* WorldSettings; // 0x310(0x08)
	char pad_318[0x8]; // 0x318(0x08)
	struct TArray<struct UAssetUserData*> AssetUserData; // 0x320(0x10)
	char pad_330[0x10]; // 0x330(0x10)
};

// Class Engine.AmbientSound
// Size: 0x3f8 (Inherited: 0x3f0)
struct AAmbientSound : AActor {
	struct UAudioComponent* AudioComponent; // 0x3f0(0x08)

	void Stop(); // Function Engine.AmbientSound.Stop // Final|Native|Public|BlueprintCallable // @ game+0x5b049a8
	void Play(float StartTime); // Function Engine.AmbientSound.Play // Final|Native|Public|BlueprintCallable // @ game+0x5af9358
	void FadeOut(float FadeOutDuration, float FadeVolumeLevel); // Function Engine.AmbientSound.FadeOut // Final|Native|Public|BlueprintCallable // @ game+0x5aeade4
	void FadeIn(float FadeInDuration, float FadeVolumeLevel); // Function Engine.AmbientSound.FadeIn // Final|Native|Public|BlueprintCallable // @ game+0x5aeacf4
	void AdjustVolume(float AdjustVolumeDuration, float AdjustVolumeLevel); // Function Engine.AmbientSound.AdjustVolume // Final|Native|Public|BlueprintCallable // @ game+0x5ae4fd4
};

// Class Engine.BrushShape
// Size: 0x428 (Inherited: 0x428)
struct ABrushShape : ABrush {
};

// Class Engine.AudioVolume
// Size: 0x470 (Inherited: 0x428)
struct AAudioVolume : AVolume {
	float Priority; // 0x428(0x04)
	char bEnabled : 1; // 0x42c(0x01)
	char pad_42C_1 : 7; // 0x42c(0x01)
	char pad_42D[0x3]; // 0x42d(0x03)
	struct FReverbSettings Settings; // 0x430(0x18)
	struct FInteriorSettings AmbientZoneSettings; // 0x448(0x24)
	char pad_46C[0x4]; // 0x46c(0x04)

	void SetReverbSettings(struct FReverbSettings NewReverbSettings); // Function Engine.AudioVolume.SetReverbSettings // Final|Native|Public|HasOutParms|BlueprintCallable // @ game+0x5b02e34
	void SetPriority(float NewPriority); // Function Engine.AudioVolume.SetPriority // Final|Native|Public|BlueprintCallable // @ game+0x5b028b8
	void SetInteriorSettings(struct FInteriorSettings NewInteriorSettings); // Function Engine.AudioVolume.SetInteriorSettings // Final|Native|Public|HasOutParms|BlueprintCallable // @ game+0x5b01070
	void SetEnabled(bool bNewEnabled); // Function Engine.AudioVolume.SetEnabled // Final|Native|Public|BlueprintCallable // @ game+0x5b00494
	void OnRep_bEnabled(); // Function Engine.AudioVolume.OnRep_bEnabled // Final|Native|Private // @ game+0x4d2bda0
};

// Class Engine.BlockingVolume
// Size: 0x428 (Inherited: 0x428)
struct ABlockingVolume : AVolume {
};

// Class Engine.CameraBlockingVolume
// Size: 0x428 (Inherited: 0x428)
struct ACameraBlockingVolume : AVolume {
};

// Class Engine.CullDistanceVolume
// Size: 0x450 (Inherited: 0x428)
struct ACullDistanceVolume : AVolume {
	struct TArray<struct FCullDistanceSizePair> CullDistances; // 0x428(0x10)
	char bEnabled : 1; // 0x438(0x01)
	char pad_438_1 : 7; // 0x438(0x01)
	char pad_439[0x3]; // 0x439(0x03)
	float CullDistanceForLODActor; // 0x43c(0x04)
	float CullDistanceForLODActorTooFar; // 0x440(0x04)
	bool bUseActorBound; // 0x444(0x01)
	char pad_445[0x3]; // 0x445(0x03)
	float IgnoreActorBoundSize; // 0x448(0x04)
	char pad_44C[0x4]; // 0x44c(0x04)
};

// Class Engine.LevelStreamingVolume
// Size: 0x440 (Inherited: 0x428)
struct ALevelStreamingVolume : AVolume {
	struct TArray<struct FName> StreamingLevelNames; // 0x428(0x10)
	char bEditorPreVisOnly : 1; // 0x438(0x01)
	char bDisabled : 1; // 0x438(0x01)
	char pad_438_2 : 6; // 0x438(0x01)
	char pad_439[0x3]; // 0x439(0x03)
	enum class EStreamingVolumeUsage StreamingUsage; // 0x43c(0x01)
	char pad_43D[0x3]; // 0x43d(0x03)
};

// Class Engine.LightmassCharacterIndirectDetailVolume
// Size: 0x428 (Inherited: 0x428)
struct ALightmassCharacterIndirectDetailVolume : AVolume {
};

// Class Engine.LightmassImportanceVolume
// Size: 0x428 (Inherited: 0x428)
struct ALightmassImportanceVolume : AVolume {
};

// Class Engine.MeshMergeCullingVolume
// Size: 0x428 (Inherited: 0x428)
struct AMeshMergeCullingVolume : AVolume {
};

// Class Engine.NavigationTypes
// Size: 0x38 (Inherited: 0x38)
struct UNavigationTypes : UObject {
};

// Class Engine.NavMeshBoundsVolume
// Size: 0x430 (Inherited: 0x428)
struct ANavMeshBoundsVolume : AVolume {
	struct FNavAgentSelector SupportedAgents; // 0x428(0x04)
	char pad_42C[0x4]; // 0x42c(0x04)
};

// Class Engine.NavRelevantInterface
// Size: 0x38 (Inherited: 0x38)
struct UNavRelevantInterface : UInterface {
};

// Class Engine.NavArea
// Size: 0x50 (Inherited: 0x38)
struct UNavArea : UObject {
	float DefaultCost; // 0x38(0x04)
	float FixedAreaEnteringCost; // 0x3c(0x04)
	struct FColor DrawColor; // 0x40(0x04)
	struct FNavAgentSelector SupportedAgents; // 0x44(0x04)
	char bSupportsAgent0 : 1; // 0x48(0x01)
	char bSupportsAgent1 : 1; // 0x48(0x01)
	char bSupportsAgent2 : 1; // 0x48(0x01)
	char bSupportsAgent3 : 1; // 0x48(0x01)
	char bSupportsAgent4 : 1; // 0x48(0x01)
	char bSupportsAgent5 : 1; // 0x48(0x01)
	char bSupportsAgent6 : 1; // 0x48(0x01)
	char bSupportsAgent7 : 1; // 0x48(0x01)
	char bSupportsAgent8 : 1; // 0x49(0x01)
	char bSupportsAgent9 : 1; // 0x49(0x01)
	char bSupportsAgent10 : 1; // 0x49(0x01)
	char bSupportsAgent11 : 1; // 0x49(0x01)
	char bSupportsAgent12 : 1; // 0x49(0x01)
	char bSupportsAgent13 : 1; // 0x49(0x01)
	char bSupportsAgent14 : 1; // 0x49(0x01)
	char bSupportsAgent15 : 1; // 0x49(0x01)
	char pad_4A[0x6]; // 0x4a(0x06)
};

// Class Engine.NavModifierVolume
// Size: 0x438 (Inherited: 0x428)
struct ANavModifierVolume : AVolume {
	char pad_428[0x8]; // 0x428(0x08)
	struct UClass* AreaClass; // 0x430(0x08)

	void SetAreaClass(struct UClass* NewAreaClass); // Function Engine.NavModifierVolume.SetAreaClass // Final|Native|Public|BlueprintCallable // @ game+0x5afe06c
};

// Class Engine.DefaultPhysicsVolume
// Size: 0x440 (Inherited: 0x440)
struct ADefaultPhysicsVolume : APhysicsVolume {
};

// Class Engine.KillZVolume
// Size: 0x440 (Inherited: 0x440)
struct AKillZVolume : APhysicsVolume {
};

// Class Engine.PainCausingVolume
// Size: 0x468 (Inherited: 0x440)
struct APainCausingVolume : APhysicsVolume {
	char bPainCausing : 1; // 0x440(0x01)
	char pad_440_1 : 7; // 0x440(0x01)
	char pad_441[0x3]; // 0x441(0x03)
	float DamagePerSec; // 0x444(0x04)
	struct UClass* DamageType; // 0x448(0x08)
	float PainInterval; // 0x450(0x04)
	char bEntryPain : 1; // 0x454(0x01)
	char BACKUP_bPainCausing : 1; // 0x454(0x01)
	char pad_454_2 : 6; // 0x454(0x01)
	char pad_455[0x3]; // 0x455(0x03)
	struct AController* DamageInstigator; // 0x458(0x08)
	char pad_460[0x8]; // 0x460(0x08)
};

// Class Engine.BlendableInterface
// Size: 0x38 (Inherited: 0x38)
struct UBlendableInterface : UInterface {
};

// Class Engine.Scene
// Size: 0x38 (Inherited: 0x38)
struct UScene : UObject {
};

// Class Engine.Interface_PostProcessVolume
// Size: 0x38 (Inherited: 0x38)
struct UInterface_PostProcessVolume : UInterface {
};

// Class Engine.PostProcessVolume
// Size: 0x9b0 (Inherited: 0x428)
struct APostProcessVolume : AVolume {
	char pad_428[0x8]; // 0x428(0x08)
	struct FPostProcessSettings Settings; // 0x430(0x570)
	float Priority; // 0x9a0(0x04)
	float BlendRadius; // 0x9a4(0x04)
	float BlendWeight; // 0x9a8(0x04)
	char bEnabled : 1; // 0x9ac(0x01)
	char bUnbound : 1; // 0x9ac(0x01)
	char pad_9AC_2 : 6; // 0x9ac(0x01)
	char pad_9AD[0x3]; // 0x9ad(0x03)

	void UpdateBlendableByIndex(int32 Index, float InWeight); // Function Engine.PostProcessVolume.UpdateBlendableByIndex // Final|RequiredAPI|Native|Public|BlueprintCallable // @ game+0x5b0555c
	void AddOrUpdateBlendable(TScriptInterface<struct UBlendableInterface> InBlendableObject, float InWeight); // Function Engine.PostProcessVolume.AddOrUpdateBlendable // Final|RequiredAPI|Native|Public|BlueprintCallable // @ game+0x5ae45b8
};

// Class Engine.PrecomputedVisibilityOverrideVolume
// Size: 0x458 (Inherited: 0x428)
struct APrecomputedVisibilityOverrideVolume : AVolume {
	struct TArray<struct AActor*> OverrideVisibleActors; // 0x428(0x10)
	struct TArray<struct AActor*> OverrideInvisibleActors; // 0x438(0x10)
	struct TArray<struct FName> OverrideInvisibleLevels; // 0x448(0x10)
};

// Class Engine.PrecomputedVisibilityVolume
// Size: 0x428 (Inherited: 0x428)
struct APrecomputedVisibilityVolume : AVolume {
};

// Class Engine.TriggerVolume
// Size: 0x428 (Inherited: 0x428)
struct ATriggerVolume : AVolume {
};

// Class Engine.NavAgentInterface
// Size: 0x38 (Inherited: 0x38)
struct UNavAgentInterface : UInterface {
};

// Class Engine.CameraShake
// Size: 0x170 (Inherited: 0x38)
struct UCameraShake : UObject {
	char bSingleInstance : 1; // 0x38(0x01)
	char pad_38_1 : 7; // 0x38(0x01)
	char pad_39[0x3]; // 0x39(0x03)
	float OscillationDuration; // 0x3c(0x04)
	float OscillationBlendInTime; // 0x40(0x04)
	float OscillationBlendOutTime; // 0x44(0x04)
	struct FROscillator RotOscillation; // 0x48(0x24)
	struct FVOscillator LocOscillation; // 0x6c(0x24)
	struct FFOscillator FOVOscillation; // 0x90(0x0c)
	float AnimPlayRate; // 0x9c(0x04)
	float AnimScale; // 0xa0(0x04)
	float AnimBlendInTime; // 0xa4(0x04)
	float AnimBlendOutTime; // 0xa8(0x04)
	float RandomAnimSegmentDuration; // 0xac(0x04)
	struct UCameraAnim* Anim; // 0xb0(0x08)
	char bRandomAnimSegment : 1; // 0xb8(0x01)
	char pad_B8_1 : 7; // 0xb8(0x01)
	char pad_B9[0x17]; // 0xb9(0x17)
	struct APlayerCameraManager* CameraOwner; // 0xd0(0x08)
	char pad_D8[0x80]; // 0xd8(0x80)
	float ShakeScale; // 0x158(0x04)
	float OscillatorTimeRemaining; // 0x15c(0x04)
	struct UCameraAnimInst* AnimInst; // 0x160(0x08)
	char pad_168[0x8]; // 0x168(0x08)

	void ReceiveStopShake(bool bImmediately); // Function Engine.CameraShake.ReceiveStopShake // Event|Public|BlueprintEvent // @ game+0x33e45c
	void ReceivePlayShake(float Scale); // Function Engine.CameraShake.ReceivePlayShake // Event|Public|BlueprintEvent // @ game+0x33e45c
	bool ReceiveIsFinished(); // Function Engine.CameraShake.ReceiveIsFinished // Native|Event|Public|BlueprintEvent|Const // @ game+0xc218c0
	void BlueprintUpdateCameraShake(float DeltaTime, float ALPHA, struct FMinimalViewInfo POV, struct FMinimalViewInfo ModifiedPOV); // Function Engine.CameraShake.BlueprintUpdateCameraShake // Event|Public|HasOutParms|BlueprintEvent // @ game+0x33e45c
};

// Class Engine.InputComponent
// Size: 0x280 (Inherited: 0x200)
struct UInputComponent : UActorComponent {
	char pad_200[0x80]; // 0x200(0x80)

	bool WasControllerKeyJustReleased(struct FKey Key); // Function Engine.InputComponent.WasControllerKeyJustReleased // Final|Native|Private|BlueprintCallable|BlueprintPure|Const // @ game+0x5af2248
	bool WasControllerKeyJustPressed(struct FKey Key); // Function Engine.InputComponent.WasControllerKeyJustPressed // Final|Native|Private|BlueprintCallable|BlueprintPure|Const // @ game+0x5af2248
	bool IsControllerKeyDown(struct FKey Key); // Function Engine.InputComponent.IsControllerKeyDown // Final|Native|Private|BlueprintCallable|BlueprintPure|Const // @ game+0x5af2248
	void GetTouchState(int32 FingerIndex, float LocationX, float LocationY, bool bIsCurrentlyPressed); // Function Engine.InputComponent.GetTouchState // Final|Native|Private|HasOutParms|BlueprintCallable|BlueprintPure|Const // @ game+0x5af1650
	struct FVector GetControllerVectorKeyState(struct FKey Key); // Function Engine.InputComponent.GetControllerVectorKeyState // Final|Native|Private|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5aed748
	void GetControllerMouseDelta(float DeltaX, float DeltaY); // Function Engine.InputComponent.GetControllerMouseDelta // Final|Native|Private|HasOutParms|BlueprintCallable|BlueprintPure|Const // @ game+0x5aed678
	float GetControllerKeyTimeDown(struct FKey Key); // Function Engine.InputComponent.GetControllerKeyTimeDown // Final|Native|Private|BlueprintCallable|BlueprintPure|Const // @ game+0x5aed458
	void GetControllerAnalogStickState(enum class EControllerAnalogStick WhichStick, float StickX, float StickY); // Function Engine.InputComponent.GetControllerAnalogStickState // Final|Native|Private|HasOutParms|BlueprintCallable|BlueprintPure|Const // @ game+0x5aed560
	float GetControllerAnalogKeyState(struct FKey Key); // Function Engine.InputComponent.GetControllerAnalogKeyState // Final|Native|Private|BlueprintCallable|BlueprintPure|Const // @ game+0x5aed458
};

// Class Engine.CurveFloat
// Size: 0xb8 (Inherited: 0x40)
struct UCurveFloat : UCurveBase {
	struct FRichCurve FloatCurve; // 0x40(0x70)
	bool bIsEventCurve; // 0xb0(0x01)
	char pad_B1[0x7]; // 0xb1(0x07)

	float GetFloatValue(float InTime); // Function Engine.CurveFloat.GetFloatValue // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x2d23d8
	float GetDerivative(float InTime); // Function Engine.CurveFloat.GetDerivative // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5aed8d4
};

// Class Engine.DecalActor
// Size: 0x3f8 (Inherited: 0x3f0)
struct ADecalActor : AActor {
	struct UDecalComponent* Decal; // 0x3f0(0x08)

	void SetDecalMaterial(struct UMaterialInterface* NewDecalMaterial); // Function Engine.DecalActor.SetDecalMaterial // Final|Native|Public|BlueprintCallable // @ game+0x5b001f0
	struct UMaterialInterface* GetDecalMaterial(); // Function Engine.DecalActor.GetDecalMaterial // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5aed8ac
	struct UMaterialInstanceDynamic* CreateDynamicMaterialInstance(); // Function Engine.DecalActor.CreateDynamicMaterialInstance // Native|Public|BlueprintCallable // @ game+0x4d25038
};

// Class Engine.DestructibleActor
// Size: 0x410 (Inherited: 0x3f0)
struct ADestructibleActor : AActor {
	struct UDestructibleComponent* DestructibleComponent; // 0x3f0(0x08)
	char bAffectNavigation : 1; // 0x3f8(0x01)
	char pad_3F8_1 : 7; // 0x3f8(0x01)
	char pad_3F9[0x7]; // 0x3f9(0x07)
	struct FMulticastDelegate OnActorFracture; // 0x400(0x10)
};

// Class Engine.DistanceFieldCapture
// Size: 0x3f8 (Inherited: 0x3f0)
struct ADistanceFieldCapture : AActor {
	struct UDistanceFieldCaptureComponent* CaptureComponent; // 0x3f0(0x08)
};

// Class Engine.DocumentationActor
// Size: 0x3f8 (Inherited: 0x3f0)
struct ADocumentationActor : AActor {
	char pad_3F0[0x8]; // 0x3f0(0x08)
};

// Class Engine.Emitter
// Size: 0x440 (Inherited: 0x3f0)
struct AEmitter : AActor {
	struct UParticleSystemComponent* ParticleSystemComponent; // 0x3f0(0x08)
	char bDestroyOnSystemFinish : 1; // 0x3f8(0x01)
	char bPostUpdateTickGroup : 1; // 0x3f8(0x01)
	char bCurrentlyActive : 1; // 0x3f8(0x01)
	char pad_3F8_3 : 5; // 0x3f8(0x01)
	char pad_3F9[0x7]; // 0x3f9(0x07)
	struct FMulticastDelegate OnParticleSpawn; // 0x400(0x10)
	struct FMulticastDelegate OnParticleBurst; // 0x410(0x10)
	struct FMulticastDelegate OnParticleDeath; // 0x420(0x10)
	struct FMulticastDelegate OnParticleCollide; // 0x430(0x10)

	void ToggleActive(); // Function Engine.Emitter.ToggleActive // Final|Native|Public|BlueprintCallable // @ game+0x5b05224
	void SetVectorParameter(struct FName ParameterName, struct FVector Param); // Function Engine.Emitter.SetVectorParameter // Final|Native|Public|HasDefaults|BlueprintCallable // @ game+0x5b039d4
	void SetTemplate(struct UParticleSystem* NewTemplate); // Function Engine.Emitter.SetTemplate // Native|Public|BlueprintCallable // @ game+0x5b031e0
	void SetMaterialParameter(struct FName ParameterName, struct UMaterialInterface* Param); // Function Engine.Emitter.SetMaterialParameter // Final|Native|Public|BlueprintCallable // @ game+0x5b01abc
	void SetFloatParameter(struct FName ParameterName, float Param); // Function Engine.Emitter.SetFloatParameter // Final|Native|Public|BlueprintCallable // @ game+0x5b005e8
	void SetColorParameter(struct FName ParameterName, struct FLinearColor Param); // Function Engine.Emitter.SetColorParameter // Final|Native|Public|HasDefaults|BlueprintCallable // @ game+0x5affc14
	void SetActorParameter(struct FName ParameterName, struct AActor* Param); // Function Engine.Emitter.SetActorParameter // Final|Native|Public|BlueprintCallable // @ game+0x5afd7d4
	void OnRep_bCurrentlyActive(); // Function Engine.Emitter.OnRep_bCurrentlyActive // Native|Public // @ game+0x815b50
	void OnParticleSystemFinished(struct UParticleSystemComponent* FinishedComponent); // Function Engine.Emitter.OnParticleSystemFinished // Native|Public // @ game+0x4d43554
	bool IsActive(); // Function Engine.Emitter.IsActive // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5af1fac
	void Deactivate(); // Function Engine.Emitter.Deactivate // Final|Native|Public|BlueprintCallable // @ game+0x5ae8ab4
	void Activate(); // Function Engine.Emitter.Activate // Final|Native|Public|BlueprintCallable // @ game+0x5ae2e48
};

// Class Engine.EmitterCameraLensEffectBase
// Size: 0x4b0 (Inherited: 0x440)
struct AEmitterCameraLensEffectBase : AEmitter {
	struct UParticleSystem* PS_CameraEffect; // 0x440(0x08)
	struct UParticleSystem* PS_CameraEffectNonExtremeContent; // 0x448(0x08)
	struct APlayerCameraManager* BaseCamera; // 0x450(0x08)
	char pad_458[0x8]; // 0x458(0x08)
	struct FTransform RelativeTransform; // 0x460(0x30)
	float BaseFOV; // 0x490(0x04)
	char bAllowMultipleInstances : 1; // 0x494(0x01)
	char bResetWhenRetriggered : 1; // 0x494(0x01)
	char pad_494_2 : 6; // 0x494(0x01)
	char pad_495[0x3]; // 0x495(0x03)
	struct TArray<struct UClass*> EmittersToTreatAsSame; // 0x498(0x10)
	float DistFromCamera; // 0x4a8(0x04)
	char pad_4AC[0x4]; // 0x4ac(0x04)
};

// Class Engine.FoliageBlockingVolumeActor
// Size: 0x3f8 (Inherited: 0x3f0)
struct AFoliageBlockingVolumeActor : AActor {
	struct UFoliageBlockingVolumeComponent* FoliageBlockingVolumeComponent; // 0x3f0(0x08)
};

// Class Engine.DebugCameraHUD
// Size: 0x4d8 (Inherited: 0x4d8)
struct ADebugCameraHUD : AHUD {
};

// Class Engine.AtmosphericFog
// Size: 0x3f8 (Inherited: 0x3f0)
struct AAtmosphericFog : AInfo {
	struct UAtmosphericFogComponent* AtmosphericFogComponent; // 0x3f0(0x08)
};

// Class Engine.ExponentialHeightFog
// Size: 0x400 (Inherited: 0x3f0)
struct AExponentialHeightFog : AInfo {
	struct UExponentialHeightFogComponent* Component; // 0x3f0(0x08)
	char bEnabled : 1; // 0x3f8(0x01)
	char pad_3F8_1 : 7; // 0x3f8(0x01)
	char pad_3F9[0x7]; // 0x3f9(0x07)

	void OnRep_bEnabled(); // Function Engine.ExponentialHeightFog.OnRep_bEnabled // Native|Public // @ game+0xe3d10c
};

// Class Engine.GameNetworkManager
// Size: 0x478 (Inherited: 0x3f0)
struct AGameNetworkManager : AInfo {
	int32 AdjustedNetSpeed; // 0x3f0(0x04)
	float LastNetSpeedUpdateTime; // 0x3f4(0x04)
	int32 TotalNetBandwidth; // 0x3f8(0x04)
	int32 MinDynamicBandwidth; // 0x3fc(0x04)
	int32 MaxDynamicBandwidth; // 0x400(0x04)
	char bIsStandbyCheckingEnabled : 1; // 0x404(0x01)
	char bHasStandbyCheatTriggered : 1; // 0x404(0x01)
	char pad_404_2 : 6; // 0x404(0x01)
	char pad_405[0x3]; // 0x405(0x03)
	float StandbyRxCheatTime; // 0x408(0x04)
	float StandbyTxCheatTime; // 0x40c(0x04)
	int32 BadPingThreshold; // 0x410(0x04)
	float PercentMissingForRxStandby; // 0x414(0x04)
	float PercentMissingForTxStandby; // 0x418(0x04)
	float PercentForBadPing; // 0x41c(0x04)
	float JoinInProgressStandbyWaitTime; // 0x420(0x04)
	float MoveRepSize; // 0x424(0x04)
	float MAXPOSITIONERRORSQUARED; // 0x428(0x04)
	float MAXNEARZEROVELOCITYSQUARED; // 0x42c(0x04)
	float CLIENTADJUSTUPDATECOST; // 0x430(0x04)
	float MAXCLIENTUPDATEINTERVAL; // 0x434(0x04)
	float MaxMoveDeltaTime; // 0x438(0x04)
	float ClientNetSendMoveDeltaTime; // 0x43c(0x04)
	float ClientNetSendMoveDeltaTimeThrottled; // 0x440(0x04)
	int32 ClientNetSendMoveThrottleAtNetSpeed; // 0x444(0x04)
	int32 ClientNetSendMoveThrottleOverPlayerCount; // 0x448(0x04)
	bool ClientAuthorativePosition; // 0x44c(0x01)
	char pad_44D[0x3]; // 0x44d(0x03)
	float ClientErrorUpdateRateLimit; // 0x450(0x04)
	bool bMovementTimeDiscrepancyDetection; // 0x454(0x01)
	bool bMovementTimeDiscrepancyResolution; // 0x455(0x01)
	char pad_456[0x2]; // 0x456(0x02)
	float MovementTimeDiscrepancyResolutionMinFPS; // 0x458(0x04)
	float MovementTimeDiscrepancyMaxTimeMargin; // 0x45c(0x04)
	float MovementTimeDiscrepancyMinTimeMargin; // 0x460(0x04)
	float MovementTimeDiscrepancyResolutionRate; // 0x464(0x04)
	float MovementTimeDiscrepancyDriftAllowance; // 0x468(0x04)
	bool bMovementTimeDiscrepancyForceCorrectionsDuringResolution; // 0x46c(0x01)
	bool bUseDistanceBasedRelevancy; // 0x46d(0x01)
	char pad_46E[0xa]; // 0x46e(0x0a)
};

// Class Engine.SkyLight
// Size: 0x400 (Inherited: 0x3f0)
struct ASkyLight : AInfo {
	struct USkyLightComponent* LightComponent; // 0x3f0(0x08)
	char bEnabled : 1; // 0x3f8(0x01)
	char pad_3F8_1 : 7; // 0x3f8(0x01)
	char pad_3F9[0x7]; // 0x3f9(0x07)

	void OnRep_bEnabled(); // Function Engine.SkyLight.OnRep_bEnabled // Native|Public // @ game+0xe3d10c
};

// Class Engine.WindDirectionalSource
// Size: 0x3f8 (Inherited: 0x3f0)
struct AWindDirectionalSource : AInfo {
	struct UWindDirectionalSourceComponent* Component; // 0x3f0(0x08)
};

// Class Engine.WorldSettings
// Size: 0x5e0 (Inherited: 0x3f0)
struct AWorldSettings : AInfo {
	char pad_3F0[0x8]; // 0x3f0(0x08)
	char bEnableWorldBoundsChecks : 1; // 0x3f8(0x01)
	char bEnableNavigationSystem : 1; // 0x3f8(0x01)
	char bEnableAISystem : 1; // 0x3f8(0x01)
	char bEnableWorldComposition : 1; // 0x3f8(0x01)
	char bUseClientSideLevelStreamingVolumes : 1; // 0x3f8(0x01)
	char bEnableWorldOriginRebasing : 1; // 0x3f8(0x01)
	char bWorldGravitySet : 1; // 0x3f8(0x01)
	char bGlobalGravitySet : 1; // 0x3f8(0x01)
	char pad_3F9[0x3]; // 0x3f9(0x03)
	float KillZ; // 0x3fc(0x04)
	struct AInfo* LevelAttribute; // 0x400(0x08)
	struct UClass* KillZDamageType; // 0x408(0x08)
	float WorldGravityZ; // 0x410(0x04)
	float GlobalGravityZ; // 0x414(0x04)
	struct UClass* DefaultPhysicsVolumeClass; // 0x418(0x08)
	struct UClass* PhysicsCollisionHandlerClass; // 0x420(0x08)
	struct UClass* DefaultGameMode; // 0x428(0x08)
	struct UClass* GameNetworkManagerClass; // 0x430(0x08)
	int32 PackedLightAndShadowMapTextureSize; // 0x438(0x04)
	char bMinimizeBSPSections : 1; // 0x43c(0x01)
	char pad_43C_1 : 7; // 0x43c(0x01)
	char pad_43D[0x3]; // 0x43d(0x03)
	struct FVector DefaultColorScale; // 0x440(0x0c)
	float DefaultMaxDistanceFieldOcclusionDistance; // 0x44c(0x04)
	float GlobalDistanceFieldViewDistance; // 0x450(0x04)
	float DynamicIndirectShadowsSelfShadowingIntensity; // 0x454(0x04)
	char bPrecomputeVisibility : 1; // 0x458(0x01)
	char bPlaceCellsOnlyAlongCameraTracks : 1; // 0x458(0x01)
	char pad_458_2 : 6; // 0x458(0x01)
	char pad_459[0x3]; // 0x459(0x03)
	int32 VisibilityCellSize; // 0x45c(0x04)
	enum class EVisibilityAggressiveness VisibilityAggressiveness; // 0x460(0x01)
	char pad_461[0x3]; // 0x461(0x03)
	char bForceNoPrecomputedLighting : 1; // 0x464(0x01)
	char pad_464_1 : 7; // 0x464(0x01)
	char pad_465[0x3]; // 0x465(0x03)
	struct FLightmassWorldInfoSettings LightmassSettings; // 0x468(0x44)
	char pad_4AC[0x4]; // 0x4ac(0x04)
	struct FReverbSettings DefaultReverbSettings; // 0x4b0(0x18)
	struct FInteriorSettings DefaultAmbientZoneSettings; // 0x4c8(0x24)
	char pad_4EC[0x4]; // 0x4ec(0x04)
	struct USoundMix* DefaultBaseSoundMix; // 0x4f0(0x08)
	float WorldToMeters; // 0x4f8(0x04)
	float MonoCullingDistance; // 0x4fc(0x04)
	struct UBookMark* BookMarks[0x0a]; // 0x500(0x50)
	struct UExtendedReflectionSettings* ReflectionSettings; // 0x550(0x08)
	float TimeDilation; // 0x558(0x04)
	float MatineeTimeDilation; // 0x55c(0x04)
	float DemoPlayTimeDilation; // 0x560(0x04)
	float MinGlobalTimeDilation; // 0x564(0x04)
	float MaxGlobalTimeDilation; // 0x568(0x04)
	char pad_56C[0x8]; // 0x56c(0x08)
	struct FBox MBPBounds; // 0x574(0x1c)
	char bOverrideDefaultBroadphaseSettings : 1; // 0x590(0x01)
	char pad_590_1 : 7; // 0x590(0x01)
	char pad_591[0x3]; // 0x591(0x03)
	char bHighPriorityLoading : 1; // 0x594(0x01)
	char bHighPriorityLoadingLocal : 1; // 0x594(0x01)
	char pad_594_2 : 6; // 0x594(0x01)
	char pad_595[0x3]; // 0x595(0x03)
	struct TArray<struct FNetViewer> ReplicationViewers; // 0x598(0x10)
	struct FMulticastDelegate OnPause; // 0x5a8(0x10)
	struct FMulticastDelegate OnResume; // 0x5b8(0x10)
	struct TArray<struct UAssetUserData*> AssetUserData; // 0x5c8(0x10)
	struct APlayerState* Pauser; // 0x5d8(0x08)

	void TakeMBPBounds(); // Function Engine.WorldSettings.TakeMBPBounds // Native|Event|Public|BlueprintEvent // @ game+0xe3d10c
	void OnRep_WorldGravityZ(); // Function Engine.WorldSettings.OnRep_WorldGravityZ // Native|Public // @ game+0x815b50
};

// Class Engine.InstancedDeferredDecalActor
// Size: 0x428 (Inherited: 0x3f0)
struct AInstancedDeferredDecalActor : AActor {
	bool bUseInstancePool; // 0x3f0(0x01)
	bool bUseDynamicInstance; // 0x3f1(0x01)
	char pad_3F2[0x6]; // 0x3f2(0x06)
	struct UMaterialInterface* SharedMaterial; // 0x3f8(0x08)
	struct UInstancedDeferredDecalComponent* RootDecalComponent; // 0x400(0x08)
	struct TArray<struct UInstancedDeferredDecalComponent*> decals; // 0x408(0x10)
	char pad_418[0x10]; // 0x418(0x10)

	void SetUseInstancePool(bool bUse); // Function Engine.InstancedDeferredDecalActor.SetUseInstancePool // Final|Native|Public|BlueprintCallable // @ game+0x5b03944
	void SetUseDynamicInstance(bool bUse); // Function Engine.InstancedDeferredDecalActor.SetUseDynamicInstance // Final|Native|Public|BlueprintCallable // @ game+0x4de6408
	void SetDecalMaterial(struct UMaterialInterface* NewDecalMaterial); // Function Engine.InstancedDeferredDecalActor.SetDecalMaterial // Final|Native|Public|BlueprintCallable // @ game+0x5b00288
	bool GetUseInstancePool(); // Function Engine.InstancedDeferredDecalActor.GetUseInstancePool // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x4de062c
	bool GetUseDynamicInstance(); // Function Engine.InstancedDeferredDecalActor.GetUseDynamicInstance // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x4de0644
	struct UMaterialInterface* GetDecalMaterial(); // Function Engine.InstancedDeferredDecalActor.GetDecalMaterial // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x4d4aa50
	struct UMaterialInstanceDynamic* CreateDynamicMaterialInstance(); // Function Engine.InstancedDeferredDecalActor.CreateDynamicMaterialInstance // Native|Public|BlueprintCallable // @ game+0x4d25038
	void AddInstance(struct FVector4 InstanceTransform, struct FVector DecalSize); // Function Engine.InstancedDeferredDecalActor.AddInstance // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5ae42b4
};

// Class Engine.InstancedSplineDecalActor
// Size: 0x3f8 (Inherited: 0x3f0)
struct AInstancedSplineDecalActor : AActor {
	struct UInstancedSplineDecalComponent* InstancedSplineDecalComponent; // 0x3f0(0x08)
};

// Class Engine.LevelBlockLandscapeGizmoActor
// Size: 0x3f8 (Inherited: 0x3f0)
struct ALevelBlockLandscapeGizmoActor : AActor {
	struct ULevelBlockLandscapeGizmoComponent* LandscapeGizmoComponent; // 0x3f0(0x08)
};

// Class Engine.LevelBlocksDataActor
// Size: 0x3f8 (Inherited: 0x3f0)
struct ALevelBlocksDataActor : AActor {
	struct ULevelBlocksDataComponent* LevelBlocksDataComponent; // 0x3f0(0x08)
};

// Class Engine.LevelBlockSpawnedActor
// Size: 0x3f0 (Inherited: 0x3f0)
struct ALevelBlockSpawnedActor : AActor {
};

// Class Engine.LevelBlockSpawnPointActor
// Size: 0x3f8 (Inherited: 0x3f0)
struct ALevelBlockSpawnPointActor : AActor {
	struct ULevelBlockSpawnPointComponent* SpawnPointComponent; // 0x3f0(0x08)
};

// Class Engine.LevelBounds
// Size: 0x3f8 (Inherited: 0x3f0)
struct ALevelBounds : AActor {
	bool bAutoUpdateBounds; // 0x3f0(0x01)
	char pad_3F1[0x7]; // 0x3f1(0x07)
};

// Class Engine.Light
// Size: 0x400 (Inherited: 0x3f0)
struct ALight : AActor {
	struct ULightComponent* LightComponent; // 0x3f0(0x08)
	char bEnabled : 1; // 0x3f8(0x01)
	char pad_3F8_1 : 7; // 0x3f8(0x01)
	char pad_3F9[0x7]; // 0x3f9(0x07)

	void ToggleEnabled(); // Function Engine.Light.ToggleEnabled // Final|Native|Public|BlueprintCallable // @ game+0x5b052a0
	void SetLightFunctionScale(struct FVector NewLightFunctionScale); // Function Engine.Light.SetLightFunctionScale // Final|Native|Public|HasDefaults|BlueprintCallable // @ game+0x5b01550
	void SetLightFunctionMaterial(struct UMaterialInterface* NewLightFunctionMaterial); // Function Engine.Light.SetLightFunctionMaterial // Final|Native|Public|BlueprintCallable // @ game+0x5b014bc
	void SetLightFunctionFadeDistance(float NewLightFunctionFadeDistance); // Function Engine.Light.SetLightFunctionFadeDistance // Final|Native|Public|BlueprintCallable // @ game+0x5b01420
	void SetLightColor(struct FLinearColor NewLightColor); // Function Engine.Light.SetLightColor // Final|Native|Public|HasDefaults|BlueprintCallable // @ game+0x5b012ec
	void SetEnabled(bool bSetEnabled); // Function Engine.Light.SetEnabled // Final|Native|Public|BlueprintCallable // @ game+0x5b00550
	void SetCastShadows(bool bNewValue); // Function Engine.Light.SetCastShadows // Final|Native|Public|BlueprintCallable // @ game+0x5aff484
	void SetBrightness(float NewBrightness); // Function Engine.Light.SetBrightness // Final|Native|Public|BlueprintCallable // @ game+0x5aff240
	void SetAffectTranslucentLighting(bool bNewValue); // Function Engine.Light.SetAffectTranslucentLighting // Final|Native|Public|BlueprintCallable // @ game+0x5afdc0c
	void OnRep_bEnabled(); // Function Engine.Light.OnRep_bEnabled // Native|Public // @ game+0xe3d10c
	bool IsEnabled(); // Function Engine.Light.IsEnabled // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5af2378
	struct FLinearColor GetLightColor(); // Function Engine.Light.GetLightColor // Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5aef580
	float GetBrightness(); // Function Engine.Light.GetBrightness // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5aecad8
};

// Class Engine.DirectionalLight
// Size: 0x400 (Inherited: 0x400)
struct ADirectionalLight : ALight {
};

// Class Engine.PointLight
// Size: 0x408 (Inherited: 0x400)
struct APointLight : ALight {
	struct UPointLightComponent* PointLightComponent; // 0x400(0x08)

	void SetRadius(float NewRadius); // Function Engine.PointLight.SetRadius // Final|RequiredAPI|Native|Public|BlueprintCallable // @ game+0x5b029e8
	void SetLightFalloffExponent(float NewLightFalloffExponent); // Function Engine.PointLight.SetLightFalloffExponent // Final|RequiredAPI|Native|Public|BlueprintCallable // @ game+0x5b01384
};

// Class Engine.spotlight
// Size: 0x408 (Inherited: 0x400)
struct Aspotlight : ALight {
	struct USpotLightComponent* SpotLightComponent; // 0x400(0x08)

	void SetOuterConeAngle(float NewOuterConeAngle); // Function Engine.spotlight.SetOuterConeAngle // Final|Native|Public|BlueprintCallable // @ game+0x5b020e8
	void SetInnerConeAngle(float NewInnerConeAngle); // Function Engine.spotlight.SetInnerConeAngle // Final|Native|Public|BlueprintCallable // @ game+0x5b00fd4
};

// Class Engine.GeneratedMeshAreaLight
// Size: 0x408 (Inherited: 0x408)
struct AGeneratedMeshAreaLight : Aspotlight {
};

// Class Engine.LightmassPortal
// Size: 0x3f8 (Inherited: 0x3f0)
struct ALightmassPortal : AActor {
	struct ULightmassPortalComponent* PortalComponent; // 0x3f0(0x08)
};

// Class Engine.LODActor
// Size: 0x428 (Inherited: 0x3f0)
struct ALODActor : AActor {
	struct UStaticMeshComponent* StaticMeshComponent; // 0x3f0(0x08)
	struct TArray<struct AActor*> SubActors; // 0x3f8(0x10)
	float LODDrawDistance; // 0x408(0x04)
	int32 LODLevel; // 0x40c(0x04)
	struct TArray<struct UObject*> SubObjects; // 0x410(0x10)
	char pad_420[0x8]; // 0x420(0x08)
};

// Class Engine.MaterialInstanceActor
// Size: 0x400 (Inherited: 0x3f0)
struct AMaterialInstanceActor : AActor {
	struct TArray<struct AActor*> TargetActors; // 0x3f0(0x10)
};

// Class Engine.MatineeActor
// Size: 0x498 (Inherited: 0x3f0)
struct AMatineeActor : AActor {
	struct UInterpData* MatineeData; // 0x3f0(0x08)
	struct FName MatineeControllerName; // 0x3f8(0x08)
	float PlayRate; // 0x400(0x04)
	char bPlayOnLevelLoad : 1; // 0x404(0x01)
	char bForceStartPos : 1; // 0x404(0x01)
	char pad_404_2 : 6; // 0x404(0x01)
	char pad_405[0x3]; // 0x405(0x03)
	float ForceStartPosition; // 0x408(0x04)
	char bLooping : 1; // 0x40c(0x01)
	char bRewindOnPlay : 1; // 0x40c(0x01)
	char bNoResetOnRewind : 1; // 0x40c(0x01)
	char bRewindIfAlreadyPlaying : 1; // 0x40c(0x01)
	char bDisableRadioFilter : 1; // 0x40c(0x01)
	char bClientSideOnly : 1; // 0x40c(0x01)
	char bSkipUpdateIfNotVisible : 1; // 0x40c(0x01)
	char bIsSkippable : 1; // 0x40c(0x01)
	char pad_40D[0x3]; // 0x40d(0x03)
	int32 PreferredSplitScreenNum; // 0x410(0x04)
	char bDisableMovementInput : 1; // 0x414(0x01)
	char bDisableLookAtInput : 1; // 0x414(0x01)
	char bHidePlayer : 1; // 0x414(0x01)
	char bHideHud : 1; // 0x414(0x01)
	char pad_414_4 : 4; // 0x414(0x01)
	char pad_415[0x3]; // 0x415(0x03)
	struct TArray<struct FInterpGroupActorInfo> GroupActorInfos; // 0x418(0x10)
	char bShouldShowGore : 1; // 0x428(0x01)
	char pad_428_1 : 7; // 0x428(0x01)
	char pad_429[0x7]; // 0x429(0x07)
	struct TArray<struct UInterpGroupInst*> GroupInst; // 0x430(0x10)
	struct TArray<struct FCameraCutInfo> CameraCuts; // 0x440(0x10)
	char bIsPlaying : 1; // 0x450(0x01)
	char bReversePlayback : 1; // 0x450(0x01)
	char bPaused : 1; // 0x450(0x01)
	char bPendingStop : 1; // 0x450(0x01)
	char pad_450_4 : 4; // 0x450(0x01)
	char pad_451[0x3]; // 0x451(0x03)
	float InterpPosition; // 0x454(0x04)
	char pad_458[0x4]; // 0x458(0x04)
	bool ReplicationForceIsPlaying; // 0x45c(0x01)
	char pad_45D[0x3]; // 0x45d(0x03)
	struct FMulticastDelegate OnPlay; // 0x460(0x10)
	struct FMulticastDelegate OnStop; // 0x470(0x10)
	struct FMulticastDelegate OnPause; // 0x480(0x10)
	char pad_490[0x8]; // 0x490(0x08)

	void Stop(); // Function Engine.MatineeActor.Stop // Native|Public|BlueprintCallable // @ game+0x815938
	void SetPosition(float NewPosition, bool bJump); // Function Engine.MatineeActor.SetPosition // Final|Native|Public|BlueprintCallable // @ game+0xd2d474
	void SetLoopingState(bool bNewLooping); // Function Engine.MatineeActor.SetLoopingState // Native|Public|BlueprintCallable // @ game+0xde7440
	void Reverse(); // Function Engine.MatineeActor.Reverse // Native|Public|BlueprintCallable // @ game+0x769f14
	void Play(); // Function Engine.MatineeActor.Play // Native|Public|BlueprintCallable // @ game+0x815b50
	void Pause(); // Function Engine.MatineeActor.Pause // Native|Public|BlueprintCallable // @ game+0x4d679f8
	void EnableGroupByName(struct FString GroupName, bool bEnable); // Function Engine.MatineeActor.EnableGroupByName // Final|Native|Public|BlueprintCallable // @ game+0x5aeaa50
	void ChangePlaybackDirection(); // Function Engine.MatineeActor.ChangePlaybackDirection // Native|Public|BlueprintCallable // @ game+0x4d2bda0
};

// Class Engine.MatineeActorCameraAnim
// Size: 0x4a0 (Inherited: 0x498)
struct AMatineeActorCameraAnim : AMatineeActor {
	struct UCameraAnim* CameraAnim; // 0x498(0x08)
};

// Class Engine.MinimapLabelActor
// Size: 0x3f8 (Inherited: 0x3f0)
struct AMinimapLabelActor : AActor {
	struct UMinimapLabelComponent* MinimapLabelComponent; // 0x3f0(0x08)
};

// Class Engine.MinimapObjectActor
// Size: 0x3f8 (Inherited: 0x3f0)
struct AMinimapObjectActor : AActor {
	struct UMinimapObjectComponent* MinimapObjectComponent; // 0x3f0(0x08)
};

// Class Engine.AbstractNavData
// Size: 0x598 (Inherited: 0x598)
struct AAbstractNavData : ANavigationData {
};

// Class Engine.NavigationGraph
// Size: 0x598 (Inherited: 0x598)
struct ANavigationGraph : ANavigationData {
};

// Class Engine.NavigationGraphNode
// Size: 0x3f0 (Inherited: 0x3f0)
struct ANavigationGraphNode : AActor {
};

// Class Engine.PlayerStartPIE
// Size: 0x420 (Inherited: 0x420)
struct APlayerStartPIE : APlayerStart {
};

// Class Engine.NavPathObserverInterface
// Size: 0x38 (Inherited: 0x38)
struct UNavPathObserverInterface : UInterface {
};

// Class Engine.NavigationTestingActor
// Size: 0x500 (Inherited: 0x3f0)
struct ANavigationTestingActor : AActor {
	char pad_3F0[0x10]; // 0x3f0(0x10)
	struct UCapsuleComponent* CapsuleComponent; // 0x400(0x08)
	struct UNavigationInvokerComponent* InvokerComponent; // 0x408(0x08)
	char bActAsNavigationInvoker : 1; // 0x410(0x01)
	char pad_410_1 : 7; // 0x410(0x01)
	char pad_411[0x7]; // 0x411(0x07)
	struct FNavAgentProperties NavAgentProps; // 0x418(0x20)
	struct FVector QueryingExtent; // 0x438(0x0c)
	char pad_444[0x4]; // 0x444(0x04)
	struct ANavigationData* MyNavData; // 0x448(0x08)
	struct FVector ProjectedLocation; // 0x450(0x0c)
	char bProjectedLocationValid : 1; // 0x45c(0x01)
	char bSearchStart : 1; // 0x45c(0x01)
	char bUseHierarchicalPathfinding : 1; // 0x45c(0x01)
	char bGatherDetailedInfo : 1; // 0x45c(0x01)
	char bDrawDistanceToWall : 1; // 0x45c(0x01)
	char bShowNodePool : 1; // 0x45c(0x01)
	char bShowBestPath : 1; // 0x45c(0x01)
	char bShowDiffWithPreviousStep : 1; // 0x45c(0x01)
	char bShouldBeVisibleInGame : 1; // 0x45d(0x01)
	char pad_45D_1 : 7; // 0x45d(0x01)
	char pad_45E[0x2]; // 0x45e(0x02)
	enum class ENavCostDisplay CostDisplayMode; // 0x460(0x01)
	char pad_461[0x3]; // 0x461(0x03)
	struct FVector2D TextCanvasOffset; // 0x464(0x08)
	char bPathExist : 1; // 0x46c(0x01)
	char bPathIsPartial : 1; // 0x46c(0x01)
	char bPathSearchOutOfNodes : 1; // 0x46c(0x01)
	char pad_46C_3 : 5; // 0x46c(0x01)
	char pad_46D[0x3]; // 0x46d(0x03)
	float PathfindingTime; // 0x470(0x04)
	float PathCost; // 0x474(0x04)
	int32 PathfindingSteps; // 0x478(0x04)
	char pad_47C[0x4]; // 0x47c(0x04)
	struct ANavigationTestingActor* OtherActor; // 0x480(0x08)
	struct UClass* FilterClass; // 0x488(0x08)
	int32 ShowStepIndex; // 0x490(0x04)
	float OffsetFromCornersDistance; // 0x494(0x04)
	char pad_498[0x68]; // 0x498(0x68)
};

// Class Engine.NavLinkDefinition
// Size: 0x60 (Inherited: 0x38)
struct UNavLinkDefinition : UObject {
	struct TArray<struct FNavigationLink> Links; // 0x38(0x10)
	struct TArray<struct FNavigationSegmentLink> SegmentLinks; // 0x48(0x10)
	char pad_58[0x8]; // 0x58(0x08)
};

// Class Engine.NavLinkHostInterface
// Size: 0x38 (Inherited: 0x38)
struct UNavLinkHostInterface : UInterface {
};

// Class Engine.NavLinkProxy
// Size: 0x440 (Inherited: 0x3f0)
struct ANavLinkProxy : AActor {
	char pad_3F0[0x10]; // 0x3f0(0x10)
	struct TArray<struct FNavigationLink> PointLinks; // 0x400(0x10)
	struct TArray<struct FNavigationSegmentLink> SegmentLinks; // 0x410(0x10)
	struct UNavLinkCustomComponent* SmartLinkComp; // 0x420(0x08)
	bool bSmartLinkIsRelevant; // 0x428(0x01)
	char pad_429[0x7]; // 0x429(0x07)
	struct FMulticastDelegate OnSmartLinkReached; // 0x430(0x10)

	void SetSmartLinkEnabled(bool bEnabled); // Function Engine.NavLinkProxy.SetSmartLinkEnabled // Final|Native|Public|BlueprintCallable // @ game+0x5b02ef4
	void ResumePathFollowing(struct AActor* Agent); // Function Engine.NavLinkProxy.ResumePathFollowing // Final|Native|Public|BlueprintCallable // @ game+0x5afaa34
	void ReceiveSmartLinkReached(struct AActor* Agent, struct FVector Destination); // Function Engine.NavLinkProxy.ReceiveSmartLinkReached // Event|Public|HasOutParms|HasDefaults|BlueprintEvent // @ game+0x33e45c
	bool IsSmartLinkEnabled(); // Function Engine.NavLinkProxy.IsSmartLinkEnabled // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5af2c3c
	bool HasMovingAgents(); // Function Engine.NavLinkProxy.HasMovingAgents // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5af1c34
};

// Class Engine.Note
// Size: 0x3f0 (Inherited: 0x3f0)
struct ANote : AActor {
};

// Class Engine.ParticleSystem
// Size: 0x148 (Inherited: 0x38)
struct UParticleSystem : UObject {
	enum class EParticleSystemUpdateMode SystemUpdateMode; // 0x38(0x01)
	char pad_39[0x3]; // 0x39(0x03)
	float UpdateTime_FPS; // 0x3c(0x04)
	float UpdateTime_Delta; // 0x40(0x04)
	float WarmupTime; // 0x44(0x04)
	float WarmupTickRate; // 0x48(0x04)
	char pad_4C[0x4]; // 0x4c(0x04)
	struct TArray<struct UParticleEmitter*> Emitters; // 0x50(0x10)
	struct UParticleSystemComponent* PreviewComponent; // 0x60(0x08)
	struct UInterpCurveEdSetup* CurveEdSetup; // 0x68(0x08)
	char bOrientZAxisTowardCamera : 1; // 0x70(0x01)
	char pad_70_1 : 7; // 0x70(0x01)
	char pad_71[0x3]; // 0x71(0x03)
	float LODDistanceCheckTime; // 0x74(0x04)
	enum class ParticleSystemLODMethod LODMethod; // 0x78(0x01)
	char pad_79[0x7]; // 0x79(0x07)
	struct TArray<float> LODDistances; // 0x80(0x10)
	char bApplyLODDistanceFactorForLowFOV : 1; // 0x90(0x01)
	char bRegenerateLODDuplicate : 1; // 0x90(0x01)
	char pad_90_2 : 6; // 0x90(0x01)
	char pad_91[0x7]; // 0x91(0x07)
	struct TArray<struct FParticleSystemLOD> LODSettings; // 0x98(0x10)
	char bUseFixedRelativeBoundingBox : 1; // 0xa8(0x01)
	char pad_A8_1 : 7; // 0xa8(0x01)
	char pad_A9[0x3]; // 0xa9(0x03)
	struct FBox FixedRelativeBoundingBox; // 0xac(0x1c)
	float SecondsBeforeInactive; // 0xc8(0x04)
	char bShouldResetPeakCounts : 1; // 0xcc(0x01)
	char bHasPhysics : 1; // 0xcc(0x01)
	char bUseRealtimeThumbnail : 1; // 0xcc(0x01)
	char ThumbnailImageOutOfDate : 1; // 0xcc(0x01)
	char pad_CC_4 : 4; // 0xcc(0x01)
	char pad_CD[0x3]; // 0xcd(0x03)
	float Delay; // 0xd0(0x04)
	float DelayLow; // 0xd4(0x04)
	char bUseDelayRange : 1; // 0xd8(0x01)
	char pad_D8_1 : 7; // 0xd8(0x01)
	char pad_D9[0x3]; // 0xd9(0x03)
	bool bAutoDeactivate; // 0xdc(0x01)
	char pad_DD[0x3]; // 0xdd(0x03)
	uint32 MinTimeBetweenTicks; // 0xe0(0x04)
	enum class EParticleSystemInsignificanceReaction InsignificantReaction; // 0xe4(0x01)
	char pad_E5[0x3]; // 0xe5(0x03)
	float InsignificanceDelay; // 0xe8(0x04)
	enum class EParticleSignificanceLevel MaxSignificanceLevel; // 0xec(0x01)
	char pad_ED[0x3]; // 0xed(0x03)
	struct FVector MacroUVPosition; // 0xf0(0x0c)
	float MacroUVRadius; // 0xfc(0x04)
	enum class EParticleSystemOcclusionBoundsMethod OcclusionBoundsMethod; // 0x100(0x01)
	char pad_101[0x3]; // 0x101(0x03)
	struct FBox CustomOcclusionBounds; // 0x104(0x1c)
	struct TArray<struct FLODSoloTrack> SoloTracking; // 0x120(0x10)
	struct TArray<struct FNamedEmitterMaterial> NamedMaterialSlots; // 0x130(0x10)
	char pad_140[0x8]; // 0x140(0x08)

	bool ContainsEmitterType(struct UClass* TypeData); // Function Engine.ParticleSystem.ContainsEmitterType // Final|Native|Public|BlueprintCallable // @ game+0x5ae84f8
};

// Class Engine.ParticleEventManager
// Size: 0x3f0 (Inherited: 0x3f0)
struct AParticleEventManager : AActor {
};

// Class Engine.Interface_CollisionDataProvider
// Size: 0x38 (Inherited: 0x38)
struct UInterface_CollisionDataProvider : UInterface {
};

// Class Engine.SkeletalMesh
// Size: 0x300 (Inherited: 0x38)
struct USkeletalMesh : UObject {
	char pad_38[0x20]; // 0x38(0x20)
	struct USkeleton* Skeleton; // 0x58(0x08)
	struct FBoxSphereBounds ImportedBounds; // 0x60(0x1c)
	struct FBoxSphereBounds ExtendedBounds; // 0x7c(0x1c)
	struct FVector PositiveBoundsExtension; // 0x98(0x0c)
	struct FVector NegativeBoundsExtension; // 0xa4(0x0c)
	struct TArray<struct FSkeletalMaterial> Materials; // 0xb0(0x10)
	float UVDensityRate; // 0xc0(0x04)
	char pad_C4[0x4]; // 0xc4(0x04)
	struct TArray<struct FBoneMirrorInfo> SkelMirrorTable; // 0xc8(0x10)
	enum class EAxis SkelMirrorAxis; // 0xd8(0x01)
	enum class EAxis SkelMirrorFlipAxis; // 0xd9(0x01)
	char pad_DA[0x6]; // 0xda(0x06)
	struct TArray<struct FSkeletalMeshLODInfo> LODInfo; // 0xe0(0x10)
	char bUseFullPrecisionUVs : 1; // 0xf0(0x01)
	char bHasBeenSimplified : 1; // 0xf0(0x01)
	char bHasVertexColors : 1; // 0xf0(0x01)
	char bEnablePerPolyCollision : 1; // 0xf0(0x01)
	char pad_F0_4 : 4; // 0xf0(0x01)
	char pad_F1[0x7]; // 0xf1(0x07)
	struct UBodySetup* BodySetup; // 0xf8(0x08)
	struct UPhysicsAsset* PhysicsAsset; // 0x100(0x08)
	struct UPhysicsAsset* ShadowPhysicsAsset; // 0x108(0x08)
	struct TArray<struct UNodeMappingContainer*> NodeMappingData; // 0x110(0x10)
	struct TArray<struct UMorphTarget*> MorphTargets; // 0x120(0x10)
	char pad_130[0x168]; // 0x130(0x168)
	struct TArray<struct FClothingAssetData_Legacy> ClothingAssets; // 0x298(0x10)
	struct UClass* PostProcessAnimBlueprint; // 0x2a8(0x08)
	struct TArray<struct UClothingAssetBase*> MeshClothingAssets; // 0x2b0(0x10)
	struct TArray<struct UAssetUserData*> AssetUserData; // 0x2c0(0x10)
	char pad_2D0[0x8]; // 0x2d0(0x08)
	struct TArray<struct USkeletalMeshSocket*> Sockets; // 0x2d8(0x10)
	char pad_2E8[0x18]; // 0x2e8(0x18)

	int32 NumSockets(); // Function Engine.SkeletalMesh.NumSockets // Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5af8b0c
	bool IsSectionUsingCloth(int32 InSectionIndex, bool bCheckCorrespondingSections); // Function Engine.SkeletalMesh.IsSectionUsingCloth // Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5af2a50
	struct USkeletalMeshSocket* GetSocketByIndex(int32 Index); // Function Engine.SkeletalMesh.GetSocketByIndex // Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5af0e74
	struct UNodeMappingContainer* GetNodeMappingContainer(struct UBlueprint* SourceAsset); // Function Engine.SkeletalMesh.GetNodeMappingContainer // Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5aefe50
	struct FBoxSphereBounds GetImportedBounds(); // Function Engine.SkeletalMesh.GetImportedBounds // Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable // @ game+0x5aee7c8
	struct FBoxSphereBounds GetBounds(); // Function Engine.SkeletalMesh.GetBounds // Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable // @ game+0x5aeca74
	struct USkeletalMeshSocket* FindSocketAndIndex(struct FName InSocketName, int32 OutIndex); // Function Engine.SkeletalMesh.FindSocketAndIndex // Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const // @ game+0x5aeb028
	struct USkeletalMeshSocket* FindSocket(struct FName InSocketName); // Function Engine.SkeletalMesh.FindSocket // Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5aeaf90
};

// Class Engine.AnimationAsset
// Size: 0x88 (Inherited: 0x38)
struct UAnimationAsset : UObject {
	char pad_38[0x8]; // 0x38(0x08)
	struct USkeleton* Skeleton; // 0x40(0x08)
	char pad_48[0x20]; // 0x48(0x20)
	struct TArray<struct UAnimMetaData*> MetaData; // 0x68(0x10)
	struct TArray<struct UAssetUserData*> AssetUserData; // 0x78(0x10)
};

// Class Engine.ReflectionCapture
// Size: 0x3f8 (Inherited: 0x3f0)
struct AReflectionCapture : AActor {
	struct UReflectionCaptureComponent* CaptureComponent; // 0x3f0(0x08)
};

// Class Engine.BoxReflectionCapture
// Size: 0x3f8 (Inherited: 0x3f8)
struct ABoxReflectionCapture : AReflectionCapture {
};

// Class Engine.PlaneReflectionCapture
// Size: 0x3f8 (Inherited: 0x3f8)
struct APlaneReflectionCapture : AReflectionCapture {
};

// Class Engine.SphereReflectionCapture
// Size: 0x400 (Inherited: 0x3f8)
struct ASphereReflectionCapture : AReflectionCapture {
	struct UDrawSphereComponent* DrawCaptureRadius; // 0x3f8(0x08)
};

// Class Engine.RigidBodyBase
// Size: 0x3f0 (Inherited: 0x3f0)
struct ARigidBodyBase : AActor {
};

// Class Engine.PhysicsConstraintActor
// Size: 0x410 (Inherited: 0x3f0)
struct APhysicsConstraintActor : ARigidBodyBase {
	struct UPhysicsConstraintComponent* ConstraintComp; // 0x3f0(0x08)
	struct AActor* ConstraintActor1; // 0x3f8(0x08)
	struct AActor* ConstraintActor2; // 0x400(0x08)
	char bDisableCollision : 1; // 0x408(0x01)
	char pad_408_1 : 7; // 0x408(0x01)
	char pad_409[0x7]; // 0x409(0x07)
};

// Class Engine.PhysicsThruster
// Size: 0x3f8 (Inherited: 0x3f0)
struct APhysicsThruster : ARigidBodyBase {
	struct UPhysicsThrusterComponent* ThrusterComponent; // 0x3f0(0x08)
};

// Class Engine.RadialForceActor
// Size: 0x3f8 (Inherited: 0x3f0)
struct ARadialForceActor : ARigidBodyBase {
	struct URadialForceComponent* ForceComponent; // 0x3f0(0x08)

	void ToggleForce(); // Function Engine.RadialForceActor.ToggleForce // Native|Public|BlueprintCallable // @ game+0x769f14
	void FireImpulse(); // Function Engine.RadialForceActor.FireImpulse // Native|Public|BlueprintCallable // @ game+0xe3d10c
	void EnableForce(); // Function Engine.RadialForceActor.EnableForce // Native|Public|BlueprintCallable // @ game+0x815b50
	void DisableForce(); // Function Engine.RadialForceActor.DisableForce // Native|Public|BlueprintCallable // @ game+0x815938
};

// Class Engine.SceneCapture
// Size: 0x3f8 (Inherited: 0x3f0)
struct ASceneCapture : AActor {
	struct UStaticMeshComponent* MeshComp; // 0x3f0(0x08)
};

// Class Engine.PlanarReflection
// Size: 0x408 (Inherited: 0x3f8)
struct APlanarReflection : ASceneCapture {
	struct UPlanarReflectionComponent* PlanarReflectionComponent; // 0x3f8(0x08)
	bool bShowPreviewPlane; // 0x400(0x01)
	char pad_401[0x7]; // 0x401(0x07)

	void OnInterpToggle(bool bEnable); // Function Engine.PlanarReflection.OnInterpToggle // Final|Native|Public|BlueprintCallable // @ game+0x5af8b2c
};

// Class Engine.SceneCapture2D
// Size: 0x408 (Inherited: 0x3f8)
struct ASceneCapture2D : ASceneCapture {
	struct USceneCaptureComponent2D* CaptureComponent2D; // 0x3f8(0x08)
	struct UDrawFrustumComponent* DrawFrustum; // 0x400(0x08)

	void OnInterpToggle(bool bEnable); // Function Engine.SceneCapture2D.OnInterpToggle // Final|Native|Public|BlueprintCallable // @ game+0x5af8b2c
};

// Class Engine.SceneCaptureCube
// Size: 0x408 (Inherited: 0x3f8)
struct ASceneCaptureCube : ASceneCapture {
	struct USceneCaptureComponentCube* CaptureComponentCube; // 0x3f8(0x08)
	struct UDrawFrustumComponent* DrawFrustum; // 0x400(0x08)

	void OnInterpToggle(bool bEnable); // Function Engine.SceneCaptureCube.OnInterpToggle // Final|Native|Public|BlueprintCallable // @ game+0x5af8b2c
};

// Class Engine.MatineeAnimInterface
// Size: 0x38 (Inherited: 0x38)
struct UMatineeAnimInterface : UInterface {
};

// Class Engine.SplineMeshActor
// Size: 0x3f8 (Inherited: 0x3f0)
struct ASplineMeshActor : AActor {
	struct USplineMeshComponent* SplineMeshComponent; // 0x3f0(0x08)
};

// Class Engine.BillboardComponent
// Size: 0xa00 (Inherited: 0x9d0)
struct UBillboardComponent : UPrimitiveComponent {
	struct UTexture2D* Sprite; // 0x9d0(0x08)
	char bIsScreenSizeScaled : 1; // 0x9d8(0x01)
	char pad_9D8_1 : 7; // 0x9d8(0x01)
	char pad_9D9[0x3]; // 0x9d9(0x03)
	float ScreenSize; // 0x9dc(0x04)
	float U; // 0x9e0(0x04)
	float UL; // 0x9e4(0x04)
	float V; // 0x9e8(0x04)
	float VL; // 0x9ec(0x04)
	struct FColor Color; // 0x9f0(0x04)
	char pad_9F4[0xc]; // 0x9f4(0x0c)

	void SetUV(int32 NewU, int32 NewUL, int32 NewV, int32 NewVL); // Function Engine.BillboardComponent.SetUV // Native|Public|BlueprintCallable // @ game+0x5b03650
	void SetSpriteAndUV(struct UTexture2D* NewSprite, int32 NewU, int32 NewUL, int32 NewV, int32 NewVL); // Function Engine.BillboardComponent.SetSpriteAndUV // Native|Public|BlueprintCallable // @ game+0x5b03020
	void SetSprite(struct UTexture2D* NewSprite); // Function Engine.BillboardComponent.SetSprite // Native|Public|BlueprintCallable // @ game+0x5b02f8c
	void SetColor(struct FColor ApplyColor, bool bDirty); // Function Engine.BillboardComponent.SetColor // Final|Native|Public|HasDefaults // @ game+0x5affb30
};

// Class Engine.StaticMesh
// Size: 0x180 (Inherited: 0x38)
struct UStaticMesh : UObject {
	char pad_38[0x18]; // 0x38(0x18)
	int32 MinLOD; // 0x50(0x04)
	char pad_54[0x4]; // 0x54(0x04)
	struct TArray<struct UMaterialInterface*> Materials; // 0x58(0x10)
	struct TArray<struct FStaticMaterial> StaticMaterials; // 0x68(0x10)
	float LightmapUVDensity; // 0x78(0x04)
	int32 LightMapResolution; // 0x7c(0x04)
	int32 LightMapCoordinateIndex; // 0x80(0x04)
	float DistanceFieldSelfShadowBias; // 0x84(0x04)
	struct UBodySetup* BodySetup; // 0x88(0x08)
	int32 LODForCollision; // 0x90(0x04)
	char bGenerateMeshDistanceField : 1; // 0x94(0x01)
	char bAllowTesselation : 1; // 0x94(0x01)
	char bStripComplexCollisionForConsole : 1; // 0x94(0x01)
	char bHasNavigationData : 1; // 0x94(0x01)
	char bRequiresAreaWeightedSampling : 1; // 0x94(0x01)
	char pad_94_5 : 3; // 0x94(0x01)
	char pad_95[0x3]; // 0x95(0x03)
	float LpvBiasMultiplier; // 0x98(0x04)
	bool bAllowCPUAccess; // 0x9c(0x01)
	char pad_9D[0x33]; // 0x9d(0x33)
	struct TArray<struct UStaticMeshSocket*> Sockets; // 0xd0(0x10)
	char pad_E0[0x10]; // 0xe0(0x10)
	struct FVector PositiveBoundsExtension; // 0xf0(0x0c)
	struct FVector NegativeBoundsExtension; // 0xfc(0x0c)
	struct FBoxSphereBounds ExtendedBounds; // 0x108(0x1c)
	bool bIgnoreDistanceFieldData; // 0x124(0x01)
	char pad_125[0x3]; // 0x125(0x03)
	int32 ElementToIgnoreForTexFactor; // 0x128(0x04)
	char pad_12C[0x4]; // 0x12c(0x04)
	struct TArray<struct UAssetUserData*> AssetUserData; // 0x130(0x10)
	struct UNavCollision* NavCollision; // 0x140(0x08)
	struct FMeshImposterLODSettings ImposterLODSettings; // 0x148(0x28)
	struct TArray<struct UMaterialInstanceConstant*> ImposterLODOverrideMaterials; // 0x170(0x10)

	int32 GetNumSections(int32 InLOD); // Function Engine.StaticMesh.GetNumSections // Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5af00a8
	int32 GetNumLODs(); // Function Engine.StaticMesh.GetNumLODs // Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5af0038
	struct FBoxSphereBounds GetBounds(); // Function Engine.StaticMesh.GetBounds // Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5aecaa4
	struct FBox GetBoundingBox(); // Function Engine.StaticMesh.GetBoundingBox // Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5aec998
};

// Class Engine.StaticMeshIndoorVolumeComponent
// Size: 0x5c0 (Inherited: 0x4b0)
struct UStaticMeshIndoorVolumeComponent : USceneComponent {
	struct UStaticMesh* StaticMesh; // 0x4b0(0x08)
	char pad_4B8[0x108]; // 0x4b8(0x108)
};

// Class Engine.StaticMeshIndoorVolumeContainerComponent
// Size: 0x500 (Inherited: 0x4b0)
struct UStaticMeshIndoorVolumeContainerComponent : USceneComponent {
	struct TArray<struct FInstanceRun> InstanceRuns; // 0x4b0(0x10)
	char pad_4C0[0x40]; // 0x4c0(0x40)
};

// Class Engine.StaticMeshIndoorVolume
// Size: 0x3f8 (Inherited: 0x3f0)
struct AStaticMeshIndoorVolume : AActor {
	struct UStaticMeshIndoorVolumeComponent* VolumeComponent; // 0x3f0(0x08)
};

// Class Engine.TextRenderActor
// Size: 0x3f8 (Inherited: 0x3f0)
struct ATextRenderActor : AActor {
	struct UTextRenderComponent* TextRender; // 0x3f0(0x08)
};

// Class Engine.TriggerCapsule
// Size: 0x3f8 (Inherited: 0x3f8)
struct ATriggerCapsule : ATriggerBase {
};

// Class Engine.TriggerSphere
// Size: 0x3f8 (Inherited: 0x3f8)
struct ATriggerSphere : ATriggerBase {
};

// Class Engine.VectorFieldVolume
// Size: 0x3f8 (Inherited: 0x3f0)
struct AVectorFieldVolume : AActor {
	struct UVectorFieldComponent* VectorFieldComponent; // 0x3f0(0x08)
};

// Class Engine.ApplicationLifecycleComponent
// Size: 0x250 (Inherited: 0x200)
struct UApplicationLifecycleComponent : UActorComponent {
	struct FMulticastDelegate ApplicationWillDeactivateDelegate; // 0x200(0x10)
	struct FMulticastDelegate ApplicationHasReactivatedDelegate; // 0x210(0x10)
	struct FMulticastDelegate ApplicationWillEnterBackgroundDelegate; // 0x220(0x10)
	struct FMulticastDelegate ApplicationHasEnteredForegroundDelegate; // 0x230(0x10)
	struct FMulticastDelegate ApplicationWillTerminateDelegate; // 0x240(0x10)

	void ApplicationLifetimeDelegate__DelegateSignature(); // DelegateFunction Engine.ApplicationLifecycleComponent.ApplicationLifetimeDelegate__DelegateSignature // MulticastDelegate|Public|Delegate // @ game+0x33e45c
};

// Class Engine.LevelBlocksData
// Size: 0x48 (Inherited: 0x38)
struct ULevelBlocksData : UObject {
	struct TArray<struct ULevelBlockResourceContainer*> ResourceContainers; // 0x38(0x10)
};

// Class Engine.LevelBlocksDataComponent
// Size: 0x2c0 (Inherited: 0x200)
struct ULevelBlocksDataComponent : UActorComponent {
	char pad_200[0x8]; // 0x200(0x08)
	struct ULevelBlocksData* LevelBlocksData; // 0x208(0x08)
	char pad_210[0x18]; // 0x210(0x18)
	int32 RandomSeed; // 0x228(0x04)
	char pad_22C[0x4]; // 0x22c(0x04)
	struct TArray<struct AActor*> SpawnedActors; // 0x230(0x10)
	char pad_240[0x80]; // 0x240(0x80)

	void OnRep_RandomSeed(); // Function Engine.LevelBlocksDataComponent.OnRep_RandomSeed // Final|Native|Private // @ game+0x5af8c00
	void OnKillcamLoadingFinished(); // Function Engine.LevelBlocksDataComponent.OnKillcamLoadingFinished // Final|Native|Private // @ game+0x5af8bc8
};

// Class Engine.InterpToMovementComponent
// Size: 0x2f0 (Inherited: 0x250)
struct UInterpToMovementComponent : UMovementComponent {
	float Duration; // 0x248(0x04)
	char bPauseOnImpact : 1; // 0x24c(0x01)
	enum class EInterpToBehaviourType BehaviourType; // 0x250(0x01)
	char bForceSubStepping : 1; // 0x254(0x01)
	char pad_255_2 : 6; // 0x255(0x01)
	char pad_256[0x2]; // 0x256(0x02)
	struct FMulticastDelegate OnInterpToReverse; // 0x258(0x10)
	struct FMulticastDelegate OnInterpToStop; // 0x268(0x10)
	struct FMulticastDelegate OnWaitBeginDelegate; // 0x278(0x10)
	struct FMulticastDelegate OnWaitEndDelegate; // 0x288(0x10)
	struct FMulticastDelegate OnResetDelegate; // 0x298(0x10)
	float MaxSimulationTimeStep; // 0x2a8(0x04)
	int32 MaxSimulationIterations; // 0x2ac(0x04)
	struct TArray<struct FInterpControlPoint> ControlPoints; // 0x2b0(0x10)
	char pad_2C0[0x30]; // 0x2c0(0x30)

	void StopSimulating(struct FHitResult HitResult); // Function Engine.InterpToMovementComponent.StopSimulating // Final|Native|Public|HasOutParms|BlueprintCallable // @ game+0x5b04fbc
	void RestartMovement(float InitialDirection); // Function Engine.InterpToMovementComponent.RestartMovement // Final|Native|Public|BlueprintCallable // @ game+0x5afa6f0
	void OnInterpToWaitEndDelegate__DelegateSignature(struct FHitResult ImpactResult, float Time); // DelegateFunction Engine.InterpToMovementComponent.OnInterpToWaitEndDelegate__DelegateSignature // MulticastDelegate|Public|Delegate|HasOutParms // @ game+0x33e45c
	void OnInterpToWaitBeginDelegate__DelegateSignature(struct FHitResult ImpactResult, float Time); // DelegateFunction Engine.InterpToMovementComponent.OnInterpToWaitBeginDelegate__DelegateSignature // MulticastDelegate|Public|Delegate|HasOutParms // @ game+0x33e45c
	void OnInterpToStopDelegate__DelegateSignature(struct FHitResult ImpactResult, float Time); // DelegateFunction Engine.InterpToMovementComponent.OnInterpToStopDelegate__DelegateSignature // MulticastDelegate|Public|Delegate|HasOutParms // @ game+0x33e45c
	void OnInterpToReverseDelegate__DelegateSignature(struct FHitResult ImpactResult, float Time); // DelegateFunction Engine.InterpToMovementComponent.OnInterpToReverseDelegate__DelegateSignature // MulticastDelegate|Public|Delegate|HasOutParms // @ game+0x33e45c
	void OnInterpToResetDelegate__DelegateSignature(struct FHitResult ImpactResult, float Time); // DelegateFunction Engine.InterpToMovementComponent.OnInterpToResetDelegate__DelegateSignature // MulticastDelegate|Public|Delegate|HasOutParms // @ game+0x33e45c
	void FinaliseControlPoints(); // Function Engine.InterpToMovementComponent.FinaliseControlPoints // Final|Native|Public|BlueprintCallable // @ game+0x5aeaed4
};

// Class Engine.AssetUserData
// Size: 0x38 (Inherited: 0x38)
struct UAssetUserData : UObject {
};

// Class Engine.Skeleton
// Size: 0x3b0 (Inherited: 0x38)
struct USkeleton : UObject {
	char pad_38[0x8]; // 0x38(0x08)
	struct TArray<struct FBoneNode> BoneTree; // 0x40(0x10)
	struct TArray<struct FTransform> RefLocalPoses; // 0x50(0x10)
	char pad_60[0x110]; // 0x60(0x110)
	struct FGuid VirtualBoneGuid; // 0x170(0x10)
	struct TArray<struct FVirtualBone> VirtualBones; // 0x180(0x10)
	struct TArray<struct FSkeletonToMeshLinkup> LinkupCache; // 0x190(0x10)
	struct TArray<struct USkeletalMeshSocket*> Sockets; // 0x1a0(0x10)
	char pad_1B0[0x50]; // 0x1b0(0x50)
	struct FSmartNameContainer SmartNames; // 0x200(0x50)
	char pad_250[0x18]; // 0x250(0x18)
	struct TArray<struct UBlendProfile*> BlendProfiles; // 0x268(0x10)
	struct TArray<struct FAnimSlotGroup> SlotGroups; // 0x278(0x10)
	char pad_288[0x118]; // 0x288(0x118)
	struct TArray<struct UAssetUserData*> AssetUserData; // 0x3a0(0x10)
};

// Class Engine.AnimSequenceBase
// Size: 0xb0 (Inherited: 0x88)
struct UAnimSequenceBase : UAnimationAsset {
	struct TArray<struct FAnimNotifyEvent> Notifies; // 0x88(0x10)
	float SequenceLength; // 0x98(0x04)
	float RateScale; // 0x9c(0x04)
	struct FRawCurveTracks RawCurveData; // 0xa0(0x10)

	float GetPlayLength(); // Function Engine.AnimSequenceBase.GetPlayLength // RequiredAPI|Native|Public|BlueprintCallable // @ game+0x5af0ba4
};

// Class Engine.AnimCompositeBase
// Size: 0xb0 (Inherited: 0xb0)
struct UAnimCompositeBase : UAnimSequenceBase {
};

// Class Engine.AnimMontage
// Size: 0x1b8 (Inherited: 0xb0)
struct UAnimMontage : UAnimCompositeBase {
	struct FAlphaBlend BlendIn; // 0xb0(0x38)
	float BlendInTime; // 0xe8(0x04)
	char pad_EC[0x4]; // 0xec(0x04)
	struct FAlphaBlend BlendOut; // 0xf0(0x38)
	float BlendOutTime; // 0x128(0x04)
	float BlendOutTriggerTime; // 0x12c(0x04)
	struct FName SyncGroup; // 0x130(0x08)
	int32 SyncSlotIndex; // 0x138(0x04)
	char pad_13C[0x4]; // 0x13c(0x04)
	struct FMarkerSyncData MarkerData; // 0x140(0x20)
	struct TArray<struct FCompositeSection> CompositeSections; // 0x160(0x10)
	struct TArray<struct FSlotAnimationTrack> SlotAnimTracks; // 0x170(0x10)
	struct TArray<struct FBranchingPoint> BranchingPoints; // 0x180(0x10)
	bool bEnableRootMotionTranslation; // 0x190(0x01)
	bool bEnableRootMotionRotation; // 0x191(0x01)
	enum class ERootMotionRootLock RootMotionRootLock; // 0x192(0x01)
	char pad_193[0x5]; // 0x193(0x05)
	struct TArray<struct FBranchingPointMarker> BranchingPointMarkers; // 0x198(0x10)
	struct TArray<int32> BranchingPointStateNotifyIndices; // 0x1a8(0x10)

	void OnMontageClosedMulticaster__DelegateSignature(); // DelegateFunction Engine.AnimMontage.OnMontageClosedMulticaster__DelegateSignature // MulticastDelegate|Public|Delegate // @ game+0x33e45c
};

// Class Engine.RVOAvoidanceInterface
// Size: 0x38 (Inherited: 0x38)
struct URVOAvoidanceInterface : UInterface {
};

// Class Engine.NetworkPredictionInterface
// Size: 0x38 (Inherited: 0x38)
struct UNetworkPredictionInterface : UInterface {
};

// Class Engine.RotatingMovementComponent
// Size: 0x270 (Inherited: 0x250)
struct URotatingMovementComponent : UMovementComponent {
	struct FRotator RotationRate; // 0x248(0x0c)
	struct FVector PivotTranslation; // 0x254(0x0c)
	char bRotationInLocalSpace : 1; // 0x260(0x01)
	char pad_268_1 : 7; // 0x268(0x01)
	char pad_269[0x7]; // 0x269(0x07)
};

// Class Engine.NavigationInvokerComponent
// Size: 0x210 (Inherited: 0x200)
struct UNavigationInvokerComponent : UActorComponent {
	float TileGenerationRadius; // 0x200(0x04)
	float TileRemovalRadius; // 0x204(0x04)
	char pad_208[0x8]; // 0x208(0x08)
};

// Class Engine.NavRelevantComponent
// Size: 0x230 (Inherited: 0x200)
struct UNavRelevantComponent : UActorComponent {
	char pad_200[0x24]; // 0x200(0x24)
	char bAttachToOwnersRoot : 1; // 0x224(0x01)
	char pad_224_1 : 7; // 0x224(0x01)
	char pad_225[0x3]; // 0x225(0x03)
	struct UObject* CachedNavParent; // 0x228(0x08)

	void SetNavigationRelevancy(bool bRelevant); // Function Engine.NavRelevantComponent.SetNavigationRelevancy // Final|Native|Public|BlueprintCallable // @ game+0x5b4d8c4
};

// Class Engine.NavLinkCustomInterface
// Size: 0x38 (Inherited: 0x38)
struct UNavLinkCustomInterface : UInterface {
};

// Class Engine.NavLinkCustomComponent
// Size: 0x340 (Inherited: 0x230)
struct UNavLinkCustomComponent : UNavRelevantComponent {
	char pad_230[0x8]; // 0x230(0x08)
	uint32 NavLinkUserId; // 0x238(0x04)
	char pad_23C[0x4]; // 0x23c(0x04)
	struct UClass* EnabledAreaClass; // 0x240(0x08)
	struct UClass* DisabledAreaClass; // 0x248(0x08)
	struct FVector LinkRelativeStart; // 0x250(0x0c)
	struct FVector LinkRelativeEnd; // 0x25c(0x0c)
	enum class ENavLinkDirection LinkDirection; // 0x268(0x01)
	char pad_269[0x3]; // 0x269(0x03)
	char bLinkEnabled : 1; // 0x26c(0x01)
	char bNotifyWhenEnabled : 1; // 0x26c(0x01)
	char bNotifyWhenDisabled : 1; // 0x26c(0x01)
	char bCreateBoxObstacle : 1; // 0x26c(0x01)
	char pad_26C_4 : 4; // 0x26c(0x01)
	char pad_26D[0x3]; // 0x26d(0x03)
	struct FVector ObstacleOffset; // 0x270(0x0c)
	struct FVector ObstacleExtent; // 0x27c(0x0c)
	struct UClass* ObstacleAreaClass; // 0x288(0x08)
	float BroadcastRadius; // 0x290(0x04)
	float BroadcastInterval; // 0x294(0x04)
	enum class ECollisionChannel BroadcastChannel; // 0x298(0x01)
	char pad_299[0xa7]; // 0x299(0xa7)
};

// Class Engine.NavModifierComponent
// Size: 0x260 (Inherited: 0x230)
struct UNavModifierComponent : UNavRelevantComponent {
	struct UClass* AreaClass; // 0x230(0x08)
	struct FVector FailsafeExtent; // 0x238(0x0c)
	char pad_244[0x1c]; // 0x244(0x1c)

	void SetAreaClass(struct UClass* NewAreaClass); // Function Engine.NavModifierComponent.SetAreaClass // Final|Native|Public|BlueprintCallable // @ game+0x5b45038
};

// Class Engine.PawnNoiseEmitterComponent
// Size: 0x230 (Inherited: 0x200)
struct UPawnNoiseEmitterComponent : UActorComponent {
	char bAIPerceptionSystemCompatibilityMode : 1; // 0x200(0x01)
	char pad_200_1 : 7; // 0x200(0x01)
	char pad_201[0x3]; // 0x201(0x03)
	struct FVector LastRemoteNoisePosition; // 0x204(0x0c)
	float NoiseLifetime; // 0x210(0x04)
	float LastRemoteNoiseVolume; // 0x214(0x04)
	float LastRemoteNoiseTime; // 0x218(0x04)
	float LastLocalNoiseVolume; // 0x21c(0x04)
	float LastLocalNoiseTime; // 0x220(0x04)
	char pad_224[0xc]; // 0x224(0x0c)

	void MakeNoise(struct AActor* NoiseMaker, float Loudness, struct FVector NoiseLocation); // Function Engine.PawnNoiseEmitterComponent.MakeNoise // BlueprintAuthorityOnly|Native|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b36a7c
};

// Class Engine.PhysicalAnimationComponent
// Size: 0x240 (Inherited: 0x200)
struct UPhysicalAnimationComponent : UActorComponent {
	float StrengthMultiplyer; // 0x200(0x04)
	char pad_204[0x4]; // 0x204(0x04)
	struct USkeletalMeshComponent* SkeletalMeshComponent; // 0x208(0x08)
	char pad_210[0x30]; // 0x210(0x30)

	void SetStrengthMultiplyer(float InStrengthMultiplyer); // Function Engine.PhysicalAnimationComponent.SetStrengthMultiplyer // Final|Native|Public|BlueprintCallable // @ game+0x5b50dcc
	void SetSkeletalMeshComponent(struct USkeletalMeshComponent* InSkeletalMeshComponent); // Function Engine.PhysicalAnimationComponent.SetSkeletalMeshComponent // Final|Native|Public|BlueprintCallable // @ game+0x5b4f724
	struct FTransform GetBodyTargetTransform(struct FName BodyName); // Function Engine.PhysicalAnimationComponent.GetBodyTargetTransform // Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5b22498
	void ApplyPhysicalAnimationSettingsBelow(struct FName BodyName, struct FPhysicalAnimationData PhysicalAnimationData, bool bIncludeSelf); // Function Engine.PhysicalAnimationComponent.ApplyPhysicalAnimationSettingsBelow // Final|Native|Public|HasOutParms|BlueprintCallable // @ game+0x5b0bef8
	void ApplyPhysicalAnimationSettings(struct FName BodyName, struct FPhysicalAnimationData PhysicalAnimationData); // Function Engine.PhysicalAnimationComponent.ApplyPhysicalAnimationSettings // Final|Native|Public|HasOutParms|BlueprintCallable // @ game+0x5b0bdf4
	void ApplyPhysicalAnimationProfileBelow(struct FName BodyName, struct FName ProfileName, bool bIncludeSelf, bool bClearNotFound); // Function Engine.PhysicalAnimationComponent.ApplyPhysicalAnimationProfileBelow // Final|Native|Public|BlueprintCallable // @ game+0x5b0bc74
};

// Class Engine.PhysicsHandleComponent
// Size: 0x2b0 (Inherited: 0x200)
struct UPhysicsHandleComponent : UActorComponent {
	struct UPrimitiveComponent* GrabbedComponent; // 0x200(0x08)
	char pad_208[0xc]; // 0x208(0x0c)
	char pad_214_0 : 1; // 0x214(0x01)
	char bSoftAngularConstraint : 1; // 0x214(0x01)
	char bSoftLinearConstraint : 1; // 0x214(0x01)
	char bInterpolateTarget : 1; // 0x214(0x01)
	char pad_214_4 : 4; // 0x214(0x01)
	char pad_215[0x3]; // 0x215(0x03)
	float LinearDamping; // 0x218(0x04)
	float LinearStiffness; // 0x21c(0x04)
	float AngularDamping; // 0x220(0x04)
	float AngularStiffness; // 0x224(0x04)
	char pad_228[0x68]; // 0x228(0x68)
	float InterpolationSpeed; // 0x290(0x04)
	char pad_294[0x1c]; // 0x294(0x1c)

	void SetTargetRotation(struct FRotator NewRotation); // Function Engine.PhysicsHandleComponent.SetTargetRotation // Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable // @ game+0x5b51770
	void SetTargetLocationAndRotation(struct FVector NewLocation, struct FRotator NewRotation); // Function Engine.PhysicsHandleComponent.SetTargetLocationAndRotation // Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable // @ game+0x5b51668
	void SetTargetLocation(struct FVector NewLocation); // Function Engine.PhysicsHandleComponent.SetTargetLocation // Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable // @ game+0x5b515c4
	void SetLinearStiffness(float NewLinearStiffness); // Function Engine.PhysicsHandleComponent.SetLinearStiffness // Final|RequiredAPI|Native|Public|BlueprintCallable // @ game+0x5b4c994
	void SetLinearDamping(float NewLinearDamping); // Function Engine.PhysicsHandleComponent.SetLinearDamping // Final|RequiredAPI|Native|Public|BlueprintCallable // @ game+0x5b4c580
	void SetInterpolationSpeed(float NewInterpolationSpeed); // Function Engine.PhysicsHandleComponent.SetInterpolationSpeed // Final|RequiredAPI|Native|Public|BlueprintCallable // @ game+0x5b4bcf4
	void SetAngularStiffness(float NewAngularStiffness); // Function Engine.PhysicsHandleComponent.SetAngularStiffness // Final|RequiredAPI|Native|Public|BlueprintCallable // @ game+0x5b44720
	void SetAngularDamping(float NewAngularDamping); // Function Engine.PhysicsHandleComponent.SetAngularDamping // Final|RequiredAPI|Native|Public|BlueprintCallable // @ game+0x5b44180
	void ReleaseComponent(); // Function Engine.PhysicsHandleComponent.ReleaseComponent // RequiredAPI|Native|Public|BlueprintCallable // @ game+0xd58780
	void GrabComponentAtLocationWithRotation(struct UPrimitiveComponent* Component, struct FName InBoneName, struct FVector Location, struct FRotator Rotation); // Function Engine.PhysicsHandleComponent.GrabComponentAtLocationWithRotation // Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable // @ game+0x5b2d2d4
	void GrabComponentAtLocation(struct UPrimitiveComponent* Component, struct FName InBoneName, struct FVector GrabLocation); // Function Engine.PhysicsHandleComponent.GrabComponentAtLocation // Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable // @ game+0x5b2d188
	void GrabComponent(struct UPrimitiveComponent* Component, struct FName InBoneName, struct FVector GrabLocation, bool bConstrainRotation); // Function Engine.PhysicsHandleComponent.GrabComponent // RequiredAPI|Native|Public|HasDefaults|BlueprintCallable // @ game+0x5b2d008
	void GetTargetLocationAndRotation(struct FVector TargetLocation, struct FRotator TargetRotation); // Function Engine.PhysicsHandleComponent.GetTargetLocationAndRotation // Final|RequiredAPI|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5b2a8b8
	struct UPrimitiveComponent* GetGrabbedComponent(); // Function Engine.PhysicsHandleComponent.GetGrabbedComponent // Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b24c04
};

// Class Engine.PlatformEventsComponent
// Size: 0x220 (Inherited: 0x200)
struct UPlatformEventsComponent : UActorComponent {
	struct FMulticastDelegate PlatformChangedToLaptopModeDelegate; // 0x200(0x10)
	struct FMulticastDelegate PlatformChangedToTabletModeDelegate; // 0x210(0x10)

	bool SupportsConvertibleLaptops(); // Function Engine.PlatformEventsComponent.SupportsConvertibleLaptops // Final|Native|Public|BlueprintCallable // @ game+0x5b5a9b8
	void PlatformEventDelegate__DelegateSignature(); // DelegateFunction Engine.PlatformEventsComponent.PlatformEventDelegate__DelegateSignature // MulticastDelegate|Public|Delegate // @ game+0x33e45c
	bool IsInTabletMode(); // Function Engine.PlatformEventsComponent.IsInTabletMode // Final|Native|Public|BlueprintCallable // @ game+0x5b2fc1c
	bool IsInLaptopMode(); // Function Engine.PlatformEventsComponent.IsInLaptopMode // Final|Native|Public|BlueprintCallable // @ game+0x5b2fbf0
};

// Class Engine.AtmosphericFogComponent
// Size: 0x6d0 (Inherited: 0x4b0)
struct UAtmosphericFogComponent : USceneComponent {
	float SunMultiplier; // 0x4b0(0x04)
	float FogMultiplier; // 0x4b4(0x04)
	float DensityMultiplier; // 0x4b8(0x04)
	float DensityOffset; // 0x4bc(0x04)
	float DistanceScale; // 0x4c0(0x04)
	float AltitudeScale; // 0x4c4(0x04)
	float DistanceOffset; // 0x4c8(0x04)
	float GroundOffset; // 0x4cc(0x04)
	float StartDistance; // 0x4d0(0x04)
	float SunDiscScale; // 0x4d4(0x04)
	struct TArray<struct FFogHeightDensityPair> HeightDensityLayers; // 0x4d8(0x10)
	float DefaultBrightness; // 0x4e8(0x04)
	struct FColor DefaultLightColor; // 0x4ec(0x04)
	char bDisableSunDisk : 1; // 0x4f0(0x01)
	char bDisableGroundScattering : 1; // 0x4f0(0x01)
	char pad_4F0_2 : 6; // 0x4f0(0x01)
	char pad_4F1[0x3]; // 0x4f1(0x03)
	struct FAtmospherePrecomputeParameters PrecomputeParams; // 0x4f4(0x2c)
	struct UTexture2D* TransmittanceTexture; // 0x520(0x08)
	struct UTexture2D* IrradianceTexture; // 0x528(0x08)
	char pad_530[0x1a0]; // 0x530(0x1a0)

	void StartPrecompute(); // Function Engine.AtmosphericFogComponent.StartPrecompute // Final|Native|Public|BlueprintCallable // @ game+0xc0af08
	void SetSunMultiplier(float NewSunMultiplier); // Function Engine.AtmosphericFogComponent.SetSunMultiplier // Final|RequiredAPI|Native|Public|BlueprintCallable // @ game+0x5b4a2cc
	void SetStartDistance(float NewStartDistance); // Function Engine.AtmosphericFogComponent.SetStartDistance // Final|RequiredAPI|Native|Public|BlueprintCallable // @ game+0x5b50648
	void SetPrecomputeParams(float DensityHeight, int32 MaxScatteringOrder, int32 InscatterAltitudeSampleNum); // Function Engine.AtmosphericFogComponent.SetPrecomputeParams // Final|RequiredAPI|Native|Public|BlueprintCallable // @ game+0x5b4ebf4
	void SetFogMultiplier(float NewFogMultiplier); // Function Engine.AtmosphericFogComponent.SetFogMultiplier // Final|RequiredAPI|Native|Public|BlueprintCallable // @ game+0x5b4a55c
	void SetDistanceScale(float NewDistanceScale); // Function Engine.AtmosphericFogComponent.SetDistanceScale // Final|RequiredAPI|Native|Public|BlueprintCallable // @ game+0x5b48d10
	void SetDistanceOffset(float NewDistanceOffset); // Function Engine.AtmosphericFogComponent.SetDistanceOffset // Final|RequiredAPI|Native|Public|BlueprintCallable // @ game+0x5b48c68
	void SetDensityOffset(float NewDensityOffset); // Function Engine.AtmosphericFogComponent.SetDensityOffset // Final|RequiredAPI|Native|Public|BlueprintCallable // @ game+0x5b48830
	void SetDensityMultiplier(float NewDensityMultiplier); // Function Engine.AtmosphericFogComponent.SetDensityMultiplier // Final|RequiredAPI|Native|Public|BlueprintCallable // @ game+0x5b48788
	void SetDefaultLightColor(struct FLinearColor NewLightColor); // Function Engine.AtmosphericFogComponent.SetDefaultLightColor // Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable // @ game+0x5b485dc
	void SetDefaultBrightness(float NewBrightness); // Function Engine.AtmosphericFogComponent.SetDefaultBrightness // Final|RequiredAPI|Native|Public|BlueprintCallable // @ game+0x5b48534
	void SetAltitudeScale(float NewAltitudeScale); // Function Engine.AtmosphericFogComponent.SetAltitudeScale // Final|RequiredAPI|Native|Public|BlueprintCallable // @ game+0x5b440d8
	void DisableSunDisk(bool NewSunDisk); // Function Engine.AtmosphericFogComponent.DisableSunDisk // Final|RequiredAPI|Native|Public|BlueprintCallable // @ game+0x5b1acec
	void DisableGroundScattering(bool NewGroundScattering); // Function Engine.AtmosphericFogComponent.DisableGroundScattering // Final|RequiredAPI|Native|Public|BlueprintCallable // @ game+0x5b1ac38
};

// Class Engine.SpatializationPluginSourceSettingsBase
// Size: 0x38 (Inherited: 0x38)
struct USpatializationPluginSourceSettingsBase : UObject {
};

// Class Engine.OcclusionPluginSourceSettingsBase
// Size: 0x38 (Inherited: 0x38)
struct UOcclusionPluginSourceSettingsBase : UObject {
};

// Class Engine.ReverbPluginSourceSettingsBase
// Size: 0x38 (Inherited: 0x38)
struct UReverbPluginSourceSettingsBase : UObject {
};

// Class Engine.SoundAttenuation
// Size: 0x168 (Inherited: 0x38)
struct USoundAttenuation : UObject {
	struct FSoundAttenuationSettings Attenuation; // 0x38(0x130)
};

// Class Engine.AudioComponent
// Size: 0x780 (Inherited: 0x4b0)
struct UAudioComponent : USceneComponent {
	struct USoundBase* Sound; // 0x4b0(0x08)
	struct TArray<struct FAudioComponentParam> InstanceParameters; // 0x4b8(0x10)
	struct USoundClass* SoundClassOverride; // 0x4c8(0x08)
	char bAutoDestroy : 1; // 0x4d0(0x01)
	char bStopWhenOwnerDestroyed : 1; // 0x4d0(0x01)
	char bShouldRemainActiveIfDropped : 1; // 0x4d0(0x01)
	char bAllowSpatialization : 1; // 0x4d0(0x01)
	char bOverrideAttenuation : 1; // 0x4d0(0x01)
	char pad_4D0_5 : 3; // 0x4d0(0x01)
	char pad_4D1[0x3]; // 0x4d1(0x03)
	char bOverrideSubtitlePriority : 1; // 0x4d4(0x01)
	char pad_4D4_1 : 7; // 0x4d4(0x01)
	char pad_4D5[0x3]; // 0x4d5(0x03)
	char bIsUISound : 1; // 0x4d8(0x01)
	char bEnableLowPassFilter : 1; // 0x4d8(0x01)
	char bOverridePriority : 1; // 0x4d8(0x01)
	char bSuppressSubtitles : 1; // 0x4d8(0x01)
	char pad_4D8_4 : 4; // 0x4d8(0x01)
	char pad_4D9[0x7]; // 0x4d9(0x07)
	struct FName AudioComponentUserID; // 0x4e0(0x08)
	float PitchModulationMin; // 0x4e8(0x04)
	float PitchModulationMax; // 0x4ec(0x04)
	float VolumeModulationMin; // 0x4f0(0x04)
	float VolumeModulationMax; // 0x4f4(0x04)
	float VolumeMultiplier; // 0x4f8(0x04)
	float Priority; // 0x4fc(0x04)
	float SubtitlePriority; // 0x500(0x04)
	float VolumeWeightedPriorityScale; // 0x504(0x04)
	float PitchMultiplier; // 0x508(0x04)
	float HighFrequencyGainMultiplier; // 0x50c(0x04)
	float LowPassFilterFrequency; // 0x510(0x04)
	char pad_514[0x4]; // 0x514(0x04)
	struct USoundAttenuation* AttenuationSettings; // 0x518(0x08)
	struct FSoundAttenuationSettings AttenuationOverrides; // 0x520(0x130)
	struct USoundConcurrency* ConcurrencySettings; // 0x650(0x08)
	char pad_658[0x8]; // 0x658(0x08)
	struct FMulticastDelegate OnAudioFinished; // 0x660(0x10)
	char pad_670[0x70]; // 0x670(0x70)
	struct FMulticastDelegate OnAudioPlaybackPercent; // 0x6e0(0x10)
	char pad_6F0[0x70]; // 0x6f0(0x70)
	DelegateProperty OnQueueSubtitles; // 0x760(0x10)
	char pad_770[0x10]; // 0x770(0x10)

	void Stop(); // Function Engine.AudioComponent.Stop // Native|Public|BlueprintCallable // @ game+0x5b59fc0
	void SetWaveParameter(struct FName InName, struct USoundWave* InWave); // Function Engine.AudioComponent.SetWaveParameter // Final|Native|Public|BlueprintCallable // @ game+0x5b52ec0
	void SetVolumeMultiplier(float NewVolumeMultiplier); // Function Engine.AudioComponent.SetVolumeMultiplier // Final|Native|Public|BlueprintCallable // @ game+0x5b528dc
	void SetUISound(bool bInUISound); // Function Engine.AudioComponent.SetUISound // Final|Native|Public|BlueprintCallable // @ game+0x5b51ed0
	void SetSubmixSend(struct USoundSubmix* Submix, float SendLevel); // Function Engine.AudioComponent.SetSubmixSend // Final|Native|Public|BlueprintCallable // @ game+0x5b51000
	void SetSound(struct USoundBase* NewSound); // Function Engine.AudioComponent.SetSound // Final|Native|Public|BlueprintCallable // @ game+0x5b4f96c
	void SetPitchMultiplier(float NewPitchMultiplier); // Function Engine.AudioComponent.SetPitchMultiplier // Final|Native|Public|BlueprintCallable // @ game+0x5b4e3f4
	void SetPaused(bool bPause); // Function Engine.AudioComponent.SetPaused // Final|Native|Public|BlueprintCallable // @ game+0x5b4e1e4
	void SetIntParameter(struct FName InName, int32 inInt); // Function Engine.AudioComponent.SetIntParameter // Final|Native|Public|BlueprintCallable // @ game+0x5b4b7fc
	void SetFloatParameter(struct FName InName, float inFloat); // Function Engine.AudioComponent.SetFloatParameter // Final|Native|Public|BlueprintCallable // @ game+0x5b4a144
	void SetBoolParameter(struct FName InName, bool InBool); // Function Engine.AudioComponent.SetBoolParameter // Final|Native|Public|BlueprintCallable // @ game+0x5b46170
	void Play(float StartTime); // Function Engine.AudioComponent.Play // Native|Public|BlueprintCallable // @ game+0x5b3d380
	bool IsPlaying(); // Function Engine.AudioComponent.IsPlaying // Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5af27e4
	void FadeOut(float FadeOutDuration, float FadeVolumeLevel); // Function Engine.AudioComponent.FadeOut // Native|Public|BlueprintCallable // @ game+0x5b1eff8
	void FadeIn(float FadeInDuration, float FadeVolumeLevel, float StartTime); // Function Engine.AudioComponent.FadeIn // Native|Public|BlueprintCallable // @ game+0x5b1eed4
	bool BP_GetAttenuationSettingsToApply(struct FSoundAttenuationSettings OutAttenuationSettings); // Function Engine.AudioComponent.BP_GetAttenuationSettingsToApply // Final|Native|Public|HasOutParms|BlueprintCallable // @ game+0x5b0e1dc
	void AdjustVolume(float AdjustVolumeDuration, float AdjustVolumeLevel); // Function Engine.AudioComponent.AdjustVolume // Final|Native|Public|BlueprintCallable // @ game+0x5b0b760
	void AdjustAttenuation(struct FSoundAttenuationSettings InAttenuationSettings); // Function Engine.AudioComponent.AdjustAttenuation // Final|Native|Public|HasOutParms|BlueprintCallable // @ game+0x5b0b550
};

// Class Engine.DecalComponent
// Size: 0x540 (Inherited: 0x4b0)
struct UDecalComponent : USceneComponent {
	struct UMaterialInterface* DecalMaterial; // 0x4b0(0x08)
	int32 SortOrder; // 0x4b8(0x04)
	float FadeScreenSize; // 0x4bc(0x04)
	float FadeStartDelay; // 0x4c0(0x04)
	float FadeDuration; // 0x4c4(0x04)
	char bDestroyOwnerAfterFade : 1; // 0x4c8(0x01)
	char pad_4C8_1 : 7; // 0x4c8(0x01)
	struct FDecalChannels DecalChannels; // 0x4c9(0x01)
	char pad_4CA[0x2]; // 0x4ca(0x02)
	struct FVector DecalSize; // 0x4cc(0x0c)
	float NormalFadeStart; // 0x4d8(0x04)
	float NormalFadeEnd; // 0x4dc(0x04)
	char pad_4E0[0x60]; // 0x4e0(0x60)

	void SetSortOrder(int32 Value); // Function Engine.DecalComponent.SetSortOrder // Final|Native|Public|BlueprintCallable // @ game+0x5b4f8d4
	void SetFadeOut(float StartDelay, float Duration, bool DestroyOwnerAfterFade); // Function Engine.DecalComponent.SetFadeOut // Final|Native|Public|BlueprintCallable // @ game+0x5b49e54
	void SetDecalMaterial(struct UMaterialInterface* NewDecalMaterial); // Function Engine.DecalComponent.SetDecalMaterial // Final|Native|Public|BlueprintCallable // @ game+0x5b48404
	float GetFadeStartDelay(); // Function Engine.DecalComponent.GetFadeStartDelay // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b247a4
	float GetFadeDuration(); // Function Engine.DecalComponent.GetFadeDuration // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b2478c
	struct UMaterialInterface* GetDecalMaterial(); // Function Engine.DecalComponent.GetDecalMaterial // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b23ce8
	struct UMaterialInstanceDynamic* CreateDynamicMaterialInstance(); // Function Engine.DecalComponent.CreateDynamicMaterialInstance // Native|Public|BlueprintCallable // @ game+0x5b19530
};

// Class Engine.DistanceFieldCaptureComponent
// Size: 0x4c0 (Inherited: 0x4b0)
struct UDistanceFieldCaptureComponent : USceneComponent {
	char pad_4B0[0x10]; // 0x4b0(0x10)
};

// Class Engine.ExponentialHeightFogComponent
// Size: 0x570 (Inherited: 0x4b0)
struct UExponentialHeightFogComponent : USceneComponent {
	float FogDensity; // 0x4b0(0x04)
	struct FLinearColor FogInscatteringColor; // 0x4b4(0x10)
	char pad_4C4[0x4]; // 0x4c4(0x04)
	struct TArray<struct FFogHeightDensityPair2> HeightDensityLayers; // 0x4c8(0x10)
	struct UTextureCube* InscatteringColorCubemap; // 0x4d8(0x08)
	float InscatteringColorCubemapAngle; // 0x4e0(0x04)
	struct FLinearColor InscatteringTextureTint; // 0x4e4(0x10)
	float FullyDirectionalInscatteringColorDistance; // 0x4f4(0x04)
	float NonDirectionalInscatteringColorDistance; // 0x4f8(0x04)
	float DirectionalInscatteringExponent; // 0x4fc(0x04)
	float DirectionalInscatteringStartDistance; // 0x500(0x04)
	struct FLinearColor DirectionalInscatteringColor; // 0x504(0x10)
	float FogHeightFalloff; // 0x514(0x04)
	float FogMaxOpacity; // 0x518(0x04)
	float StartDistance; // 0x51c(0x04)
	float FogCutoffDistance; // 0x520(0x04)
	bool bEnableVolumetricFog; // 0x524(0x01)
	char pad_525[0x3]; // 0x525(0x03)
	float VolumetricFogScatteringDistribution; // 0x528(0x04)
	struct FColor VolumetricFogAlbedo; // 0x52c(0x04)
	struct FLinearColor VolumetricFogEmissive; // 0x530(0x10)
	float VolumetricFogExtinctionScale; // 0x540(0x04)
	float VolumetricFogDistance; // 0x544(0x04)
	bool bOverrideLightColorsWithFogInscatteringColors; // 0x548(0x01)
	bool bUseExtendedFog; // 0x549(0x01)
	char pad_54A[0x2]; // 0x54a(0x02)
	float ExtendedFogStartDistance; // 0x54c(0x04)
	float ExtendedFogStartFalloffDistance; // 0x550(0x04)
	float ExtendedHeight; // 0x554(0x04)
	float ExtendedFallOff; // 0x558(0x04)
	float ExtendedFogDensity; // 0x55c(0x04)
	float UpDensity; // 0x560(0x04)
	float DownDensity; // 0x564(0x04)
	float Intensity; // 0x568(0x04)
	bool bUseAtmosphereScattering; // 0x56c(0x01)
	char pad_56D[0x3]; // 0x56d(0x03)

	void SetVolumetricFogScatteringDistribution(float NewValue); // Function Engine.ExponentialHeightFogComponent.SetVolumetricFogScatteringDistribution // Final|Native|Public|BlueprintCallable // @ game+0x5b52ce8
	void SetVolumetricFogExtinctionScale(float NewValue); // Function Engine.ExponentialHeightFogComponent.SetVolumetricFogExtinctionScale // Final|Native|Public|BlueprintCallable // @ game+0x5b52c40
	void SetVolumetricFogEmissive(struct FLinearColor NewValue); // Function Engine.ExponentialHeightFogComponent.SetVolumetricFogEmissive // Final|Native|Public|HasDefaults|BlueprintCallable // @ game+0x5b52b58
	void SetVolumetricFogDistance(float NewValue); // Function Engine.ExponentialHeightFogComponent.SetVolumetricFogDistance // Final|Native|Public|BlueprintCallable // @ game+0x5b52ab0
	void SetVolumetricFogAlbedo(struct FColor NewValue); // Function Engine.ExponentialHeightFogComponent.SetVolumetricFogAlbedo // Final|Native|Public|HasDefaults|BlueprintCallable // @ game+0x5b52a14
	void SetVolumetricFog(bool bNewValue); // Function Engine.ExponentialHeightFogComponent.SetVolumetricFog // Final|Native|Public|BlueprintCallable // @ game+0x5b52974
	void SetUpDensity(float Value); // Function Engine.ExponentialHeightFogComponent.SetUpDensity // Final|Native|Public|BlueprintCallable // @ game+0x5b52074
	void SetStartDistance(float Value); // Function Engine.ExponentialHeightFogComponent.SetStartDistance // Final|Native|Public|BlueprintCallable // @ game+0x5b506f0
	void SetNonDirectionalInscatteringColorDistance(float Value); // Function Engine.ExponentialHeightFogComponent.SetNonDirectionalInscatteringColorDistance // Final|Native|Public|BlueprintCallable // @ game+0x5b4d9f4
	void SetIntensity(float Value); // Function Engine.ExponentialHeightFogComponent.SetIntensity // Final|Native|Public|BlueprintCallable // @ game+0x5b4b9f0
	void SetInscatteringTextureTint(struct FLinearColor Value); // Function Engine.ExponentialHeightFogComponent.SetInscatteringTextureTint // Final|Native|Public|HasDefaults|BlueprintCallable // @ game+0x5b4b5f4
	void SetInscatteringColorCubemapAngle(float Value); // Function Engine.ExponentialHeightFogComponent.SetInscatteringColorCubemapAngle // Final|Native|Public|BlueprintCallable // @ game+0x5b4b54c
	void SetInscatteringColorCubemap(struct UTextureCube* Value); // Function Engine.ExponentialHeightFogComponent.SetInscatteringColorCubemap // Final|Native|Public|BlueprintCallable // @ game+0x5b4b4ac
	void SetFullyDirectionalInscatteringColorDistance(float Value); // Function Engine.ExponentialHeightFogComponent.SetFullyDirectionalInscatteringColorDistance // Final|Native|Public|BlueprintCallable // @ game+0x5b4a9bc
	void SetFogMaxOpacity(float Value); // Function Engine.ExponentialHeightFogComponent.SetFogMaxOpacity // Final|Native|Public|BlueprintCallable // @ game+0x5b4a4b4
	void SetFogInscatteringColor(struct FLinearColor Value); // Function Engine.ExponentialHeightFogComponent.SetFogInscatteringColor // Final|Native|Public|HasDefaults|BlueprintCallable // @ game+0x5b4a41c
	void SetFogHeightFalloff(float Value); // Function Engine.ExponentialHeightFogComponent.SetFogHeightFalloff // Final|Native|Public|BlueprintCallable // @ game+0x5b4a374
	void SetFogDensity(float Value); // Function Engine.ExponentialHeightFogComponent.SetFogDensity // Final|Native|Public|BlueprintCallable // @ game+0x5b4a2cc
	void SetFogCutoffDistance(float Value); // Function Engine.ExponentialHeightFogComponent.SetFogCutoffDistance // Final|Native|Public|BlueprintCallable // @ game+0x5b4a224
	void SetExtendedHeightFallOff(float Value); // Function Engine.ExponentialHeightFogComponent.SetExtendedHeightFallOff // Final|Native|Public|BlueprintCallable // @ game+0x5b49dac
	void SetExtendedHeight(float Value); // Function Engine.ExponentialHeightFogComponent.SetExtendedHeight // Final|Native|Public|BlueprintCallable // @ game+0x5b49d04
	void SetExtendedFogStartFalloffDistance(float Value); // Function Engine.ExponentialHeightFogComponent.SetExtendedFogStartFalloffDistance // Final|Native|Public|BlueprintCallable // @ game+0x5b49c5c
	void SetExtendedFogStartDistance(float Value); // Function Engine.ExponentialHeightFogComponent.SetExtendedFogStartDistance // Final|Native|Public|BlueprintCallable // @ game+0x5b49bb4
	void SetExtendedFogDensity(float Value); // Function Engine.ExponentialHeightFogComponent.SetExtendedFogDensity // Final|Native|Public|BlueprintCallable // @ game+0x5b49b0c
	void SetDownDensity(float Value); // Function Engine.ExponentialHeightFogComponent.SetDownDensity // Final|Native|Public|BlueprintCallable // @ game+0x5b48db8
	void SetDirectionalInscatteringStartDistance(float Value); // Function Engine.ExponentialHeightFogComponent.SetDirectionalInscatteringStartDistance // Final|Native|Public|BlueprintCallable // @ game+0x5b48af8
	void SetDirectionalInscatteringExponent(float Value); // Function Engine.ExponentialHeightFogComponent.SetDirectionalInscatteringExponent // Final|Native|Public|BlueprintCallable // @ game+0x5b48a50
	void SetDirectionalInscatteringColor(struct FLinearColor Value); // Function Engine.ExponentialHeightFogComponent.SetDirectionalInscatteringColor // Final|Native|Public|HasDefaults|BlueprintCallable // @ game+0x5b48968
};

// Class Engine.ForceFeedbackAttenuation
// Size: 0xe0 (Inherited: 0x38)
struct UForceFeedbackAttenuation : UObject {
	struct FForceFeedbackAttenuationSettings Attenuation; // 0x38(0xa8)
};

// Class Engine.ForceFeedbackComponent
// Size: 0x590 (Inherited: 0x4b0)
struct UForceFeedbackComponent : USceneComponent {
	struct UForceFeedbackEffect* ForceFeedbackEffect; // 0x4b0(0x08)
	char bAutoDestroy : 1; // 0x4b8(0x01)
	char bStopWhenOwnerDestroyed : 1; // 0x4b8(0x01)
	char bLooping : 1; // 0x4b8(0x01)
	char bOverrideAttenuation : 1; // 0x4b8(0x01)
	char pad_4B8_4 : 4; // 0x4b8(0x01)
	char pad_4B9[0x3]; // 0x4b9(0x03)
	float IntensityMultiplier; // 0x4bc(0x04)
	struct UForceFeedbackAttenuation* AttenuationSettings; // 0x4c0(0x08)
	struct FForceFeedbackAttenuationSettings AttenuationOverrides; // 0x4c8(0xa8)
	struct FMulticastDelegate OnForceFeedbackFinished; // 0x570(0x10)
	char pad_580[0x10]; // 0x580(0x10)

	void Stop(); // Function Engine.ForceFeedbackComponent.Stop // Native|Public|BlueprintCallable // @ game+0x4d262b4
	void SetIntensityMultiplier(float NewIntensityMultiplier); // Function Engine.ForceFeedbackComponent.SetIntensityMultiplier // Final|Native|Public|BlueprintCallable // @ game+0x5b4bb34
	void SetForceFeedbackEffect(struct UForceFeedbackEffect* NewForceFeedbackEffect); // Function Engine.ForceFeedbackComponent.SetForceFeedbackEffect // Final|Native|Public|BlueprintCallable // @ game+0x5b4a6bc
	void Play(float StartTime); // Function Engine.ForceFeedbackComponent.Play // Native|Public|BlueprintCallable // @ game+0x5b3d41c
	bool BP_GetAttenuationSettingsToApply(struct FForceFeedbackAttenuationSettings OutAttenuationSettings); // Function Engine.ForceFeedbackComponent.BP_GetAttenuationSettingsToApply // Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const // @ game+0x5b0e2e8
	void AdjustAttenuation(struct FForceFeedbackAttenuationSettings InAttenuationSettings); // Function Engine.ForceFeedbackComponent.AdjustAttenuation // Final|Native|Public|HasOutParms|BlueprintCallable // @ game+0x5b0b64c
};

// Class Engine.InstancedDeferredDecalComponent
// Size: 0x550 (Inherited: 0x4b0)
struct UInstancedDeferredDecalComponent : USceneComponent {
	struct UMaterialInterface* DecalMaterial; // 0x4b0(0x08)
	bool KeepInstanceBufferCPUAccess; // 0x4b8(0x01)
	struct FDecalChannels DecalChannels; // 0x4b9(0x01)
	char pad_4BA[0x96]; // 0x4ba(0x96)

	void SetDecalMaterial(struct UMaterialInterface* NewDecalMaterial); // Function Engine.InstancedDeferredDecalComponent.SetDecalMaterial // Final|Native|Public|BlueprintCallable // @ game+0x5b48404
	struct UMaterialInterface* GetDecalMaterial(); // Function Engine.InstancedDeferredDecalComponent.GetDecalMaterial // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b23ce8
	struct UMaterialInstanceDynamic* CreateDynamicMaterialInstance(); // Function Engine.InstancedDeferredDecalComponent.CreateDynamicMaterialInstance // Native|Public|BlueprintCallable // @ game+0x5b19530
};

// Class Engine.InstancedSplineDecalComponent
// Size: 0x520 (Inherited: 0x4b0)
struct UInstancedSplineDecalComponent : USceneComponent {
	bool UseDynamicInstanceBuffer; // 0x4b0(0x01)
	bool KeepInstanceBufferCPUAccess; // 0x4b1(0x01)
	char pad_4B2[0x6]; // 0x4b2(0x06)
	struct TArray<struct FInstancedSplineDecalInstanceData> PerInstanceDecalData; // 0x4b8(0x10)
	struct UStaticMesh* StaticMesh; // 0x4c8(0x08)
	struct UMaterialInterface* DecalMaterial; // 0x4d0(0x08)
	char pad_4D8[0x48]; // 0x4d8(0x48)

	bool SetStaticMesh(struct UStaticMesh* NewMesh); // Function Engine.InstancedSplineDecalComponent.SetStaticMesh // Final|Native|Public|BlueprintCallable // @ game+0x5b50c8c
	void SetDecalMaterial(struct UMaterialInterface* NewDecalMaterial); // Function Engine.InstancedSplineDecalComponent.SetDecalMaterial // Final|Native|Public|BlueprintCallable // @ game+0x5b4849c
	bool RemoveInstance(int32 InstanceIndex); // Function Engine.InstancedSplineDecalComponent.RemoveInstance // Native|Public|BlueprintCallable // @ game+0x5b41b3c
	void OnRep_StaticMesh(struct UStaticMesh* OldStaticMesh); // Function Engine.InstancedSplineDecalComponent.OnRep_StaticMesh // Final|Native|Public // @ game+0x5b3c754
	int32 GetInstanceCount(); // Function Engine.InstancedSplineDecalComponent.GetInstanceCount // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b247a4
	struct UMaterialInterface* GetDecalMaterial(); // Function Engine.InstancedSplineDecalComponent.GetDecalMaterial // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b23d00
	struct UMaterialInstanceDynamic* CreateDynamicMaterialInstance(); // Function Engine.InstancedSplineDecalComponent.CreateDynamicMaterialInstance // Native|Public|BlueprintCallable // @ game+0x5b19558
	void ClearInstances(); // Function Engine.InstancedSplineDecalComponent.ClearInstances // Native|Public|BlueprintCallable // @ game+0x4d2c57c
	int32 AddInstanceWorldSpace(struct FTransform WorldTransform, struct FSplineParams SplineParams); // Function Engine.InstancedSplineDecalComponent.AddInstanceWorldSpace // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b0a150
	int32 AddInstance(struct FTransform InstanceTransform, struct FSplineParams SplineParams); // Function Engine.InstancedSplineDecalComponent.AddInstance // Native|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b09d08
};

// Class Engine.PrimaryDataAsset
// Size: 0x40 (Inherited: 0x40)
struct UPrimaryDataAsset : UDataAsset {
};

// Class Engine.LevelBlockType
// Size: 0x68 (Inherited: 0x40)
struct ULevelBlockType : UDataAsset {
	enum class ESpawnPointRollType RollType; // 0x40(0x01)
	char pad_41[0x7]; // 0x41(0x07)
	struct TArray<struct FLevelBlockVariation> Variants; // 0x48(0x10)
	struct TArray<struct FRotationRange> RotationRanges; // 0x58(0x10)
};

// Class Engine.LevelBlockSpawnPointComponent
// Size: 0x4c0 (Inherited: 0x4b0)
struct ULevelBlockSpawnPointComponent : USceneComponent {
	struct ULevelBlockType* LevelBlockType; // 0x4b0(0x08)
	bool bRandomizeRotation; // 0x4b8(0x01)
	enum class EPreviewIndexType PreviewIndexType; // 0x4b9(0x01)
	char pad_4BA[0x2]; // 0x4ba(0x02)
	int32 PreviewIndex; // 0x4bc(0x04)
};

// Class Engine.LightComponentBase
// Size: 0x4e0 (Inherited: 0x4b0)
struct ULightComponentBase : USceneComponent {
	struct FGuid LightGuid; // 0x4b0(0x10)
	float Brightness; // 0x4c0(0x04)
	float Intensity; // 0x4c4(0x04)
	struct FColor LightColor; // 0x4c8(0x04)
	char bAffectsWorld : 1; // 0x4cc(0x01)
	char CastShadows : 1; // 0x4cc(0x01)
	char CastStaticShadows : 1; // 0x4cc(0x01)
	char CastDynamicShadows : 1; // 0x4cc(0x01)
	char bAffectTranslucentLighting : 1; // 0x4cc(0x01)
	char bCastVolumetricShadow : 1; // 0x4cc(0x01)
	char pad_4CC_6 : 2; // 0x4cc(0x01)
	char pad_4CD[0x3]; // 0x4cd(0x03)
	float IndirectLightingIntensity; // 0x4d0(0x04)
	float VolumetricScatteringIntensity; // 0x4d4(0x04)
	bool bCachedCastShadow; // 0x4d8(0x01)
	char pad_4D9[0x7]; // 0x4d9(0x07)

	void SetCastVolumetricShadow(bool bNewValue); // Function Engine.LightComponentBase.SetCastVolumetricShadow // Final|Native|Public|BlueprintCallable // @ game+0x5b470e8
	void SetCastShadows(bool bNewValue); // Function Engine.LightComponentBase.SetCastShadows // Final|Native|Public|BlueprintCallable // @ game+0x5b47054
	struct FLinearColor GetLightColor(); // Function Engine.LightComponentBase.GetLightColor // Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5b26a54
};

// Class Engine.LightComponent
// Size: 0x5d0 (Inherited: 0x4e0)
struct ULightComponent : ULightComponentBase {
	float Temperature; // 0x4e0(0x04)
	float MaxDrawDistance; // 0x4e4(0x04)
	float MaxDistanceFadeRange; // 0x4e8(0x04)
	char bUseTemperature : 1; // 0x4ec(0x01)
	char pad_4EC_1 : 7; // 0x4ec(0x01)
	char pad_4ED[0x3]; // 0x4ed(0x03)
	int32 ShadowMapChannel; // 0x4f0(0x04)
	char pad_4F4[0x4]; // 0x4f4(0x04)
	float MinRoughness; // 0x4f8(0x04)
	float ShadowResolutionScale; // 0x4fc(0x04)
	float ShadowBias; // 0x500(0x04)
	float ShadowSharpen; // 0x504(0x04)
	float ContactShadowLength; // 0x508(0x04)
	char InverseSquaredFalloff : 1; // 0x50c(0x01)
	char CastTranslucentShadows : 1; // 0x50c(0x01)
	char bCastShadowsFromCinematicObjectsOnly : 1; // 0x50c(0x01)
	char bAffectDynamicIndirectLighting : 1; // 0x50c(0x01)
	char pad_50C_4 : 4; // 0x50c(0x01)
	char pad_50D[0x3]; // 0x50d(0x03)
	struct FLightingChannels LightingChannels; // 0x510(0x03)
	char pad_513[0x5]; // 0x513(0x05)
	struct UMaterialInterface* LightFunctionMaterial; // 0x518(0x08)
	struct FVector LightFunctionScale; // 0x520(0x0c)
	char pad_52C[0x4]; // 0x52c(0x04)
	struct UTextureLightProfile* IESTexture; // 0x530(0x08)
	char bUseIESBrightness : 1; // 0x538(0x01)
	char pad_538_1 : 7; // 0x538(0x01)
	char pad_539[0x3]; // 0x539(0x03)
	float IESBrightnessScale; // 0x53c(0x04)
	float LightFunctionFadeDistance; // 0x540(0x04)
	float DisabledBrightness; // 0x544(0x04)
	char bEnableLightShaftBloom : 1; // 0x548(0x01)
	char pad_548_1 : 7; // 0x548(0x01)
	char pad_549[0x3]; // 0x549(0x03)
	float BloomScale; // 0x54c(0x04)
	float BloomThreshold; // 0x550(0x04)
	struct FColor BloomTint; // 0x554(0x04)
	bool bUseRayTracedDistanceFieldShadows; // 0x558(0x01)
	char pad_559[0x3]; // 0x559(0x03)
	float RayStartOffsetDepthScale; // 0x55c(0x04)
	char pad_560[0x70]; // 0x560(0x70)

	void SetVolumetricScatteringIntensity(float NewIntensity); // Function Engine.LightComponent.SetVolumetricScatteringIntensity // Final|Native|Public|BlueprintCallable // @ game+0x5b52d90
	void SetTemperature(float NewTemperature); // Function Engine.LightComponent.SetTemperature // Final|Native|Public|BlueprintCallable // @ game+0x5b5181c
	void SetLightFunctionScale(struct FVector NewLightFunctionScale); // Function Engine.LightComponent.SetLightFunctionScale // Final|Native|Public|HasDefaults|BlueprintCallable // @ game+0x5b4c1a0
	void SetLightFunctionMaterial(struct UMaterialInterface* NewLightFunctionMaterial); // Function Engine.LightComponent.SetLightFunctionMaterial // Final|Native|Public|BlueprintCallable // @ game+0x5b4c110
	void SetLightFunctionFadeDistance(float NewLightFunctionFadeDistance); // Function Engine.LightComponent.SetLightFunctionFadeDistance // Final|Native|Public|BlueprintCallable // @ game+0x5b4c078
	void SetLightFunctionDisabledBrightness(float NewValue); // Function Engine.LightComponent.SetLightFunctionDisabledBrightness // Final|Native|Public|BlueprintCallable // @ game+0x5b4bfe0
	void SetLightColor(struct FLinearColor NewLightColor, bool bSRGB); // Function Engine.LightComponent.SetLightColor // Final|Native|Public|HasDefaults|BlueprintCallable // @ game+0x5b4bd8c
	void SetIntensity(float NewIntensity); // Function Engine.LightComponent.SetIntensity // Final|Native|Public|BlueprintCallable // @ game+0x4983f0
	void SetIndirectLightingIntensity(float NewIntensity); // Function Engine.LightComponent.SetIndirectLightingIntensity // Final|Native|Public|BlueprintCallable // @ game+0x5b4b2e4
	void SetIESTexture(struct UTextureLightProfile* NewValue); // Function Engine.LightComponent.SetIESTexture // Final|Native|Public|BlueprintCallable // @ game+0x5b4b198
	void SetEnableLightShaftBloom(bool bNewValue); // Function Engine.LightComponent.SetEnableLightShaftBloom // Final|Native|Public|BlueprintCallable // @ game+0x5b493ec
	void SetBloomTint(struct FColor NewValue); // Function Engine.LightComponent.SetBloomTint // Final|Native|Public|HasDefaults|BlueprintCallable // @ game+0x5b45a58
	void SetBloomThreshold(float NewValue); // Function Engine.LightComponent.SetBloomThreshold // Final|Native|Public|BlueprintCallable // @ game+0x5b459c0
	void SetBloomScale(float NewValue); // Function Engine.LightComponent.SetBloomScale // Final|Native|Public|BlueprintCallable // @ game+0x5b45928
	void SetAffectTranslucentLighting(bool bNewValue); // Function Engine.LightComponent.SetAffectTranslucentLighting // Final|Native|Public|BlueprintCallable // @ game+0x5b43a04
	void SetAffectDynamicIndirectLighting(bool bNewValue); // Function Engine.LightComponent.SetAffectDynamicIndirectLighting // Final|Native|Public|BlueprintCallable // @ game+0x5b43934
};

// Class Engine.DirectionalLightComponent
// Size: 0x650 (Inherited: 0x5d0)
struct UDirectionalLightComponent : ULightComponent {
	char bEnableLightShaftOcclusion : 1; // 0x5d0(0x01)
	char pad_5D0_1 : 7; // 0x5d0(0x01)
	char pad_5D1[0x3]; // 0x5d1(0x03)
	float OcclusionMaskDarkness; // 0x5d4(0x04)
	float OcclusionDepthRange; // 0x5d8(0x04)
	struct FVector LightShaftOverrideDirection; // 0x5dc(0x0c)
	float WholeSceneDynamicShadowRadius; // 0x5e8(0x04)
	float DynamicShadowDistanceMovableLight; // 0x5ec(0x04)
	float DynamicShadowDistanceStationaryLight; // 0x5f0(0x04)
	int32 DynamicShadowCascades; // 0x5f4(0x04)
	float CascadeDistributionExponent; // 0x5f8(0x04)
	float CascadeTransitionFraction; // 0x5fc(0x04)
	float ShadowDistanceFadeoutFraction; // 0x600(0x04)
	char bUseInsetShadowsForMovableObjects : 1; // 0x604(0x01)
	char pad_604_1 : 7; // 0x604(0x01)
	char pad_605[0x3]; // 0x605(0x03)
	int32 FarShadowCascadeCount; // 0x608(0x04)
	float FarShadowDistance; // 0x60c(0x04)
	float DistanceFieldShadowDistance; // 0x610(0x04)
	float LightSourceAngle; // 0x614(0x04)
	float TraceDistance; // 0x618(0x04)
	struct FLightmassDirectionalLightSettings LightmassSettings; // 0x61c(0x10)
	char bCastModulatedShadows : 1; // 0x62c(0x01)
	char pad_62C_1 : 7; // 0x62c(0x01)
	char pad_62D[0x3]; // 0x62d(0x03)
	struct FColor ModulatedShadowColor; // 0x630(0x04)
	char bUsedAsAtmosphereSunLight : 1; // 0x634(0x01)
	char bUseGridShadow : 1; // 0x634(0x01)
	char pad_634_2 : 6; // 0x634(0x01)
	char pad_635[0x3]; // 0x635(0x03)
	struct TArray<struct FGridShadowSplitSettings> GridShadowSplitSettings; // 0x638(0x10)
	char pad_648[0x8]; // 0x648(0x08)

	void SetShadowDistanceFadeoutFraction(float NewValue); // Function Engine.DirectionalLightComponent.SetShadowDistanceFadeoutFraction // Final|Native|Public|BlueprintCallable // @ game+0x5b4f598
	void SetOcclusionMaskDarkness(float NewValue); // Function Engine.DirectionalLightComponent.SetOcclusionMaskDarkness // Final|Native|Public|BlueprintCallable // @ game+0x5b4dd04
	void SetLightShaftOverrideDirection(struct FVector NewValue); // Function Engine.DirectionalLightComponent.SetLightShaftOverrideDirection // Final|Native|Public|HasDefaults|BlueprintCallable // @ game+0x5b4c240
	void SetEnableLightShaftOcclusion(bool bNewValue); // Function Engine.DirectionalLightComponent.SetEnableLightShaftOcclusion // Final|Native|Public|BlueprintCallable // @ game+0x5b494b4
	void SetDynamicShadowDistanceStationaryLight(float NewValue); // Function Engine.DirectionalLightComponent.SetDynamicShadowDistanceStationaryLight // Final|Native|Public|BlueprintCallable // @ game+0x5b49040
	void SetDynamicShadowDistanceMovableLight(float NewValue); // Function Engine.DirectionalLightComponent.SetDynamicShadowDistanceMovableLight // Final|Native|Public|BlueprintCallable // @ game+0x5b48f98
	void SetDynamicShadowCascades(int32 NewValue); // Function Engine.DirectionalLightComponent.SetDynamicShadowCascades // Final|Native|Public|BlueprintCallable // @ game+0x5b48ef8
	void SetCascadeTransitionFraction(float NewValue); // Function Engine.DirectionalLightComponent.SetCascadeTransitionFraction // Final|Native|Public|BlueprintCallable // @ game+0x5b46e48
	void SetCascadeDistributionExponent(float NewValue); // Function Engine.DirectionalLightComponent.SetCascadeDistributionExponent // Final|Native|Public|BlueprintCallable // @ game+0x5b46da0
};

// Class Engine.PointLightComponent
// Size: 0x600 (Inherited: 0x5d0)
struct UPointLightComponent : ULightComponent {
	float Radius; // 0x5d0(0x04)
	float AttenuationRadius; // 0x5d4(0x04)
	char bUseInverseSquaredFalloff : 1; // 0x5d8(0x01)
	char pad_5D8_1 : 7; // 0x5d8(0x01)
	char pad_5D9[0x3]; // 0x5d9(0x03)
	float LightFalloffExponent; // 0x5dc(0x04)
	float SourceRadius; // 0x5e0(0x04)
	float SourceLength; // 0x5e4(0x04)
	struct FLightmassPointLightSettings LightmassSettings; // 0x5e8(0x0c)
	char pad_5F4[0xc]; // 0x5f4(0x0c)

	void SetSourceRadius(float bNewValue); // Function Engine.PointLightComponent.SetSourceRadius // Final|Native|Public|BlueprintCallable // @ game+0x5b4fcec
	void SetSourceLength(float NewValue); // Function Engine.PointLightComponent.SetSourceLength // Final|Native|Public|BlueprintCallable // @ game+0x5b4fc54
	void SetLightFalloffExponent(float NewLightFalloffExponent); // Function Engine.PointLightComponent.SetLightFalloffExponent // Final|Native|Public|BlueprintCallable // @ game+0x5b4bf48
	void SetAttenuationRadius(float NewRadius); // Function Engine.PointLightComponent.SetAttenuationRadius // Final|Native|Public|BlueprintCallable // @ game+0x5b455dc
};

// Class Engine.SpotLightComponent
// Size: 0x610 (Inherited: 0x600)
struct USpotLightComponent : UPointLightComponent {
	float InnerConeAngle; // 0x5f8(0x04)
	float OuterConeAngle; // 0x5fc(0x04)
	float LightShaftConeAngle; // 0x600(0x04)
	char pad_60C[0x4]; // 0x60c(0x04)

	void SetOuterConeAngle(float NewOuterConeAngle); // Function Engine.SpotLightComponent.SetOuterConeAngle // Final|Native|Public|BlueprintCallable // @ game+0x5b4e14c
	void SetInnerConeAngle(float NewInnerConeAngle); // Function Engine.SpotLightComponent.SetInnerConeAngle // Final|Native|Public|BlueprintCallable // @ game+0x5b4b414
};

// Class Engine.SkyLightComponent
// Size: 0x690 (Inherited: 0x4e0)
struct USkyLightComponent : ULightComponentBase {
	enum class ESkyLightSourceType SourceType; // 0x4e0(0x01)
	char pad_4E1[0x7]; // 0x4e1(0x07)
	struct UTextureCube* Cubemap; // 0x4e8(0x08)
	float SourceCubemapAngle; // 0x4f0(0x04)
	int32 CubemapResolution; // 0x4f4(0x04)
	float SkyDistanceThreshold; // 0x4f8(0x04)
	bool bCaptureEmissiveOnly; // 0x4fc(0x01)
	bool bLowerHemisphereIsBlack; // 0x4fd(0x01)
	char pad_4FE[0x2]; // 0x4fe(0x02)
	struct FLinearColor LowerHemisphereColor; // 0x500(0x10)
	float OcclusionMaxDistance; // 0x510(0x04)
	float Contrast; // 0x514(0x04)
	float OcclusionExponent; // 0x518(0x04)
	float MinOcclusion; // 0x51c(0x04)
	struct FColor OcclusionTint; // 0x520(0x04)
	enum class EOcclusionCombineMode OcclusionCombineMode; // 0x524(0x01)
	char pad_525[0xa3]; // 0x525(0xa3)
	struct UTextureCube* BlendDestinationCubemap; // 0x5c8(0x08)
	char pad_5D0[0xc0]; // 0x5d0(0xc0)

	void SetVolumetricScatteringIntensity(float NewIntensity); // Function Engine.SkyLightComponent.SetVolumetricScatteringIntensity // Final|Native|Public|BlueprintCallable // @ game+0x5b52e28
	void SetOcclusionTint(struct FColor InTint); // Function Engine.SkyLightComponent.SetOcclusionTint // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b4dd9c
	void SetOcclusionExponent(float InOcclusionExponent); // Function Engine.SkyLightComponent.SetOcclusionExponent // Final|Native|Public|BlueprintCallable // @ game+0x5b4dc6c
	void SetOcclusionContrast(float InOcclusionContrast); // Function Engine.SkyLightComponent.SetOcclusionContrast // Final|Native|Public|BlueprintCallable // @ game+0x5b4dbd4
	void SetMinOcclusion(float InMinOcclusion); // Function Engine.SkyLightComponent.SetMinOcclusion // Final|Native|Public|BlueprintCallable // @ game+0x5b4d3fc
	void SetLightColor(struct FLinearColor NewLightColor); // Function Engine.SkyLightComponent.SetLightColor // Final|Native|Public|HasDefaults|BlueprintCallable // @ game+0x5b4be80
	void SetIntensity(float NewIntensity); // Function Engine.SkyLightComponent.SetIntensity // Final|Native|Public|BlueprintCallable // @ game+0xaa4294
	void SetIndirectLightingIntensity(float NewIntensity); // Function Engine.SkyLightComponent.SetIndirectLightingIntensity // Final|Native|Public|BlueprintCallable // @ game+0x5b4b37c
	void SetCubemapBlend(struct UTextureCube* SourceCubemap, struct UTextureCube* DestinationCubemap, float InBlendFraction); // Function Engine.SkyLightComponent.SetCubemapBlend // Final|Native|Public|BlueprintCallable // @ game+0x5b480b8
	void SetCubemap(struct UTextureCube* NewCubemap); // Function Engine.SkyLightComponent.SetCubemap // Final|Native|Public|BlueprintCallable // @ game+0x5b47ffc
	void RecaptureSky(); // Function Engine.SkyLightComponent.RecaptureSky // Final|Native|Public|BlueprintCallable // @ game+0x5b41a38
};

// Class Engine.LightmassPortalComponent
// Size: 0x4c0 (Inherited: 0x4b0)
struct ULightmassPortalComponent : USceneComponent {
	struct UBoxComponent* PreviewBox; // 0x4b0(0x08)
	char pad_4B8[0x8]; // 0x4b8(0x08)
};

// Class Engine.NavigationGraphNodeComponent
// Size: 0x4e0 (Inherited: 0x4b0)
struct UNavigationGraphNodeComponent : USceneComponent {
	struct FNavGraphNode Node; // 0x4b0(0x18)
	struct UNavigationGraphNodeComponent* NextNodeComponent; // 0x4c8(0x08)
	struct UNavigationGraphNodeComponent* PrevNodeComponent; // 0x4d0(0x08)
	char pad_4D8[0x8]; // 0x4d8(0x08)
};

// Class Engine.PhysicsConstraintComponent
// Size: 0x6f0 (Inherited: 0x4b0)
struct UPhysicsConstraintComponent : USceneComponent {
	struct AActor* ConstraintActor1; // 0x4b0(0x08)
	struct FConstrainComponentPropName ComponentName1; // 0x4b8(0x08)
	struct AActor* ConstraintActor2; // 0x4c0(0x08)
	struct FConstrainComponentPropName ComponentName2; // 0x4c8(0x08)
	char pad_4D0[0x10]; // 0x4d0(0x10)
	struct UPhysicsConstraintTemplate* ConstraintSetup; // 0x4e0(0x08)
	struct FMulticastDelegate OnConstraintBroken; // 0x4e8(0x10)
	char pad_4F8[0x8]; // 0x4f8(0x08)
	struct FConstraintInstance ConstraintInstance; // 0x500(0x1f0)

	void SetOrientationDriveTwistAndSwing(bool bEnableTwistDrive, bool bEnableSwingDrive); // Function Engine.PhysicsConstraintComponent.SetOrientationDriveTwistAndSwing // Final|Native|Public|BlueprintCallable // @ game+0x5b4df28
	void SetOrientationDriveSLERP(bool bEnableSLERP); // Function Engine.PhysicsConstraintComponent.SetOrientationDriveSLERP // Final|Native|Public|BlueprintCallable // @ game+0x5b4de58
	void SetLinearZLimit(enum class ELinearConstraintMotion ConstraintType, float LimitSize); // Function Engine.PhysicsConstraintComponent.SetLinearZLimit // Final|Native|Public|BlueprintCallable // @ game+0x5b4ce6c
	void SetLinearYLimit(enum class ELinearConstraintMotion ConstraintType, float LimitSize); // Function Engine.PhysicsConstraintComponent.SetLinearYLimit // Final|Native|Public|BlueprintCallable // @ game+0x5b4cd78
	void SetLinearXLimit(enum class ELinearConstraintMotion ConstraintType, float LimitSize); // Function Engine.PhysicsConstraintComponent.SetLinearXLimit // Final|Native|Public|BlueprintCallable // @ game+0x5b4cc84
	void SetLinearVelocityTarget(struct FVector InVelTarget); // Function Engine.PhysicsConstraintComponent.SetLinearVelocityTarget // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b4cb70
	void SetLinearVelocityDrive(bool bEnableDriveX, bool bEnableDriveY, bool bEnableDriveZ); // Function Engine.PhysicsConstraintComponent.SetLinearVelocityDrive // Final|Native|Public|BlueprintCallable // @ game+0x5b4ca38
	void SetLinearPositionTarget(struct FVector InPosTarget); // Function Engine.PhysicsConstraintComponent.SetLinearPositionTarget // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b4c880
	void SetLinearPositionDrive(bool bEnableDriveX, bool bEnableDriveY, bool bEnableDriveZ); // Function Engine.PhysicsConstraintComponent.SetLinearPositionDrive // Final|Native|Public|BlueprintCallable // @ game+0x5b4c748
	void SetLinearDriveParams(float PositionStrength, float VelocityStrength, float InForceLimit); // Function Engine.PhysicsConstraintComponent.SetLinearDriveParams // Final|Native|Public|BlueprintCallable // @ game+0x5b4c624
	void SetDisableCollision(bool bDisableCollision); // Function Engine.PhysicsConstraintComponent.SetDisableCollision // Final|Native|Public|BlueprintCallable // @ game+0x5b48ba0
	void SetConstraintReferencePosition(enum class EConstraintFrame Frame, struct FVector RefPosition); // Function Engine.PhysicsConstraintComponent.SetConstraintReferencePosition // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b47eb0
	void SetConstraintReferenceOrientation(enum class EConstraintFrame Frame, struct FVector PriAxis, struct FVector SecAxis); // Function Engine.PhysicsConstraintComponent.SetConstraintReferenceOrientation // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b47d60
	void SetConstraintReferenceFrame(enum class EConstraintFrame Frame, struct FTransform RefFrame); // Function Engine.PhysicsConstraintComponent.SetConstraintReferenceFrame // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b47c2c
	void SetConstrainedComponents(struct UPrimitiveComponent* Component1, struct FName BoneName1, struct UPrimitiveComponent* Component2, struct FName BoneName2); // Function Engine.PhysicsConstraintComponent.SetConstrainedComponents // Final|Native|Public|BlueprintCallable // @ game+0x5b47804
	void SetAngularVelocityTarget(struct FVector InVelTarget); // Function Engine.PhysicsConstraintComponent.SetAngularVelocityTarget // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b44d5c
	void SetAngularVelocityDriveTwistAndSwing(bool bEnableTwistDrive, bool bEnableSwingDrive); // Function Engine.PhysicsConstraintComponent.SetAngularVelocityDriveTwistAndSwing // Final|Native|Public|BlueprintCallable // @ game+0x5b44c68
	void SetAngularVelocityDriveSLERP(bool bEnableSLERP); // Function Engine.PhysicsConstraintComponent.SetAngularVelocityDriveSLERP // Final|Native|Public|BlueprintCallable // @ game+0x5b44b94
	void SetAngularVelocityDrive(bool bEnableSwingDrive, bool bEnableTwistDrive); // Function Engine.PhysicsConstraintComponent.SetAngularVelocityDrive // Final|Native|Public|BlueprintCallable // @ game+0x5b44aa0
	void SetAngularTwistLimit(enum class EAngularConstraintMotion ConstraintType, float TwistLimitAngle); // Function Engine.PhysicsConstraintComponent.SetAngularTwistLimit // Final|Native|Public|BlueprintCallable // @ game+0x5b449ac
	void SetAngularSwing2Limit(enum class EAngularConstraintMotion MotionType, float Swing2LimitAngle); // Function Engine.PhysicsConstraintComponent.SetAngularSwing2Limit // Final|Native|Public|BlueprintCallable // @ game+0x5b448b8
	void SetAngularSwing1Limit(enum class EAngularConstraintMotion MotionType, float Swing1LimitAngle); // Function Engine.PhysicsConstraintComponent.SetAngularSwing1Limit // Final|Native|Public|BlueprintCallable // @ game+0x5b447c4
	void SetAngularOrientationTarget(struct FRotator InPosTarget); // Function Engine.PhysicsConstraintComponent.SetAngularOrientationTarget // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b44684
	void SetAngularOrientationDrive(bool bEnableSwingDrive, bool bEnableTwistDrive); // Function Engine.PhysicsConstraintComponent.SetAngularOrientationDrive // Final|Native|Public|BlueprintCallable // @ game+0x5b44590
	void SetAngularDriveParams(float PositionStrength, float VelocityStrength, float InForceLimit); // Function Engine.PhysicsConstraintComponent.SetAngularDriveParams // Final|Native|Public|BlueprintCallable // @ game+0x5b442ec
	void SetAngularDriveMode(enum class EAngularDriveMode DriveMode); // Function Engine.PhysicsConstraintComponent.SetAngularDriveMode // Final|Native|Public|BlueprintCallable // @ game+0x5b44224
	float GetCurrentTwist(); // Function Engine.PhysicsConstraintComponent.GetCurrentTwist // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b238e4
	float GetCurrentSwing2(); // Function Engine.PhysicsConstraintComponent.GetCurrentSwing2 // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b238b0
	float GetCurrentSwing1(); // Function Engine.PhysicsConstraintComponent.GetCurrentSwing1 // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b2387c
	void GetConstraintForce(struct FVector OutLinearForce, struct FVector OutAngularForce); // Function Engine.PhysicsConstraintComponent.GetConstraintForce // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b230e4
	void BreakConstraint(); // Function Engine.PhysicsConstraintComponent.BreakConstraint // Final|Native|Public|BlueprintCallable // @ game+0x5b127b4
};

// Class Engine.PhysicsSpringComponent
// Size: 0x4e0 (Inherited: 0x4b0)
struct UPhysicsSpringComponent : USceneComponent {
	float SpringStiffness; // 0x4b0(0x04)
	float SpringDamping; // 0x4b4(0x04)
	float SpringLengthAtRest; // 0x4b8(0x04)
	float SpringRadius; // 0x4bc(0x04)
	enum class ECollisionChannel SpringChannel; // 0x4c0(0x01)
	bool bIgnoreSelf; // 0x4c1(0x01)
	char pad_4C2[0x2]; // 0x4c2(0x02)
	float SpringCompression; // 0x4c4(0x04)
	char pad_4C8[0x18]; // 0x4c8(0x18)

	struct FVector GetSpringRestingPoint(); // Function Engine.PhysicsSpringComponent.GetSpringRestingPoint // Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5b2a010
	struct FVector GetSpringDirection(); // Function Engine.PhysicsSpringComponent.GetSpringDirection // Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5b29fe0
	struct FVector GetSpringCurrentEndPoint(); // Function Engine.PhysicsSpringComponent.GetSpringCurrentEndPoint // Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5b29fac
	float GetNormalizedCompressionScalar(); // Function Engine.PhysicsSpringComponent.GetNormalizedCompressionScalar // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b275c0
};

// Class Engine.PhysicsThrusterComponent
// Size: 0x4c0 (Inherited: 0x4b0)
struct UPhysicsThrusterComponent : USceneComponent {
	float ThrustStrength; // 0x4b0(0x04)
	char pad_4B4[0xc]; // 0x4b4(0x0c)
};

// Class Engine.PostProcessComponent
// Size: 0xa40 (Inherited: 0x4b0)
struct UPostProcessComponent : USceneComponent {
	char pad_4B0[0x10]; // 0x4b0(0x10)
	struct FPostProcessSettings Settings; // 0x4c0(0x570)
	float Priority; // 0xa30(0x04)
	float BlendRadius; // 0xa34(0x04)
	float BlendWeight; // 0xa38(0x04)
	char bEnabled : 1; // 0xa3c(0x01)
	char bUnbound : 1; // 0xa3c(0x01)
	char pad_A3C_2 : 6; // 0xa3c(0x01)
	char pad_A3D[0x3]; // 0xa3d(0x03)

	void AddOrUpdateBlendable(TScriptInterface<struct UBlendableInterface> InBlendableObject, float InWeight); // Function Engine.PostProcessComponent.AddOrUpdateBlendable // Final|RequiredAPI|Native|Public|BlueprintCallable // @ game+0x5b0a740
};

// Class Engine.BrushComponent
// Size: 0x9f0 (Inherited: 0x9d0)
struct UBrushComponent : UPrimitiveComponent {
	struct UModel* Brush; // 0x9d0(0x08)
	struct UBodySetup* BrushBodySetup; // 0x9d8(0x08)
	struct FVector PrePivot; // 0x9e0(0x0c)
	char pad_9EC[0x4]; // 0x9ec(0x04)
};

// Class Engine.ConcreteCollisionComponent
// Size: 0xa00 (Inherited: 0x9d0)
struct UConcreteCollisionComponent : UPrimitiveComponent {
	char pad_9D0[0x8]; // 0x9d0(0x08)
	struct TArray<struct UPhysicalMaterial*> PhysicalMaterials; // 0x9d8(0x10)
	struct TArray<struct FConcreteCollisionSourceData> SourceData; // 0x9e8(0x10)
	struct UBodySetup* BodySetup; // 0x9f8(0x08)
};

// Class Engine.DrawFrustumComponent
// Size: 0x9f0 (Inherited: 0x9d0)
struct UDrawFrustumComponent : UPrimitiveComponent {
	struct FColor FrustumColor; // 0x9d0(0x04)
	float FrustumAngle; // 0x9d4(0x04)
	float FrustumAspectRatio; // 0x9d8(0x04)
	float FrustumStartDist; // 0x9dc(0x04)
	float FrustumEndDist; // 0x9e0(0x04)
	char pad_9E4[0x4]; // 0x9e4(0x04)
	struct UTexture* Texture; // 0x9e8(0x08)
};

// Class Engine.FoliageBlockingVolumeComponent
// Size: 0x9e0 (Inherited: 0x9d0)
struct UFoliageBlockingVolumeComponent : UPrimitiveComponent {
	struct TArray<struct FVector2D> Points; // 0x9d0(0x10)
};

// Class Engine.GrassVolumeComponent
// Size: 0xa00 (Inherited: 0xa00)
struct UGrassVolumeComponent : UBoxComponent {
};

// Class Engine.GrassVolumesContainerComponent
// Size: 0x9e0 (Inherited: 0x9d0)
struct UGrassVolumesContainerComponent : UPrimitiveComponent {
	struct TArray<struct FGrassBoxVolumeData> GrassBoxVolumes; // 0x9d0(0x10)
};

// Class Engine.LevelBlockLandscapeGizmoComponent
// Size: 0xa30 (Inherited: 0x9d0)
struct ULevelBlockLandscapeGizmoComponent : UPrimitiveComponent {
	struct ALandscape* SourceLandscapeActor; // 0x9d0(0x1c)
	struct ALandscape* TargetLandscapeActor; // 0x9ec(0x1c)
	struct UTexture2D* BlendMask; // 0xa08(0x08)
	struct FVector2D Extent; // 0xa10(0x08)
	struct FIntPoint TargetLandscapeRect; // 0xa18(0x08)
	char bHeightmap : 1; // 0xa20(0x01)
	char bWeightmaps : 1; // 0xa20(0x01)
	char bVisibility : 1; // 0xa20(0x01)
	char bHideFoliage : 1; // 0xa20(0x01)
	char pad_A20_4 : 4; // 0xa20(0x01)
	char pad_A21[0xf]; // 0xa21(0x0f)
};

// Class Engine.LineBatchComponent
// Size: 0xa10 (Inherited: 0x9d0)
struct ULineBatchComponent : UPrimitiveComponent {
	char pad_9D0[0x40]; // 0x9d0(0x40)
};

// Class Engine.MaterialBillboardComponent
// Size: 0x9e0 (Inherited: 0x9d0)
struct UMaterialBillboardComponent : UPrimitiveComponent {
	struct TArray<struct FMaterialSpriteElement> Elements; // 0x9d0(0x10)

	void SetElements(struct TArray<struct FMaterialSpriteElement> NewElements); // Function Engine.MaterialBillboardComponent.SetElements // Final|Native|Public|HasOutParms|BlueprintCallable // @ game+0x5b490e8
	void AddElement(struct UMaterialInterface* Material, struct UCurveFloat* DistanceToOpacityCurve, bool bSizeIsInScreenSpace, float BaseSizeX, float BaseSizeY, struct UCurveFloat* DistanceToSizeCurve); // Function Engine.MaterialBillboardComponent.AddElement // Final|Native|Public|BlueprintCallable // @ game+0x5b09654
};

// Class Engine.PoseableMeshComponent
// Size: 0xd60 (Inherited: 0xc80)
struct UPoseableMeshComponent : USkinnedMeshComponent {
	char pad_C80[0xe0]; // 0xc80(0xe0)

	void SetBoneTransformByName(struct FName BoneName, struct FTransform InTransform, enum class EBoneSpaces BoneSpace); // Function Engine.PoseableMeshComponent.SetBoneTransformByName // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b45ff4
	void SetBoneScaleByName(struct FName BoneName, struct FVector InScale3D, enum class EBoneSpaces BoneSpace); // Function Engine.PoseableMeshComponent.SetBoneScaleByName // Final|Native|Public|HasDefaults|BlueprintCallable // @ game+0x5b45eb8
	void SetBoneRotationByName(struct FName BoneName, struct FRotator InRotation, enum class EBoneSpaces BoneSpace); // Function Engine.PoseableMeshComponent.SetBoneRotationByName // Final|Native|Public|HasDefaults|BlueprintCallable // @ game+0x5b45d2c
	void SetBoneLocationByName(struct FName BoneName, struct FVector InLocation, enum class EBoneSpaces BoneSpace); // Function Engine.PoseableMeshComponent.SetBoneLocationByName // Final|Native|Public|HasDefaults|BlueprintCallable // @ game+0x5b45bf0
	void ResetBoneTransformByName(struct FName BoneName); // Function Engine.PoseableMeshComponent.ResetBoneTransformByName // Final|Native|Public|BlueprintCallable // @ game+0x5b421e0
	struct FTransform GetBoneTransformByName(struct FName BoneName, enum class EBoneSpaces BoneSpace); // Function Engine.PoseableMeshComponent.GetBoneTransformByName // Final|Native|Public|HasDefaults|BlueprintCallable // @ game+0x5b22b14
	struct FVector GetBoneScaleByName(struct FName BoneName, enum class EBoneSpaces BoneSpace); // Function Engine.PoseableMeshComponent.GetBoneScaleByName // Final|Native|Public|HasDefaults|BlueprintCallable // @ game+0x5b229e4
	struct FRotator GetBoneRotationByName(struct FName BoneName, enum class EBoneSpaces BoneSpace); // Function Engine.PoseableMeshComponent.GetBoneRotationByName // Final|Native|Public|HasDefaults|BlueprintCallable // @ game+0x5b228b4
	struct FVector GetBoneLocationByName(struct FName BoneName, enum class EBoneSpaces BoneSpace); // Function Engine.PoseableMeshComponent.GetBoneLocationByName // Final|Native|Public|HasDefaults|BlueprintCallable // @ game+0x5b22600
	void CopyPoseFromSkeletalComponent(struct USkeletalMeshComponent* InComponentToCopy); // Function Engine.PoseableMeshComponent.CopyPoseFromSkeletalComponent // Final|Native|Public|BlueprintCallable // @ game+0x5b19388
};

// Class Engine.SplineMeshComponent
// Size: 0xc20 (Inherited: 0xb80)
struct USplineMeshComponent : UStaticMeshComponent {
	struct FSplineMeshParams SplineParams; // 0xb80(0x58)
	struct FVector SplineUpDir; // 0xbd8(0x0c)
	char bAllowSplineEditingPerInstance : 1; // 0xbe4(0x01)
	char bSmoothInterpRollScale : 1; // 0xbe4(0x01)
	char pad_BE4_2 : 6; // 0xbe4(0x01)
	char pad_BE5[0x3]; // 0xbe5(0x03)
	enum class ESplineMeshAxis ForwardAxis; // 0xbe8(0x01)
	char pad_BE9[0x3]; // 0xbe9(0x03)
	float SplineBoundaryMin; // 0xbec(0x04)
	float SplineBoundaryMax; // 0xbf0(0x04)
	char pad_BF4[0x4]; // 0xbf4(0x04)
	struct UBodySetup* BodySetup; // 0xbf8(0x08)
	struct FGuid CachedMeshBodySetupGuid; // 0xc00(0x10)
	char bMeshDirty : 1; // 0xc10(0x01)
	char pad_C10_1 : 7; // 0xc10(0x01)
	char pad_C11[0xf]; // 0xc11(0x0f)

	void UpdateMesh(); // Function Engine.SplineMeshComponent.UpdateMesh // Final|Native|Public|BlueprintCallable // @ game+0x5b5c154
	void SetStartTangent(struct FVector StartTangent, bool bUpdateMesh); // Function Engine.SplineMeshComponent.SetStartTangent // Final|Native|Public|HasDefaults|BlueprintCallable // @ game+0x5b50b90
	void SetStartScale(struct FVector2D StartScale, bool bUpdateMesh); // Function Engine.SplineMeshComponent.SetStartScale // Final|Native|Public|HasDefaults|BlueprintCallable // @ game+0x5b50a90
	void SetStartRoll(float StartRoll, bool bUpdateMesh); // Function Engine.SplineMeshComponent.SetStartRoll // Final|Native|Public|BlueprintCallable // @ game+0x5b50994
	void SetStartPosition(struct FVector StartPos, bool bUpdateMesh); // Function Engine.SplineMeshComponent.SetStartPosition // Final|Native|Public|HasDefaults|BlueprintCallable // @ game+0x5b50898
	void SetStartOffset(struct FVector2D StartOffset, bool bUpdateMesh); // Function Engine.SplineMeshComponent.SetStartOffset // Final|Native|Public|HasDefaults|BlueprintCallable // @ game+0x5b50798
	void SetStartAndEnd(struct FVector StartPos, struct FVector StartTangent, struct FVector EndPos, struct FVector EndTangent, bool bUpdateMesh); // Function Engine.SplineMeshComponent.SetStartAndEnd // Final|Native|Public|HasDefaults|BlueprintCallable // @ game+0x5b5043c
	void SetSplineUpDir(struct FVector InSplineUpDir, bool bUpdateMesh); // Function Engine.SplineMeshComponent.SetSplineUpDir // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b50278
	void SetForwardAxis(enum class ESplineMeshAxis InForwardAxis, bool bUpdateMesh); // Function Engine.SplineMeshComponent.SetForwardAxis // Final|Native|Public|BlueprintCallable // @ game+0x5b4a8c8
	void SetEndTangent(struct FVector EndTangent, bool bUpdateMesh); // Function Engine.SplineMeshComponent.SetEndTangent // Final|Native|Public|HasDefaults|BlueprintCallable // @ game+0x5b49a10
	void SetEndScale(struct FVector2D EndScale, bool bUpdateMesh); // Function Engine.SplineMeshComponent.SetEndScale // Final|Native|Public|HasDefaults|BlueprintCallable // @ game+0x5b49910
	void SetEndRoll(float EndRoll, bool bUpdateMesh); // Function Engine.SplineMeshComponent.SetEndRoll // Final|Native|Public|BlueprintCallable // @ game+0x5b49814
	void SetEndPosition(struct FVector EndPos, bool bUpdateMesh); // Function Engine.SplineMeshComponent.SetEndPosition // Final|Native|Public|HasDefaults|BlueprintCallable // @ game+0x5b49718
	void SetEndOffset(struct FVector2D EndOffset, bool bUpdateMesh); // Function Engine.SplineMeshComponent.SetEndOffset // Final|Native|Public|HasDefaults|BlueprintCallable // @ game+0x5b49618
	void SetBoundaryMin(float InBoundaryMin, bool bUpdateMesh); // Function Engine.SplineMeshComponent.SetBoundaryMin // Final|Native|Public|BlueprintCallable // @ game+0x5b46650
	void SetBoundaryMax(float InBoundaryMax, bool bUpdateMesh); // Function Engine.SplineMeshComponent.SetBoundaryMax // Final|Native|Public|BlueprintCallable // @ game+0x5b46460
	struct FVector GetStartTangent(); // Function Engine.SplineMeshComponent.GetStartTangent // Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5b2a0e0
	struct FVector2D GetStartScale(); // Function Engine.SplineMeshComponent.GetStartScale // Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5b2a0b8
	float GetStartRoll(); // Function Engine.SplineMeshComponent.GetStartRoll // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b2a0a0
	struct FVector GetStartPosition(); // Function Engine.SplineMeshComponent.GetStartPosition // Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5b2a078
	struct FVector2D GetStartOffset(); // Function Engine.SplineMeshComponent.GetStartOffset // Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5b2a050
	struct FVector GetSplineUpDir(); // Function Engine.SplineMeshComponent.GetSplineUpDir // Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5b29f84
	enum class ESplineMeshAxis GetForwardAxis(); // Function Engine.SplineMeshComponent.GetForwardAxis // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b248b0
	struct FVector GetEndTangent(); // Function Engine.SplineMeshComponent.GetEndTangent // Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5b246cc
	struct FVector2D GetEndScale(); // Function Engine.SplineMeshComponent.GetEndScale // Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5b246a4
	float GetEndRoll(); // Function Engine.SplineMeshComponent.GetEndRoll // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b2468c
	struct FVector GetEndPosition(); // Function Engine.SplineMeshComponent.GetEndPosition // Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5b24664
	struct FVector2D GetEndOffset(); // Function Engine.SplineMeshComponent.GetEndOffset // Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5b2463c
	float GetBoundaryMin(); // Function Engine.SplineMeshComponent.GetBoundaryMin // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b22c70
	float GetBoundaryMax(); // Function Engine.SplineMeshComponent.GetBoundaryMax // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b22c40
	void CalculateSplineMeshParams(struct USplineComponent* SplineComponent, struct USplineComponent* UpSplineComponent, int32 SegmentsCount, bool bUseSplineRotation, struct TArray<struct FSplineMeshParams> SegmentParams, struct TArray<struct FVector> SegmentsUpVectors); // Function Engine.SplineMeshComponent.CalculateSplineMeshParams // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x5b13a5c
};

// Class Engine.InstancedSplineMeshComponent
// Size: 0xc00 (Inherited: 0xb80)
struct UInstancedSplineMeshComponent : UStaticMeshComponent {
	struct TArray<struct FSplineInstanceData> PerInstanceSMData; // 0xb80(0x10)
	struct FVector SplineUpDir; // 0xb90(0x0c)
	char bSmoothInterpRollScale : 1; // 0xb9c(0x01)
	char pad_B9C_1 : 7; // 0xb9c(0x01)
	char pad_B9D[0x3]; // 0xb9d(0x03)
	enum class ESplineMeshAxis ForwardAxis; // 0xba0(0x01)
	char pad_BA1[0x3]; // 0xba1(0x03)
	float SplineBoundaryMin; // 0xba4(0x04)
	float SplineBoundaryMax; // 0xba8(0x04)
	struct FVector CollisionOffset; // 0xbac(0x0c)
	int32 InstanceStartCullDistance; // 0xbb8(0x04)
	int32 InstanceEndCullDistance; // 0xbbc(0x04)
	char pad_BC0[0x18]; // 0xbc0(0x18)
	struct UBodySetup* BodySetup; // 0xbd8(0x08)
	struct FGuid CachedMeshBodySetupGuid; // 0xbe0(0x10)
	uint32 CachedCollisionBuildVersion; // 0xbf0(0x04)
	char pad_BF4[0xc]; // 0xbf4(0x0c)

	void UpdateMesh(); // Function Engine.InstancedSplineMeshComponent.UpdateMesh // Final|Native|Public|BlueprintCallable // @ game+0x5b5c140
	void SetForwardAxis(enum class ESplineMeshAxis InForwardAxis, bool bUpdateMesh); // Function Engine.InstancedSplineMeshComponent.SetForwardAxis // Final|Native|Public|BlueprintCallable // @ game+0x5b4a7dc
	void SetCullDistances(int32 StartCullDistance, int32 EndCullDistance, bool bUpdateMesh); // Function Engine.InstancedSplineMeshComponent.SetCullDistances // Final|Native|Public|BlueprintCallable // @ game+0x5b481ec
	void SetBoundaryMin(float InBoundaryMin, bool bUpdateMesh); // Function Engine.InstancedSplineMeshComponent.SetBoundaryMin // Final|Native|Public|BlueprintCallable // @ game+0x5b4655c
	void SetBoundaryMax(float InBoundaryMax, bool bUpdateMesh); // Function Engine.InstancedSplineMeshComponent.SetBoundaryMax // Final|Native|Public|BlueprintCallable // @ game+0x5b4636c
	bool RemoveInstance(int32 InstanceIndex, bool bUpdateMesh); // Function Engine.InstancedSplineMeshComponent.RemoveInstance // Native|Public|BlueprintCallable // @ game+0x5b41be0
	bool GetInstanceSpline(int32 InstanceIndex, struct FSplineMeshParams OutSplineSegment, struct FVector InSplineUpDir, bool bWorldSpace); // Function Engine.InstancedSplineMeshComponent.GetInstanceSpline // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5b2571c
	int32 GetInstanceCount(); // Function Engine.InstancedSplineMeshComponent.GetInstanceCount // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x4d261f4
	enum class ESplineMeshAxis GetForwardAxis(); // Function Engine.InstancedSplineMeshComponent.GetForwardAxis // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b24898
	float GetBoundaryMin(); // Function Engine.InstancedSplineMeshComponent.GetBoundaryMin // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b22c58
	float GetBoundaryMax(); // Function Engine.InstancedSplineMeshComponent.GetBoundaryMax // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b22c28
	void ClearInstances(bool bUpdateMesh); // Function Engine.InstancedSplineMeshComponent.ClearInstances // Native|Public|BlueprintCallable // @ game+0x5b16b64
	int32 AddInstanceWorldSpace(struct FSplineMeshParams WorldSplineSegment, struct FVector InSplineUpDir, bool bUpdateMesh); // Function Engine.InstancedSplineMeshComponent.AddInstanceWorldSpace // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b0a2c8
	int32 AddInstance(struct FSplineMeshParams SplineSegment, struct FVector InSplineUpDir, bool bUpdateMesh); // Function Engine.InstancedSplineMeshComponent.AddInstance // Native|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b09e84
};

// Class Engine.LODParentComponent
// Size: 0xb80 (Inherited: 0xb80)
struct ULODParentComponent : UStaticMeshComponent {
};

// Class Engine.Texture
// Size: 0xc8 (Inherited: 0x38)
struct UTexture : UObject {
	char pad_38[0x8]; // 0x38(0x08)
	struct FGuid LightingGuid; // 0x40(0x10)
	int32 LODBias; // 0x50(0x04)
	int32 NumCinematicMipLevels; // 0x54(0x04)
	int32 GlobalLODBias; // 0x58(0x04)
	char SRGB : 1; // 0x5c(0x01)
	char NeverStream : 1; // 0x5c(0x01)
	char bNoTiling : 1; // 0x5c(0x01)
	char bUseCinematicMipLevels : 1; // 0x5c(0x01)
	char bAsyncResourceReleaseHasBeenStarted : 1; // 0x5c(0x01)
	char pad_5C_5 : 3; // 0x5c(0x01)
	char pad_5D[0x3]; // 0x5d(0x03)
	int32 CachedCombinedLODBias; // 0x60(0x04)
	enum class TextureCompressionSettings CompressionSettings; // 0x64(0x01)
	enum class TextureFilter Filter; // 0x65(0x01)
	enum class TextureGroup LODGroup; // 0x66(0x01)
	char pad_67[0x1]; // 0x67(0x01)
	struct FPerPlatformFloat Downscale; // 0x68(0x04)
	enum class ETextureDownscaleOptions DownscaleOptions; // 0x6c(0x01)
	char pad_6D[0x3]; // 0x6d(0x03)
	struct TArray<struct UAssetUserData*> AssetUserData; // 0x70(0x10)
	char pad_80[0x48]; // 0x80(0x48)
};

// Class Engine.Texture2D
// Size: 0x108 (Inherited: 0xc8)
struct UTexture2D : UTexture {
	int32 StreamingIndex; // 0xc8(0x04)
	int32 LevelIndex; // 0xcc(0x04)
	int32 FirstResourceMemMip; // 0xd0(0x04)
	struct FIntPoint ImportedSize; // 0xd4(0x08)
	char pad_DC[0x4]; // 0xdc(0x04)
	double ForceMipLevelsToBeResidentTimestamp; // 0xe0(0x08)
	char bTemporarilyDisableStreaming : 1; // 0xe8(0x01)
	char bIsStreamable : 1; // 0xe8(0x01)
	char bHasStreamingUpdatePending : 1; // 0xe8(0x01)
	char bForceMiplevelsToBeResident : 1; // 0xe8(0x01)
	char bIgnoreStreamingMipBias : 1; // 0xe8(0x01)
	char bGlobalForceMipLevelsToBeResident : 1; // 0xe8(0x01)
	char bIsTransient : 1; // 0xe8(0x01)
	char pad_E8_7 : 1; // 0xe8(0x01)
	char pad_E9[0x3]; // 0xe9(0x03)
	enum class TextureAddress AddressX; // 0xec(0x01)
	enum class TextureAddress AddressY; // 0xed(0x01)
	char pad_EE[0x1a]; // 0xee(0x1a)

	void SetForceMipLevelsToBeResident(float Seconds, int32 CinematicTextureGroups); // Function Engine.Texture2D.SetForceMipLevelsToBeResident // Native|Public|BlueprintCallable // @ game+0xdf16b0
	int32 Blueprint_GetSizeY(); // Function Engine.Texture2D.Blueprint_GetSizeY // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b0ebd4
	int32 Blueprint_GetSizeX(); // Function Engine.Texture2D.Blueprint_GetSizeX // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b0ebac
};

// Class Engine.MinimapLabelData
// Size: 0x60 (Inherited: 0x40)
struct UMinimapLabelData : UDataAsset {
	struct UTexture2D* Color; // 0x40(0x20)
};

// Class Engine.MinimapLabelComponent
// Size: 0x9e0 (Inherited: 0x9d0)
struct UMinimapLabelComponent : UPrimitiveComponent {
	struct UMinimapLabelData* LabelData; // 0x9d0(0x08)
	struct FVector2D Offset; // 0x9d8(0x08)
};

// Class Engine.MinimapObjectData
// Size: 0x100 (Inherited: 0x40)
struct UMinimapObjectData : UDataAsset {
	struct UTexture2D* Color; // 0x40(0x20)
	struct UTexture2D* Normal; // 0x60(0x20)
	float Height; // 0x80(0x04)
	char pad_84[0x7c]; // 0x84(0x7c)
};

// Class Engine.MinimapObjectComponent
// Size: 0x9e0 (Inherited: 0x9d0)
struct UMinimapObjectComponent : UPrimitiveComponent {
	struct UMinimapObjectData* ObjectData; // 0x9d0(0x08)
	char pad_9D8[0x8]; // 0x9d8(0x08)
};

// Class Engine.ModelComponent
// Size: 0xa10 (Inherited: 0x9d0)
struct UModelComponent : UPrimitiveComponent {
	char pad_9D0[0x18]; // 0x9d0(0x18)
	struct UBodySetup* ModelBodySetup; // 0x9e8(0x08)
	char pad_9F0[0x20]; // 0x9f0(0x20)
};

// Class Engine.NavLinkComponent
// Size: 0x9f0 (Inherited: 0x9d0)
struct UNavLinkComponent : UPrimitiveComponent {
	char pad_9D0[0x8]; // 0x9d0(0x08)
	struct TArray<struct FNavigationLink> Links; // 0x9d8(0x10)
	char pad_9E8[0x8]; // 0x9e8(0x08)
};

// Class Engine.NavLinkRenderingComponent
// Size: 0x9d0 (Inherited: 0x9d0)
struct UNavLinkRenderingComponent : UPrimitiveComponent {
};

// Class Engine.NavMeshRenderingComponent
// Size: 0x9e0 (Inherited: 0x9d0)
struct UNavMeshRenderingComponent : UPrimitiveComponent {
	char pad_9D0[0x10]; // 0x9d0(0x10)
};

// Class Engine.NavTestRenderingComponent
// Size: 0x9d0 (Inherited: 0x9d0)
struct UNavTestRenderingComponent : UPrimitiveComponent {
};

// Class Engine.MeshClippingUnderwaterComponent
// Size: 0xa40 (Inherited: 0xa00)
struct UMeshClippingUnderwaterComponent : UBoxComponent {
	bool bEnabled; // 0xa00(0x01)
	bool bUseParentBounds; // 0xa01(0x01)
	char pad_A02[0x2]; // 0xa02(0x02)
	float ExtendUpwards; // 0xa04(0x04)
	float ExtendDownwards; // 0xa08(0x04)
	char pad_A0C[0x34]; // 0xa0c(0x34)

	struct FOrientedBox GetOrientedBoxBounds(struct FTransform LocalToWorld); // Function Engine.MeshClippingUnderwaterComponent.GetOrientedBoxBounds // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5b2784c
};

// Class Engine.SphereComponent
// Size: 0xa00 (Inherited: 0x9f0)
struct USphereComponent : UShapeComponent {
	float SphereRadius; // 0x9f0(0x04)
	char pad_9F4[0xc]; // 0x9f4(0x0c)

	void SetSphereRadius(float InSphereRadius, bool bUpdateOverlaps); // Function Engine.SphereComponent.SetSphereRadius // Final|Native|Public|BlueprintCallable // @ game+0x5b4fe24
	float GetUnscaledSphereRadius(); // Function Engine.SphereComponent.GetUnscaledSphereRadius // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b2bc0c
	float GetShapeScale(); // Function Engine.SphereComponent.GetShapeScale // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b29d58
	float GetScaledSphereRadius(); // Function Engine.SphereComponent.GetScaledSphereRadius // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b29904
};

// Class Engine.DrawSphereComponent
// Size: 0xa00 (Inherited: 0xa00)
struct UDrawSphereComponent : USphereComponent {
};

// Class Engine.TextRenderComponent
// Size: 0xa20 (Inherited: 0x9d0)
struct UTextRenderComponent : UPrimitiveComponent {
	struct FText Text; // 0x9d0(0x18)
	struct UMaterialInterface* TextMaterial; // 0x9e8(0x08)
	struct UFont* Font; // 0x9f0(0x08)
	enum class EHorizTextAligment HorizontalAlignment; // 0x9f8(0x01)
	enum class EVerticalTextAligment VerticalAlignment; // 0x9f9(0x01)
	char pad_9FA[0x2]; // 0x9fa(0x02)
	struct FColor TextRenderColor; // 0x9fc(0x04)
	float XScale; // 0xa00(0x04)
	float YScale; // 0xa04(0x04)
	float WorldSize; // 0xa08(0x04)
	float InvDefaultSize; // 0xa0c(0x04)
	float HorizSpacingAdjust; // 0xa10(0x04)
	float VertSpacingAdjust; // 0xa14(0x04)
	char bAlwaysRenderAsText : 1; // 0xa18(0x01)
	char pad_A18_1 : 7; // 0xa18(0x01)
	char pad_A19[0x7]; // 0xa19(0x07)

	void SetYScale(float Value); // Function Engine.TextRenderComponent.SetYScale // Final|Native|Public|BlueprintCallable // @ game+0x5b53520
	void SetXScale(float Value); // Function Engine.TextRenderComponent.SetXScale // Final|Native|Public|BlueprintCallable // @ game+0x5b53480
	void SetWorldSize(float Value); // Function Engine.TextRenderComponent.SetWorldSize // Final|Native|Public|BlueprintCallable // @ game+0x5b53304
	void SetVertSpacingAdjust(float Value); // Function Engine.TextRenderComponent.SetVertSpacingAdjust // Final|Native|Public|BlueprintCallable // @ game+0x5b52684
	void SetVerticalAlignment(enum class EVerticalTextAligment Value); // Function Engine.TextRenderComponent.SetVerticalAlignment // Final|Native|Public|BlueprintCallable // @ game+0x5b52844
	void SetTextRenderColor(struct FColor Value); // Function Engine.TextRenderComponent.SetTextRenderColor // Final|Native|Public|HasDefaults|BlueprintCallable // @ game+0x5b51a4c
	void SetTextMaterial(struct UMaterialInterface* Material); // Function Engine.TextRenderComponent.SetTextMaterial // Final|Native|Public|BlueprintCallable // @ game+0x5b519b4
	void SetText(struct FString Value); // Function Engine.TextRenderComponent.SetText // Final|Native|Public|BlueprintCallable // @ game+0x5b518b4
	void SetHorizSpacingAdjust(float Value); // Function Engine.TextRenderComponent.SetHorizSpacingAdjust // Final|Native|Public|BlueprintCallable // @ game+0x5b4b060
	void SetHorizontalAlignment(enum class EHorizTextAligment Value); // Function Engine.TextRenderComponent.SetHorizontalAlignment // Final|Native|Public|BlueprintCallable // @ game+0x5b4b100
	void SetFont(struct UFont* Value); // Function Engine.TextRenderComponent.SetFont // Final|Native|Public|BlueprintCallable // @ game+0x5b4a604
	void K2_SetText(struct FText Value); // Function Engine.TextRenderComponent.K2_SetText // Final|Native|Public|HasOutParms|BlueprintCallable // @ game+0x5b31c84
	struct FVector GetTextWorldSize(); // Function Engine.TextRenderComponent.GetTextWorldSize // Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5b2aa9c
	struct FVector GetTextLocalSize(); // Function Engine.TextRenderComponent.GetTextLocalSize // Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5b2aa08
};

// Class Engine.VectorFieldComponent
// Size: 0xa00 (Inherited: 0x9d0)
struct UVectorFieldComponent : UPrimitiveComponent {
	struct UVectorField* VectorField; // 0x9d0(0x08)
	float Intensity; // 0x9d8(0x04)
	float Tightness; // 0x9dc(0x04)
	char bPreviewVectorField : 1; // 0x9e0(0x01)
	char pad_9E0_1 : 7; // 0x9e0(0x01)
	char pad_9E1[0x1f]; // 0x9e1(0x1f)

	void SetIntensity(float NewIntensity); // Function Engine.VectorFieldComponent.SetIntensity // Native|Public|BlueprintCallable // @ game+0x5b4ba98
};

// Class Engine.RadialForceComponent
// Size: 0x4e0 (Inherited: 0x4b0)
struct URadialForceComponent : USceneComponent {
	float Radius; // 0x4b0(0x04)
	enum class ERadialImpulseFalloff Falloff; // 0x4b4(0x01)
	char pad_4B5[0x3]; // 0x4b5(0x03)
	float ImpulseStrength; // 0x4b8(0x04)
	char bImpulseVelChange : 1; // 0x4bc(0x01)
	char bIgnoreOwningActor : 1; // 0x4bc(0x01)
	char pad_4BC_2 : 6; // 0x4bc(0x01)
	char pad_4BD[0x3]; // 0x4bd(0x03)
	float ForceStrength; // 0x4c0(0x04)
	float DestructibleDamage; // 0x4c4(0x04)
	struct TArray<enum class EObjectTypeQuery> ObjectTypesToAffect; // 0x4c8(0x10)
	char pad_4D8[0x8]; // 0x4d8(0x08)

	void RemoveObjectTypeToAffect(enum class EObjectTypeQuery ObjectType); // Function Engine.RadialForceComponent.RemoveObjectTypeToAffect // Native|Public|BlueprintCallable // @ game+0x5b41e48
	void FireImpulse(); // Function Engine.RadialForceComponent.FireImpulse // Native|Public|BlueprintCallable // @ game+0x4d51018
	void AddObjectTypeToAffect(enum class EObjectTypeQuery ObjectType); // Function Engine.RadialForceComponent.AddObjectTypeToAffect // Native|Public|BlueprintCallable // @ game+0x5b0a58c
};

// Class Engine.TextureCube
// Size: 0x120 (Inherited: 0xc8)
struct UTextureCube : UTexture {
	char pad_C8[0x58]; // 0xc8(0x58)
};

// Class Engine.ReflectionCaptureComponent
// Size: 0x530 (Inherited: 0x4b0)
struct UReflectionCaptureComponent : USceneComponent {
	struct UBillboardComponent* CaptureOffsetComponent; // 0x4b0(0x08)
	enum class EReflectionSourceType ReflectionSourceType; // 0x4b8(0x01)
	bool bOverrideCullDistance; // 0x4b9(0x01)
	enum class EIndoorOutdoorMask IndoorOutdoorMask; // 0x4ba(0x01)
	bool bSharedComponent; // 0x4bb(0x01)
	char pad_4BC[0x4]; // 0x4bc(0x04)
	struct UTextureCube* Cubemap; // 0x4c0(0x08)
	float SourceCubemapAngle; // 0x4c8(0x04)
	float Brightness; // 0x4cc(0x04)
	struct FVector CaptureOffset; // 0x4d0(0x0c)
	float CullDistance; // 0x4dc(0x04)
	char pad_4E0[0x50]; // 0x4e0(0x50)
};

// Class Engine.BoxReflectionCaptureComponent
// Size: 0x540 (Inherited: 0x530)
struct UBoxReflectionCaptureComponent : UReflectionCaptureComponent {
	float BoxTransitionDistance; // 0x528(0x04)
	struct UBoxComponent* PreviewInfluenceBox; // 0x530(0x08)
	struct UBoxComponent* PreviewCaptureBox; // 0x538(0x08)
};

// Class Engine.BoxReflectionCaptureSAComponent
// Size: 0x540 (Inherited: 0x540)
struct UBoxReflectionCaptureSAComponent : UBoxReflectionCaptureComponent {
};

// Class Engine.PlaneReflectionCaptureComponent
// Size: 0x540 (Inherited: 0x530)
struct UPlaneReflectionCaptureComponent : UReflectionCaptureComponent {
	float InfluenceRadiusScale; // 0x528(0x04)
	struct UDrawSphereComponent* PreviewInfluenceRadius; // 0x530(0x08)
	struct UBoxComponent* PreviewCaptureBox; // 0x538(0x08)
};

// Class Engine.SphereReflectionCaptureComponent
// Size: 0x540 (Inherited: 0x530)
struct USphereReflectionCaptureComponent : UReflectionCaptureComponent {
	float InfluenceRadius; // 0x528(0x04)
	float CaptureDistanceScale; // 0x52c(0x04)
	struct UDrawSphereComponent* PreviewInfluenceRadius; // 0x530(0x08)
};

// Class Engine.PlanarReflectionComponent
// Size: 0x610 (Inherited: 0x530)
struct UPlanarReflectionComponent : USceneCaptureComponent {
	struct UBoxComponent* PreviewBox; // 0x530(0x08)
	float NormalDistortionStrength; // 0x538(0x04)
	float PrefilterRoughness; // 0x53c(0x04)
	float PrefilterRoughnessDistance; // 0x540(0x04)
	int32 ScreenPercentage; // 0x544(0x04)
	float ExtraFOV; // 0x548(0x04)
	float DistanceFromPlaneFadeStart; // 0x54c(0x04)
	float DistanceFromPlaneFadeEnd; // 0x550(0x04)
	float DistanceFromPlaneFadeoutStart; // 0x554(0x04)
	float DistanceFromPlaneFadeoutEnd; // 0x558(0x04)
	float AngleFromPlaneFadeStart; // 0x55c(0x04)
	float AngleFromPlaneFadeEnd; // 0x560(0x04)
	bool bRenderSceneTwoSided; // 0x564(0x01)
	char pad_565[0xab]; // 0x565(0xab)
};

// Class Engine.SceneCaptureComponentCube
// Size: 0x540 (Inherited: 0x530)
struct USceneCaptureComponentCube : USceneCaptureComponent {
	struct UTextureRenderTargetCube* TextureTarget; // 0x530(0x08)
	char pad_538[0x8]; // 0x538(0x08)

	void CaptureScene(); // Function Engine.SceneCaptureComponentCube.CaptureScene // Final|Native|Public|BlueprintCallable // @ game+0x5b16544
};

// Class Engine.StereoLayerComponent
// Size: 0x550 (Inherited: 0x4b0)
struct UStereoLayerComponent : USceneComponent {
	char bLiveTexture : 1; // 0x4b0(0x01)
	char bSupportsDepth : 1; // 0x4b0(0x01)
	char bNoAlphaChannel : 1; // 0x4b0(0x01)
	char pad_4B0_3 : 5; // 0x4b0(0x01)
	char pad_4B1[0x7]; // 0x4b1(0x07)
	struct UTexture* Texture; // 0x4b8(0x08)
	struct UTexture* LeftTexture; // 0x4c0(0x08)
	char bQuadPreserveTextureRatio : 1; // 0x4c8(0x01)
	char pad_4C8_1 : 7; // 0x4c8(0x01)
	char pad_4C9[0x3]; // 0x4c9(0x03)
	struct FVector2D QuadSize; // 0x4cc(0x08)
	struct FBox2D UVRect; // 0x4d4(0x14)
	float CylinderRadius; // 0x4e8(0x04)
	float CylinderOverlayArc; // 0x4ec(0x04)
	int32 CylinderHeight; // 0x4f0(0x04)
	enum class EStereoLayerType StereoLayerType; // 0x4f4(0x01)
	enum class EStereoLayerShape StereoLayerShape; // 0x4f5(0x01)
	char pad_4F6[0x2]; // 0x4f6(0x02)
	int32 Priority; // 0x4f8(0x04)
	char pad_4FC[0x54]; // 0x4fc(0x54)

	void SetUVRect(struct FBox2D InUVRect); // Function Engine.StereoLayerComponent.SetUVRect // Final|Native|Public|HasDefaults|BlueprintCallable // @ game+0x5b51fc8
	void SetTexture(struct UTexture* InTexture); // Function Engine.StereoLayerComponent.SetTexture // Final|Native|Public|BlueprintCallable // @ game+0x5b51ae0
	void SetQuadSize(struct FVector2D InQuadSize); // Function Engine.StereoLayerComponent.SetQuadSize // Final|Native|Public|HasDefaults|BlueprintCallable // @ game+0x5b4ef74
	void SetPriority(int32 InPriority); // Function Engine.StereoLayerComponent.SetPriority // Final|Native|Public|BlueprintCallable // @ game+0x5b4ee4c
	void MarkTextureForUpdate(); // Function Engine.StereoLayerComponent.MarkTextureForUpdate // Final|Native|Public|BlueprintCallable // @ game+0x5b38e5c
	struct FBox2D GetUVRect(); // Function Engine.StereoLayerComponent.GetUVRect // Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5b2ba30
	struct UTexture* GetTexture(); // Function Engine.StereoLayerComponent.GetTexture // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x54884f4
	struct FVector2D GetQuadSize(); // Function Engine.StereoLayerComponent.GetQuadSize // Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5b28534
	int32 GetPriority(); // Function Engine.StereoLayerComponent.GetPriority // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b2851c
};

// Class Engine.WindDirectionalSourceComponent
// Size: 0x4d0 (Inherited: 0x4b0)
struct UWindDirectionalSourceComponent : USceneComponent {
	float Strength; // 0x4b0(0x04)
	float Speed; // 0x4b4(0x04)
	float MinGustAmount; // 0x4b8(0x04)
	float MaxGustAmount; // 0x4bc(0x04)
	float Radius; // 0x4c0(0x04)
	char bPointWind : 1; // 0x4c4(0x01)
	char pad_4C4_1 : 7; // 0x4c4(0x01)
	char pad_4C5[0xb]; // 0x4c5(0x0b)

	void SetWindType(enum class EWindSourceType InNewType); // Function Engine.WindDirectionalSourceComponent.SetWindType // Final|Native|Public|BlueprintCallable // @ game+0x5b52f9c
	void SetStrength(float InNewStrength); // Function Engine.WindDirectionalSourceComponent.SetStrength // Final|Native|Public|BlueprintCallable // @ game+0x5b50d2c
	void SetSpeed(float InNewSpeed); // Function Engine.WindDirectionalSourceComponent.SetSpeed // Final|Native|Public|BlueprintCallable // @ game+0x5b4fd84
	void SetRadius(float InNewRadius); // Function Engine.WindDirectionalSourceComponent.SetRadius // Final|Native|Public|BlueprintCallable // @ game+0x5b4f028
	void SetMinimumGustAmount(float InNewMinGust); // Function Engine.WindDirectionalSourceComponent.SetMinimumGustAmount // Final|Native|Public|BlueprintCallable // @ game+0x5b4d494
	void SetMaximumGustAmount(float InNewMaxGust); // Function Engine.WindDirectionalSourceComponent.SetMaximumGustAmount // Final|Native|Public|BlueprintCallable // @ game+0x5b4d2a8
};

// Class Engine.TimelineComponent
// Size: 0x2f0 (Inherited: 0x200)
struct UTimelineComponent : UActorComponent {
	struct FTimeline TheTimeline; // 0x200(0xe0)
	char bIgnoreTimeDilation : 1; // 0x2e0(0x01)
	char pad_2E0_1 : 7; // 0x2e0(0x01)
	char pad_2E1[0xf]; // 0x2e1(0x0f)

	void Stop(); // Function Engine.TimelineComponent.Stop // Final|RequiredAPI|Native|Public|BlueprintCallable // @ game+0x5b59fd8
	void SetVectorCurve(struct UCurveVector* NewVectorCurve, struct FName VectorTrackName); // Function Engine.TimelineComponent.SetVectorCurve // Final|RequiredAPI|Native|Public|BlueprintCallable // @ game+0x5b52440
	void SetTimelineLengthMode(enum class ETimelineLengthMode NewLengthMode); // Function Engine.TimelineComponent.SetTimelineLengthMode // Final|RequiredAPI|Native|Public|BlueprintCallable // @ game+0x5b51c30
	void SetTimelineLength(float NewLength); // Function Engine.TimelineComponent.SetTimelineLength // Final|RequiredAPI|Native|Public|BlueprintCallable // @ game+0x5b51b80
	void SetPlayRate(float NewRate); // Function Engine.TimelineComponent.SetPlayRate // Final|RequiredAPI|Native|Public|BlueprintCallable // @ game+0x5b4e524
	void SetPlaybackPosition(float NewPosition, bool bFireEvents, bool bFireUpdate); // Function Engine.TimelineComponent.SetPlaybackPosition // Final|RequiredAPI|Native|Public|BlueprintCallable // @ game+0x5b4e5bc
	void SetNewTime(float NewTime); // Function Engine.TimelineComponent.SetNewTime // Final|RequiredAPI|Native|Public|BlueprintCallable // @ game+0x5b4d958
	void SetLooping(bool bNewLooping); // Function Engine.TimelineComponent.SetLooping // Final|RequiredAPI|Native|Public|BlueprintCallable // @ game+0x5b4d180
	void SetLinearColorCurve(struct UCurveLinearColor* NewLinearColorCurve, struct FName LinearColorTrackName); // Function Engine.TimelineComponent.SetLinearColorCurve // Final|RequiredAPI|Native|Public|BlueprintCallable // @ game+0x5b4c33c
	void SetIgnoreTimeDilation(bool bNewIgnoreTimeDilation); // Function Engine.TimelineComponent.SetIgnoreTimeDilation // Final|RequiredAPI|Native|Public|BlueprintCallable // @ game+0x5b4b24c
	void SetFloatCurve(struct UCurveFloat* NewFloatCurve, struct FName FloatTrackName); // Function Engine.TimelineComponent.SetFloatCurve // Final|RequiredAPI|Native|Public|BlueprintCallable // @ game+0x5b4a020
	void ReverseFromEnd(); // Function Engine.TimelineComponent.ReverseFromEnd // Final|RequiredAPI|Native|Public|BlueprintCallable // @ game+0x5b42590
	void Reverse(); // Function Engine.TimelineComponent.Reverse // Final|RequiredAPI|Native|Public|BlueprintCallable // @ game+0x5b42560
	void PlayFromStart(); // Function Engine.TimelineComponent.PlayFromStart // Final|RequiredAPI|Native|Public|BlueprintCallable // @ game+0x8b8498
	void Play(); // Function Engine.TimelineComponent.Play // Final|RequiredAPI|Native|Public|BlueprintCallable // @ game+0x8b8520
	void OnRep_Timeline(); // Function Engine.TimelineComponent.OnRep_Timeline // Final|Native|Public // @ game+0x5b3c7ec
	bool IsReversing(); // Function Engine.TimelineComponent.IsReversing // Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b30330
	bool IsPlaying(); // Function Engine.TimelineComponent.IsPlaying // Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b2fef8
	bool IsLooping(); // Function Engine.TimelineComponent.IsLooping // Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b2fdf4
	float GetTimelineLength(); // Function Engine.TimelineComponent.GetTimelineLength // Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b2ad94
	float GetPlayRate(); // Function Engine.TimelineComponent.GetPlayRate // Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b27c40
	float GetPlaybackPosition(); // Function Engine.TimelineComponent.GetPlaybackPosition // Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b27c58
	bool GetIgnoreTimeDilation(); // Function Engine.TimelineComponent.GetIgnoreTimeDilation // Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b24dc0
};

// Class Engine.AnimComposite
// Size: 0xc0 (Inherited: 0xb0)
struct UAnimComposite : UAnimCompositeBase {
	struct FAnimTrack AnimationTrack; // 0xb0(0x10)
};

// Class Engine.AnimSequence
// Size: 0x1a8 (Inherited: 0xb0)
struct UAnimSequence : UAnimSequenceBase {
	int32 NumFrames; // 0xb0(0x04)
	char pad_B4[0x4]; // 0xb4(0x04)
	struct TArray<struct FTrackToSkeletonMap> TrackToSkeletonMapTable; // 0xb8(0x10)
	char pad_C8[0x90]; // 0xc8(0x90)
	enum class EAdditiveAnimationType AdditiveAnimType; // 0x158(0x01)
	enum class EAdditiveBasePoseType RefPoseType; // 0x159(0x01)
	char pad_15A[0x6]; // 0x15a(0x06)
	struct UAnimSequence* RefPoseSeq; // 0x160(0x08)
	int32 RefFrameIndex; // 0x168(0x04)
	int32 EncodingPkgVersion; // 0x16c(0x04)
	struct FName RetargetSource; // 0x170(0x08)
	enum class EAnimInterpolationType Interpolation; // 0x178(0x01)
	bool bAlwaysCookingCompressedData; // 0x179(0x01)
	bool bEnableRootMotion; // 0x17a(0x01)
	enum class ERootMotionRootLock RootMotionRootLock; // 0x17b(0x01)
	bool bForceRootLock; // 0x17c(0x01)
	bool bRootMotionSettingsCopiedFromMontage; // 0x17d(0x01)
	char pad_17E[0x2]; // 0x17e(0x02)
	struct TArray<struct FAnimSyncMarker> AuthoredSyncMarkers; // 0x180(0x10)
	char pad_190[0x18]; // 0x190(0x18)
};

// Class Engine.BlendSpaceBase
// Size: 0x150 (Inherited: 0x88)
struct UBlendSpaceBase : UAnimationAsset {
	char pad_88[0x8]; // 0x88(0x08)
	bool bRotationBlendInMeshSpace; // 0x90(0x01)
	char pad_91[0x3]; // 0x91(0x03)
	float AnimLength; // 0x94(0x04)
	struct TArray<struct FPerBoneInterpolation> PerBoneBlend; // 0x98(0x10)
	struct FInterpolationParameter InterpolationParam[0x03]; // 0xa8(0x18)
	float TargetWeightInterpolationSpeedPerSec; // 0xc0(0x04)
	enum class ENotifyTriggerMode NotifyTriggerMode; // 0xc4(0x01)
	char pad_C5[0x3]; // 0xc5(0x03)
	int32 SampleIndexWithMarkers; // 0xc8(0x04)
	char pad_CC[0x4]; // 0xcc(0x04)
	struct TArray<struct FBlendSample> SampleData; // 0xd0(0x10)
	struct TArray<struct FEditorElement> GridSamples; // 0xe0(0x10)
	struct FBlendParameter BlendParameters[0x03]; // 0xf0(0x60)
};

// Class Engine.BlendSpace
// Size: 0x158 (Inherited: 0x150)
struct UBlendSpace : UBlendSpaceBase {
	enum class EBlendSpaceAxis AxisToScaleAnimation; // 0x150(0x01)
	char pad_151[0x7]; // 0x151(0x07)
};

// Class Engine.AimOffsetBlendSpace
// Size: 0x158 (Inherited: 0x158)
struct UAimOffsetBlendSpace : UBlendSpace {
};

// Class Engine.BlendSpace1D
// Size: 0x158 (Inherited: 0x150)
struct UBlendSpace1D : UBlendSpaceBase {
	bool bScaleAnimation; // 0x150(0x01)
	char pad_151[0x7]; // 0x151(0x07)
};

// Class Engine.AimOffsetBlendSpace1D
// Size: 0x158 (Inherited: 0x158)
struct UAimOffsetBlendSpace1D : UBlendSpace1D {
};

// Class Engine.PoseAsset
// Size: 0x1a0 (Inherited: 0x88)
struct UPoseAsset : UAnimationAsset {
	struct FPoseDataContainer PoseContainer; // 0x88(0x90)
	bool bAdditivePose; // 0x118(0x01)
	char pad_119[0x3]; // 0x119(0x03)
	int32 BasePoseIndex; // 0x11c(0x04)
	struct FName RetargetSource; // 0x120(0x08)
	char pad_128[0x78]; // 0x128(0x78)
};

// Class Engine.AnimStateMachineTypes
// Size: 0x38 (Inherited: 0x38)
struct UAnimStateMachineTypes : UObject {
};

// Class Engine.AnimClassInterface
// Size: 0x38 (Inherited: 0x38)
struct UAnimClassInterface : UInterface {
};

// Class Engine.AnimClassData
// Size: 0xa8 (Inherited: 0x38)
struct UAnimClassData : UObject {
	char pad_38[0x8]; // 0x38(0x08)
	struct TArray<struct FBakedAnimationStateMachine> BakedStateMachines; // 0x40(0x10)
	struct USkeleton* TargetSkeleton; // 0x50(0x08)
	struct TArray<struct FAnimNotifyEvent> AnimNotifies; // 0x58(0x10)
	int32 RootAnimNodeIndex; // 0x68(0x04)
	char pad_6C[0x4]; // 0x6c(0x04)
	struct TArray<int32> OrderedSavedPoseIndices; // 0x70(0x10)
	struct UStructProperty* RootAnimNodeProperty; // 0x80(0x08)
	struct TArray<struct UStructProperty*> AnimNodeProperties; // 0x88(0x10)
	struct TArray<struct FName> SyncGroupNames; // 0x98(0x10)
};

// Class Engine.AnimCompress
// Size: 0x58 (Inherited: 0x38)
struct UAnimCompress : UObject {
	struct FString Description; // 0x38(0x10)
	char bNeedsSkeleton : 1; // 0x48(0x01)
	char pad_48_1 : 7; // 0x48(0x01)
	char pad_49[0x3]; // 0x49(0x03)
	enum class AnimationCompressionFormat TranslationCompressionFormat; // 0x4c(0x01)
	enum class AnimationCompressionFormat RotationCompressionFormat; // 0x4d(0x01)
	enum class AnimationCompressionFormat ScaleCompressionFormat; // 0x4e(0x01)
	char pad_4F[0x1]; // 0x4f(0x01)
	float MaxCurveError; // 0x50(0x04)
	char pad_54[0x4]; // 0x54(0x04)
};

// Class Engine.AnimCompress_Automatic
// Size: 0x60 (Inherited: 0x58)
struct UAnimCompress_Automatic : UAnimCompress {
	float MaxEndEffectorError; // 0x58(0x04)
	char bTryFixedBitwiseCompression : 1; // 0x5c(0x01)
	char bTryPerTrackBitwiseCompression : 1; // 0x5c(0x01)
	char bTryLinearKeyRemovalCompression : 1; // 0x5c(0x01)
	char bTryIntervalKeyRemoval : 1; // 0x5c(0x01)
	char bRunCurrentDefaultCompressor : 1; // 0x5c(0x01)
	char bAutoReplaceIfExistingErrorTooGreat : 1; // 0x5c(0x01)
	char bRaiseMaxErrorToExisting : 1; // 0x5c(0x01)
	char pad_5C_7 : 1; // 0x5c(0x01)
	char pad_5D[0x3]; // 0x5d(0x03)
};

// Class Engine.AnimCompress_BitwiseCompressOnly
// Size: 0x58 (Inherited: 0x58)
struct UAnimCompress_BitwiseCompressOnly : UAnimCompress {
};

// Class Engine.AnimCompress_LeastDestructive
// Size: 0x58 (Inherited: 0x58)
struct UAnimCompress_LeastDestructive : UAnimCompress {
};

// Class Engine.AnimCompress_RemoveEverySecondKey
// Size: 0x60 (Inherited: 0x58)
struct UAnimCompress_RemoveEverySecondKey : UAnimCompress {
	int32 MinKeys; // 0x58(0x04)
	char bStartAtSecondKey : 1; // 0x5c(0x01)
	char pad_5C_1 : 7; // 0x5c(0x01)
	char pad_5D[0x3]; // 0x5d(0x03)
};

// Class Engine.AnimCompress_RemoveLinearKeys
// Size: 0x78 (Inherited: 0x58)
struct UAnimCompress_RemoveLinearKeys : UAnimCompress {
	float MaxPosDiff; // 0x58(0x04)
	float MaxAngleDiff; // 0x5c(0x04)
	float MaxScaleDiff; // 0x60(0x04)
	float MaxEffectorDiff; // 0x64(0x04)
	float MinEffectorDiff; // 0x68(0x04)
	float EffectorDiffSocket; // 0x6c(0x04)
	float ParentKeyScale; // 0x70(0x04)
	char bRetarget : 1; // 0x74(0x01)
	char bActuallyFilterLinearKeys : 1; // 0x74(0x01)
	char pad_74_2 : 6; // 0x74(0x01)
	char pad_75[0x3]; // 0x75(0x03)
};

// Class Engine.AnimCompress_PerTrackCompression
// Size: 0xf8 (Inherited: 0x78)
struct UAnimCompress_PerTrackCompression : UAnimCompress_RemoveLinearKeys {
	float MaxZeroingThreshold; // 0x78(0x04)
	float MaxPosDiffBitwise; // 0x7c(0x04)
	float MaxAngleDiffBitwise; // 0x80(0x04)
	float MaxScaleDiffBitwise; // 0x84(0x04)
	struct TArray<enum class AnimationCompressionFormat> AllowedRotationFormats; // 0x88(0x10)
	struct TArray<enum class AnimationCompressionFormat> AllowedTranslationFormats; // 0x98(0x10)
	struct TArray<enum class AnimationCompressionFormat> AllowedScaleFormats; // 0xa8(0x10)
	char bResampleAnimation : 1; // 0xb8(0x01)
	char pad_B8_1 : 7; // 0xb8(0x01)
	char pad_B9[0x3]; // 0xb9(0x03)
	float ResampledFramerate; // 0xbc(0x04)
	int32 MinKeysForResampling; // 0xc0(0x04)
	char bUseAdaptiveError : 1; // 0xc4(0x01)
	char bUseOverrideForEndEffectors : 1; // 0xc4(0x01)
	char pad_C4_2 : 6; // 0xc4(0x01)
	char pad_C5[0x3]; // 0xc5(0x03)
	int32 TrackHeightBias; // 0xc8(0x04)
	float ParentingDivisor; // 0xcc(0x04)
	float ParentingDivisorExponent; // 0xd0(0x04)
	char bUseAdaptiveError2 : 1; // 0xd4(0x01)
	char pad_D4_1 : 7; // 0xd4(0x01)
	char pad_D5[0x3]; // 0xd5(0x03)
	float RotationErrorSourceRatio; // 0xd8(0x04)
	float TranslationErrorSourceRatio; // 0xdc(0x04)
	float ScaleErrorSourceRatio; // 0xe0(0x04)
	float MaxErrorPerTrackRatio; // 0xe4(0x04)
	float PerturbationProbeSize; // 0xe8(0x04)
	char pad_EC[0xc]; // 0xec(0x0c)
};

// Class Engine.AnimCompress_RemoveTrivialKeys
// Size: 0x68 (Inherited: 0x58)
struct UAnimCompress_RemoveTrivialKeys : UAnimCompress {
	float MaxPosDiff; // 0x58(0x04)
	float MaxAngleDiff; // 0x5c(0x04)
	float MaxScaleDiff; // 0x60(0x04)
	char pad_64[0x4]; // 0x64(0x04)
};

// Class Engine.AnimSingleNodeInstance
// Size: 0x3c0 (Inherited: 0x3a8)
struct UAnimSingleNodeInstance : UAnimInstance {
	struct UAnimationAsset* CurrentAsset; // 0x3a8(0x08)
	DelegateProperty PostEvaluateAnimEvent; // 0x3b0(0x10)

	void StopAnim(); // Function Engine.AnimSingleNodeInstance.StopAnim // Final|Native|Public|BlueprintCallable // @ game+0x5b59ff0
	void SetReverse(bool bInReverse); // Function Engine.AnimSingleNodeInstance.SetReverse // Final|Native|Public|BlueprintCallable // @ game+0x5b4f254
	void SetPreviewCurveOverride(struct FName PoseName, float Value, bool bRemoveIfZero); // Function Engine.AnimSingleNodeInstance.SetPreviewCurveOverride // Final|Native|Public|HasOutParms|BlueprintCallable // @ game+0x5b4ed08
	void SetPositionWithPreviousTime(float InPosition, float InPreviousTime, bool bFireNotifies); // Function Engine.AnimSingleNodeInstance.SetPositionWithPreviousTime // Final|Native|Public|BlueprintCallable // @ game+0x5b4ea28
	void SetPosition(float InPosition, bool bFireNotifies); // Function Engine.AnimSingleNodeInstance.SetPosition // Final|Native|Public|BlueprintCallable // @ game+0x5b4e860
	void SetPlayRate(float InPlayRate); // Function Engine.AnimSingleNodeInstance.SetPlayRate // Final|Native|Public|BlueprintCallable // @ game+0x5b4e48c
	void SetPlaying(bool bIsPlaying); // Function Engine.AnimSingleNodeInstance.SetPlaying // Final|Native|Public|BlueprintCallable // @ game+0x5b4e7cc
	void SetLooping(bool bIsLooping); // Function Engine.AnimSingleNodeInstance.SetLooping // Final|Native|Public|BlueprintCallable // @ game+0x5b4d0ec
	void SetBlendSpaceInput(struct FVector InBlendInput); // Function Engine.AnimSingleNodeInstance.SetBlendSpaceInput // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b45790
	void SetAnimationAsset(struct UAnimationAsset* NewAsset, bool bIsLooping, float InPlayRate); // Function Engine.AnimSingleNodeInstance.SetAnimationAsset // Native|Public|BlueprintCallable // @ game+0x5b44f00
	void PlayAnim(bool bIsLooping, float InPlayRate, float InStartPosition); // Function Engine.AnimSingleNodeInstance.PlayAnim // Final|Native|Public|BlueprintCallable // @ game+0x5b3d4b8
	float GetLength(); // Function Engine.AnimSingleNodeInstance.GetLength // Final|Native|Public|BlueprintCallable // @ game+0x5b26944
};

// Class Engine.AnimMetaData
// Size: 0x38 (Inherited: 0x38)
struct UAnimMetaData : UObject {
};

// Class Engine.AnimNotify_PlaySound
// Size: 0x68 (Inherited: 0x48)
struct UAnimNotify_PlaySound : UAnimNotify {
	struct USoundBase* Sound; // 0x48(0x08)
	float VolumeMultiplier; // 0x50(0x04)
	float PitchMultiplier; // 0x54(0x04)
	char bFollow : 1; // 0x58(0x01)
	char pad_58_1 : 7; // 0x58(0x01)
	char pad_59[0x7]; // 0x59(0x07)
	struct FName AttachName; // 0x60(0x08)
};

// Class Engine.AnimNotify_ResetClothingSimulation
// Size: 0x48 (Inherited: 0x48)
struct UAnimNotify_ResetClothingSimulation : UAnimNotify {
};

// Class Engine.AnimNotifyState_DisableRootMotion
// Size: 0x40 (Inherited: 0x40)
struct UAnimNotifyState_DisableRootMotion : UAnimNotifyState {
};

// Class Engine.AnimNotifyState_TimedParticleEffect
// Size: 0x70 (Inherited: 0x40)
struct UAnimNotifyState_TimedParticleEffect : UAnimNotifyState {
	struct UParticleSystem* PSTemplate; // 0x40(0x08)
	struct FName SocketName; // 0x48(0x08)
	struct FVector LocationOffset; // 0x50(0x0c)
	struct FRotator RotationOffset; // 0x5c(0x0c)
	bool bDestroyAtEnd; // 0x68(0x01)
	char pad_69[0x7]; // 0x69(0x07)
};

// Class Engine.AnimNotifyState_Trail
// Size: 0x70 (Inherited: 0x40)
struct UAnimNotifyState_Trail : UAnimNotifyState {
	struct UParticleSystem* PSTemplate; // 0x40(0x08)
	struct FName FirstSocketName; // 0x48(0x08)
	struct FName SecondSocketName; // 0x50(0x08)
	enum class ETrailWidthMode WidthScaleMode; // 0x58(0x01)
	char pad_59[0x7]; // 0x59(0x07)
	struct FName WidthScaleCurve; // 0x60(0x08)
	char bRecycleSpawnedSystems : 1; // 0x68(0x01)
	char pad_68_1 : 7; // 0x68(0x01)
	char pad_69[0x7]; // 0x69(0x07)

	struct UParticleSystem* OverridePSTemplate(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Function Engine.AnimNotifyState_Trail.OverridePSTemplate // Event|Public|BlueprintEvent|Const // @ game+0x33e45c
};

// Class Engine.AnimSet
// Size: 0x100 (Inherited: 0x38)
struct UAnimSet : UObject {
	char bAnimRotationOnly : 1; // 0x38(0x01)
	char pad_38_1 : 7; // 0x38(0x01)
	char pad_39[0x7]; // 0x39(0x07)
	struct TArray<struct FName> TrackBoneNames; // 0x40(0x10)
	struct TArray<struct FAnimSetMeshLinkup> LinkupCache; // 0x50(0x10)
	struct TArray<bool> BoneUseAnimTranslation; // 0x60(0x10)
	struct TArray<bool> ForceUseMeshTranslation; // 0x70(0x10)
	struct TArray<struct FName> UseTranslationBoneNames; // 0x80(0x10)
	struct TArray<struct FName> ForceMeshTranslationBoneNames; // 0x90(0x10)
	struct FName PreviewSkelMeshName; // 0xa0(0x08)
	struct FName BestRatioSkelMeshName; // 0xa8(0x08)
	char pad_B0[0x50]; // 0xb0(0x50)
};

// Class Engine.AssetImportData
// Size: 0x38 (Inherited: 0x38)
struct UAssetImportData : UObject {
};

// Class Engine.AssetManager
// Size: 0x3b0 (Inherited: 0x38)
struct UAssetManager : UObject {
	char pad_38[0x260]; // 0x38(0x260)
	struct TArray<struct UObject*> ObjectReferenceList; // 0x298(0x10)
	bool bIsGlobalAsyncScanEnvironment; // 0x2a8(0x01)
	bool bShouldKeepHardRefs; // 0x2a9(0x01)
	bool bShouldGuessTypeAndName; // 0x2aa(0x01)
	bool bShouldUseSynchronousLoad; // 0x2ab(0x01)
	bool bIsBulkScanning; // 0x2ac(0x01)
	bool bIsManagementDatabaseCurrent; // 0x2ad(0x01)
	bool bUpdateManagementDatabaseAfterScan; // 0x2ae(0x01)
	char pad_2AF[0x101]; // 0x2af(0x101)
};

// Class Engine.AssetMappingTable
// Size: 0x48 (Inherited: 0x38)
struct UAssetMappingTable : UObject {
	struct TArray<struct FAssetMapping> MappedAssets; // 0x38(0x10)
};

// Class Engine.AutomationTestSettings
// Size: 0x330 (Inherited: 0x38)
struct UAutomationTestSettings : UObject {
	struct TArray<struct FString> EngineTestModules; // 0x38(0x10)
	struct TArray<struct FString> EditorTestModules; // 0x48(0x10)
	struct FStringAssetReference AutomationTestmap; // 0x58(0x10)
	struct TArray<struct FEditorMapPerformanceTestDefinition> EditorPerformanceTestMaps; // 0x68(0x10)
	struct TArray<struct FStringAssetReference> AssetsToOpen; // 0x78(0x10)
	struct FBuildPromotionTestSettings BuildPromotionTest; // 0x88(0x1f0)
	struct FMaterialEditorPromotionSettings MaterialEditorPromotionTest; // 0x278(0x30)
	struct FParticleEditorPromotionSettings ParticleEditorPromotionTest; // 0x2a8(0x10)
	struct FBlueprintEditorPromotionSettings BlueprintEditorPromotionTest; // 0x2b8(0x30)
	struct TArray<struct FString> TestLevelFolders; // 0x2e8(0x10)
	struct TArray<struct FExternalToolDefinition> ExternalTools; // 0x2f8(0x10)
	struct TArray<struct FEditorImportExportTestDefinition> ImportExportTestDefinitions; // 0x308(0x10)
	struct TArray<struct FLaunchOnTestSettings> LaunchOnSettings; // 0x318(0x10)
	struct FIntPoint DefaultScreenshotResolution; // 0x328(0x08)
};

// Class Engine.AvoidanceManager
// Size: 0xf0 (Inherited: 0x38)
struct UAvoidanceManager : UObject {
	char pad_38[0x8]; // 0x38(0x08)
	float DefaultTimeToLive; // 0x40(0x04)
	float LockTimeAfterAvoid; // 0x44(0x04)
	float LockTimeAfterClean; // 0x48(0x04)
	float DeltaTimeToPredict; // 0x4c(0x04)
	float ArtificialRadiusExpansion; // 0x50(0x04)
	float TestHeightDifference; // 0x54(0x04)
	float HeightCheckMargin; // 0x58(0x04)
	char pad_5C[0x94]; // 0x5c(0x94)

	bool RegisterMovementComponent(struct UMovementComponent* MovementComp, float AvoidanceWeight); // Function Engine.AvoidanceManager.RegisterMovementComponent // Final|Native|Public|BlueprintCallable // @ game+0x5b41a4c
	int32 GetObjectCount(); // Function Engine.AvoidanceManager.GetObjectCount // Final|Native|Public|BlueprintCallable // @ game+0x5b27738
	int32 GetNewAvoidanceUID(); // Function Engine.AvoidanceManager.GetNewAvoidanceUID // Final|Native|Public|BlueprintCallable // @ game+0x5b2759c
	struct FVector GetAvoidanceVelocityIgnoringUID(struct FNavAvoidanceData AvoidanceData, float DeltaTime, int32 IgnoreThisUID); // Function Engine.AvoidanceManager.GetAvoidanceVelocityIgnoringUID // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b2218c
	struct FVector GetAvoidanceVelocityForComponent(struct UMovementComponent* MovementComp); // Function Engine.AvoidanceManager.GetAvoidanceVelocityForComponent // Final|Native|Public|HasDefaults|BlueprintCallable // @ game+0x5b220dc
	struct FVector GetAvoidanceVelocity(struct FNavAvoidanceData AvoidanceData, float DeltaTime); // Function Engine.AvoidanceManager.GetAvoidanceVelocity // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b21fb4
};

// Class Engine.BlendProfile
// Size: 0x58 (Inherited: 0x38)
struct UBlendProfile : UObject {
	char pad_38[0x8]; // 0x38(0x08)
	struct USkeleton* OwningSkeleton; // 0x40(0x08)
	struct TArray<struct FBlendProfileBoneEntry> ProfileEntries; // 0x48(0x10)
};

// Class Engine.BlueprintCore
// Size: 0x60 (Inherited: 0x38)
struct UBlueprintCore : UObject {
	struct UClass* SkeletonGeneratedClass; // 0x38(0x08)
	struct UClass* GeneratedClass; // 0x40(0x08)
	bool bLegacyNeedToPurgeSkelRefs; // 0x48(0x01)
	bool bLegacyGeneratedClassIsAuthoritative; // 0x49(0x01)
	char pad_4A[0x2]; // 0x4a(0x02)
	struct FGuid BlueprintGuid; // 0x4c(0x10)
	char pad_5C[0x4]; // 0x5c(0x04)
};

// Class Engine.Blueprint
// Size: 0x1b0 (Inherited: 0x60)
struct UBlueprint : UBlueprintCore {
	char bRecompileOnLoad : 1; // 0x60(0x01)
	char pad_60_1 : 7; // 0x60(0x01)
	char pad_61[0x7]; // 0x61(0x07)
	struct UClass* ParentClass; // 0x68(0x08)
	struct UObject* PRIVATE_InnermostPreviousCDO; // 0x70(0x08)
	char bHasBeenRegenerated : 1; // 0x78(0x01)
	char bIsRegeneratingOnLoad : 1; // 0x78(0x01)
	char pad_78_2 : 6; // 0x78(0x01)
	char pad_79[0x7]; // 0x79(0x07)
	struct USimpleConstructionScript* SimpleConstructionScript; // 0x80(0x08)
	struct TArray<struct UActorComponent*> ComponentTemplates; // 0x88(0x10)
	struct TArray<struct UTimelineTemplate*> Timelines; // 0x98(0x10)
	struct UInheritableComponentHandler* InheritableComponentHandler; // 0xa8(0x08)
	enum class EBlueprintType BlueprintType; // 0xb0(0x01)
	char pad_B1[0x3]; // 0xb1(0x03)
	int32 BlueprintSystemVersion; // 0xb4(0x04)
	char pad_B8[0xe8]; // 0xb8(0xe8)
	bool bNativize; // 0x1a0(0x01)
	char pad_1A1[0xf]; // 0x1a1(0x0f)
};

// Class Engine.AnimBlueprint
// Size: 0x1d0 (Inherited: 0x1b0)
struct UAnimBlueprint : UBlueprint {
	struct USkeleton* TargetSkeleton; // 0x1a8(0x08)
	struct TArray<struct FAnimGroupInfo> Groups; // 0x1b0(0x10)
	bool bUseMultiThreadedAnimationUpdate; // 0x1c0(0x01)
	bool bWarnAboutBlueprintUsage; // 0x1c1(0x01)
	char pad_1CA[0x6]; // 0x1ca(0x06)
};

// Class Engine.LevelScriptBlueprint
// Size: 0x1b0 (Inherited: 0x1b0)
struct ULevelScriptBlueprint : UBlueprint {
};

// Class Engine.BlueprintMapLibrary
// Size: 0x38 (Inherited: 0x38)
struct UBlueprintMapLibrary : UBlueprintFunctionLibrary {

	void Map_Values(struct TMap<int32, int32> TargetMap, struct TArray<int32> Values); // Function Engine.BlueprintMapLibrary.Map_Values // Final|Native|Static|Private|HasOutParms|BlueprintCallable // @ game+0x5b38c94
	bool Map_Remove(struct TMap<int32, int32> TargetMap, int32 Key); // Function Engine.BlueprintMapLibrary.Map_Remove // Final|Native|Static|Private|HasOutParms|BlueprintCallable // @ game+0x5b38a74
	int32 Map_Length(struct TMap<int32, int32> TargetMap); // Function Engine.BlueprintMapLibrary.Map_Length // Final|Native|Static|Private|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x5b38954
	void Map_Keys(struct TMap<int32, int32> TargetMap, struct TArray<int32> Keys); // Function Engine.BlueprintMapLibrary.Map_Keys // Final|Native|Static|Private|HasOutParms|BlueprintCallable // @ game+0x5b3878c
	bool Map_Find(struct TMap<int32, int32> TargetMap, int32 Key, int32 Value); // Function Engine.BlueprintMapLibrary.Map_Find // Final|Native|Static|Private|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x5b38448
	bool Map_Contains(struct TMap<int32, int32> TargetMap, int32 Key); // Function Engine.BlueprintMapLibrary.Map_Contains // Final|Native|Static|Private|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x5b38224
	void Map_Clear(struct TMap<int32, int32> TargetMap); // Function Engine.BlueprintMapLibrary.Map_Clear // Final|Native|Static|Private|HasOutParms|BlueprintCallable // @ game+0x5b38118
	bool Map_Add(struct TMap<int32, int32> TargetMap, int32 Key, int32 Value); // Function Engine.BlueprintMapLibrary.Map_Add // Final|Native|Static|Private|HasOutParms|BlueprintCallable // @ game+0x5b37e1c
};

// Class Engine.DynamicSubsystem
// Size: 0x40 (Inherited: 0x40)
struct UDynamicSubsystem : USubsystem {
};

// Class Engine.GameInstanceSubsystem
// Size: 0x40 (Inherited: 0x40)
struct UGameInstanceSubsystem : USubsystem {
};

// Class Engine.PlatformGameInstance
// Size: 0x290 (Inherited: 0x1e0)
struct UPlatformGameInstance : UGameInstance {
	struct FMulticastDelegate ApplicationWillDeactivateDelegate; // 0x1d8(0x10)
	struct FMulticastDelegate ApplicationHasReactivatedDelegate; // 0x1e8(0x10)
	struct FMulticastDelegate ApplicationWillEnterBackgroundDelegate; // 0x1f8(0x10)
	struct FMulticastDelegate ApplicationHasEnteredForegroundDelegate; // 0x208(0x10)
	struct FMulticastDelegate ApplicationWillTerminateDelegate; // 0x218(0x10)
	struct FMulticastDelegate ApplicationRegisteredForRemoteNotificationsDelegate; // 0x228(0x10)
	struct FMulticastDelegate ApplicationRegisteredForUserNotificationsDelegate; // 0x238(0x10)
	struct FMulticastDelegate ApplicationFailedToRegisterForRemoteNotificationsDelegate; // 0x248(0x10)
	struct FMulticastDelegate ApplicationReceivedRemoteNotificationDelegate; // 0x258(0x10)
	struct FMulticastDelegate ApplicationReceivedLocalNotificationDelegate; // 0x268(0x10)
	struct FMulticastDelegate ApplicationReceivedScreenOrientationChangedNotificationDelegate; // 0x278(0x10)

	void PlatformScreenOrientationChangedDelegate__DelegateSignature(enum class EScreenOrientation inScreenOrientation); // DelegateFunction Engine.PlatformGameInstance.PlatformScreenOrientationChangedDelegate__DelegateSignature // MulticastDelegate|Public|Delegate // @ game+0x33e45c
	void PlatformRegisteredForUserNotificationsDelegate__DelegateSignature(int32 inInt); // DelegateFunction Engine.PlatformGameInstance.PlatformRegisteredForUserNotificationsDelegate__DelegateSignature // MulticastDelegate|Public|Delegate // @ game+0x33e45c
	void PlatformRegisteredForRemoteNotificationsDelegate__DelegateSignature(struct TArray<bool> inArray); // DelegateFunction Engine.PlatformGameInstance.PlatformRegisteredForRemoteNotificationsDelegate__DelegateSignature // MulticastDelegate|Public|Delegate|HasOutParms // @ game+0x33e45c
	void PlatformReceivedRemoteNotificationDelegate__DelegateSignature(struct FString inString); // DelegateFunction Engine.PlatformGameInstance.PlatformReceivedRemoteNotificationDelegate__DelegateSignature // MulticastDelegate|Public|Delegate // @ game+0x33e45c
	void PlatformReceivedLocalNotificationDelegate__DelegateSignature(struct FString inString, int32 inInt); // DelegateFunction Engine.PlatformGameInstance.PlatformReceivedLocalNotificationDelegate__DelegateSignature // MulticastDelegate|Public|Delegate // @ game+0x33e45c
	void PlatformFailedToRegisterForRemoteNotificationsDelegate__DelegateSignature(struct FString inString); // DelegateFunction Engine.PlatformGameInstance.PlatformFailedToRegisterForRemoteNotificationsDelegate__DelegateSignature // MulticastDelegate|Public|Delegate // @ game+0x33e45c
	void PlatformDelegate__DelegateSignature(); // DelegateFunction Engine.PlatformGameInstance.PlatformDelegate__DelegateSignature // MulticastDelegate|Public|Delegate // @ game+0x33e45c
};

// Class Engine.BlueprintPlatformLibrary
// Size: 0x38 (Inherited: 0x38)
struct UBlueprintPlatformLibrary : UBlueprintFunctionLibrary {

	void ScheduleLocalNotificationFromNow(int32 inSecondsFromNow, struct FText Title, struct FText Body, struct FText Action, struct FString ActivationEvent); // Function Engine.BlueprintPlatformLibrary.ScheduleLocalNotificationFromNow // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x5b42e08
	void ScheduleLocalNotificationAtTime(struct FDateTime FireDateTime, bool LocalTime, struct FText Title, struct FText Body, struct FText Action, struct FString ActivationEvent); // Function Engine.BlueprintPlatformLibrary.ScheduleLocalNotificationAtTime // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b42acc
	void GetLaunchNotification(bool NotificationLaunchedApp, struct FString ActivationEvent, int32 FireDate); // Function Engine.BlueprintPlatformLibrary.GetLaunchNotification // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x5b266bc
	void ClearAllLocalNotifications(); // Function Engine.BlueprintPlatformLibrary.ClearAllLocalNotifications // Final|Native|Static|Public|BlueprintCallable // @ game+0x5b16b3c
	void CancelLocalNotification(struct FString ActivationEvent); // Function Engine.BlueprintPlatformLibrary.CancelLocalNotification // Final|Native|Static|Public|BlueprintCallable // @ game+0x5b13de0
};

// Class Engine.BlueprintSetLibrary
// Size: 0x38 (Inherited: 0x38)
struct UBlueprintSetLibrary : UBlueprintFunctionLibrary {

	void Set_Union(SetProperty A, SetProperty B, SetProperty Result); // Function Engine.BlueprintSetLibrary.Set_Union // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x5b548cc
	void Set_ToArray(SetProperty A, struct TArray<int32> Result); // Function Engine.BlueprintSetLibrary.Set_ToArray // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x5b54704
	void Set_RemoveItems(SetProperty TargetSet, struct TArray<int32> Items); // Function Engine.BlueprintSetLibrary.Set_RemoveItems // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x5b5453c
	bool Set_Remove(SetProperty TargetSet, int32 Item); // Function Engine.BlueprintSetLibrary.Set_Remove // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x5b5431c
	int32 Set_Length(SetProperty TargetSet); // Function Engine.BlueprintSetLibrary.Set_Length // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x5b541fc
	void Set_Intersection(SetProperty A, SetProperty B, SetProperty Result); // Function Engine.BlueprintSetLibrary.Set_Intersection // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x5b53f68
	void Set_Difference(SetProperty A, SetProperty B, SetProperty Result); // Function Engine.BlueprintSetLibrary.Set_Difference // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x5b53cd4
	bool Set_Contains(SetProperty TargetSet, int32 ItemToFind); // Function Engine.BlueprintSetLibrary.Set_Contains // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x5b53ab4
	void Set_Clear(SetProperty TargetSet); // Function Engine.BlueprintSetLibrary.Set_Clear // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x5b539a8
	void Set_AddItems(SetProperty TargetSet, struct TArray<int32> NewItems); // Function Engine.BlueprintSetLibrary.Set_AddItems // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x5b537e0
	bool Set_Add(SetProperty TargetSet, int32 NewItem); // Function Engine.BlueprintSetLibrary.Set_Add // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x5b535c0
};

// Class Engine.DataTableFunctionLibrary
// Size: 0x38 (Inherited: 0x38)
struct UDataTableFunctionLibrary : UBlueprintFunctionLibrary {

	void GetDataTableRowNames(struct UDataTable* Table, struct TArray<struct FName> OutRowNames); // Function Engine.DataTableFunctionLibrary.GetDataTableRowNames // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x5b23918
	bool GetDataTableRowFromName(struct UDataTable* Table, struct FName RowName, struct FTableRowBase OutRow); // Function Engine.DataTableFunctionLibrary.GetDataTableRowFromName // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x9400f8
	void EvaluateCurveTableRow(struct UCurveTable* CurveTable, struct FName RowName, float InXY, enum class EEvaluateCurveTableResult OutResult, float OutXY, struct FString ContextString); // Function Engine.DataTableFunctionLibrary.EvaluateCurveTableRow // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x5b1e78c
};

// Class Engine.DebugDrawService
// Size: 0x38 (Inherited: 0x38)
struct UDebugDrawService : UBlueprintFunctionLibrary {
};

// Class Engine.CollisionProfile
// Size: 0x168 (Inherited: 0x48)
struct UCollisionProfile : UDeveloperSettings {
	struct TArray<struct FCollisionResponseTemplate> Profiles; // 0x48(0x10)
	struct TArray<struct FCustomChannelSetup> DefaultChannelResponses; // 0x58(0x10)
	struct TArray<struct FCustomProfile> EditProfiles; // 0x68(0x10)
	struct TArray<struct FRedirector> ProfileRedirects; // 0x78(0x10)
	struct TArray<struct FRedirector> CollisionChannelRedirects; // 0x88(0x10)
	char pad_98[0xd0]; // 0x98(0xd0)
};

// Class Engine.KismetSystemLibrary
// Size: 0x38 (Inherited: 0x38)
struct UKismetSystemLibrary : UBlueprintFunctionLibrary {

	void StackTrace(); // Function Engine.KismetSystemLibrary.StackTrace // Final|Native|Static|Public|BlueprintCallable // @ game+0x5b59f74
	bool SphereTraceSingleForObjects(struct UObject* WorldContextObject, struct FVector Start, struct FVector End, float Radius, struct TArray<enum class EObjectTypeQuery> ObjectTypes, bool bTraceComplex, struct TArray<struct AActor*> ActorsToIgnore, enum class EDrawDebugTrace DrawDebugType, struct FHitResult OutHit, bool bIgnoreSelf, struct FLinearColor TraceColor, struct FLinearColor TraceHitColor, float DrawTime); // Function Engine.KismetSystemLibrary.SphereTraceSingleForObjects // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b59910
	bool SphereTraceSingleByProfile(struct UObject* WorldContextObject, struct FVector Start, struct FVector End, float Radius, struct FName ProfileName, bool bTraceComplex, struct TArray<struct AActor*> ActorsToIgnore, enum class EDrawDebugTrace DrawDebugType, struct FHitResult OutHit, bool bIgnoreSelf, struct FLinearColor TraceColor, struct FLinearColor TraceHitColor, float DrawTime); // Function Engine.KismetSystemLibrary.SphereTraceSingleByProfile // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b59418
	bool SphereTraceSingle(struct UObject* WorldContextObject, struct FVector Start, struct FVector End, float Radius, enum class ETraceTypeQuery TraceChannel, bool bTraceComplex, struct TArray<struct AActor*> ActorsToIgnore, enum class EDrawDebugTrace DrawDebugType, struct FHitResult OutHit, bool bIgnoreSelf, struct FLinearColor TraceColor, struct FLinearColor TraceHitColor, float DrawTime); // Function Engine.KismetSystemLibrary.SphereTraceSingle // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b58f20
	bool SphereTraceMultiForObjects(struct UObject* WorldContextObject, struct FVector Start, struct FVector End, float Radius, struct TArray<enum class EObjectTypeQuery> ObjectTypes, bool bTraceComplex, struct TArray<struct AActor*> ActorsToIgnore, enum class EDrawDebugTrace DrawDebugType, struct TArray<struct FHitResult> OutHits, bool bIgnoreSelf, struct FLinearColor TraceColor, struct FLinearColor TraceHitColor, float DrawTime); // Function Engine.KismetSystemLibrary.SphereTraceMultiForObjects // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b58a1c
	bool SphereTraceMultiByProfile(struct UObject* WorldContextObject, struct FVector Start, struct FVector End, float Radius, struct FName ProfileName, bool bTraceComplex, struct TArray<struct AActor*> ActorsToIgnore, enum class EDrawDebugTrace DrawDebugType, struct TArray<struct FHitResult> OutHits, bool bIgnoreSelf, struct FLinearColor TraceColor, struct FLinearColor TraceHitColor, float DrawTime); // Function Engine.KismetSystemLibrary.SphereTraceMultiByProfile // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b58540
	bool SphereTraceMulti(struct UObject* WorldContextObject, struct FVector Start, struct FVector End, float Radius, enum class ETraceTypeQuery TraceChannel, bool bTraceComplex, struct TArray<struct AActor*> ActorsToIgnore, enum class EDrawDebugTrace DrawDebugType, struct TArray<struct FHitResult> OutHits, bool bIgnoreSelf, struct FLinearColor TraceColor, struct FLinearColor TraceHitColor, float DrawTime); // Function Engine.KismetSystemLibrary.SphereTraceMulti // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b58068
	bool SphereOverlapComponents(struct UObject* WorldContextObject, struct FVector SpherePos, float SphereRadius, struct TArray<enum class EObjectTypeQuery> ObjectTypes, struct UClass* ComponentClassFilter, struct TArray<struct AActor*> ActorsToIgnore, struct TArray<struct UPrimitiveComponent*> OutComponents); // Function Engine.KismetSystemLibrary.SphereOverlapComponents // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b57d58
	bool SphereOverlapActors(struct UObject* WorldContextObject, struct FVector SpherePos, float SphereRadius, struct TArray<enum class EObjectTypeQuery> ObjectTypes, struct UClass* ActorClassFilter, struct TArray<struct AActor*> ActorsToIgnore, struct TArray<struct AActor*> OutActors); // Function Engine.KismetSystemLibrary.SphereOverlapActors // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b57a48
	void ShowPlatformSpecificLeaderboardScreen(struct FString CategoryName); // Function Engine.KismetSystemLibrary.ShowPlatformSpecificLeaderboardScreen // Final|Native|Static|Public|BlueprintCallable // @ game+0x5b54e54
	void ShowPlatformSpecificAchievementsScreen(struct APlayerController* SpecificPlayer); // Function Engine.KismetSystemLibrary.ShowPlatformSpecificAchievementsScreen // Final|Native|Static|Public|BlueprintCallable // @ game+0x5b54dd4
	void ShowInterstitialAd(); // Function Engine.KismetSystemLibrary.ShowInterstitialAd // Final|Native|Static|Public|BlueprintCallable // @ game+0x5b54c50
	void ShowAdBanner(int32 AdIdIndex, bool bShowOnBottomOfScreen); // Function Engine.KismetSystemLibrary.ShowAdBanner // Final|Native|Static|Public|BlueprintCallable // @ game+0x5b54b60
	void SetWindowTitle(struct FText Title); // Function Engine.KismetSystemLibrary.SetWindowTitle // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x5b53040
	void SetVolumeButtonsHandledBySystem(bool bEnabled); // Function Engine.KismetSystemLibrary.SetVolumeButtonsHandledBySystem // Final|Native|Static|Public|BlueprintCallable // @ game+0x4d09aac
	void SetVectorPropertyByName(struct UObject* Object, struct FName PropertyName, struct FVector Value); // Function Engine.KismetSystemLibrary.SetVectorPropertyByName // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b52564
	void SetUserActivity(struct FUserActivity UserActivity); // Function Engine.KismetSystemLibrary.SetUserActivity // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x5b52344
	void SetTransformPropertyByName(struct UObject* Object, struct FName PropertyName, struct FTransform Value); // Function Engine.KismetSystemLibrary.SetTransformPropertyByName // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b51d58
	void SetTextPropertyByName(struct UObject* Object, struct FName PropertyName, struct FText Value); // Function Engine.KismetSystemLibrary.SetTextPropertyByName // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0xbc55cc
	void SetSuppressViewportTransitionMessage(struct UObject* WorldContextObject, bool bState); // Function Engine.KismetSystemLibrary.SetSuppressViewportTransitionMessage // Final|Native|Static|Public|BlueprintCallable // @ game+0x5b51170
	void SetStructurePropertyByName(struct UObject* Object, struct FName PropertyName, struct FGenericStruct Value); // Function Engine.KismetSystemLibrary.SetStructurePropertyByName // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x5b47654
	void SetStringPropertyByName(struct UObject* Object, struct FName PropertyName, struct FString Value); // Function Engine.KismetSystemLibrary.SetStringPropertyByName // Final|Native|Static|Public|BlueprintCallable // @ game+0x5b50e64
	void SetRotatorPropertyByName(struct UObject* Object, struct FName PropertyName, struct FRotator Value); // Function Engine.KismetSystemLibrary.SetRotatorPropertyByName // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b4f478
	void SetObjectPropertyByName(struct UObject* Object, struct FName PropertyName, struct UObject* Value); // Function Engine.KismetSystemLibrary.SetObjectPropertyByName // Final|Native|Static|Public|BlueprintCallable // @ game+0xc24da8
	void SetNamePropertyByName(struct UObject* Object, struct FName PropertyName, struct FName Value); // Function Engine.KismetSystemLibrary.SetNamePropertyByName // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x5b4d74c
	void SetLinearColorPropertyByName(struct UObject* Object, struct FName PropertyName, struct FLinearColor Value); // Function Engine.KismetSystemLibrary.SetLinearColorPropertyByName // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b4c460
	void SetIntPropertyByName(struct UObject* Object, struct FName PropertyName, int32 Value); // Function Engine.KismetSystemLibrary.SetIntPropertyByName // Final|Native|Static|Public|BlueprintCallable // @ game+0x5b4b8d8
	void SetInterfacePropertyByName(struct UObject* Object, struct FName PropertyName, TScriptInterface<struct UInterface> Value); // Function Engine.KismetSystemLibrary.SetInterfacePropertyByName // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x5b4bbcc
	void SetFloatPropertyByName(struct UObject* Object, struct FName PropertyName, float Value); // Function Engine.KismetSystemLibrary.SetFloatPropertyByName // Final|Native|Static|Public|BlueprintCallable // @ game+0xb4f8ac
	void SetCollisionProfileNameProperty(struct UObject* Object, struct FName PropertyName, struct FCollisionProfileName Value); // Function Engine.KismetSystemLibrary.SetCollisionProfileNameProperty // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x5b47654
	void SetClassPropertyByName(struct UObject* Object, struct FName PropertyName, struct UClass* Value); // Function Engine.KismetSystemLibrary.SetClassPropertyByName // Final|Native|Static|Public|BlueprintCallable // @ game+0x5b4717c
	void SetBytePropertyByName(struct UObject* Object, struct FName PropertyName, bool Value); // Function Engine.KismetSystemLibrary.SetBytePropertyByName // Final|Native|Static|Public|BlueprintCallable // @ game+0x5b46848
	void SetBoolPropertyByName(struct UObject* Object, struct FName PropertyName, bool Value); // Function Engine.KismetSystemLibrary.SetBoolPropertyByName // Final|Native|Static|Public|BlueprintCallable // @ game+0x5b46250
	void SetAssetPropertyByName(struct UObject* Object, struct FName PropertyName, struct UObject* Value); // Function Engine.KismetSystemLibrary.SetAssetPropertyByName // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x5b453ec
	void SetAssetClassPropertyByName(struct UObject* Object, struct FName PropertyName, struct UClass* Value); // Function Engine.KismetSystemLibrary.SetAssetClassPropertyByName // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x5b451fc
	void RetriggerableDelay(struct UObject* WorldContextObject, float Duration, struct FLatentActionInfo LatentInfo); // Function Engine.KismetSystemLibrary.RetriggerableDelay // Final|Native|Static|Public|BlueprintCallable // @ game+0x8962f4
	void ResetGamepadAssignmentToController(int32 ControllerId); // Function Engine.KismetSystemLibrary.ResetGamepadAssignmentToController // Final|Native|Static|Public|BlueprintCallable // @ game+0x4d09aac
	void ResetGamepadAssignments(); // Function Engine.KismetSystemLibrary.ResetGamepadAssignments // Final|Native|Static|Public|BlueprintCallable // @ game+0xc0af08
	void RegisterForRemoteNotifications(); // Function Engine.KismetSystemLibrary.RegisterForRemoteNotifications // Final|Native|Static|Public|BlueprintCallable // @ game+0xc0af08
	void QuitGame(struct UObject* WorldContextObject, struct APlayerController* SpecificPlayer, enum class EQuitPreference QuitPreference); // Function Engine.KismetSystemLibrary.QuitGame // Final|Native|Static|Public|BlueprintCallable // @ game+0x5b3fe7c
	void PrintWarning(struct FString inString); // Function Engine.KismetSystemLibrary.PrintWarning // Final|Native|Static|Public|BlueprintCallable // @ game+0x4d36390
	void PrintText(struct UObject* WorldContextObject, struct FText InText, bool bPrintToScreen, bool bPrintToLog, struct FLinearColor TextColor, float Duration); // Function Engine.KismetSystemLibrary.PrintText // Final|Native|Static|Public|HasDefaults|BlueprintCallable // @ game+0x5b3f5c0
	void PrintString(struct UObject* WorldContextObject, struct FString inString, bool bPrintToScreen, bool bPrintToLog, struct FLinearColor TextColor, float Duration); // Function Engine.KismetSystemLibrary.PrintString // Final|Native|Static|Public|HasDefaults|BlueprintCallable // @ game+0x68ae88
	void OnAssetLoaded__DelegateSignature(struct UObject* Loaded); // DelegateFunction Engine.KismetSystemLibrary.OnAssetLoaded__DelegateSignature // Public|Delegate // @ game+0x33e45c
	void OnAssetClassLoaded__DelegateSignature(struct UClass* Loaded); // DelegateFunction Engine.KismetSystemLibrary.OnAssetClassLoaded__DelegateSignature // Public|Delegate // @ game+0x33e45c
	void MoveComponentTo(struct USceneComponent* Component, struct FVector TargetRelativeLocation, struct FRotator TargetRelativeRotation, bool bEaseOut, bool bEaseIn, float OverTime, bool bForceShortestRotationPath, enum class EMoveComponentAction MoveAction, struct FLatentActionInfo LatentInfo); // Function Engine.KismetSystemLibrary.MoveComponentTo // Final|Native|Static|Public|HasDefaults|BlueprintCallable // @ game+0x5b3a5c4
	struct FText MakeLiteralText(struct FText Value); // Function Engine.KismetSystemLibrary.MakeLiteralText // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b36904
	struct FString MakeLiteralString(struct FString Value); // Function Engine.KismetSystemLibrary.MakeLiteralString // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b367c4
	struct FName MakeLiteralName(struct FName Value); // Function Engine.KismetSystemLibrary.MakeLiteralName // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0xcd2008
	int32 MakeLiteralInt(int32 Value); // Function Engine.KismetSystemLibrary.MakeLiteralInt // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b3673c
	float MakeLiteralFloat(float Value); // Function Engine.KismetSystemLibrary.MakeLiteralFloat // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0xbe32d8
	bool MakeLiteralByte(bool Value); // Function Engine.KismetSystemLibrary.MakeLiteralByte // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b366b4
	bool MakeLiteralBool(bool Value); // Function Engine.KismetSystemLibrary.MakeLiteralBool // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b18658
	void LoadInterstitialAd(int32 AdIdIndex); // Function Engine.KismetSystemLibrary.LoadInterstitialAd // Final|Native|Static|Public|BlueprintCallable // @ game+0x5b35808
	void LoadAssetClass(struct UObject* WorldContextObject, struct UClass* AssetClass, DelegateProperty OnLoaded, struct FLatentActionInfo LatentInfo); // Function Engine.KismetSystemLibrary.LoadAssetClass // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x5b354c4
	void LoadAsset(struct UObject* WorldContextObject, struct UObject* Asset, DelegateProperty OnLoaded, struct FLatentActionInfo LatentInfo); // Function Engine.KismetSystemLibrary.LoadAsset // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x5b3529c
	bool LineTraceSingleForObjects(struct UObject* WorldContextObject, struct FVector Start, struct FVector End, struct TArray<enum class EObjectTypeQuery> ObjectTypes, bool bTraceComplex, struct TArray<struct AActor*> ActorsToIgnore, enum class EDrawDebugTrace DrawDebugType, struct FHitResult OutHit, bool bIgnoreSelf, struct FLinearColor TraceColor, struct FLinearColor TraceHitColor, float DrawTime); // Function Engine.KismetSystemLibrary.LineTraceSingleForObjects // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b34af4
	bool LineTraceSingleByProfile(struct UObject* WorldContextObject, struct FVector Start, struct FVector End, struct FName ProfileName, bool bTraceComplex, struct TArray<struct AActor*> ActorsToIgnore, enum class EDrawDebugTrace DrawDebugType, struct FHitResult OutHit, bool bIgnoreSelf, struct FLinearColor TraceColor, struct FLinearColor TraceHitColor, float DrawTime); // Function Engine.KismetSystemLibrary.LineTraceSingleByProfile // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b34644
	bool LineTraceSingle(struct UObject* WorldContextObject, struct FVector Start, struct FVector End, enum class ETraceTypeQuery TraceChannel, bool bTraceComplex, struct TArray<struct AActor*> ActorsToIgnore, enum class EDrawDebugTrace DrawDebugType, struct FHitResult OutHit, bool bIgnoreSelf, struct FLinearColor TraceColor, struct FLinearColor TraceHitColor, float DrawTime); // Function Engine.KismetSystemLibrary.LineTraceSingle // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b34194
	bool LineTraceMultiForObjects(struct UObject* WorldContextObject, struct FVector Start, struct FVector End, struct TArray<enum class EObjectTypeQuery> ObjectTypes, bool bTraceComplex, struct TArray<struct AActor*> ActorsToIgnore, enum class EDrawDebugTrace DrawDebugType, struct TArray<struct FHitResult> OutHits, bool bIgnoreSelf, struct FLinearColor TraceColor, struct FLinearColor TraceHitColor, float DrawTime); // Function Engine.KismetSystemLibrary.LineTraceMultiForObjects // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b33cd8
	bool LineTraceMultiByProfile(struct UObject* WorldContextObject, struct FVector Start, struct FVector End, struct FName ProfileName, bool bTraceComplex, struct TArray<struct AActor*> ActorsToIgnore, enum class EDrawDebugTrace DrawDebugType, struct TArray<struct FHitResult> OutHits, bool bIgnoreSelf, struct FLinearColor TraceColor, struct FLinearColor TraceHitColor, float DrawTime); // Function Engine.KismetSystemLibrary.LineTraceMultiByProfile // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b33848
	bool LineTraceMulti(struct UObject* WorldContextObject, struct FVector Start, struct FVector End, enum class ETraceTypeQuery TraceChannel, bool bTraceComplex, struct TArray<struct AActor*> ActorsToIgnore, enum class EDrawDebugTrace DrawDebugType, struct TArray<struct FHitResult> OutHits, bool bIgnoreSelf, struct FLinearColor TraceColor, struct FLinearColor TraceHitColor, float DrawTime); // Function Engine.KismetSystemLibrary.LineTraceMulti // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b333c4
	void LaunchURL(struct FString URL); // Function Engine.KismetSystemLibrary.LaunchURL // Final|Native|Static|Public|BlueprintCallable // @ game+0x5b32a10
	void K2_UnPauseTimerHandle(struct UObject* WorldContextObject, struct FTimerHandle Handle); // Function Engine.KismetSystemLibrary.K2_UnPauseTimerHandle // Final|Native|Static|Public|BlueprintCallable // @ game+0x5b32244
	void K2_UnPauseTimerDelegate(DelegateProperty Delegate); // Function Engine.KismetSystemLibrary.K2_UnPauseTimerDelegate // Final|Native|Static|Public|BlueprintCallable // @ game+0x5b321a0
	void K2_UnPauseTimer(struct UObject* Object, struct FString FunctionName); // Function Engine.KismetSystemLibrary.K2_UnPauseTimer // Final|Native|Static|Public|BlueprintCallable // @ game+0x5b32060
	bool K2_TimerExistsHandle(struct UObject* WorldContextObject, struct FTimerHandle Handle); // Function Engine.KismetSystemLibrary.K2_TimerExistsHandle // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b31f54
	bool K2_TimerExistsDelegate(DelegateProperty Delegate); // Function Engine.KismetSystemLibrary.K2_TimerExistsDelegate // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b31ea0
	bool K2_TimerExists(struct UObject* Object, struct FString FunctionName); // Function Engine.KismetSystemLibrary.K2_TimerExists // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b31d60
	struct FTimerHandle K2_SetTimerDelegate(DelegateProperty Delegate, float Time, bool bLooping); // Function Engine.KismetSystemLibrary.K2_SetTimerDelegate // Final|Native|Static|Public|BlueprintCallable // @ game+0xaa1a9c
	struct FTimerHandle K2_SetTimer(struct UObject* Object, struct FString FunctionName, float Time, bool bLooping); // Function Engine.KismetSystemLibrary.K2_SetTimer // Final|Native|Static|Public|BlueprintCallable // @ game+0xaa1598
	void K2_PauseTimerHandle(struct UObject* WorldContextObject, struct FTimerHandle Handle); // Function Engine.KismetSystemLibrary.K2_PauseTimerHandle // Final|Native|Static|Public|BlueprintCallable // @ game+0x5b31b74
	void K2_PauseTimerDelegate(DelegateProperty Delegate); // Function Engine.KismetSystemLibrary.K2_PauseTimerDelegate // Final|Native|Static|Public|BlueprintCallable // @ game+0x5b31ad0
	void K2_PauseTimer(struct UObject* Object, struct FString FunctionName); // Function Engine.KismetSystemLibrary.K2_PauseTimer // Final|Native|Static|Public|BlueprintCallable // @ game+0x5b31990
	bool K2_IsValidTimerHandle(struct FTimerHandle Handle); // Function Engine.KismetSystemLibrary.K2_IsValidTimerHandle // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b3190c
	bool K2_IsTimerPausedHandle(struct UObject* WorldContextObject, struct FTimerHandle Handle); // Function Engine.KismetSystemLibrary.K2_IsTimerPausedHandle // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b317f8
	bool K2_IsTimerPausedDelegate(DelegateProperty Delegate); // Function Engine.KismetSystemLibrary.K2_IsTimerPausedDelegate // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b31744
	bool K2_IsTimerPaused(struct UObject* Object, struct FString FunctionName); // Function Engine.KismetSystemLibrary.K2_IsTimerPaused // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b31604
	bool K2_IsTimerActiveHandle(struct UObject* WorldContextObject, struct FTimerHandle Handle); // Function Engine.KismetSystemLibrary.K2_IsTimerActiveHandle // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b314f0
	bool K2_IsTimerActiveDelegate(DelegateProperty Delegate); // Function Engine.KismetSystemLibrary.K2_IsTimerActiveDelegate // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b3143c
	bool K2_IsTimerActive(struct UObject* Object, struct FString FunctionName); // Function Engine.KismetSystemLibrary.K2_IsTimerActive // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b312fc
	struct FTimerHandle K2_InvalidateTimerHandle(struct FTimerHandle Handle); // Function Engine.KismetSystemLibrary.K2_InvalidateTimerHandle // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x5b31268
	float K2_GetTimerRemainingTimeHandle(struct UObject* WorldContextObject, struct FTimerHandle Handle); // Function Engine.KismetSystemLibrary.K2_GetTimerRemainingTimeHandle // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b3118c
	float K2_GetTimerRemainingTimeDelegate(DelegateProperty Delegate); // Function Engine.KismetSystemLibrary.K2_GetTimerRemainingTimeDelegate // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b310d8
	float K2_GetTimerRemainingTime(struct UObject* Object, struct FString FunctionName); // Function Engine.KismetSystemLibrary.K2_GetTimerRemainingTime // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b30f94
	float K2_GetTimerElapsedTimeHandle(struct UObject* WorldContextObject, struct FTimerHandle Handle); // Function Engine.KismetSystemLibrary.K2_GetTimerElapsedTimeHandle // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b30eb8
	float K2_GetTimerElapsedTimeDelegate(DelegateProperty Delegate); // Function Engine.KismetSystemLibrary.K2_GetTimerElapsedTimeDelegate // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b30e04
	float K2_GetTimerElapsedTime(struct UObject* Object, struct FString FunctionName); // Function Engine.KismetSystemLibrary.K2_GetTimerElapsedTime // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b30cc0
	void K2_ClearTimerHandle(struct UObject* WorldContextObject, struct FTimerHandle Handle); // Function Engine.KismetSystemLibrary.K2_ClearTimerHandle // Final|Native|Static|Public|BlueprintCallable // @ game+0x5b309c4
	void K2_ClearTimerDelegate(DelegateProperty Delegate); // Function Engine.KismetSystemLibrary.K2_ClearTimerDelegate // Final|Native|Static|Public|BlueprintCallable // @ game+0x5b30920
	void K2_ClearTimer(struct UObject* Object, struct FString FunctionName); // Function Engine.KismetSystemLibrary.K2_ClearTimer // Final|Native|Static|Public|BlueprintCallable // @ game+0x5b307e0
	void K2_ClearAndInvalidateTimerHandle(struct UObject* WorldContextObject, struct FTimerHandle Handle); // Function Engine.KismetSystemLibrary.K2_ClearAndInvalidateTimerHandle // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0xbf16a0
	bool IsValidClass(struct UClass* Class); // Function Engine.KismetSystemLibrary.IsValidClass // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b3061c
	bool IsValid(struct UObject* Object); // Function Engine.KismetSystemLibrary.IsValid // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x2d3390
	bool IsStandalone(struct UObject* WorldContextObject); // Function Engine.KismetSystemLibrary.IsStandalone // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b303f8
	bool IsServer(struct UObject* WorldContextObject); // Function Engine.KismetSystemLibrary.IsServer // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b30350
	bool IsPackagedForDistribution(); // Function Engine.KismetSystemLibrary.IsPackagedForDistribution // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0xc52118
	bool IsLoggedIn(struct APlayerController* SpecificPlayer); // Function Engine.KismetSystemLibrary.IsLoggedIn // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b2fd64
	bool IsInterstitialAdRequested(); // Function Engine.KismetSystemLibrary.IsInterstitialAdRequested // Final|Native|Static|Public|BlueprintCallable // @ game+0x5b2fc90
	bool IsInterstitialAdAvailable(); // Function Engine.KismetSystemLibrary.IsInterstitialAdAvailable // Final|Native|Static|Public|BlueprintCallable // @ game+0x5b2fc48
	bool IsDedicatedServer(struct UObject* WorldContextObject); // Function Engine.KismetSystemLibrary.IsDedicatedServer // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b2fa28
	bool IsControllerAssignedToGamepad(int32 ControllerId); // Function Engine.KismetSystemLibrary.IsControllerAssignedToGamepad // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b2f9a4
	void HideAdBanner(); // Function Engine.KismetSystemLibrary.HideAdBanner // Final|Native|Static|Public|BlueprintCallable // @ game+0x5b2e3d0
	bool GetVolumeButtonsHandledBySystem(); // Function Engine.KismetSystemLibrary.GetVolumeButtonsHandledBySystem // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0xc52118
	struct FString GetUniqueDeviceId(); // Function Engine.KismetSystemLibrary.GetUniqueDeviceId // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b2ba54
	bool GetSupportedFullscreenResolutions(struct TArray<struct FIntPoint> Resolutions); // Function Engine.KismetSystemLibrary.GetSupportedFullscreenResolutions // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x5b2a2cc
	int32 GetRenderingMaterialQualityLevel(); // Function Engine.KismetSystemLibrary.GetRenderingMaterialQualityLevel // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b28b2c
	int32 GetRenderingDetailMode(); // Function Engine.KismetSystemLibrary.GetRenderingDetailMode // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b28b08
	struct TArray<struct FString> GetPreferredLanguages(); // Function Engine.KismetSystemLibrary.GetPreferredLanguages // Final|Native|Static|Public|BlueprintCallable // @ game+0x5b284cc
	struct FString GetPlatformUserName(); // Function Engine.KismetSystemLibrary.GetPlatformUserName // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b27b90
	struct FString GetPathName(struct UObject* Object); // Function Engine.KismetSystemLibrary.GetPathName // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b27a58
	struct FString GetObjectName(struct UObject* Object); // Function Engine.KismetSystemLibrary.GetObjectName // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0xc8c374
	int32 GetMinYResolutionForUI(); // Function Engine.KismetSystemLibrary.GetMinYResolutionForUI // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b27380
	int32 GetMinYResolutionFor3DView(); // Function Engine.KismetSystemLibrary.GetMinYResolutionFor3DView // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b27360
	struct FString GetLocalCurrencySymbol(); // Function Engine.KismetSystemLibrary.GetLocalCurrencySymbol // Final|Native|Static|Public|BlueprintCallable // @ game+0x5b26acc
	struct FString GetLocalCurrencyCode(); // Function Engine.KismetSystemLibrary.GetLocalCurrencyCode // Final|Native|Static|Public|BlueprintCallable // @ game+0x5b26acc
	float GetGameTimeInSeconds(struct UObject* WorldContextObject); // Function Engine.KismetSystemLibrary.GetGameTimeInSeconds // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b24ad8
	struct FString GetGameName(); // Function Engine.KismetSystemLibrary.GetGameName // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b249dc
	struct FString GetGameBundleId(); // Function Engine.KismetSystemLibrary.GetGameBundleId // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b248c8
	struct FString GetEngineVersion(); // Function Engine.KismetSystemLibrary.GetEngineVersion // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b246f4
	struct FString GetDisplayName(struct UObject* Object); // Function Engine.KismetSystemLibrary.GetDisplayName // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b24438
	struct FString GetDeviceId(); // Function Engine.KismetSystemLibrary.GetDeviceId // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b23eec
	struct FString GetDefaultLocale(); // Function Engine.KismetSystemLibrary.GetDefaultLocale // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b23d18
	bool GetConvenientWindowedResolutions(struct TArray<struct FIntPoint> Resolutions); // Function Engine.KismetSystemLibrary.GetConvenientWindowedResolutions // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x5b2323c
	void GetComponentBounds(struct USceneComponent* Component, struct FVector Origin, struct FVector BoxExtent, float SphereRadius); // Function Engine.KismetSystemLibrary.GetComponentBounds // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b22f4c
	struct FString GetCommandLine(); // Function Engine.KismetSystemLibrary.GetCommandLine // Final|Native|Static|Public|BlueprintCallable // @ game+0x5b22ec4
	struct FString GetClassDisplayName(struct UClass* Class); // Function Engine.KismetSystemLibrary.GetClassDisplayName // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b22dcc
	int32 GetAdIDCount(); // Function Engine.KismetSystemLibrary.GetAdIDCount // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b216d4
	void GetActorListFromComponentList(struct TArray<struct UPrimitiveComponent*> ComponentList, struct UClass* ActorClassFilter, struct TArray<struct AActor*> OutActorList); // Function Engine.KismetSystemLibrary.GetActorListFromComponentList // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x5b21540
	void GetActorBounds(struct AActor* Actor, struct FVector Origin, struct FVector BoxExtent); // Function Engine.KismetSystemLibrary.GetActorBounds // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b213fc
	void ForceCloseAdBanner(); // Function Engine.KismetSystemLibrary.ForceCloseAdBanner // Final|Native|Static|Public|BlueprintCallable // @ game+0x5b20bf8
	void FlushPersistentDebugLines(struct UObject* WorldContextObject); // Function Engine.KismetSystemLibrary.FlushPersistentDebugLines // Final|Native|Static|Public|BlueprintCallable // @ game+0x4cf2d64
	void FlushDebugStrings(struct UObject* WorldContextObject); // Function Engine.KismetSystemLibrary.FlushDebugStrings // Final|Native|Static|Public|BlueprintCallable // @ game+0x4cf2d64
	void ExecuteConsoleCommand(struct UObject* WorldContextObject, struct FString Command, struct APlayerController* SpecificPlayer); // Function Engine.KismetSystemLibrary.ExecuteConsoleCommand // Final|Native|Static|Public|BlueprintCallable // @ game+0x9f6004
	void DrawDebugString(struct UObject* WorldContextObject, struct FVector TextLocation, struct FString Text, struct AActor* TestBaseActor, struct FLinearColor TextColor, float Duration); // Function Engine.KismetSystemLibrary.DrawDebugString // Final|Native|Static|Public|HasDefaults|BlueprintCallable // @ game+0x5b1d600
	void DrawDebugSphere(struct UObject* WorldContextObject, struct FVector Center, float Radius, int32 Segments, struct FLinearColor LineColor, float Duration, float Thickness); // Function Engine.KismetSystemLibrary.DrawDebugSphere // Final|Native|Static|Public|HasDefaults|BlueprintCallable // @ game+0x5b1d3e8
	void DrawDebugPoint(struct UObject* WorldContextObject, struct FVector Position, float Size, struct FLinearColor PointColor, float Duration); // Function Engine.KismetSystemLibrary.DrawDebugPoint // Final|Native|Static|Public|HasDefaults|BlueprintCallable // @ game+0x5b1d25c
	void DrawDebugPlane(struct UObject* WorldContextObject, struct FPlane PlaneCoordinates, struct FVector Location, float Size, struct FLinearColor PlaneColor, float Duration); // Function Engine.KismetSystemLibrary.DrawDebugPlane // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b1d088
	void DrawDebugLine(struct UObject* WorldContextObject, struct FVector LineStart, struct FVector LineEnd, struct FLinearColor LineColor, float Duration, float Thickness); // Function Engine.KismetSystemLibrary.DrawDebugLine // Final|Native|Static|Public|HasDefaults|BlueprintCallable // @ game+0x5b1ceb8
	void DrawDebugFrustum(struct UObject* WorldContextObject, struct FTransform FrustumTransform, struct FLinearColor FrustumColor, float Duration, float Thickness); // Function Engine.KismetSystemLibrary.DrawDebugFrustum // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b1cccc
	void DrawDebugFloatHistoryTransform(struct UObject* WorldContextObject, struct FDebugFloatHistory FloatHistory, struct FTransform DrawTransform, struct FVector2D DrawSize, struct FLinearColor DrawColor, float Duration); // Function Engine.KismetSystemLibrary.DrawDebugFloatHistoryTransform // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b1ca54
	void DrawDebugFloatHistoryLocation(struct UObject* WorldContextObject, struct FDebugFloatHistory FloatHistory, struct FVector DrawLocation, struct FVector2D DrawSize, struct FLinearColor DrawColor, float Duration); // Function Engine.KismetSystemLibrary.DrawDebugFloatHistoryLocation // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b1c830
	void DrawDebugCylinder(struct UObject* WorldContextObject, struct FVector Start, struct FVector End, float Radius, int32 Segments, struct FLinearColor LineColor, float Duration, float Thickness); // Function Engine.KismetSystemLibrary.DrawDebugCylinder // Final|Native|Static|Public|HasDefaults|BlueprintCallable // @ game+0x5b1c5d4
	void DrawDebugCoordinateSystem(struct UObject* WorldContextObject, struct FVector AxisLoc, struct FRotator AxisRot, float Scale, float Duration, float Thickness); // Function Engine.KismetSystemLibrary.DrawDebugCoordinateSystem // Final|Native|Static|Public|HasDefaults|BlueprintCallable // @ game+0x5b1c404
	void DrawDebugConeInDegrees(struct UObject* WorldContextObject, struct FVector Origin, struct FVector Direction, float Length, float AngleWidth, float AngleHeight, int32 NumSides, struct FLinearColor LineColor, float Duration, float Thickness); // Function Engine.KismetSystemLibrary.DrawDebugConeInDegrees // Final|Native|Static|Public|HasDefaults|BlueprintCallable // @ game+0x5b1c11c
	void DrawDebugCone(struct UObject* WorldContextObject, struct FVector Origin, struct FVector Direction, float Length, float AngleWidth, float AngleHeight, int32 NumSides, struct FLinearColor LineColor, float Duration, float Thickness); // Function Engine.KismetSystemLibrary.DrawDebugCone // Final|Native|Static|Public|HasDefaults|BlueprintCallable // @ game+0x5b1c11c
	void DrawDebugCircle(struct UObject* WorldContextObject, struct FVector Center, float Radius, int32 NumSegments, struct FLinearColor LineColor, float Duration, float Thickness, struct FVector YAxis, struct FVector ZAxis, bool bDrawAxis); // Function Engine.KismetSystemLibrary.DrawDebugCircle // Final|Native|Static|Public|HasDefaults|BlueprintCallable // @ game+0x5b1be30
	void DrawDebugCapsule(struct UObject* WorldContextObject, struct FVector Center, float HalfHeight, float Radius, struct FRotator Rotation, struct FLinearColor LineColor, float Duration, float Thickness); // Function Engine.KismetSystemLibrary.DrawDebugCapsule // Final|Native|Static|Public|HasDefaults|BlueprintCallable // @ game+0x5b1bbd4
	void DrawDebugCamera(struct ACameraActor* CameraActor, struct FLinearColor CameraColor, float Duration); // Function Engine.KismetSystemLibrary.DrawDebugCamera // Final|Native|Static|Public|HasDefaults|BlueprintCallable // @ game+0x5b1bac4
	void DrawDebugBox(struct UObject* WorldContextObject, struct FVector Center, struct FVector Extent, struct FLinearColor LineColor, struct FRotator Rotation, float Duration, float Thickness); // Function Engine.KismetSystemLibrary.DrawDebugBox // Final|Native|Static|Public|HasDefaults|BlueprintCallable // @ game+0x5b1b8b0
	void DrawDebugArrow(struct UObject* WorldContextObject, struct FVector LineStart, struct FVector LineEnd, float ArrowSize, struct FLinearColor LineColor, float Duration, float Thickness); // Function Engine.KismetSystemLibrary.DrawDebugArrow // Final|Native|Static|Public|HasDefaults|BlueprintCallable // @ game+0x5b1b698
	bool DoesImplementInterface(struct UObject* TestObject, struct UClass* Interface); // Function Engine.KismetSystemLibrary.DoesImplementInterface // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0xd12f7c
	void Delay(struct UObject* WorldContextObject, float Duration, struct FLatentActionInfo LatentInfo); // Function Engine.KismetSystemLibrary.Delay // Final|Native|Static|Public|BlueprintCallable // @ game+0x89665c
	void CreateCopyForUndoBuffer(struct UObject* ObjectToModify); // Function Engine.KismetSystemLibrary.CreateCopyForUndoBuffer // Final|Native|Static|Public|BlueprintCallable // @ game+0x5b194b0
	struct UObject* Conv_InterfaceToObject(TScriptInterface<struct UInterface> Interface); // Function Engine.KismetSystemLibrary.Conv_InterfaceToObject // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x5b18d10
	struct UObject* Conv_AssetToObject(struct UObject* Asset); // Function Engine.KismetSystemLibrary.Conv_AssetToObject // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x5b182d8
	struct UClass* Conv_AssetClassToClass(struct UClass* AssetClass); // Function Engine.KismetSystemLibrary.Conv_AssetClassToClass // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x5b181cc
	void ControlScreensaver(bool bAllowScreenSaver); // Function Engine.KismetSystemLibrary.ControlScreensaver // Final|Native|Static|Public|BlueprintCallable // @ game+0x4d09aac
	bool ComponentOverlapComponents(struct UPrimitiveComponent* Component, struct FTransform ComponentTransform, struct TArray<enum class EObjectTypeQuery> ObjectTypes, struct UClass* ComponentClassFilter, struct TArray<struct AActor*> ActorsToIgnore, struct TArray<struct UPrimitiveComponent*> OutComponents); // Function Engine.KismetSystemLibrary.ComponentOverlapComponents // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b173fc
	bool ComponentOverlapActors(struct UPrimitiveComponent* Component, struct FTransform ComponentTransform, struct TArray<enum class EObjectTypeQuery> ObjectTypes, struct UClass* ActorClassFilter, struct TArray<struct AActor*> ActorsToIgnore, struct TArray<struct AActor*> OutActors); // Function Engine.KismetSystemLibrary.ComponentOverlapActors // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b170e4
	void CollectGarbage(); // Function Engine.KismetSystemLibrary.CollectGarbage // Final|Native|Static|Public|BlueprintCallable // @ game+0x5b170d0
	bool CapsuleTraceSingleForObjects(struct UObject* WorldContextObject, struct FVector Start, struct FVector End, float Radius, float HalfHeight, struct TArray<enum class EObjectTypeQuery> ObjectTypes, bool bTraceComplex, struct TArray<struct AActor*> ActorsToIgnore, enum class EDrawDebugTrace DrawDebugType, struct FHitResult OutHit, bool bIgnoreSelf, struct FLinearColor TraceColor, struct FLinearColor TraceHitColor, float DrawTime); // Function Engine.KismetSystemLibrary.CapsuleTraceSingleForObjects // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b15fbc
	bool CapsuleTraceSingleByProfile(struct UObject* WorldContextObject, struct FVector Start, struct FVector End, float Radius, float HalfHeight, struct FName ProfileName, bool bTraceComplex, struct TArray<struct AActor*> ActorsToIgnore, enum class EDrawDebugTrace DrawDebugType, struct FHitResult OutHit, bool bIgnoreSelf, struct FLinearColor TraceColor, struct FLinearColor TraceHitColor, float DrawTime); // Function Engine.KismetSystemLibrary.CapsuleTraceSingleByProfile // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b15a70
	bool CapsuleTraceSingle(struct UObject* WorldContextObject, struct FVector Start, struct FVector End, float Radius, float HalfHeight, enum class ETraceTypeQuery TraceChannel, bool bTraceComplex, struct TArray<struct AActor*> ActorsToIgnore, enum class EDrawDebugTrace DrawDebugType, struct FHitResult OutHit, bool bIgnoreSelf, struct FLinearColor TraceColor, struct FLinearColor TraceHitColor, float DrawTime); // Function Engine.KismetSystemLibrary.CapsuleTraceSingle // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b15520
	bool CapsuleTraceMultiForObjects(struct UObject* WorldContextObject, struct FVector Start, struct FVector End, float Radius, float HalfHeight, struct TArray<enum class EObjectTypeQuery> ObjectTypes, bool bTraceComplex, struct TArray<struct AActor*> ActorsToIgnore, enum class EDrawDebugTrace DrawDebugType, struct TArray<struct FHitResult> OutHits, bool bIgnoreSelf, struct FLinearColor TraceColor, struct FLinearColor TraceHitColor, float DrawTime); // Function Engine.KismetSystemLibrary.CapsuleTraceMultiForObjects // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b14fb0
	bool CapsuleTraceMultiByProfile(struct UObject* WorldContextObject, struct FVector Start, struct FVector End, float Radius, float HalfHeight, struct FName ProfileName, bool bTraceComplex, struct TArray<struct AActor*> ActorsToIgnore, enum class EDrawDebugTrace DrawDebugType, struct TArray<struct FHitResult> OutHits, bool bIgnoreSelf, struct FLinearColor TraceColor, struct FLinearColor TraceHitColor, float DrawTime); // Function Engine.KismetSystemLibrary.CapsuleTraceMultiByProfile // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b14a84
	bool CapsuleTraceMulti(struct UObject* WorldContextObject, struct FVector Start, struct FVector End, float Radius, float HalfHeight, enum class ETraceTypeQuery TraceChannel, bool bTraceComplex, struct TArray<struct AActor*> ActorsToIgnore, enum class EDrawDebugTrace DrawDebugType, struct TArray<struct FHitResult> OutHits, bool bIgnoreSelf, struct FLinearColor TraceColor, struct FLinearColor TraceHitColor, float DrawTime); // Function Engine.KismetSystemLibrary.CapsuleTraceMulti // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b14554
	bool CapsuleOverlapComponents(struct UObject* WorldContextObject, struct FVector CapsulePos, float Radius, float HalfHeight, struct TArray<enum class EObjectTypeQuery> ObjectTypes, struct UClass* ComponentClassFilter, struct TArray<struct AActor*> ActorsToIgnore, struct TArray<struct UPrimitiveComponent*> OutComponents); // Function Engine.KismetSystemLibrary.CapsuleOverlapComponents // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b141f8
	bool CapsuleOverlapActors(struct UObject* WorldContextObject, struct FVector CapsulePos, float Radius, float HalfHeight, struct TArray<enum class EObjectTypeQuery> ObjectTypes, struct UClass* ActorClassFilter, struct TArray<struct AActor*> ActorsToIgnore, struct TArray<struct AActor*> OutActors); // Function Engine.KismetSystemLibrary.CapsuleOverlapActors // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b13e9c
	bool CanLaunchURL(struct FString URL); // Function Engine.KismetSystemLibrary.CanLaunchURL // Final|Native|Static|Public|BlueprintCallable // @ game+0x5b13d18
	bool BoxTraceSingleForObjects(struct UObject* WorldContextObject, struct FVector Start, struct FVector End, struct FVector HalfSize, struct FRotator Orientation, struct TArray<enum class EObjectTypeQuery> ObjectTypes, bool bTraceComplex, struct TArray<struct AActor*> ActorsToIgnore, enum class EDrawDebugTrace DrawDebugType, struct FHitResult OutHit, bool bIgnoreSelf, struct FLinearColor TraceColor, struct FLinearColor TraceHitColor, float DrawTime); // Function Engine.KismetSystemLibrary.BoxTraceSingleForObjects // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b12014
	bool BoxTraceSingleByProfile(struct UObject* WorldContextObject, struct FVector Start, struct FVector End, struct FVector HalfSize, struct FRotator Orientation, struct FName ProfileName, bool bTraceComplex, struct TArray<struct AActor*> ActorsToIgnore, enum class EDrawDebugTrace DrawDebugType, struct FHitResult OutHit, bool bIgnoreSelf, struct FLinearColor TraceColor, struct FLinearColor TraceHitColor, float DrawTime); // Function Engine.KismetSystemLibrary.BoxTraceSingleByProfile // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b11ab4
	bool BoxTraceSingle(struct UObject* WorldContextObject, struct FVector Start, struct FVector End, struct FVector HalfSize, struct FRotator Orientation, enum class ETraceTypeQuery TraceChannel, bool bTraceComplex, struct TArray<struct AActor*> ActorsToIgnore, enum class EDrawDebugTrace DrawDebugType, struct FHitResult OutHit, bool bIgnoreSelf, struct FLinearColor TraceColor, struct FLinearColor TraceHitColor, float DrawTime); // Function Engine.KismetSystemLibrary.BoxTraceSingle // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b11550
	bool BoxTraceMultiForObjects(struct UObject* WorldContextObject, struct FVector Start, struct FVector End, struct FVector HalfSize, struct FRotator Orientation, struct TArray<enum class EObjectTypeQuery> ObjectTypes, bool bTraceComplex, struct TArray<struct AActor*> ActorsToIgnore, enum class EDrawDebugTrace DrawDebugType, struct TArray<struct FHitResult> OutHits, bool bIgnoreSelf, struct FLinearColor TraceColor, struct FLinearColor TraceHitColor, float DrawTime); // Function Engine.KismetSystemLibrary.BoxTraceMultiForObjects // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b10fc4
	bool BoxTraceMultiByProfile(struct UObject* WorldContextObject, struct FVector Start, struct FVector End, struct FVector HalfSize, struct FRotator Orientation, struct FName ProfileName, bool bTraceComplex, struct TArray<struct AActor*> ActorsToIgnore, enum class EDrawDebugTrace DrawDebugType, struct TArray<struct FHitResult> OutHits, bool bIgnoreSelf, struct FLinearColor TraceColor, struct FLinearColor TraceHitColor, float DrawTime); // Function Engine.KismetSystemLibrary.BoxTraceMultiByProfile // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b10a70
	bool BoxTraceMulti(struct UObject* WorldContextObject, struct FVector Start, struct FVector End, struct FVector HalfSize, struct FRotator Orientation, enum class ETraceTypeQuery TraceChannel, bool bTraceComplex, struct TArray<struct AActor*> ActorsToIgnore, enum class EDrawDebugTrace DrawDebugType, struct TArray<struct FHitResult> OutHits, bool bIgnoreSelf, struct FLinearColor TraceColor, struct FLinearColor TraceHitColor, float DrawTime); // Function Engine.KismetSystemLibrary.BoxTraceMulti // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b10508
	bool BoxOverlapComponents(struct UObject* WorldContextObject, struct FVector BoxPos, struct FVector Extent, struct TArray<enum class EObjectTypeQuery> ObjectTypes, struct UClass* ComponentClassFilter, struct TArray<struct AActor*> ActorsToIgnore, struct TArray<struct UPrimitiveComponent*> OutComponents); // Function Engine.KismetSystemLibrary.BoxOverlapComponents // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b101e0
	bool BoxOverlapActors(struct UObject* WorldContextObject, struct FVector BoxPos, struct FVector BoxExtent, struct TArray<enum class EObjectTypeQuery> ObjectTypes, struct UClass* ActorClassFilter, struct TArray<struct AActor*> ActorsToIgnore, struct TArray<struct AActor*> OutActors); // Function Engine.KismetSystemLibrary.BoxOverlapActors // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b0feb8
	struct FDebugFloatHistory AddFloatHistorySample(float Value, struct FDebugFloatHistory FloatHistory); // Function Engine.KismetSystemLibrary.AddFloatHistorySample // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x5b0987c
};

// Class Engine.GameplayStatics
// Size: 0x38 (Inherited: 0x38)
struct UGameplayStatics : UBlueprintFunctionLibrary {

	void UnloadStreamLevel(struct UObject* WorldContextObject, struct FName LevelName, struct FLatentActionInfo LatentInfo); // Function Engine.GameplayStatics.UnloadStreamLevel // Final|Native|Static|Public|BlueprintCallable // @ game+0x5b5bdc0
	bool SuggestProjectileVelocity_CustomArc(struct UObject* WorldContextObject, struct FVector OutLaunchVelocity, struct FVector StartPos, struct FVector EndPos, float OverrideGravityZ, float ArcParam); // Function Engine.GameplayStatics.SuggestProjectileVelocity_CustomArc // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b5a770
	struct UAudioComponent* SpawnSoundAttached(struct USoundBase* Sound, struct USceneComponent* AttachToComponent, struct FName AttachPointName, struct FVector Location, struct FRotator Rotation, enum class EAttachLocation LocationType, bool bStopWhenAttachedToDestroyed, float VolumeMultiplier, float PitchMultiplier, float StartTime, struct USoundAttenuation* AttenuationSettings, struct USoundConcurrency* ConcurrencySettings, bool bAutoDestroy); // Function Engine.GameplayStatics.SpawnSoundAttached // Final|Native|Static|Public|HasDefaults|BlueprintCallable // @ game+0x5b575d4
	struct UAudioComponent* SpawnSoundAtLocation(struct UObject* WorldContextObject, struct USoundBase* Sound, struct FVector Location, struct FRotator Rotation, float VolumeMultiplier, float PitchMultiplier, float StartTime, struct USoundAttenuation* AttenuationSettings, struct USoundConcurrency* ConcurrencySettings, bool bAutoDestroy); // Function Engine.GameplayStatics.SpawnSoundAtLocation // Final|Native|Static|Public|HasDefaults|BlueprintCallable // @ game+0x5b57260
	struct UAudioComponent* SpawnSound2D(struct UObject* WorldContextObject, struct USoundBase* Sound, float VolumeMultiplier, float PitchMultiplier, float StartTime, struct USoundConcurrency* ConcurrencySettings, bool bPersistAcrossLevelTransition, bool bAutoDestroy); // Function Engine.GameplayStatics.SpawnSound2D // Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable // @ game+0x5b56fa0
	struct UObject* SpawnObject(struct UClass* ObjectClass, struct UObject* Outer); // Function Engine.GameplayStatics.SpawnObject // Final|Native|Static|Public|BlueprintCallable // @ game+0x5b56ec4
	struct UForceFeedbackComponent* SpawnForceFeedbackAttached(struct UForceFeedbackEffect* ForceFeedbackEffect, struct USceneComponent* AttachToComponent, struct FName AttachPointName, struct FVector Location, struct FRotator Rotation, enum class EAttachLocation LocationType, bool bStopWhenAttachedToDestroyed, bool bLooping, float IntensityMultiplier, float StartTime, struct UForceFeedbackAttenuation* AttenuationSettings, bool bAutoDestroy); // Function Engine.GameplayStatics.SpawnForceFeedbackAttached // Final|Native|Static|Public|HasDefaults|BlueprintCallable // @ game+0x5b56aa4
	struct UForceFeedbackComponent* SpawnForceFeedbackAtLocation(struct UObject* WorldContextObject, struct UForceFeedbackEffect* ForceFeedbackEffect, struct FVector Location, struct FRotator Rotation, bool bLooping, float IntensityMultiplier, float StartTime, struct UForceFeedbackAttenuation* AttenuationSettings, bool bAutoDestroy); // Function Engine.GameplayStatics.SpawnForceFeedbackAtLocation // Final|Native|Static|Public|HasDefaults|BlueprintCallable // @ game+0x5b56774
	struct UParticleSystemComponent* SpawnEmitterAttached(struct UParticleSystem* EmitterTemplate, struct USceneComponent* AttachToComponent, struct FName AttachPointName, struct FVector Location, struct FRotator Rotation, enum class EAttachLocation LocationType, bool bAutoDestroy); // Function Engine.GameplayStatics.SpawnEmitterAttached // Final|Native|Static|Public|HasDefaults|BlueprintCallable // @ game+0x5b564f8
	struct UParticleSystemComponent* SpawnEmitterAtLocation(struct UObject* WorldContextObject, struct UParticleSystem* EmitterTemplate, struct FVector Location, struct FRotator Rotation, bool bAutoDestroy); // Function Engine.GameplayStatics.SpawnEmitterAtLocation // Final|Native|Static|Public|HasDefaults|BlueprintCallable // @ game+0x5b56324
	struct UAudioComponent* SpawnDialogueAttached(struct UDialogueWave* Dialogue, struct FDialogueContext Context, struct USceneComponent* AttachToComponent, struct FName AttachPointName, struct FVector Location, struct FRotator Rotation, enum class EAttachLocation LocationType, bool bStopWhenAttachedToDestroyed, float VolumeMultiplier, float PitchMultiplier, float StartTime, struct USoundAttenuation* AttenuationSettings, bool bAutoDestroy); // Function Engine.GameplayStatics.SpawnDialogueAttached // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b55e74
	struct UAudioComponent* SpawnDialogueAtLocation(struct UObject* WorldContextObject, struct UDialogueWave* Dialogue, struct FDialogueContext Context, struct FVector Location, struct FRotator Rotation, float VolumeMultiplier, float PitchMultiplier, float StartTime, struct USoundAttenuation* AttenuationSettings, bool bAutoDestroy); // Function Engine.GameplayStatics.SpawnDialogueAtLocation // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b55ac0
	struct UAudioComponent* SpawnDialogue2D(struct UObject* WorldContextObject, struct UDialogueWave* Dialogue, struct FDialogueContext Context, float VolumeMultiplier, float PitchMultiplier, float StartTime, bool bAutoDestroy); // Function Engine.GameplayStatics.SpawnDialogue2D // Final|BlueprintCosmetic|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x5b5581c
	struct UDecalComponent* SpawnDecalAttached(struct UMaterialInterface* DecalMaterial, struct FVector DecalSize, struct USceneComponent* AttachToComponent, struct FName AttachPointName, struct FVector Location, struct FRotator Rotation, enum class EAttachLocation LocationType, float LifeSpan); // Function Engine.GameplayStatics.SpawnDecalAttached // Final|Native|Static|Public|HasDefaults|BlueprintCallable // @ game+0x5b5553c
	struct UDecalComponent* SpawnDecalAtLocation(struct UObject* WorldContextObject, struct UMaterialInterface* DecalMaterial, struct FVector DecalSize, struct FVector Location, struct FRotator Rotation, float LifeSpan); // Function Engine.GameplayStatics.SpawnDecalAtLocation // Final|Native|Static|Public|HasDefaults|BlueprintCallable // @ game+0x5b552fc
	void SetWorldOriginLocation(struct UObject* WorldContextObject, struct FIntVector NewLocation); // Function Engine.GameplayStatics.SetWorldOriginLocation // Final|Native|Static|Public|HasDefaults|BlueprintCallable // @ game+0x5b53208
	void SetSubtitlesEnabled(bool bEnabled); // Function Engine.GameplayStatics.SetSubtitlesEnabled // Final|Native|Static|Public|BlueprintCallable // @ game+0x5b510e0
	void SetSoundMixClassOverride(struct UObject* WorldContextObject, struct USoundMix* InSoundMixModifier, struct USoundClass* InSoundClass, float Volume, float Pitch, float FadeInTime, bool bApplyToChildren); // Function Engine.GameplayStatics.SetSoundMixClassOverride // Final|Native|Static|Public|BlueprintCallable // @ game+0x5b4f9fc
	void SetPlayerControllerID(struct APlayerController* Player, int32 ControllerId); // Function Engine.GameplayStatics.SetPlayerControllerID // Final|Native|Static|Public|BlueprintCallable // @ game+0x5b4e6f8
	void SetGlobalTimeDilation(struct UObject* WorldContextObject, float TimeDilation); // Function Engine.GameplayStatics.SetGlobalTimeDilation // Final|Native|Static|Public|BlueprintCallable // @ game+0x5b4af84
	void SetGlobalPitchModulation(struct UObject* WorldContextObject, float PitchModulation, float TimeSec); // Function Engine.GameplayStatics.SetGlobalPitchModulation // Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable // @ game+0x5b4ae6c
	void SetGlobalListenerFocusParameters(struct UObject* WorldContextObject, float FocusAzimuthScale, float NonFocusAzimuthScale, float FocusDistanceScale, float NonFocusDistanceScale, float FocusVolumeScale, float NonFocusVolumeScale, float FocusPriorityScale, float NonFocusPriorityScale); // Function Engine.GameplayStatics.SetGlobalListenerFocusParameters // Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable // @ game+0x5b4ab70
	bool SetGamePaused(struct UObject* WorldContextObject, bool bPaused); // Function Engine.GameplayStatics.SetGamePaused // Final|Native|Static|Public|BlueprintCallable // @ game+0x5b4aa64
	void SetBaseSoundMix(struct UObject* WorldContextObject, struct USoundMix* InSoundMix); // Function Engine.GameplayStatics.SetBaseSoundMix // Final|Native|Static|Public|BlueprintCallable // @ game+0x5b45674
	bool SaveGameToSlot(struct USaveGame* SaveGameObject, struct FString SlotName, int32 UserIndex); // Function Engine.GameplayStatics.SaveGameToSlot // Final|Native|Static|Public|BlueprintCallable // @ game+0x5b428e4
	void RemovePlayer(struct APlayerController* Player, bool bDestroyPawn); // Function Engine.GameplayStatics.RemovePlayer // Final|Native|Static|Public|BlueprintCallable // @ game+0x5b41ee8
	struct FVector RebaseZeroOriginOntoLocal(struct UObject* WorldContextObject, struct FVector WorldLocation); // Function Engine.GameplayStatics.RebaseZeroOriginOntoLocal // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b4192c
	struct FVector RebaseLocalOriginOntoZero(struct UObject* WorldContextObject, struct FVector WorldLocation); // Function Engine.GameplayStatics.RebaseLocalOriginOntoZero // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b41820
	void PushSoundMixModifier(struct UObject* WorldContextObject, struct USoundMix* InSoundMixModifier); // Function Engine.GameplayStatics.PushSoundMixModifier // Final|Native|Static|Public|BlueprintCallable // @ game+0x5b3fd58
	bool ProjectWorldToScreen(struct APlayerController* Player, struct FVector WorldPosition, struct FVector2D ScreenPosition, bool bPlayerViewportRelative); // Function Engine.GameplayStatics.ProjectWorldToScreen // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b3fbcc
	void PopSoundMixModifier(struct UObject* WorldContextObject, struct USoundMix* InSoundMixModifier); // Function Engine.GameplayStatics.PopSoundMixModifier // Final|Native|Static|Public|BlueprintCallable // @ game+0x5b3f4a0
	void PlayWorldCameraShake(struct UObject* WorldContextObject, struct UClass* Shake, struct FVector Epicenter, float InnerRadius, float OuterRadius, float Falloff, bool bOrientShakeTowardsEpicenter); // Function Engine.GameplayStatics.PlayWorldCameraShake // Final|Native|Static|Public|HasDefaults|BlueprintCallable // @ game+0x5b3e68c
	void PlaySoundAtLocation(struct UObject* WorldContextObject, struct USoundBase* Sound, struct FVector Location, struct FRotator Rotation, float VolumeMultiplier, float PitchMultiplier, float StartTime, struct USoundAttenuation* AttenuationSettings, struct USoundConcurrency* ConcurrencySettings); // Function Engine.GameplayStatics.PlaySoundAtLocation // Final|Native|Static|Public|HasDefaults|BlueprintCallable // @ game+0x5b3e374
	void PlaySound2D(struct UObject* WorldContextObject, struct USoundBase* Sound, float VolumeMultiplier, float PitchMultiplier, float StartTime, struct USoundConcurrency* ConcurrencySettings); // Function Engine.GameplayStatics.PlaySound2D // Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable // @ game+0x5b3e170
	void PlayDialogueAtLocation(struct UObject* WorldContextObject, struct UDialogueWave* Dialogue, struct FDialogueContext Context, struct FVector Location, struct FRotator Rotation, float VolumeMultiplier, float PitchMultiplier, float StartTime, struct USoundAttenuation* AttenuationSettings); // Function Engine.GameplayStatics.PlayDialogueAtLocation // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b3d91c
	void PlayDialogue2D(struct UObject* WorldContextObject, struct UDialogueWave* Dialogue, struct FDialogueContext Context, float VolumeMultiplier, float PitchMultiplier, float StartTime); // Function Engine.GameplayStatics.PlayDialogue2D // Final|BlueprintCosmetic|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x5b3d6c8
	struct FString ParseOption(struct FString Options, struct FString Key); // Function Engine.GameplayStatics.ParseOption // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b3cccc
	void OpenLevel(struct UObject* WorldContextObject, struct FName LevelName, bool bAbsolute, struct FString Options); // Function Engine.GameplayStatics.OpenLevel // Final|Native|Static|Public|BlueprintCallable // @ game+0x5b3c830
	struct FHitResult MakeHitResult(bool bBlockingHit, bool bInitialOverlap, float Time, struct FVector Location, struct FVector ImpactPoint, struct FVector Normal, struct FVector ImpactNormal, struct UPhysicalMaterial* PhysMat, struct AActor* HitActor, struct UPrimitiveComponent* HitComponent, struct FName HitBoneName, int32 HitItem, int32 FaceIndex, struct FVector TraceStart, struct FVector TraceEnd); // Function Engine.GameplayStatics.MakeHitResult // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b36130
	void LoadStreamLevel(struct UObject* WorldContextObject, struct FName LevelName, bool bMakeVisibleAfterLoad, bool bShouldBlockOnLoad, struct FLatentActionInfo LatentInfo); // Function Engine.GameplayStatics.LoadStreamLevel // Final|Native|Static|Public|BlueprintCallable // @ game+0x5b35898
	struct USaveGame* LoadGameFromSlot(struct FString SlotName, int32 UserIndex); // Function Engine.GameplayStatics.LoadGameFromSlot // Final|Native|Static|Public|BlueprintCallable // @ game+0x5b356ec
	bool IsGamePaused(struct UObject* WorldContextObject); // Function Engine.GameplayStatics.IsGamePaused // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b2fab8
	bool HasOption(struct FString Options, struct FString InKey); // Function Engine.GameplayStatics.HasOption // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b2e144
	bool HasLaunchOption(struct FString OptionToCheck); // Function Engine.GameplayStatics.HasLaunchOption // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b2dde0
	int32 GrassOverlappingSphereCount(struct UObject* WorldContextObject, struct UStaticMesh* StaticMesh, struct FVector CenterPosition, float Radius); // Function Engine.GameplayStatics.GrassOverlappingSphereCount // Final|Native|Static|Public|HasDefaults|BlueprintCallable // @ game+0x5b2d478
	struct FIntVector GetWorldOriginLocation(struct UObject* WorldContextObject); // Function Engine.GameplayStatics.GetWorldOriginLocation // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b2cbb0
	float GetWorldDeltaSeconds(struct UObject* WorldContextObject); // Function Engine.GameplayStatics.GetWorldDeltaSeconds // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0xae6640
	float GetUnpausedTimeSeconds(struct UObject* WorldContextObject); // Function Engine.GameplayStatics.GetUnpausedTimeSeconds // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b2bb48
	float GetTimeSeconds(struct UObject* WorldContextObject); // Function Engine.GameplayStatics.GetTimeSeconds // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b2abc4
	enum class EPhysicalSurface GetSurfaceType(struct FHitResult Hit); // Function Engine.GameplayStatics.GetSurfaceType // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x5b2a390
	struct ULevelStreaming* GetStreamingLevel(struct UObject* WorldContextObject, struct FName PackageName); // Function Engine.GameplayStatics.GetStreamingLevel // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b2a1f0
	float GetRealTimeSeconds(struct UObject* WorldContextObject); // Function Engine.GameplayStatics.GetRealTimeSeconds // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x507a74
	struct APawn* GetPlayerPawn(struct UObject* WorldContextObject, int32 PlayerIndex); // Function Engine.GameplayStatics.GetPlayerPawn // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0xd00f2c
	int32 GetPlayerControllerID(struct APlayerController* Player); // Function Engine.GameplayStatics.GetPlayerControllerID // Final|Native|Static|Public|BlueprintCallable // @ game+0x5b27e20
	struct APlayerController* GetPlayerController(struct UObject* WorldContextObject, int32 PlayerIndex); // Function Engine.GameplayStatics.GetPlayerController // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b27d48
	struct ACharacter* GetPlayerCharacter(struct UObject* WorldContextObject, int32 PlayerIndex); // Function Engine.GameplayStatics.GetPlayerCharacter // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b27c70
	struct APlayerCameraManager* GetPlayerCameraManager(struct UObject* WorldContextObject, int32 PlayerIndex); // Function Engine.GameplayStatics.GetPlayerCameraManager // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x507ae8
	struct UClass* GetObjectClass(struct UObject* Object); // Function Engine.GameplayStatics.GetObjectClass // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b2767c
	void GetKeyValue(struct FString Pair, struct FString Key, struct FString Value); // Function Engine.GameplayStatics.GetKeyValue // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x5b26500
	int32 GetIntOption(struct FString Options, struct FString Key, int32 DefaultValue); // Function Engine.GameplayStatics.GetIntOption // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b261e4
	float GetGlobalTimeDilation(struct UObject* WorldContextObject); // Function Engine.GameplayStatics.GetGlobalTimeDilation // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b24b74
	struct AGameStateBase* GetGameState(struct UObject* WorldContextObject); // Function Engine.GameplayStatics.GetGameState // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0xe2c7a8
	struct AGameModeBase* GetGameMode(struct UObject* WorldContextObject); // Function Engine.GameplayStatics.GetGameMode // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b2494c
	struct UGameInstance* GetGameInstance(struct UObject* WorldContextObject); // Function Engine.GameplayStatics.GetGameInstance // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0xcebf64
	struct AActor* GetFirstActorOfClass(struct UObject* WorldContextObject, struct UClass* ActorClass); // Function Engine.GameplayStatics.GetFirstActorOfClass // Final|Native|Static|Public|BlueprintCallable // @ game+0x5b247bc
	struct UReverbEffect* GetCurrentReverbEffect(struct UObject* WorldContextObject); // Function Engine.GameplayStatics.GetCurrentReverbEffect // Final|Native|Static|Public|BlueprintCallable // @ game+0x5b23670
	struct FString GetCurrentLevelName(struct UObject* WorldContextObject, bool bRemovePrefixString); // Function Engine.GameplayStatics.GetCurrentLevelName // Final|Native|Static|Public|BlueprintCallable // @ game+0x5b23534
	float GetAudioTimeSeconds(struct UObject* WorldContextObject); // Function Engine.GameplayStatics.GetAudioTimeSeconds // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b21f18
	void GetAllActorsWithTag(struct UObject* WorldContextObject, struct FName Tag, struct TArray<struct AActor*> OutActors); // Function Engine.GameplayStatics.GetAllActorsWithTag // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x5b2187c
	void GetAllActorsWithInterface(struct UObject* WorldContextObject, struct UClass* Interface, struct TArray<struct AActor*> OutActors); // Function Engine.GameplayStatics.GetAllActorsWithInterface // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x5b2171c
	void GetAllActorsOfClass(struct UObject* WorldContextObject, struct UClass* ActorClass, struct TArray<struct AActor*> OutActors); // Function Engine.GameplayStatics.GetAllActorsOfClass // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0xd1b99c
	void GetActorArrayBounds(struct TArray<struct AActor*> Actors, bool bOnlyCollidingComponents, struct FVector Center, struct FVector BoxExtent); // Function Engine.GameplayStatics.GetActorArrayBounds // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b21224
	struct FVector GetActorArrayAverageLocation(struct TArray<struct AActor*> Actors); // Function Engine.GameplayStatics.GetActorArrayAverageLocation // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b21150
	void GetAccurateRealTime(struct UObject* WorldContextObject, int32 Seconds, float PartialSeconds); // Function Engine.GameplayStatics.GetAccurateRealTime // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x5b21010
	void FlushLevelStreaming(struct UObject* WorldContextObject); // Function Engine.GameplayStatics.FlushLevelStreaming // Final|Native|Static|Public|BlueprintCallable // @ game+0x5b20b78
	struct AActor* FinishSpawningActor(struct AActor* Actor, struct FTransform SpawnTransform); // Function Engine.GameplayStatics.FinishSpawningActor // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x311080
	bool FindCollisionUV(struct FHitResult Hit, int32 UVChannel, struct FVector2D UV); // Function Engine.GameplayStatics.FindCollisionUV // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b1f70c
	void EnableLiveStreaming(bool Enable); // Function Engine.GameplayStatics.EnableLiveStreaming // Final|Native|Static|Public|BlueprintCallable // @ game+0x5b1db04
	bool DoesSaveGameExist(struct FString SlotName, int32 UserIndex); // Function Engine.GameplayStatics.DoesSaveGameExist // Final|Native|Static|Public|BlueprintCallable // @ game+0x5b1b478
	bool DeprojectScreenToWorld(struct APlayerController* Player, struct FVector2D ScreenPosition, struct FVector WorldPosition, struct FVector WorldDirection); // Function Engine.GameplayStatics.DeprojectScreenToWorld // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b1aa94
	bool DeleteGameInSlot(struct FString SlotName, int32 UserIndex); // Function Engine.GameplayStatics.DeleteGameInSlot // Final|Native|Static|Public|BlueprintCallable // @ game+0x5b1a950
	void DeactivateReverbEffect(struct UObject* WorldContextObject, struct FName TagName); // Function Engine.GameplayStatics.DeactivateReverbEffect // Final|Native|Static|Public|BlueprintCallable // @ game+0x5b1a22c
	struct UAudioComponent* CreateSound2D(struct UObject* WorldContextObject, struct USoundBase* Sound, float VolumeMultiplier, float PitchMultiplier, float StartTime, struct USoundConcurrency* ConcurrencySettings, bool bPersistAcrossLevelTransition, bool bAutoDestroy); // Function Engine.GameplayStatics.CreateSound2D // Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable // @ game+0x5b197c0
	struct USaveGame* CreateSaveGameObjectFromBlueprint(struct UBlueprint* SaveGameBlueprint); // Function Engine.GameplayStatics.CreateSaveGameObjectFromBlueprint // Final|Native|Static|Public|BlueprintCallable // @ game+0x5b19730
	struct USaveGame* CreateSaveGameObject(struct UClass* SaveGameClass); // Function Engine.GameplayStatics.CreateSaveGameObject // Final|Native|Static|Public|BlueprintCallable // @ game+0x5b196a0
	struct APlayerController* CreatePlayer(struct UObject* WorldContextObject, int32 ControllerId, bool bSpawnPawn); // Function Engine.GameplayStatics.CreatePlayer // Final|Native|Static|Public|BlueprintCallable // @ game+0x5b19580
	void ClearSoundMixModifiers(struct UObject* WorldContextObject); // Function Engine.GameplayStatics.ClearSoundMixModifiers // Final|Native|Static|Public|BlueprintCallable // @ game+0x5b16ed4
	void ClearSoundMixClassOverride(struct UObject* WorldContextObject, struct USoundMix* InSoundMixModifier, struct USoundClass* InSoundClass, float FadeOutTime); // Function Engine.GameplayStatics.ClearSoundMixClassOverride // Final|Native|Static|Public|BlueprintCallable // @ game+0x5b16d6c
	void CancelAsyncLoading(); // Function Engine.GameplayStatics.CancelAsyncLoading // Final|Native|Static|Public|BlueprintCallable // @ game+0x5b13dcc
	void BreakHitResult(struct FHitResult Hit, bool bBlockingHit, bool bInitialOverlap, float Time, struct FVector Location, struct FVector ImpactPoint, struct FVector Normal, struct FVector ImpactNormal, struct UPhysicalMaterial* PhysMat, struct AActor* HitActor, struct UPrimitiveComponent* HitComponent, struct FName HitBoneName, int32 HitItem, int32 FaceIndex, struct FVector TraceStart, struct FVector TraceEnd); // Function Engine.GameplayStatics.BreakHitResult // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b12c34
	bool BlueprintSuggestProjectileVelocity(struct UObject* WorldContextObject, struct FVector TossVelocity, struct FVector StartLocation, struct FVector EndLocation, float LaunchSpeed, float OverrideGravityZ, enum class ESuggestProjVelocityTraceOption TraceOption, float CollisionRadius, bool bFavorHighArc, bool bDrawDebug); // Function Engine.GameplayStatics.BlueprintSuggestProjectileVelocity // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b0e824
	bool Blueprint_PredictProjectilePath_ByTraceChannel(struct UObject* WorldContextObject, struct FHitResult OutHit, struct TArray<struct FVector> OutPathPositions, struct FVector OutLastTraceDestination, struct FVector StartPos, struct FVector LaunchVelocity, bool bTracePath, float ProjectileRadius, enum class ECollisionChannel TraceChannel, bool bTraceComplex, struct TArray<struct AActor*> ActorsToIgnore, enum class EDrawDebugTrace DrawDebugType, float DrawDebugTime, float SimFrequency, float MaxSimTime, float OverrideGravityZ); // Function Engine.GameplayStatics.Blueprint_PredictProjectilePath_ByTraceChannel // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b0f45c
	bool Blueprint_PredictProjectilePath_ByObjectType(struct UObject* WorldContextObject, struct FHitResult OutHit, struct TArray<struct FVector> OutPathPositions, struct FVector OutLastTraceDestination, struct FVector StartPos, struct FVector LaunchVelocity, bool bTracePath, float ProjectileRadius, struct TArray<enum class EObjectTypeQuery> ObjectTypes, bool bTraceComplex, struct TArray<struct AActor*> ActorsToIgnore, enum class EDrawDebugTrace DrawDebugType, float DrawDebugTime, float SimFrequency, float MaxSimTime, float OverrideGravityZ); // Function Engine.GameplayStatics.Blueprint_PredictProjectilePath_ByObjectType // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b0edc8
	bool Blueprint_PredictProjectilePath_Advanced(struct UObject* WorldContextObject, struct FPredictProjectilePathParams PredictParams, struct FPredictProjectilePathResult PredictResult); // Function Engine.GameplayStatics.Blueprint_PredictProjectilePath_Advanced // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x5b0ebfc
	struct AActor* BeginSpawningActorFromClass(struct UObject* WorldContextObject, struct UClass* ActorClass, struct FTransform SpawnTransform, bool bNoCollisionFail, struct AActor* Owner); // Function Engine.GameplayStatics.BeginSpawningActorFromClass // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b0e5d8
	struct AActor* BeginSpawningActorFromBlueprint(struct UObject* WorldContextObject, struct UBlueprint* Blueprint, struct FTransform SpawnTransform, bool bNoCollisionFail); // Function Engine.GameplayStatics.BeginSpawningActorFromBlueprint // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b0e408
	struct AActor* BeginDeferredActorSpawnFromClass(struct UObject* WorldContextObject, struct UClass* ActorClass, struct FTransform SpawnTransform, enum class ESpawnActorCollisionHandlingMethod CollisionHandlingOverride, struct AActor* Owner); // Function Engine.GameplayStatics.BeginDeferredActorSpawnFromClass // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0xb8b7dc
	bool AreSubtitlesEnabled(); // Function Engine.GameplayStatics.AreSubtitlesEnabled // Final|Native|Static|Public|BlueprintCallable // @ game+0x5b0ce28
	bool AreAnyListenersWithinRange(struct UObject* WorldContextObject, struct FVector Location, float MaximumRange); // Function Engine.GameplayStatics.AreAnyListenersWithinRange // Final|Native|Static|Public|HasDefaults|BlueprintCallable // @ game+0x5b0ccec
	bool ApplyRadialDamageWithFalloff(struct UObject* WorldContextObject, float BaseDamage, float MinimumDamage, struct FVector Origin, float DamageInnerRadius, float DamageOuterRadius, float DamageFalloff, struct UClass* DamageTypeClass, struct TArray<struct AActor*> IgnoreActors, struct AActor* DamageCauser, struct AController* InstigatedByController, enum class ECollisionChannel DamagePreventionChannel); // Function Engine.GameplayStatics.ApplyRadialDamageWithFalloff // Final|BlueprintAuthorityOnly|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b0c6bc
	bool ApplyRadialDamage(struct UObject* WorldContextObject, float BaseDamage, struct FVector Origin, float DamageRadius, struct UClass* DamageTypeClass, struct TArray<struct AActor*> IgnoreActors, struct AActor* DamageCauser, struct AController* InstigatedByController, bool bDoFullDamage, enum class ECollisionChannel DamagePreventionChannel); // Function Engine.GameplayStatics.ApplyRadialDamage // Final|BlueprintAuthorityOnly|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b0c2fc
	float ApplyPointDamage(struct AActor* DamagedActor, float BaseDamage, struct FVector HitFromDirection, struct FHitResult HitInfo, struct AController* EventInstigator, struct AActor* DamageCauser, struct UClass* DamageTypeClass); // Function Engine.GameplayStatics.ApplyPointDamage // Final|BlueprintAuthorityOnly|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b0c048
	float ApplyDamage(struct AActor* DamagedActor, float BaseDamage, struct AController* EventInstigator, struct AActor* DamageCauser, struct UClass* DamageTypeClass); // Function Engine.GameplayStatics.ApplyDamage // Final|BlueprintAuthorityOnly|Native|Static|Public|BlueprintCallable // @ game+0x5b0bab4
	void ActivateReverbEffect(struct UObject* WorldContextObject, struct UReverbEffect* ReverbEffect, struct FName TagName, float Priority, float Volume, float FadeTime); // Function Engine.GameplayStatics.ActivateReverbEffect // Final|Native|Static|Public|BlueprintCallable // @ game+0x5b09450
};

// Class Engine.HeadMountedDisplayFunctionLibrary
// Size: 0x38 (Inherited: 0x38)
struct UHeadMountedDisplayFunctionLibrary : UBlueprintFunctionLibrary {

	void SetWorldToMetersScale(struct UObject* WorldContext, float NewScale); // Function Engine.HeadMountedDisplayFunctionLibrary.SetWorldToMetersScale // Final|Native|Static|Public|BlueprintCallable // @ game+0x5b533a4
	void SetTrackingOrigin(enum class EHMDTrackingOrigin Origin); // Function Engine.HeadMountedDisplayFunctionLibrary.SetTrackingOrigin // Final|Native|Static|Public|BlueprintCallable // @ game+0x5b51cbc
	void SetClippingPlanes(float Near, float Far); // Function Engine.HeadMountedDisplayFunctionLibrary.SetClippingPlanes // Final|Native|Static|Public|BlueprintCallable // @ game+0x5b47294
	void ResetOrientationAndPosition(float Yaw, enum class EOrientPositionSelector Options); // Function Engine.HeadMountedDisplayFunctionLibrary.ResetOrientationAndPosition // Final|Native|Static|Public|BlueprintCallable // @ game+0x5b42314
	bool IsInLowPersistenceMode(); // Function Engine.HeadMountedDisplayFunctionLibrary.IsInLowPersistenceMode // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x2d3490
	bool IsHeadMountedDisplayEnabled(); // Function Engine.HeadMountedDisplayFunctionLibrary.IsHeadMountedDisplayEnabled // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b2fba4
	bool IsHeadMountedDisplayConnected(); // Function Engine.HeadMountedDisplayFunctionLibrary.IsHeadMountedDisplayConnected // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b2fb5c
	bool HasValidTrackingPosition(); // Function Engine.HeadMountedDisplayFunctionLibrary.HasValidTrackingPosition // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b2e2dc
	float GetWorldToMetersScale(struct UObject* WorldContext); // Function Engine.HeadMountedDisplayFunctionLibrary.GetWorldToMetersScale // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b2cee0
	void GetVRFocusState(bool bUseFocus, bool bHasFocus); // Function Engine.HeadMountedDisplayFunctionLibrary.GetVRFocusState // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x5b2c3c4
	void GetTrackingSensorParameters(struct FVector Origin, struct FRotator Rotation, float LeftFOV, float RightFOV, float TopFOV, float BottomFOV, float Distance, float NearPlane, float FarPlane, bool IsActive, int32 Index); // Function Engine.HeadMountedDisplayFunctionLibrary.GetTrackingSensorParameters // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b2b0fc
	enum class EHMDTrackingOrigin GetTrackingOrigin(); // Function Engine.HeadMountedDisplayFunctionLibrary.GetTrackingOrigin // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b2b0b8
	float GetScreenPercentage(); // Function Engine.HeadMountedDisplayFunctionLibrary.GetScreenPercentage // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b29c64
	void GetPositionalTrackingCameraParameters(struct FVector CameraOrigin, struct FRotator CameraRotation, float HFOV, float VFOV, float CameraDistance, float NearPlane, float FarPlane); // Function Engine.HeadMountedDisplayFunctionLibrary.GetPositionalTrackingCameraParameters // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b28198
	void GetOrientationAndPosition(struct FRotator DeviceRotation, struct FVector DevicePosition); // Function Engine.HeadMountedDisplayFunctionLibrary.GetOrientationAndPosition // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b27754
	int32 GetNumOfTrackingSensors(); // Function Engine.HeadMountedDisplayFunctionLibrary.GetNumOfTrackingSensors // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b27620
	struct FName GetHMDDeviceName(); // Function Engine.HeadMountedDisplayFunctionLibrary.GetHMDDeviceName // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b24c1c
	void EnableLowPersistenceMode(bool bEnable); // Function Engine.HeadMountedDisplayFunctionLibrary.EnableLowPersistenceMode // Final|Native|Static|Public|BlueprintCallable // @ game+0x4d09aac
	bool EnableHMD(bool bEnable); // Function Engine.HeadMountedDisplayFunctionLibrary.EnableHMD // Final|Native|Static|Public|BlueprintCallable // @ game+0x5b1da24
};

// Class Engine.KismetArrayLibrary
// Size: 0x38 (Inherited: 0x38)
struct UKismetArrayLibrary : UBlueprintFunctionLibrary {

	void SetArrayPropertyByName(struct UObject* Object, struct FName PropertyName, struct TArray<int32> Value); // Function Engine.KismetArrayLibrary.SetArrayPropertyByName // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0xbf6e50
	void FilterArray(struct TArray<struct AActor*> TargetArray, struct UClass* FilterClass, struct TArray<struct AActor*> FilteredArray); // Function Engine.KismetArrayLibrary.FilterArray // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x5b1f0d8
	void Array_Shuffle(struct TArray<int32> TargetArray); // Function Engine.KismetArrayLibrary.Array_Shuffle // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x5b0dcf4
	void Array_Set(struct TArray<int32> TargetArray, int32 Index, int32 Item, bool bSizeToFit); // Function Engine.KismetArrayLibrary.Array_Set // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x2d4a78
	void Array_Resize(struct TArray<int32> TargetArray, int32 Size); // Function Engine.KismetArrayLibrary.Array_Resize // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x5b0db9c
	bool Array_RemoveItem(struct TArray<int32> TargetArray, int32 Item); // Function Engine.KismetArrayLibrary.Array_RemoveItem // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x5b0d970
	void Array_Remove(struct TArray<int32> TargetArray, int32 IndexToRemove); // Function Engine.KismetArrayLibrary.Array_Remove // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x5b0d818
	int32 Array_Length(struct TArray<int32> TargetArray); // Function Engine.KismetArrayLibrary.Array_Length // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0xbb61b0
	int32 Array_LastIndex(struct TArray<int32> TargetArray); // Function Engine.KismetArrayLibrary.Array_LastIndex // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x5b0d700
	bool Array_IsValidIndex(struct TArray<int32> TargetArray, int32 IndexToTest); // Function Engine.KismetArrayLibrary.Array_IsValidIndex // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x5b0d594
	void Array_Insert(struct TArray<int32> TargetArray, int32 NewItem, int32 Index); // Function Engine.KismetArrayLibrary.Array_Insert // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x5b0d2e4
	void Array_Get(struct TArray<int32> TargetArray, int32 Index, int32 Item); // Function Engine.KismetArrayLibrary.Array_Get // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0xb63c60
	int32 Array_Find(struct TArray<int32> TargetArray, int32 ItemToFind); // Function Engine.KismetArrayLibrary.Array_Find // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x5b0d0b8
	bool Array_Contains(struct TArray<int32> TargetArray, int32 ItemToFind); // Function Engine.KismetArrayLibrary.Array_Contains // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0xc63680
	void Array_Clear(struct TArray<int32> TargetArray); // Function Engine.KismetArrayLibrary.Array_Clear // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0xb732dc
	void Array_Append(struct TArray<int32> TargetArray, struct TArray<int32> SourceArray); // Function Engine.KismetArrayLibrary.Array_Append // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0xb8afe0
	int32 Array_AddUnique(struct TArray<int32> TargetArray, int32 NewItem); // Function Engine.KismetArrayLibrary.Array_AddUnique // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x5b0ce50
	int32 Array_Add(struct TArray<int32> TargetArray, int32 NewItem); // Function Engine.KismetArrayLibrary.Array_Add // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0xb8b25c
};

// Class Engine.KismetGuidLibrary
// Size: 0x38 (Inherited: 0x38)
struct UKismetGuidLibrary : UBlueprintFunctionLibrary {

	void Parse_StringToGuid(struct FString GuidString, struct FGuid OutGuid, bool SUCCESS); // Function Engine.KismetGuidLibrary.Parse_StringToGuid // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b3ce7c
	bool NotEqual_GuidGuid(struct FGuid A, struct FGuid B); // Function Engine.KismetGuidLibrary.NotEqual_GuidGuid // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b3c110
	struct FGuid NewGuid(); // Function Engine.KismetGuidLibrary.NewGuid // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b3b8cc
	bool IsValid_Guid(struct FGuid InGuid); // Function Engine.KismetGuidLibrary.IsValid_Guid // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b30738
	void Invalidate_Guid(struct FGuid InGuid); // Function Engine.KismetGuidLibrary.Invalidate_Guid // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b2f144
	bool EqualEqual_GuidGuid(struct FGuid A, struct FGuid B); // Function Engine.KismetGuidLibrary.EqualEqual_GuidGuid // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b1dc70
	struct FString Conv_GuidToString(struct FGuid InGuid); // Function Engine.KismetGuidLibrary.Conv_GuidToString // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b189a0
};

// Class Engine.KismetInputLibrary
// Size: 0x38 (Inherited: 0x38)
struct UKismetInputLibrary : UBlueprintFunctionLibrary {

	bool PointerEvent_IsTouchEvent(struct FPointerEvent Input); // Function Engine.KismetInputLibrary.PointerEvent_IsTouchEvent // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x5b3f284
	bool PointerEvent_IsMouseButtonDown(struct FPointerEvent Input, struct FKey MouseButton); // Function Engine.KismetInputLibrary.PointerEvent_IsMouseButtonDown // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x5b3f0f4
	float PointerEvent_GetWheelDelta(struct FPointerEvent Input); // Function Engine.KismetInputLibrary.PointerEvent_GetWheelDelta // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0xb55128
	int32 PointerEvent_GetUserIndex(struct FPointerEvent Input); // Function Engine.KismetInputLibrary.PointerEvent_GetUserIndex // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x5b3f008
	int32 PointerEvent_GetTouchpadIndex(struct FPointerEvent Input); // Function Engine.KismetInputLibrary.PointerEvent_GetTouchpadIndex // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x5b3ef1c
	struct FVector2D PointerEvent_GetScreenSpacePosition(struct FPointerEvent Input); // Function Engine.KismetInputLibrary.PointerEvent_GetScreenSpacePosition // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b3ee24
	int32 PointerEvent_GetPointerIndex(struct FPointerEvent Input); // Function Engine.KismetInputLibrary.PointerEvent_GetPointerIndex // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x5b3ed38
	struct FVector2D PointerEvent_GetLastScreenSpacePosition(struct FPointerEvent Input); // Function Engine.KismetInputLibrary.PointerEvent_GetLastScreenSpacePosition // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b3ec40
	struct FVector2D PointerEvent_GetGestureDelta(struct FPointerEvent Input); // Function Engine.KismetInputLibrary.PointerEvent_GetGestureDelta // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b3eb48
	struct FKey PointerEvent_GetEffectingButton(struct FPointerEvent Input); // Function Engine.KismetInputLibrary.PointerEvent_GetEffectingButton // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x5b3e9f0
	struct FVector2D PointerEvent_GetCursorDelta(struct FPointerEvent Input); // Function Engine.KismetInputLibrary.PointerEvent_GetCursorDelta // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b3e8f8
	bool Key_IsVectorAxis(struct FKey Key); // Function Engine.KismetInputLibrary.Key_IsVectorAxis // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x5b3292c
	bool Key_IsMouseButton(struct FKey Key); // Function Engine.KismetInputLibrary.Key_IsMouseButton // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x5b32848
	bool Key_IsModifierKey(struct FKey Key); // Function Engine.KismetInputLibrary.Key_IsModifierKey // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x5b32764
	bool Key_IsKeyboardKey(struct FKey Key); // Function Engine.KismetInputLibrary.Key_IsKeyboardKey // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x5b3263c
	bool Key_IsGamepadKey(struct FKey Key); // Function Engine.KismetInputLibrary.Key_IsGamepadKey // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x5b32558
	bool Key_IsFloatAxis(struct FKey Key); // Function Engine.KismetInputLibrary.Key_IsFloatAxis // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x5b32474
	struct FText Key_GetDisplayName(struct FKey Key); // Function Engine.KismetInputLibrary.Key_GetDisplayName // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x5b32348
	bool InputEvent_IsShiftDown(struct FInputEvent Input); // Function Engine.KismetInputLibrary.InputEvent_IsShiftDown // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x5b2f070
	bool InputEvent_IsRightShiftDown(struct FInputEvent Input); // Function Engine.KismetInputLibrary.InputEvent_IsRightShiftDown // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x5b2ef9c
	bool InputEvent_IsRightControlDown(struct FInputEvent Input); // Function Engine.KismetInputLibrary.InputEvent_IsRightControlDown // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x5b2eec8
	bool InputEvent_IsRightCommandDown(struct FInputEvent Input); // Function Engine.KismetInputLibrary.InputEvent_IsRightCommandDown // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x5b2edf4
	bool InputEvent_IsRightAltDown(struct FInputEvent Input); // Function Engine.KismetInputLibrary.InputEvent_IsRightAltDown // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x5b2ed20
	bool InputEvent_IsRepeat(struct FInputEvent Input); // Function Engine.KismetInputLibrary.InputEvent_IsRepeat // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x5b2ec54
	bool InputEvent_IsLeftShiftDown(struct FInputEvent Input); // Function Engine.KismetInputLibrary.InputEvent_IsLeftShiftDown // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x5b2eb84
	bool InputEvent_IsLeftControlDown(struct FInputEvent Input); // Function Engine.KismetInputLibrary.InputEvent_IsLeftControlDown // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x5b2eab0
	bool InputEvent_IsLeftCommandDown(struct FInputEvent Input); // Function Engine.KismetInputLibrary.InputEvent_IsLeftCommandDown // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x5b2e9dc
	bool InputEvent_IsLeftAltDown(struct FInputEvent Input); // Function Engine.KismetInputLibrary.InputEvent_IsLeftAltDown // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x5b2e908
	bool InputEvent_IsControlDown(struct FInputEvent Input); // Function Engine.KismetInputLibrary.InputEvent_IsControlDown // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x5b2e834
	bool InputEvent_IsCommandDown(struct FInputEvent Input); // Function Engine.KismetInputLibrary.InputEvent_IsCommandDown // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x5b2e760
	bool InputEvent_IsAltDown(struct FInputEvent Input); // Function Engine.KismetInputLibrary.InputEvent_IsAltDown // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x5b2e68c
	int32 GetUserIndex(struct FKeyEvent Input); // Function Engine.KismetInputLibrary.GetUserIndex // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x5b2c2a8
	struct FKey GetKey(struct FKeyEvent Input); // Function Engine.KismetInputLibrary.GetKey // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x5b26374
	float GetAnalogValue(struct FAnalogInputEvent Input); // Function Engine.KismetInputLibrary.GetAnalogValue // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x5b219c8
	bool EqualEqual_KeyKey(struct FKey A, struct FKey B); // Function Engine.KismetInputLibrary.EqualEqual_KeyKey // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b1e014
	bool EqualEqual_InputChordInputChord(struct FInputChord A, struct FInputChord B); // Function Engine.KismetInputLibrary.EqualEqual_InputChordInputChord // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b1dda0
	int32 ControllerEvent_GetUserIndex(struct FControllerEvent Input); // Function Engine.KismetInputLibrary.ControllerEvent_GetUserIndex // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x5b180ec
	struct FKey ControllerEvent_GetEffectingButton(struct FControllerEvent Input); // Function Engine.KismetInputLibrary.ControllerEvent_GetEffectingButton // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x5b17f94
	float ControllerEvent_GetAnalogValue(struct FControllerEvent Input); // Function Engine.KismetInputLibrary.ControllerEvent_GetAnalogValue // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x5b17eb4
	void CalibrateTilt(); // Function Engine.KismetInputLibrary.CalibrateTilt // Final|Native|Static|Public|BlueprintCallable // @ game+0x5b13ce0
};

// Class Engine.KismetMaterialLibrary
// Size: 0x38 (Inherited: 0x38)
struct UKismetMaterialLibrary : UBlueprintFunctionLibrary {

	void SetVectorParameterValue(struct UObject* WorldContextObject, struct UMaterialParameterCollection* Collection, struct FName ParameterName, struct FLinearColor ParameterValue); // Function Engine.KismetMaterialLibrary.SetVectorParameterValue // Final|RequiredAPI|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x759d9c
	void SetScalarParameterValue(struct UObject* WorldContextObject, struct UMaterialParameterCollection* Collection, struct FName ParameterName, float ParameterValue); // Function Engine.KismetMaterialLibrary.SetScalarParameterValue // Final|RequiredAPI|Native|Static|Public|BlueprintCallable // @ game+0xaf04b4
	struct FLinearColor GetVectorParameterValue(struct UObject* WorldContextObject, struct UMaterialParameterCollection* Collection, struct FName ParameterName); // Function Engine.KismetMaterialLibrary.GetVectorParameterValue // Final|RequiredAPI|Native|Static|Public|HasDefaults|BlueprintCallable // @ game+0x5b2c630
	float GetScalarParameterValue(struct UObject* WorldContextObject, struct UMaterialParameterCollection* Collection, struct FName ParameterName); // Function Engine.KismetMaterialLibrary.GetScalarParameterValue // Final|RequiredAPI|Native|Static|Public|BlueprintCallable // @ game+0xb122dc
	struct UMaterialInstanceDynamic* CreateDynamicMaterialInstance(struct UObject* WorldContextObject, struct UMaterialInterface* Parent); // Function Engine.KismetMaterialLibrary.CreateDynamicMaterialInstance // Final|RequiredAPI|Native|Static|Public|BlueprintCallable // @ game+0xe008c8
};

// Class Engine.KismetMathLibrary
// Size: 0x38 (Inherited: 0x38)
struct UKismetMathLibrary : UBlueprintFunctionLibrary {

	int32 Xor_IntInt(int32 A, int32 B); // Function Engine.KismetMathLibrary.Xor_IntInt // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b5ce2c
	float VSizeSquared(struct FVector A); // Function Engine.KismetMathLibrary.VSizeSquared // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b5c79c
	float VSize2DSquared(struct FVector2D A); // Function Engine.KismetMathLibrary.VSize2DSquared // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b5c650
	float VSize2D(struct FVector2D A); // Function Engine.KismetMathLibrary.VSize2D // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b5c5b0
	float VSize(struct FVector A); // Function Engine.KismetMathLibrary.VSize // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b5c6ec
	struct FVector VLerp(struct FVector A, struct FVector B, float ALPHA); // Function Engine.KismetMathLibrary.VLerp // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0xd13b70
	struct FVector VInterpTo_Constant(struct FVector Current, struct FVector Target, float DeltaTime, float InterpSpeed); // Function Engine.KismetMathLibrary.VInterpTo_Constant // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b5c400
	struct FVector VInterpTo(struct FVector Current, struct FVector Target, float DeltaTime, float InterpSpeed); // Function Engine.KismetMathLibrary.VInterpTo // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0xd4fa6c
	struct FVector VectorSpringInterp(struct FVector Current, struct FVector Target, struct FVectorSpringState SpringState, float Stiffness, float CriticalDampingFactor, float DeltaTime, float Mass); // Function Engine.KismetMathLibrary.VectorSpringInterp // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b5cb54
	struct FVector2D Vector2DInterpTo_Constant(struct FVector2D Current, struct FVector2D Target, float DeltaTime, float InterpSpeed); // Function Engine.KismetMathLibrary.Vector2DInterpTo_Constant // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b5c9cc
	struct FVector2D Vector2DInterpTo(struct FVector2D Current, struct FVector2D Target, float DeltaTime, float InterpSpeed); // Function Engine.KismetMathLibrary.Vector2DInterpTo // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b5c844
	struct FVector VEase(struct FVector A, struct FVector B, float ALPHA, enum class EEasingFunc EasingFunc, float BlendExp, int32 Steps); // Function Engine.KismetMathLibrary.VEase // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b5c1bc
	struct FDateTime UtcNow(); // Function Engine.KismetMathLibrary.UtcNow // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b5c18c
	struct FVector TransformLocation(struct FTransform T, struct FVector Location); // Function Engine.KismetMathLibrary.TransformLocation // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b5b8a8
	struct FVector TransformDirection(struct FTransform T, struct FVector Direction); // Function Engine.KismetMathLibrary.TransformDirection // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b5b4dc
	struct FDateTime Today(); // Function Engine.KismetMathLibrary.Today // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b5b498
	struct FTransform TLerp(struct FTransform A, struct FTransform B, float ALPHA, enum class ELerpInterpolationMode InterpMode); // Function Engine.KismetMathLibrary.TLerp // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b5af24
	struct FTransform TInterpTo(struct FTransform Current, struct FTransform Target, float DeltaTime, float InterpSpeed); // Function Engine.KismetMathLibrary.TInterpTo // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b5ace4
	struct FTimespan TimespanZeroValue(); // Function Engine.KismetMathLibrary.TimespanZeroValue // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x4d60a28
	float TimespanRatio(struct FTimespan A, struct FTimespan B); // Function Engine.KismetMathLibrary.TimespanRatio // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b5b3b4
	struct FTimespan TimespanMinValue(); // Function Engine.KismetMathLibrary.TimespanMinValue // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b5b398
	struct FTimespan TimespanMaxValue(); // Function Engine.KismetMathLibrary.TimespanMaxValue // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b5b37c
	bool TimespanFromString(struct FString TimespanString, struct FTimespan Result); // Function Engine.KismetMathLibrary.TimespanFromString // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b5b208
	struct FTransform TEase(struct FTransform A, struct FTransform B, float ALPHA, enum class EEasingFunc EasingFunc, float BlendExp, int32 Steps); // Function Engine.KismetMathLibrary.TEase // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b5a9f8
	float Tan(float A); // Function Engine.KismetMathLibrary.Tan // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b5b170
	struct FVector Subtract_VectorVector(struct FVector A, struct FVector B); // Function Engine.KismetMathLibrary.Subtract_VectorVector // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b5a668
	struct FVector Subtract_VectorInt(struct FVector A, int32 B); // Function Engine.KismetMathLibrary.Subtract_VectorInt // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b5a558
	struct FVector Subtract_VectorFloat(struct FVector A, float B); // Function Engine.KismetMathLibrary.Subtract_VectorFloat // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b5a448
	struct FVector2D Subtract_Vector2DVector2D(struct FVector2D A, struct FVector2D B); // Function Engine.KismetMathLibrary.Subtract_Vector2DVector2D // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b5a36c
	struct FVector2D Subtract_Vector2DFloat(struct FVector2D A, float B); // Function Engine.KismetMathLibrary.Subtract_Vector2DFloat // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b5a284
	struct FTimespan Subtract_TimespanTimespan(struct FTimespan A, struct FTimespan B); // Function Engine.KismetMathLibrary.Subtract_TimespanTimespan // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b5a1b8
	int32 Subtract_IntInt(int32 A, int32 B); // Function Engine.KismetMathLibrary.Subtract_IntInt // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0xd2ae94
	float Subtract_FloatFloat(float A, float B); // Function Engine.KismetMathLibrary.Subtract_FloatFloat // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x2d6520
	struct FDateTime Subtract_DateTimeTimespan(struct FDateTime A, struct FTimespan B); // Function Engine.KismetMathLibrary.Subtract_DateTimeTimespan // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b5a1b8
	struct FTimespan Subtract_DateTimeDateTime(struct FDateTime A, struct FDateTime B); // Function Engine.KismetMathLibrary.Subtract_DateTimeDateTime // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b5a1b8
	bool Subtract_ByteByte(bool A, bool B); // Function Engine.KismetMathLibrary.Subtract_ByteByte // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b5a0e4
	float Square(float A); // Function Engine.KismetMathLibrary.Square // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b59ee0
	float Sqrt(float A); // Function Engine.KismetMathLibrary.Sqrt // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b59e34
	float Sin(float A); // Function Engine.KismetMathLibrary.Sin // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b55078
	int32 SignOfInteger(int32 A); // Function Engine.KismetMathLibrary.SignOfInteger // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b54fe0
	float SignOfFloat(float A); // Function Engine.KismetMathLibrary.SignOfFloat // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b54f2c
	void SetRandomStreamSeed(struct FRandomStream Stream, int32 NewSeed); // Function Engine.KismetMathLibrary.SetRandomStreamSeed // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b4f0c8
	struct FVector SelectVector(struct FVector A, struct FVector B, bool bPickA); // Function Engine.KismetMathLibrary.SelectVector // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b43408
	struct FTransform SelectTransform(struct FTransform A, struct FTransform B, bool bPickA); // Function Engine.KismetMathLibrary.SelectTransform // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b4375c
	struct FString SelectString(struct FString A, struct FString B, bool bPickA); // Function Engine.KismetMathLibrary.SelectString // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b43560
	struct FRotator SelectRotator(struct FRotator A, struct FRotator B, bool bPickA); // Function Engine.KismetMathLibrary.SelectRotator // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b43408
	struct UObject* SelectObject(struct UObject* A, struct UObject* B, bool bSelectA); // Function Engine.KismetMathLibrary.SelectObject // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b431a0
	int32 SelectInt(int32 A, int32 B, bool bPickA); // Function Engine.KismetMathLibrary.SelectInt // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0xbedc4c
	float SelectFloat(float A, float B, bool bPickA); // Function Engine.KismetMathLibrary.SelectFloat // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x2d3afc
	struct FLinearColor SelectColor(struct FLinearColor A, struct FLinearColor B, bool bPickA); // Function Engine.KismetMathLibrary.SelectColor // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b432c4
	struct UClass* SelectClass(struct UClass* A, struct UClass* B, bool bSelectA); // Function Engine.KismetMathLibrary.SelectClass // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b431a0
	void SeedRandomStream(struct FRandomStream Stream); // Function Engine.KismetMathLibrary.SeedRandomStream // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b43104
	int32 Round(float A); // Function Engine.KismetMathLibrary.Round // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b42840
	struct FRotator RotatorFromAxisAndAngle(struct FVector Axis, float Angle); // Function Engine.KismetMathLibrary.RotatorFromAxisAndAngle // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b4273c
	struct FVector RotateAngleAxis(struct FVector InVect, float AngleDeg, struct FVector Axis); // Function Engine.KismetMathLibrary.RotateAngleAxis // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b425e0
	struct FRotator RLerp(struct FRotator A, struct FRotator B, float ALPHA, bool bShortestPath); // Function Engine.KismetMathLibrary.RLerp // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0xcf45f4
	struct FRotator RInterpTo_Constant(struct FRotator Current, struct FRotator Target, float DeltaTime, float InterpSpeed); // Function Engine.KismetMathLibrary.RInterpTo_Constant // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b40710
	struct FRotator RInterpTo(struct FRotator Current, struct FRotator Target, float DeltaTime, float InterpSpeed); // Function Engine.KismetMathLibrary.RInterpTo // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b40560
	void RGBToHSV_Vector(struct FLinearColor RGB, struct FLinearColor HSV); // Function Engine.KismetMathLibrary.RGBToHSV_Vector // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b4046c
	void RGBToHSV(struct FLinearColor InColor, float H, float S, float V, float A); // Function Engine.KismetMathLibrary.RGBToHSV // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b40244
	void ResetVectorSpringState(struct FVectorSpringState SpringState); // Function Engine.KismetMathLibrary.ResetVectorSpringState // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x5b4247c
	void ResetRandomStream(struct FRandomStream Stream); // Function Engine.KismetMathLibrary.ResetRandomStream // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b423f0
	void ResetFloatSpringState(struct FFloatSpringState SpringState); // Function Engine.KismetMathLibrary.ResetFloatSpringState // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x5b42288
	struct FRotator REase(struct FRotator A, struct FRotator B, float ALPHA, bool bShortestPath, enum class EEasingFunc EasingFunc, float BlendExp, int32 Steps); // Function Engine.KismetMathLibrary.REase // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b3ff9c
	struct FVector RandomUnitVectorInConeWithYawAndPitch(struct FVector ConeDir, float MaxYawInDegrees, float MaxPitchInDegrees); // Function Engine.KismetMathLibrary.RandomUnitVectorInConeWithYawAndPitch // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b416c4
	struct FVector RandomUnitVectorInCone(struct FVector ConeDir, float ConeHalfAngle); // Function Engine.KismetMathLibrary.RandomUnitVectorInCone // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b415c0
	struct FVector RandomUnitVectorFromStream(struct FRandomStream Stream); // Function Engine.KismetMathLibrary.RandomUnitVectorFromStream // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b41510
	struct FVector RandomUnitVector(); // Function Engine.KismetMathLibrary.RandomUnitVector // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b414d8
	struct FRotator RandomRotatorFromStream(bool bRoll, struct FRandomStream Stream); // Function Engine.KismetMathLibrary.RandomRotatorFromStream // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b413d0
	struct FRotator RandomRotator(bool bRoll); // Function Engine.KismetMathLibrary.RandomRotator // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b412dc
	struct FVector RandomPointInBoundingBox(struct FVector Origin, struct FVector BoxExtent); // Function Engine.KismetMathLibrary.RandomPointInBoundingBox // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b411c4
	int32 RandomIntegerInRangeFromStream(int32 Min, int32 Max, struct FRandomStream Stream); // Function Engine.KismetMathLibrary.RandomIntegerInRangeFromStream // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b4104c
	int32 RandomIntegerInRange(int32 Min, int32 Max); // Function Engine.KismetMathLibrary.RandomIntegerInRange // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0xbf601c
	int32 RandomIntegerFromStream(int32 Max, struct FRandomStream Stream); // Function Engine.KismetMathLibrary.RandomIntegerFromStream // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b40f1c
	int32 RandomInteger(int32 Max); // Function Engine.KismetMathLibrary.RandomInteger // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b40e68
	float RandomFloatInRangeFromStream(float Min, float Max, struct FRandomStream Stream); // Function Engine.KismetMathLibrary.RandomFloatInRangeFromStream // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b40d04
	float RandomFloatInRange(float Min, float Max); // Function Engine.KismetMathLibrary.RandomFloatInRange // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0xba1eac
	float RandomFloatFromStream(struct FRandomStream Stream); // Function Engine.KismetMathLibrary.RandomFloatFromStream // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b40c38
	float RandomFloat(); // Function Engine.KismetMathLibrary.RandomFloat // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b40c00
	bool RandomBoolWithWeightFromStream(float weight, struct FRandomStream RandomStream); // Function Engine.KismetMathLibrary.RandomBoolWithWeightFromStream // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b40b14
	bool RandomBoolWithWeight(float weight); // Function Engine.KismetMathLibrary.RandomBoolWithWeight // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b40a80
	bool RandomBoolFromStream(struct FRandomStream Stream); // Function Engine.KismetMathLibrary.RandomBoolFromStream // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b409a4
	bool RandomBool(); // Function Engine.KismetMathLibrary.RandomBool // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b40958
	float RadiansToDegrees(float A); // Function Engine.KismetMathLibrary.RadiansToDegrees // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b408c0
	struct FVector ProjectVectorOnToVector(struct FVector V, struct FVector Target); // Function Engine.KismetMathLibrary.ProjectVectorOnToVector // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b3fab8
	struct FVector ProjectVectorOnToPlane(struct FVector V, struct FVector PlaneNormal); // Function Engine.KismetMathLibrary.ProjectVectorOnToPlane // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b3f9a0
	struct FVector ProjectPointOnToPlane(struct FVector Point, struct FVector PlaneBase, struct FVector PlaneNormal); // Function Engine.KismetMathLibrary.ProjectPointOnToPlane // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b3f830
	bool PointsAreCoplanar(struct TArray<struct FVector> Points, float Tolerance); // Function Engine.KismetMathLibrary.PointsAreCoplanar // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x5b3f370
	int32 Percent_IntInt(int32 A, int32 B); // Function Engine.KismetMathLibrary.Percent_IntInt // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b3d29c
	float Percent_FloatFloat(float A, float B); // Function Engine.KismetMathLibrary.Percent_FloatFloat // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b3d0f0
	bool Percent_ByteByte(bool A, bool B); // Function Engine.KismetMathLibrary.Percent_ByteByte // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b3d004
	int32 Or_IntInt(int32 A, int32 B); // Function Engine.KismetMathLibrary.Or_IntInt // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b3ca14
	struct FDateTime Now(); // Function Engine.KismetMathLibrary.Now // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b3c724
	bool NotEqual_VectorVector(struct FVector A, struct FVector B, float ErrorTolerance); // Function Engine.KismetMathLibrary.NotEqual_VectorVector // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b3c53c
	bool NotEqual_Vector2DVector2D(struct FVector2D A, struct FVector2D B, float ErrorTolerance); // Function Engine.KismetMathLibrary.NotEqual_Vector2DVector2D // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b3c400
	bool NotEqual_TimespanTimespan(struct FTimespan A, struct FTimespan B); // Function Engine.KismetMathLibrary.NotEqual_TimespanTimespan // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b3c044
	bool NotEqual_RotatorRotator(struct FRotator A, struct FRotator B, float ErrorTolerance); // Function Engine.KismetMathLibrary.NotEqual_RotatorRotator // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b3c240
	bool NotEqual_ObjectObject(struct UObject* A, struct UObject* B); // Function Engine.KismetMathLibrary.NotEqual_ObjectObject // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5410724
	bool NotEqual_NameName(struct FName A, struct FName B); // Function Engine.KismetMathLibrary.NotEqual_NameName // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0xb672b0
	bool NotEqual_IntInt(int32 A, int32 B); // Function Engine.KismetMathLibrary.NotEqual_IntInt // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0xc18920
	bool NotEqual_FloatFloat(float A, float B); // Function Engine.KismetMathLibrary.NotEqual_FloatFloat // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0xb3c29c
	bool NotEqual_DateTimeDateTime(struct FDateTime A, struct FDateTime B); // Function Engine.KismetMathLibrary.NotEqual_DateTimeDateTime // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b3c044
	bool NotEqual_ClassClass(struct UClass* A, struct UClass* B); // Function Engine.KismetMathLibrary.NotEqual_ClassClass // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5410724
	bool NotEqual_ByteByte(bool A, bool B); // Function Engine.KismetMathLibrary.NotEqual_ByteByte // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x2d3174
	bool NotEqual_BoolBool(bool A, bool B); // Function Engine.KismetMathLibrary.NotEqual_BoolBool // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b3bf5c
	bool Not_PreBool(bool A); // Function Engine.KismetMathLibrary.Not_PreBool // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x2d4870
	int32 Not_Int(int32 A); // Function Engine.KismetMathLibrary.Not_Int // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b3c69c
	float NormalizeToRange(float Value, float RangeMin, float RangeMax); // Function Engine.KismetMathLibrary.NormalizeToRange // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b3bcc8
	struct FRotator NormalizedDeltaRotator(struct FRotator A, struct FRotator B); // Function Engine.KismetMathLibrary.NormalizedDeltaRotator // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b3bde8
	float NormalizeAxis(float Angle); // Function Engine.KismetMathLibrary.NormalizeAxis // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b3bbe0
	struct FVector2D Normal2D(struct FVector2D A); // Function Engine.KismetMathLibrary.Normal2D // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b3b8fc
	struct FVector Normal(struct FVector A); // Function Engine.KismetMathLibrary.Normal // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b3ba40
	struct FVector NegateVector(struct FVector A); // Function Engine.KismetMathLibrary.NegateVector // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b3b814
	struct FRotator NegateRotator(struct FRotator A); // Function Engine.KismetMathLibrary.NegateRotator // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b3b760
	bool NearlyEqual_TransformTransform(struct FTransform A, struct FTransform B, float LocationTolerance, float RotationTolerance, float Scale3DTolerance); // Function Engine.KismetMathLibrary.NearlyEqual_TransformTransform // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b3b4f8
	bool NearlyEqual_FloatFloat(float A, float B, float ErrorTolerance); // Function Engine.KismetMathLibrary.NearlyEqual_FloatFloat // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0xb59cc8
	float MultiplyMultiply_FloatFloat(float Base, float Exp); // Function Engine.KismetMathLibrary.MultiplyMultiply_FloatFloat // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b3a9c4
	float MultiplyByPi(float Value); // Function Engine.KismetMathLibrary.MultiplyByPi // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b3a92c
	struct FVector Multiply_VectorVector(struct FVector A, struct FVector B); // Function Engine.KismetMathLibrary.Multiply_VectorVector // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b3b3f0
	struct FVector Multiply_VectorInt(struct FVector A, int32 B); // Function Engine.KismetMathLibrary.Multiply_VectorInt // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b3b03c
	struct FVector Multiply_VectorFloat(struct FVector A, float B); // Function Engine.KismetMathLibrary.Multiply_VectorFloat // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x2d3730
	struct FVector2D Multiply_Vector2DVector2D(struct FVector2D A, struct FVector2D B); // Function Engine.KismetMathLibrary.Multiply_Vector2DVector2D // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b3b314
	struct FVector2D Multiply_Vector2DFloat(struct FVector2D A, float B); // Function Engine.KismetMathLibrary.Multiply_Vector2DFloat // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b3b22c
	struct FTimespan Multiply_TimespanFloat(struct FTimespan A, float Scalar); // Function Engine.KismetMathLibrary.Multiply_TimespanFloat // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b3b14c
	struct FRotator Multiply_RotatorInt(struct FRotator A, int32 B); // Function Engine.KismetMathLibrary.Multiply_RotatorInt // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b3b03c
	struct FRotator Multiply_RotatorFloat(struct FRotator A, float B); // Function Engine.KismetMathLibrary.Multiply_RotatorFloat // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b3af2c
	struct FLinearColor Multiply_LinearColorLinearColor(struct FLinearColor A, struct FLinearColor B); // Function Engine.KismetMathLibrary.Multiply_LinearColorLinearColor // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b3ae10
	struct FLinearColor Multiply_LinearColorFloat(struct FLinearColor A, float B); // Function Engine.KismetMathLibrary.Multiply_LinearColorFloat // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b3ad28
	int32 Multiply_IntInt(int32 A, int32 B); // Function Engine.KismetMathLibrary.Multiply_IntInt // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b3ac58
	float Multiply_IntFloat(int32 A, float B); // Function Engine.KismetMathLibrary.Multiply_IntFloat // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b3ab78
	float Multiply_FloatFloat(float A, float B); // Function Engine.KismetMathLibrary.Multiply_FloatFloat // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x2d3e10
	bool Multiply_ByteByte(bool A, bool B); // Function Engine.KismetMathLibrary.Multiply_ByteByte // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b3aaa0
	struct FVector MirrorVectorByNormal(struct FVector InVect, struct FVector InNormal); // Function Engine.KismetMathLibrary.MirrorVectorByNormal // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b2855c
	void MinOfIntArray(struct TArray<int32> IntArray, int32 IndexOfMinValue, int32 MinValue); // Function Engine.KismetMathLibrary.MinOfIntArray // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x5b39948
	void MinOfFloatArray(struct TArray<float> FloatArray, int32 IndexOfMinValue, float MinValue); // Function Engine.KismetMathLibrary.MinOfFloatArray // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x5b39764
	void MinOfByteArray(struct TArray<bool> ByteArray, int32 IndexOfMinValue, bool MinValue); // Function Engine.KismetMathLibrary.MinOfByteArray // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x5b39598
	void MinimumAreaRectangle(struct UObject* WorldContextObject, struct TArray<struct FVector> InVerts, struct FVector SampleSurfaceNormal, struct FVector OutRectCenter, struct FRotator OutRectRotation, float OutSideLengthX, float OutSideLengthY, bool bDebugDraw); // Function Engine.KismetMathLibrary.MinimumAreaRectangle // Final|BlueprintAuthorityOnly|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b39b14
	int32 Min(int32 A, int32 B); // Function Engine.KismetMathLibrary.Min // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b394c4
	void MaxOfIntArray(struct TArray<int32> IntArray, int32 IndexOfMaxValue, int32 MaxValue); // Function Engine.KismetMathLibrary.MaxOfIntArray // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x5b392f8
	void MaxOfFloatArray(struct TArray<float> FloatArray, int32 IndexOfMaxValue, float MaxValue); // Function Engine.KismetMathLibrary.MaxOfFloatArray // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x5b39114
	void MaxOfByteArray(struct TArray<bool> ByteArray, int32 IndexOfMaxValue, bool MaxValue); // Function Engine.KismetMathLibrary.MaxOfByteArray // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x5b38f48
	int32 Max(int32 A, int32 B); // Function Engine.KismetMathLibrary.Max // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b38e74
	float MapRangeUnclamped(float Value, float InRangeA, float InRangeB, float OutRangeA, float OutRangeB); // Function Engine.KismetMathLibrary.MapRangeUnclamped // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b37c48
	float MapRangeClamped(float Value, float InRangeA, float InRangeB, float OutRangeA, float OutRangeB); // Function Engine.KismetMathLibrary.MapRangeClamped // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x2d3bd0
	struct FVector2D MakeVector2D(float X, float Y); // Function Engine.KismetMathLibrary.MakeVector2D // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0xa86ba4
	struct FVector MakeVector(float X, float Y, float Z); // Function Engine.KismetMathLibrary.MakeVector // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x2d3a14
	struct FTransform MakeTransform(struct FVector Location, struct FRotator Rotation, struct FVector Scale); // Function Engine.KismetMathLibrary.MakeTransform // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0xb97a08
	struct FTimespan MakeTimespan(int32 Days, int32 Hours, int32 Minutes, int32 Seconds, int32 Milliseconds); // Function Engine.KismetMathLibrary.MakeTimespan // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b37a74
	struct FRotator MakeRotFromZY(struct FVector Z, struct FVector Y); // Function Engine.KismetMathLibrary.MakeRotFromZY // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b376e4
	struct FRotator MakeRotFromZX(struct FVector Z, struct FVector X); // Function Engine.KismetMathLibrary.MakeRotFromZX // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b375b4
	struct FRotator MakeRotFromZ(struct FVector Z); // Function Engine.KismetMathLibrary.MakeRotFromZ // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b374f4
	struct FRotator MakeRotFromYZ(struct FVector Y, struct FVector Z); // Function Engine.KismetMathLibrary.MakeRotFromYZ // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b373c4
	struct FRotator MakeRotFromYX(struct FVector Y, struct FVector X); // Function Engine.KismetMathLibrary.MakeRotFromYX // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b37294
	struct FRotator MakeRotFromY(struct FVector Y); // Function Engine.KismetMathLibrary.MakeRotFromY // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b371d4
	struct FRotator MakeRotFromXZ(struct FVector X, struct FVector Z); // Function Engine.KismetMathLibrary.MakeRotFromXZ // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b370a4
	struct FRotator MakeRotFromXY(struct FVector X, struct FVector Y); // Function Engine.KismetMathLibrary.MakeRotFromXY // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b36f74
	struct FRotator MakeRotFromX(struct FVector X); // Function Engine.KismetMathLibrary.MakeRotFromX // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b36eb4
	struct FRotator MakeRotator(float Roll, float Pitch, float Yaw); // Function Engine.KismetMathLibrary.MakeRotator // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x2d2db4
	struct FRotator MakeRotationFromAxes(struct FVector Forward, struct FVector Right, struct FVector Up); // Function Engine.KismetMathLibrary.MakeRotationFromAxes // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b37814
	struct FRandomStream MakeRandomStream(int32 InitialSeed); // Function Engine.KismetMathLibrary.MakeRandomStream // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b36e1c
	float MakePulsatingValue(float InCurrentTime, float InPulsesPerSecond, float InPhase); // Function Engine.KismetMathLibrary.MakePulsatingValue // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b36cc8
	struct FPlane MakePlaneFromPointAndNormal(struct FVector Point, struct FVector Normal); // Function Engine.KismetMathLibrary.MakePlaneFromPointAndNormal // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b36bb8
	struct FDateTime MakeDateTime(int32 Year, int32 Month, int32 Day, int32 Hour, int32 Minute, int32 second, int32 Millisecond); // Function Engine.KismetMathLibrary.MakeDateTime // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b35ed8
	struct FLinearColor MakeColor(float R, float G, float B, float A); // Function Engine.KismetMathLibrary.MakeColor // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0xad7754
	struct FBox2D MakeBox2D(struct FVector2D Min, struct FVector2D Max); // Function Engine.KismetMathLibrary.MakeBox2D // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b35cd0
	struct FBox MakeBox(struct FVector Min, struct FVector Max); // Function Engine.KismetMathLibrary.MakeBox // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b35dc8
	float Loge(float A); // Function Engine.KismetMathLibrary.Loge // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b35c38
	float Log(float A, float Base); // Function Engine.KismetMathLibrary.Log // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b35b5c
	bool LinePlaneIntersection_OriginNormal(struct FVector LineStart, struct FVector LineEnd, struct FVector PlaneOrigin, struct FVector PlaneNormal, float T, struct FVector Intersection); // Function Engine.KismetMathLibrary.LinePlaneIntersection_OriginNormal // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b3313c
	bool LinePlaneIntersection(struct FVector LineStart, struct FVector LineEnd, struct FPlane APlane, float T, struct FVector Intersection); // Function Engine.KismetMathLibrary.LinePlaneIntersection // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b32f18
	struct FLinearColor LinearColorLerpUsingHSV(struct FLinearColor A, struct FLinearColor B, float ALPHA); // Function Engine.KismetMathLibrary.LinearColorLerpUsingHSV // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b35154
	struct FLinearColor LinearColorLerp(struct FLinearColor A, struct FLinearColor B, float ALPHA); // Function Engine.KismetMathLibrary.LinearColorLerp // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b34fd0
	struct FVector LessLess_VectorRotator(struct FVector A, struct FRotator B); // Function Engine.KismetMathLibrary.LessLess_VectorRotator // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b32c60
	bool LessEqual_TimespanTimespan(struct FTimespan A, struct FTimespan B); // Function Engine.KismetMathLibrary.LessEqual_TimespanTimespan // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b32b94
	bool LessEqual_IntInt(int32 A, int32 B); // Function Engine.KismetMathLibrary.LessEqual_IntInt // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0xc86f88
	bool LessEqual_FloatFloat(float A, float B); // Function Engine.KismetMathLibrary.LessEqual_FloatFloat // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0xa9ed58
	bool LessEqual_DateTimeDateTime(struct FDateTime A, struct FDateTime B); // Function Engine.KismetMathLibrary.LessEqual_DateTimeDateTime // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b32b94
	bool LessEqual_ByteByte(bool A, bool B); // Function Engine.KismetMathLibrary.LessEqual_ByteByte // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b32ac0
	bool Less_TimespanTimespan(struct FTimespan A, struct FTimespan B); // Function Engine.KismetMathLibrary.Less_TimespanTimespan // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b32e4c
	bool Less_IntInt(int32 A, int32 B); // Function Engine.KismetMathLibrary.Less_IntInt // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0xa79460
	bool Less_FloatFloat(float A, float B); // Function Engine.KismetMathLibrary.Less_FloatFloat // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0xad119c
	bool Less_DateTimeDateTime(struct FDateTime A, struct FDateTime B); // Function Engine.KismetMathLibrary.Less_DateTimeDateTime // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b32e4c
	bool Less_ByteByte(bool A, bool B); // Function Engine.KismetMathLibrary.Less_ByteByte // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b32d78
	float Lerp(float A, float B, float ALPHA); // Function Engine.KismetMathLibrary.Lerp // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0xd2f7a0
	bool IsPointInBoxWithTransform(struct FVector Point, struct FTransform BoxWorldTransform, struct FVector BoxExtent); // Function Engine.KismetMathLibrary.IsPointInBoxWithTransform // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b30194
	bool IsPointInBox(struct FVector Point, struct FVector BoxOrigin, struct FVector BoxExtent); // Function Engine.KismetMathLibrary.IsPointInBox // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b30004
	bool IsMorning(struct FDateTime A); // Function Engine.KismetMathLibrary.IsMorning // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b2fe10
	bool IsLeapYear(int32 Year); // Function Engine.KismetMathLibrary.IsLeapYear // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b2fcd8
	bool IsAfternoon(struct FDateTime A); // Function Engine.KismetMathLibrary.IsAfternoon // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b2f72c
	struct FTransform InvertTransform(struct FTransform T); // Function Engine.KismetMathLibrary.InvertTransform // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b2f538
	struct FVector InverseTransformLocation(struct FTransform T, struct FVector Location); // Function Engine.KismetMathLibrary.InverseTransformLocation // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b2f2fc
	struct FVector InverseTransformDirection(struct FTransform T, struct FVector Direction); // Function Engine.KismetMathLibrary.InverseTransformDirection // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0xbc4298
	float InverseLerp(float A, float B, float Value); // Function Engine.KismetMathLibrary.InverseLerp // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b2f1dc
	bool InRange_FloatFloat(float Value, float Min, float Max, bool InclusiveMin, bool InclusiveMax); // Function Engine.KismetMathLibrary.InRange_FloatFloat // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0xc19944
	float Hypotenuse(float Width, float Height); // Function Engine.KismetMathLibrary.Hypotenuse // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b2e580
	void HSVToRGB_Vector(struct FLinearColor HSV, struct FLinearColor RGB); // Function Engine.KismetMathLibrary.HSVToRGB_Vector // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b2dcec
	struct FLinearColor HSVToRGB(float H, float S, float V, float A); // Function Engine.KismetMathLibrary.HSVToRGB // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b2db60
	float GridSnap_Float(float Location, float GridSize); // Function Engine.KismetMathLibrary.GridSnap_Float // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b2da4c
	struct FVector GreaterGreater_VectorRotator(struct FVector A, struct FRotator B); // Function Engine.KismetMathLibrary.GreaterGreater_VectorRotator // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b2d794
	bool GreaterEqual_TimespanTimespan(struct FTimespan A, struct FTimespan B); // Function Engine.KismetMathLibrary.GreaterEqual_TimespanTimespan // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b2d6c8
	bool GreaterEqual_IntInt(int32 A, int32 B); // Function Engine.KismetMathLibrary.GreaterEqual_IntInt // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0xdfbea4
	bool GreaterEqual_FloatFloat(float A, float B); // Function Engine.KismetMathLibrary.GreaterEqual_FloatFloat // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0xaac8dc
	bool GreaterEqual_DateTimeDateTime(struct FDateTime A, struct FDateTime B); // Function Engine.KismetMathLibrary.GreaterEqual_DateTimeDateTime // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b2d6c8
	bool GreaterEqual_ByteByte(bool A, bool B); // Function Engine.KismetMathLibrary.GreaterEqual_ByteByte // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b2d5f4
	bool Greater_TimespanTimespan(struct FTimespan A, struct FTimespan B); // Function Engine.KismetMathLibrary.Greater_TimespanTimespan // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b2d980
	bool Greater_IntInt(int32 A, int32 B); // Function Engine.KismetMathLibrary.Greater_IntInt // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0xa79ac0
	bool Greater_FloatFloat(float A, float B); // Function Engine.KismetMathLibrary.Greater_FloatFloat // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x2d30d8
	bool Greater_DateTimeDateTime(struct FDateTime A, struct FDateTime B); // Function Engine.KismetMathLibrary.Greater_DateTimeDateTime // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b2d980
	bool Greater_ByteByte(bool A, bool B); // Function Engine.KismetMathLibrary.Greater_ByteByte // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b2d8ac
	int32 GetYear(struct FDateTime A); // Function Engine.KismetMathLibrary.GetYear // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b2cf70
	void GetYawPitchFromVector(struct FVector InVec, float Yaw, float Pitch); // Function Engine.KismetMathLibrary.GetYawPitchFromVector // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0xbbf800
	struct FVector GetVectorArrayAverage(struct TArray<struct FVector> Vectors); // Function Engine.KismetMathLibrary.GetVectorArrayAverage // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b2c4f4
	struct FVector GetUpVector(struct FRotator InRot); // Function Engine.KismetMathLibrary.GetUpVector // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b2be7c
	float GetTotalSeconds(struct FTimespan A); // Function Engine.KismetMathLibrary.GetTotalSeconds // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b2b020
	float GetTotalMinutes(struct FTimespan A); // Function Engine.KismetMathLibrary.GetTotalMinutes // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b2af88
	float GetTotalMilliseconds(struct FTimespan A); // Function Engine.KismetMathLibrary.GetTotalMilliseconds // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b2aef0
	float GetTotalHours(struct FTimespan A); // Function Engine.KismetMathLibrary.GetTotalHours // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b2ae58
	float GetTotalDays(struct FTimespan A); // Function Engine.KismetMathLibrary.GetTotalDays // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b2adc0
	struct FTimespan GetTimeOfDay(struct FDateTime A); // Function Engine.KismetMathLibrary.GetTimeOfDay // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b2ab30
	float GetTAU(); // Function Engine.KismetMathLibrary.GetTAU // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b2a658
	int32 GetSeconds(struct FTimespan A); // Function Engine.KismetMathLibrary.GetSeconds // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b29c8c
	int32 GetSecond(struct FDateTime A); // Function Engine.KismetMathLibrary.GetSecond // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b29c8c
	struct FVector GetRightVector(struct FRotator InRot); // Function Engine.KismetMathLibrary.GetRightVector // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b28b50
	struct FVector GetReflectionVector(struct FVector Direction, struct FVector SurfaceNormal); // Function Engine.KismetMathLibrary.GetReflectionVector // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b2855c
	float GetPointDistanceToSegment(struct FVector Point, struct FVector SegmentStart, struct FVector SegmentEnd); // Function Engine.KismetMathLibrary.GetPointDistanceToSegment // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b28010
	float GetPointDistanceToLine(struct FVector Point, struct FVector LineOrigin, struct FVector LineDirection); // Function Engine.KismetMathLibrary.GetPointDistanceToLine // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b27eb0
	float GetPI(); // Function Engine.KismetMathLibrary.GetPI // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b279a4
	int32 GetMonth(struct FDateTime A); // Function Engine.KismetMathLibrary.GetMonth // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b27464
	int32 GetMinutes(struct FTimespan A); // Function Engine.KismetMathLibrary.GetMinutes // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b273a0
	int32 GetMinute(struct FDateTime A); // Function Engine.KismetMathLibrary.GetMinute // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b273a0
	float GetMinElement(struct FVector A); // Function Engine.KismetMathLibrary.GetMinElement // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b272cc
	int32 GetMilliseconds(struct FTimespan A); // Function Engine.KismetMathLibrary.GetMilliseconds // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b27208
	int32 GetMillisecond(struct FDateTime A); // Function Engine.KismetMathLibrary.GetMillisecond // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b27208
	float GetMaxElement(struct FVector A); // Function Engine.KismetMathLibrary.GetMaxElement // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b27174
	int32 GetHours(struct FTimespan A); // Function Engine.KismetMathLibrary.GetHours // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b24d00
	int32 GetHour12(struct FDateTime A); // Function Engine.KismetMathLibrary.GetHour12 // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b24c6c
	int32 GetHour(struct FDateTime A); // Function Engine.KismetMathLibrary.GetHour // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b24d00
	struct FVector GetForwardVector(struct FRotator InRot); // Function Engine.KismetMathLibrary.GetForwardVector // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b18e54
	struct FTimespan GetDuration(struct FTimespan A); // Function Engine.KismetMathLibrary.GetDuration // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b245b8
	struct FVector GetDirectionUnitVector(struct FVector From, struct FVector To); // Function Engine.KismetMathLibrary.GetDirectionUnitVector // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b24324
	int32 GetDays(struct FTimespan A); // Function Engine.KismetMathLibrary.GetDays // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b23c54
	int32 GetDayOfYear(struct FDateTime A); // Function Engine.KismetMathLibrary.GetDayOfYear // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b23bc0
	int32 GetDay(struct FDateTime A); // Function Engine.KismetMathLibrary.GetDay // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b23b28
	struct FDateTime GetDate(struct FDateTime A); // Function Engine.KismetMathLibrary.GetDate // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b23a8c
	void GetAxes(struct FRotator A, struct FVector X, struct FVector Y, struct FVector Z); // Function Engine.KismetMathLibrary.GetAxes // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b222ec
	struct FIntVector FTruncVector(struct FVector InVector); // Function Engine.KismetMathLibrary.FTruncVector // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b1ee2c
	int32 FTrunc(float A); // Function Engine.KismetMathLibrary.FTrunc // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b1ed9c
	struct FTimespan FromSeconds(float Seconds); // Function Engine.KismetMathLibrary.FromSeconds // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b20f74
	struct FTimespan FromMinutes(float Minutes); // Function Engine.KismetMathLibrary.FromMinutes // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b20ed8
	struct FTimespan FromMilliseconds(float Milliseconds); // Function Engine.KismetMathLibrary.FromMilliseconds // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b20e3c
	struct FTimespan FromHours(float Hours); // Function Engine.KismetMathLibrary.FromHours // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b20d9c
	struct FTimespan FromDays(float Days); // Function Engine.KismetMathLibrary.FromDays // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b20cfc
	float Fraction(float A); // Function Engine.KismetMathLibrary.Fraction // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b20c5c
	int32 FMod(float Dividend, float Divisor, float Remainder); // Function Engine.KismetMathLibrary.FMod // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x2d2848
	float FMin(float A, float B); // Function Engine.KismetMathLibrary.FMin // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0xb4f258
	float FMax(float A, float B); // Function Engine.KismetMathLibrary.FMax // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x2d2b34
	float FloatSpringInterp(float Current, float Target, struct FFloatSpringState SpringState, float Stiffness, float CriticalDampingFactor, float DeltaTime, float Mass); // Function Engine.KismetMathLibrary.FloatSpringInterp // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x5b208ec
	float FixedTurn(float InCurrent, float InDesired, float InDeltaRate); // Function Engine.KismetMathLibrary.FixedTurn // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b207cc
	float FInterpTo_Constant(float Current, float Target, float DeltaTime, float InterpSpeed); // Function Engine.KismetMathLibrary.FInterpTo_Constant // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0xae176c
	float FInterpTo(float Current, float Target, float DeltaTime, float InterpSpeed); // Function Engine.KismetMathLibrary.FInterpTo // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0xadd5c0
	float FInterpEaseInOut(float A, float B, float ALPHA, float Exponent); // Function Engine.KismetMathLibrary.FInterpEaseInOut // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b1ebd8
	void FindNearestPointsOnLineSegments(struct FVector Segment1Start, struct FVector Segment1End, struct FVector Segment2Start, struct FVector Segment2End, struct FVector Segment1Point, struct FVector Segment2Point); // Function Engine.KismetMathLibrary.FindNearestPointsOnLineSegments // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b1fd70
	struct FRotator FindLookAtRotation(struct FVector Start, struct FVector Target); // Function Engine.KismetMathLibrary.FindLookAtRotation // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b1fc1c
	struct FVector FindClosestPointOnSegment(struct FVector Point, struct FVector SegmentStart, struct FVector SegmentEnd); // Function Engine.KismetMathLibrary.FindClosestPointOnSegment // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b1f59c
	struct FVector FindClosestPointOnLine(struct FVector Point, struct FVector LineOrigin, struct FVector LineDirection); // Function Engine.KismetMathLibrary.FindClosestPointOnLine // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b1f428
	int32 FFloor(float A); // Function Engine.KismetMathLibrary.FFloor // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b1eb34
	float FClamp(float Value, float Min, float Max); // Function Engine.KismetMathLibrary.FClamp // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x2d3288
	int32 FCeil(float A); // Function Engine.KismetMathLibrary.FCeil // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b1ea88
	float Exp(float A); // Function Engine.KismetMathLibrary.Exp // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b1e9f0
	bool EqualEqual_VectorVector(struct FVector A, struct FVector B, float ErrorTolerance); // Function Engine.KismetMathLibrary.EqualEqual_VectorVector // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b1e62c
	bool EqualEqual_Vector2DVector2D(struct FVector2D A, struct FVector2D B, float ErrorTolerance); // Function Engine.KismetMathLibrary.EqualEqual_Vector2DVector2D // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b1e4f0
	bool EqualEqual_TransformTransform(struct FTransform A, struct FTransform B); // Function Engine.KismetMathLibrary.EqualEqual_TransformTransform // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b1e36c
	bool EqualEqual_TimespanTimespan(struct FTimespan A, struct FTimespan B); // Function Engine.KismetMathLibrary.EqualEqual_TimespanTimespan // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b1dba4
	bool EqualEqual_RotatorRotator(struct FRotator A, struct FRotator B, float ErrorTolerance); // Function Engine.KismetMathLibrary.EqualEqual_RotatorRotator // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b1e1ac
	bool EqualEqual_ObjectObject(struct UObject* A, struct UObject* B); // Function Engine.KismetMathLibrary.EqualEqual_ObjectObject // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x540eaa0
	bool EqualEqual_NameName(struct FName A, struct FName B); // Function Engine.KismetMathLibrary.EqualEqual_NameName // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x540eaa0
	bool EqualEqual_IntInt(int32 A, int32 B); // Function Engine.KismetMathLibrary.EqualEqual_IntInt // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b1df40
	bool EqualEqual_FloatFloat(float A, float B); // Function Engine.KismetMathLibrary.EqualEqual_FloatFloat // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0xaf05ac
	bool EqualEqual_DateTimeDateTime(struct FDateTime A, struct FDateTime B); // Function Engine.KismetMathLibrary.EqualEqual_DateTimeDateTime // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b1dba4
	bool EqualEqual_ClassClass(struct UClass* A, struct UClass* B); // Function Engine.KismetMathLibrary.EqualEqual_ClassClass // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0xb95dbc
	bool EqualEqual_ByteByte(bool A, bool B); // Function Engine.KismetMathLibrary.EqualEqual_ByteByte // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x2d6484
	bool EqualEqual_BoolBool(bool A, bool B); // Function Engine.KismetMathLibrary.EqualEqual_BoolBool // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0xc0f3e0
	float Ease(float A, float B, float ALPHA, enum class EEasingFunc EasingFunc, float BlendExp, int32 Steps); // Function Engine.KismetMathLibrary.Ease // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b1d818
	float DotProduct2D(struct FVector2D A, struct FVector2D B); // Function Engine.KismetMathLibrary.DotProduct2D // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b1b5b8
	float Dot_VectorVector(struct FVector A, struct FVector B); // Function Engine.KismetMathLibrary.Dot_VectorVector // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0xb6c9e4
	struct FVector Divide_VectorVector(struct FVector A, struct FVector B); // Function Engine.KismetMathLibrary.Divide_VectorVector // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b1b324
	struct FVector Divide_VectorInt(struct FVector A, int32 B); // Function Engine.KismetMathLibrary.Divide_VectorInt // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b1b1d4
	struct FVector Divide_VectorFloat(struct FVector A, float B); // Function Engine.KismetMathLibrary.Divide_VectorFloat // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b1b090
	struct FVector2D Divide_Vector2DFloat(struct FVector2D A, float B); // Function Engine.KismetMathLibrary.Divide_Vector2DFloat // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b1af6c
	int32 Divide_IntInt(int32 A, int32 B); // Function Engine.KismetMathLibrary.Divide_IntInt // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b1ae88
	float Divide_FloatFloat(float A, float B); // Function Engine.KismetMathLibrary.Divide_FloatFloat // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0xb26300
	bool Divide_ByteByte(bool A, bool B); // Function Engine.KismetMathLibrary.Divide_ByteByte // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b1ad9c
	float DegTan(float A); // Function Engine.KismetMathLibrary.DegTan // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b1a818
	float DegSin(float A); // Function Engine.KismetMathLibrary.DegSin // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0xa99f40
	float DegreesToRadians(float A); // Function Engine.KismetMathLibrary.DegreesToRadians // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b1a8b8
	float DegCos(float A); // Function Engine.KismetMathLibrary.DegCos // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b1a778
	float DegAtan2(float A, float B); // Function Engine.KismetMathLibrary.DegAtan2 // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b1a5f4
	float DegAtan(float A); // Function Engine.KismetMathLibrary.DegAtan // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b1a6d8
	float DegAsin(float A); // Function Engine.KismetMathLibrary.DegAsin // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b1a53c
	float DegAcos(float A); // Function Engine.KismetMathLibrary.DegAcos // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b1a484
	int32 DaysInYear(int32 Year); // Function Engine.KismetMathLibrary.DaysInYear // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b1a194
	int32 DaysInMonth(int32 Year, int32 Month); // Function Engine.KismetMathLibrary.DaysInMonth // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b1a0ac
	struct FDateTime DateTimeMinValue(); // Function Engine.KismetMathLibrary.DateTimeMinValue // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x4d60a28
	struct FDateTime DateTimeMaxValue(); // Function Engine.KismetMathLibrary.DateTimeMaxValue // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b1a090
	bool DateTimeFromString(struct FString DateTimeString, struct FDateTime Result); // Function Engine.KismetMathLibrary.DateTimeFromString // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b19f1c
	bool DateTimeFromIsoString(struct FString IsoString, struct FDateTime Result); // Function Engine.KismetMathLibrary.DateTimeFromIsoString // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b19db0
	float CrossProduct2D(struct FVector2D A, struct FVector2D B); // Function Engine.KismetMathLibrary.CrossProduct2D // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b19ba4
	struct FVector Cross_VectorVector(struct FVector A, struct FVector B); // Function Engine.KismetMathLibrary.Cross_VectorVector // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b19c84
	struct FVector CreateVectorFromYawPitch(float Yaw, float Pitch, float Length); // Function Engine.KismetMathLibrary.CreateVectorFromYawPitch // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b19a74
	float Cos(float A); // Function Engine.KismetMathLibrary.Cos // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b19418
	struct FTransform ConvertTransformToRelative(struct FTransform Transform, struct FTransform ParentTransform); // Function Engine.KismetMathLibrary.ConvertTransformToRelative // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b191fc
	struct FVector2D Conv_VectorToVector2D(struct FVector InVector); // Function Engine.KismetMathLibrary.Conv_VectorToVector2D // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b1916c
	struct FTransform Conv_VectorToTransform(struct FVector InLocation); // Function Engine.KismetMathLibrary.Conv_VectorToTransform // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b190a8
	struct FRotator Conv_VectorToRotator(struct FVector InVec); // Function Engine.KismetMathLibrary.Conv_VectorToRotator // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b18ff4
	struct FLinearColor Conv_VectorToLinearColor(struct FVector InVec); // Function Engine.KismetMathLibrary.Conv_VectorToLinearColor // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0xd48d64
	struct FVector Conv_Vector2DToVector(struct FVector2D InVector2D, float Z); // Function Engine.KismetMathLibrary.Conv_Vector2DToVector // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b18f08
	struct FVector Conv_RotatorToVector(struct FRotator InRot); // Function Engine.KismetMathLibrary.Conv_RotatorToVector // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b18e54
	struct FVector Conv_LinearColorToVector(struct FLinearColor InLinearColor); // Function Engine.KismetMathLibrary.Conv_LinearColorToVector // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b18db0
	struct FColor Conv_LinearColorToColor(struct FLinearColor InLinearColor); // Function Engine.KismetMathLibrary.Conv_LinearColorToColor // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0xb19204
	struct FVector Conv_IntVectorToVector(struct FIntVector InIntVector); // Function Engine.KismetMathLibrary.Conv_IntVectorToVector // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b18c40
	struct FIntVector Conv_IntToIntVector(int32 inInt); // Function Engine.KismetMathLibrary.Conv_IntToIntVector // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b18bb4
	float Conv_IntToFloat(int32 inInt); // Function Engine.KismetMathLibrary.Conv_IntToFloat // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0xbe0f10
	bool Conv_IntToByte(int32 inInt); // Function Engine.KismetMathLibrary.Conv_IntToByte // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b18b2c
	bool Conv_IntToBool(int32 inInt); // Function Engine.KismetMathLibrary.Conv_IntToBool // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b18aa8
	struct FVector Conv_FloatToVector(float inFloat); // Function Engine.KismetMathLibrary.Conv_FloatToVector // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0xb8c108
	struct FLinearColor Conv_FloatToLinearColor(float inFloat); // Function Engine.KismetMathLibrary.Conv_FloatToLinearColor // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b188e8
	struct FLinearColor Conv_ColorToLinearColor(struct FColor InColor); // Function Engine.KismetMathLibrary.Conv_ColorToLinearColor // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b187f8
	int32 Conv_ByteToInt(bool InByte); // Function Engine.KismetMathLibrary.Conv_ByteToInt // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b18770
	float Conv_ByteToFloat(bool InByte); // Function Engine.KismetMathLibrary.Conv_ByteToFloat // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0xbe9a78
	int32 Conv_BoolToInt(bool InBool); // Function Engine.KismetMathLibrary.Conv_BoolToInt // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b186e4
	float Conv_BoolToFloat(bool InBool); // Function Engine.KismetMathLibrary.Conv_BoolToFloat // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x2d3210
	bool Conv_BoolToByte(bool InBool); // Function Engine.KismetMathLibrary.Conv_BoolToByte // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b18658
	struct FTransform ComposeTransforms(struct FTransform A, struct FTransform B); // Function Engine.KismetMathLibrary.ComposeTransforms // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b17828
	struct FRotator ComposeRotators(struct FRotator A, struct FRotator B); // Function Engine.KismetMathLibrary.ComposeRotators // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b17714
	bool ClassIsChildOf(struct UClass* TestClass, struct UClass* ParentClass); // Function Engine.KismetMathLibrary.ClassIsChildOf // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b16a64
	struct FVector ClampVectorSize(struct FVector A, float Min, float Max); // Function Engine.KismetMathLibrary.ClampVectorSize // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b16870
	float ClampAxis(float Angle); // Function Engine.KismetMathLibrary.ClampAxis // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b16794
	float ClampAngle(float AngleDegrees, float MinAngleDegrees, float MaxAngleDegrees); // Function Engine.KismetMathLibrary.ClampAngle // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b16674
	int32 Clamp(int32 Value, int32 Min, int32 Max); // Function Engine.KismetMathLibrary.Clamp // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b16558
	struct FLinearColor CInterpTo(struct FLinearColor Current, struct FLinearColor Target, float DeltaTime, float InterpSpeed); // Function Engine.KismetMathLibrary.CInterpTo // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b137c0
	void BreakVector2D(struct FVector2D InVec, float X, float Y); // Function Engine.KismetMathLibrary.BreakVector2D // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0xb4c09c
	void BreakVector(struct FVector InVec, float X, float Y, float Z); // Function Engine.KismetMathLibrary.BreakVector // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x2d3f88
	void BreakTransform(struct FTransform InTransform, struct FVector Location, struct FRotator Rotation, struct FVector Scale); // Function Engine.KismetMathLibrary.BreakTransform // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x2d34a4
	void BreakTimespan(struct FTimespan InTimespan, int32 Days, int32 Hours, int32 Minutes, int32 Seconds, int32 Milliseconds); // Function Engine.KismetMathLibrary.BreakTimespan // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b1355c
	void BreakRotIntoAxes(struct FRotator InRot, struct FVector X, struct FVector Y, struct FVector Z); // Function Engine.KismetMathLibrary.BreakRotIntoAxes // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b133a8
	void BreakRotator(struct FRotator InRot, float Roll, float Pitch, float Yaw); // Function Engine.KismetMathLibrary.BreakRotator // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x2d2bd0
	void BreakRandomStream(struct FRandomStream InRandomStream, int32 InitialSeed); // Function Engine.KismetMathLibrary.BreakRandomStream // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b132bc
	void BreakDateTime(struct FDateTime InDateTime, int32 Year, int32 Month, int32 Day, int32 Hour, int32 Minute, int32 second, int32 Millisecond); // Function Engine.KismetMathLibrary.BreakDateTime // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b12918
	void BreakColor(struct FLinearColor InColor, float R, float G, float B, float A); // Function Engine.KismetMathLibrary.BreakColor // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b125a0
	bool BooleanXOR(bool A, bool B); // Function Engine.KismetMathLibrary.BooleanXOR // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b0fdd0
	bool BooleanOR(bool A, bool B); // Function Engine.KismetMathLibrary.BooleanOR // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x2d47b8
	bool BooleanNOR(bool A, bool B); // Function Engine.KismetMathLibrary.BooleanNOR // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b0fce0
	bool BooleanNAND(bool A, bool B); // Function Engine.KismetMathLibrary.BooleanNAND // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b0fbf0
	bool BooleanAND(bool A, bool B); // Function Engine.KismetMathLibrary.BooleanAND // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x2d4318
	bool BMin(bool A, bool B); // Function Engine.KismetMathLibrary.BMin // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b0e100
	bool BMax(bool A, bool B); // Function Engine.KismetMathLibrary.BMax // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b0e024
	float Atan2(float A, float B); // Function Engine.KismetMathLibrary.Atan2 // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b0deb0
	float Atan(float A); // Function Engine.KismetMathLibrary.Atan // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b0df8c
	float Asin(float A); // Function Engine.KismetMathLibrary.Asin // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b0de00
	int32 And_IntInt(int32 A, int32 B); // Function Engine.KismetMathLibrary.And_IntInt // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b0b83c
	struct FVector Add_VectorVector(struct FVector A, struct FVector B); // Function Engine.KismetMathLibrary.Add_VectorVector // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0xb844ac
	struct FVector Add_VectorInt(struct FVector A, int32 B); // Function Engine.KismetMathLibrary.Add_VectorInt // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b0b440
	struct FVector Add_VectorFloat(struct FVector A, float B); // Function Engine.KismetMathLibrary.Add_VectorFloat // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b0b330
	struct FVector2D Add_Vector2DVector2D(struct FVector2D A, struct FVector2D B); // Function Engine.KismetMathLibrary.Add_Vector2DVector2D // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b0b254
	struct FVector2D Add_Vector2DFloat(struct FVector2D A, float B); // Function Engine.KismetMathLibrary.Add_Vector2DFloat // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b0b16c
	struct FTimespan Add_TimespanTimespan(struct FTimespan A, struct FTimespan B); // Function Engine.KismetMathLibrary.Add_TimespanTimespan // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b0b0a0
	int32 Add_IntInt(int32 A, int32 B); // Function Engine.KismetMathLibrary.Add_IntInt // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0xc134bc
	float Add_FloatFloat(float A, float B); // Function Engine.KismetMathLibrary.Add_FloatFloat // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x2d3694
	struct FDateTime Add_DateTimeTimespan(struct FDateTime A, struct FTimespan B); // Function Engine.KismetMathLibrary.Add_DateTimeTimespan // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b0b0a0
	bool Add_ByteByte(bool A, bool B); // Function Engine.KismetMathLibrary.Add_ByteByte // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b0afcc
	float Acos(float A); // Function Engine.KismetMathLibrary.Acos // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b093a0
	int32 Abs_Int(int32 A); // Function Engine.KismetMathLibrary.Abs_Int // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b091d0
	float Abs(float A); // Function Engine.KismetMathLibrary.Abs // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0xa733a8
};

// Class Engine.KismetNodeHelperLibrary
// Size: 0x38 (Inherited: 0x38)
struct UKismetNodeHelperLibrary : UBlueprintFunctionLibrary {

	void MarkBit(int32 Data, int32 Index); // Function Engine.KismetNodeHelperLibrary.MarkBit // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x5b72f10
	bool HasUnmarkedBit(int32 Data, int32 NumBits); // Function Engine.KismetNodeHelperLibrary.HasUnmarkedBit // Final|Native|Static|Public|BlueprintCallable // @ game+0x5b6ef20
	bool HasMarkedBit(int32 Data, int32 NumBits); // Function Engine.KismetNodeHelperLibrary.HasMarkedBit // Final|Native|Static|Public|BlueprintCallable // @ game+0x5b6ee20
	bool GetValidValue(struct UEnum* Enum, bool EnumeratorValue); // Function Engine.KismetNodeHelperLibrary.GetValidValue // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b6eb34
	int32 GetUnmarkedBit(int32 Data, int32 StartIdx, int32 NumBits, bool bRandom); // Function Engine.KismetNodeHelperLibrary.GetUnmarkedBit // Final|Native|Static|Public|BlueprintCallable // @ game+0x5b6e9bc
	int32 GetRandomUnmarkedBit(int32 Data, int32 StartIdx, int32 NumBits); // Function Engine.KismetNodeHelperLibrary.GetRandomUnmarkedBit // Final|Native|Static|Public|BlueprintCallable // @ game+0x5b6dbfc
	int32 GetFirstUnmarkedBit(int32 Data, int32 StartIdx, int32 NumBits); // Function Engine.KismetNodeHelperLibrary.GetFirstUnmarkedBit // Final|Native|Static|Public|BlueprintCallable // @ game+0x5b6c738
	bool GetEnumeratorValueFromIndex(struct UEnum* Enum, bool EnumeratorIndex); // Function Engine.KismetNodeHelperLibrary.GetEnumeratorValueFromIndex // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b6c64c
	struct FString GetEnumeratorUserFriendlyName(struct UEnum* Enum, bool EnumeratorValue); // Function Engine.KismetNodeHelperLibrary.GetEnumeratorUserFriendlyName // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b6c514
	struct FName GetEnumeratorName(struct UEnum* Enum, bool EnumeratorValue); // Function Engine.KismetNodeHelperLibrary.GetEnumeratorName // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b6c420
	void ClearBit(int32 Data, int32 Index); // Function Engine.KismetNodeHelperLibrary.ClearBit // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x5b67b98
	void ClearAllBits(int32 Data); // Function Engine.KismetNodeHelperLibrary.ClearAllBits // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x5b67b14
	bool BitIsMarked(int32 Data, int32 Index); // Function Engine.KismetNodeHelperLibrary.BitIsMarked // Final|Native|Static|Public|BlueprintCallable // @ game+0x5b658ec
};

// Class Engine.KismetRenderingLibrary
// Size: 0x38 (Inherited: 0x38)
struct UKismetRenderingLibrary : UBlueprintFunctionLibrary {

	struct FSkelMeshSkinWeightInfo MakeSkinWeightInfo(int32 Bone0, bool Weight0, int32 Bone1, bool Weight1, int32 Bone2, bool Weight2, int32 Bone3, bool Weight3); // Function Engine.KismetRenderingLibrary.MakeSkinWeightInfo // Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b72c4c
	void ExportTexture2D(struct UObject* WorldContextObject, struct UTexture2D* Texture, struct FString FilePath, struct FString FileName); // Function Engine.KismetRenderingLibrary.ExportTexture2D // Final|RequiredAPI|Native|Static|Public|BlueprintCallable // @ game+0x5b6b294
	void ExportRenderTarget(struct UObject* WorldContextObject, struct UTextureRenderTarget2D* TextureRenderTarget, struct FString FilePath, struct FString FileName); // Function Engine.KismetRenderingLibrary.ExportRenderTarget // Final|RequiredAPI|Native|Static|Public|BlueprintCallable // @ game+0x5b6b0cc
	void EndDrawCanvasToRenderTarget(struct UObject* WorldContextObject, struct FDrawToRenderTargetContext Context); // Function Engine.KismetRenderingLibrary.EndDrawCanvasToRenderTarget // Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x5b6a9a0
	void DrawMaterialToRenderTarget(struct UObject* WorldContextObject, struct UTextureRenderTarget2D* TextureRenderTarget, struct UMaterialInterface* Material); // Function Engine.KismetRenderingLibrary.DrawMaterialToRenderTarget // Final|RequiredAPI|Native|Static|Public|BlueprintCallable // @ game+0x5b6a4d8
	struct UTextureRenderTarget2D* CreateRenderTarget2D(struct UObject* WorldContextObject, int32 Width, int32 Height); // Function Engine.KismetRenderingLibrary.CreateRenderTarget2D // Final|RequiredAPI|Native|Static|Public|BlueprintCallable // @ game+0x5b69e28
	void ConvertRenderTargetToTexture2DEditorOnly(struct UObject* WorldContextObject, struct UTextureRenderTarget2D* RenderTarget, struct UTexture2D* Texture); // Function Engine.KismetRenderingLibrary.ConvertRenderTargetToTexture2DEditorOnly // Final|RequiredAPI|Native|Static|Public|BlueprintCallable // @ game+0x5b69980
	void ClearRenderTarget2D(struct UObject* WorldContextObject, struct UTextureRenderTarget2D* TextureRenderTarget, struct FLinearColor ClearColor); // Function Engine.KismetRenderingLibrary.ClearRenderTarget2D // Final|RequiredAPI|Native|Static|Public|HasDefaults|BlueprintCallable // @ game+0x5b67c7c
	void BreakSkinWeightInfo(struct FSkelMeshSkinWeightInfo InWeight, int32 Bone0, bool Weight0, int32 Bone1, bool Weight1, int32 Bone2, bool Weight2, int32 Bone3, bool Weight3); // Function Engine.KismetRenderingLibrary.BreakSkinWeightInfo // Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x5b659c0
	void BeginDrawCanvasToRenderTarget(struct UObject* WorldContextObject, struct UTextureRenderTarget2D* TextureRenderTarget, struct UCanvas* Canvas, struct FVector2D Size, struct FDrawToRenderTargetContext Context); // Function Engine.KismetRenderingLibrary.BeginDrawCanvasToRenderTarget // Final|RequiredAPI|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b656fc
};

// Class Engine.KismetStringLibrary
// Size: 0x38 (Inherited: 0x38)
struct UKismetStringLibrary : UBlueprintFunctionLibrary {

	struct FString TrimTrailing(struct FString SourceString); // Function Engine.KismetStringLibrary.TrimTrailing // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b77a28
	struct FString Trim(struct FString SourceString); // Function Engine.KismetStringLibrary.Trim // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b77898
	struct FString ToUpper(struct FString SourceString); // Function Engine.KismetStringLibrary.ToUpper // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b77768
	struct FString ToLower(struct FString SourceString); // Function Engine.KismetStringLibrary.ToLower // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b77650
	struct FString TimeSecondsToString(float InSeconds); // Function Engine.KismetStringLibrary.TimeSecondsToString // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b77568
	bool StartsWith(struct FString SourceString, struct FString InPrefix, enum class ESearchCase SearchCase); // Function Engine.KismetStringLibrary.StartsWith // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b76470
	bool Split(struct FString SourceString, struct FString InStr, struct FString LeftS, struct FString RightS, enum class ESearchCase SearchCase, enum class ESearchDir SearchDir); // Function Engine.KismetStringLibrary.Split // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x5b7619c
	struct FString RightPad(struct FString SourceString, int32 ChCount); // Function Engine.KismetStringLibrary.RightPad // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b74a84
	struct FString RightChop(struct FString SourceString, int32 Count); // Function Engine.KismetStringLibrary.RightChop // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b74898
	struct FString Right(struct FString SourceString, int32 Count); // Function Engine.KismetStringLibrary.Right // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b746b4
	struct FString Reverse(struct FString SourceString); // Function Engine.KismetStringLibrary.Reverse // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b74534
	int32 ReplaceInline(struct FString SourceString, struct FString SearchText, struct FString ReplacementText, enum class ESearchCase SearchCase); // Function Engine.KismetStringLibrary.ReplaceInline // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x5b7430c
	struct FString Replace(struct FString SourceString, struct FString From, struct FString To, enum class ESearchCase SearchCase); // Function Engine.KismetStringLibrary.Replace // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x8e8530
	struct TArray<struct FString> ParseIntoArray(struct FString SourceString, struct FString Delimiter, bool CullEmptyStrings); // Function Engine.KismetStringLibrary.ParseIntoArray // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b73d64
	bool NotEqual_StrStr(struct FString A, struct FString B); // Function Engine.KismetStringLibrary.NotEqual_StrStr // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0xc37bec
	bool NotEqual_StriStri(struct FString A, struct FString B); // Function Engine.KismetStringLibrary.NotEqual_StriStri // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0xc07000
	struct FString Mid(struct FString SourceString, int32 Start, int32 Count); // Function Engine.KismetStringLibrary.Mid // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b73188
	bool MatchesWildcard(struct FString SourceString, struct FString Wildcard, enum class ESearchCase SearchCase); // Function Engine.KismetStringLibrary.MatchesWildcard // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b72ff4
	int32 Len(struct FString S); // Function Engine.KismetStringLibrary.Len // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b72344
	struct FString LeftPad(struct FString SourceString, int32 ChCount); // Function Engine.KismetStringLibrary.LeftPad // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b721d4
	struct FString LeftChop(struct FString SourceString, int32 Count); // Function Engine.KismetStringLibrary.LeftChop // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b71ff8
	struct FString Left(struct FString SourceString, int32 Count); // Function Engine.KismetStringLibrary.Left // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b71e20
	struct FString JoinStringArray(struct TArray<struct FString> SourceArray, struct FString Separator); // Function Engine.KismetStringLibrary.JoinStringArray // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x5b6f78c
	bool IsNumeric(struct FString SourceString); // Function Engine.KismetStringLibrary.IsNumeric // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b6f410
	struct FString GetSubstring(struct FString SourceString, int32 StartIndex, int32 Length); // Function Engine.KismetStringLibrary.GetSubstring // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b6e400
	int32 GetCharacterAsNumber(struct FString SourceString, int32 Index); // Function Engine.KismetStringLibrary.GetCharacterAsNumber // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b6bf10
	struct TArray<struct FString> GetCharacterArrayFromString(struct FString SourceString); // Function Engine.KismetStringLibrary.GetCharacterArrayFromString // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b6be2c
	int32 FindSubstring(struct FString SearchIn, struct FString Substring, bool bUseCase, bool bSearchFromEnd, int32 StartPosition); // Function Engine.KismetStringLibrary.FindSubstring // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b6b864
	bool EqualEqual_StrStr(struct FString A, struct FString B); // Function Engine.KismetStringLibrary.EqualEqual_StrStr // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x8e71a8
	bool EqualEqual_StriStri(struct FString A, struct FString B); // Function Engine.KismetStringLibrary.EqualEqual_StriStri // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b6adb0
	bool EndsWith(struct FString SourceString, struct FString InSuffix, enum class ESearchCase SearchCase); // Function Engine.KismetStringLibrary.EndsWith // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b6aa88
	int32 CullArray(struct FString SourceString, struct TArray<struct FString> inArray); // Function Engine.KismetStringLibrary.CullArray // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x5b69f44
	struct FString Conv_VectorToString(struct FVector InVec); // Function Engine.KismetStringLibrary.Conv_VectorToString // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b69798
	struct FString Conv_Vector2dToString(struct FVector2D InVec); // Function Engine.KismetStringLibrary.Conv_Vector2dToString // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b695bc
	struct FString Conv_TransformToString(struct FTransform InTrans); // Function Engine.KismetStringLibrary.Conv_TransformToString // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b692ec
	void Conv_StringToVector2D(struct FString inString, struct FVector2D OutConvertedVector2D, bool OutIsValid); // Function Engine.KismetStringLibrary.Conv_StringToVector2D // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b68f64
	void Conv_StringToVector(struct FString inString, struct FVector OutConvertedVector, bool OutIsValid); // Function Engine.KismetStringLibrary.Conv_StringToVector // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b69110
	void Conv_StringToRotator(struct FString inString, struct FRotator OutConvertedRotator, bool OutIsValid); // Function Engine.KismetStringLibrary.Conv_StringToRotator // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b68d88
	struct FName Conv_StringToName(struct FString inString); // Function Engine.KismetStringLibrary.Conv_StringToName // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0xbdb3c0
	int32 Conv_StringToInt(struct FString inString); // Function Engine.KismetStringLibrary.Conv_StringToInt // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b68cbc
	float Conv_StringToFloat(struct FString inString); // Function Engine.KismetStringLibrary.Conv_StringToFloat // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b68be8
	void Conv_StringToColor(struct FString inString, struct FLinearColor OutConvertedColor, bool OutIsValid); // Function Engine.KismetStringLibrary.Conv_StringToColor // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b68a6c
	struct FString Conv_RotatorToString(struct FRotator InRot); // Function Engine.KismetStringLibrary.Conv_RotatorToString // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b68884
	struct FString Conv_ObjectToString(struct UObject* InObj); // Function Engine.KismetStringLibrary.Conv_ObjectToString // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b686cc
	struct FString Conv_NameToString(struct FName InName); // Function Engine.KismetStringLibrary.Conv_NameToString // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0xbf3d70
	struct FString Conv_IntVectorToString(struct FIntVector InIntVec); // Function Engine.KismetStringLibrary.Conv_IntVectorToString // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b684e8
	struct FString Conv_IntToString(int32 inInt); // Function Engine.KismetStringLibrary.Conv_IntToString // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0xbf13bc
	struct FString Conv_FloatToString(float inFloat); // Function Engine.KismetStringLibrary.Conv_FloatToString // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x4a15c4
	struct FString Conv_ColorToString(struct FLinearColor InColor); // Function Engine.KismetStringLibrary.Conv_ColorToString // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b68158
	struct FString Conv_ByteToString(bool InByte); // Function Engine.KismetStringLibrary.Conv_ByteToString // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b67f8c
	struct FString Conv_BoolToString(bool InBool); // Function Engine.KismetStringLibrary.Conv_BoolToString // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b67dcc
	bool Contains(struct FString SearchIn, struct FString Substring, bool bUseCase, bool bSearchFromEnd); // Function Engine.KismetStringLibrary.Contains // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0xc5ef10
	struct FString Concat_StrStr(struct FString A, struct FString B); // Function Engine.KismetStringLibrary.Concat_StrStr // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x8e828c
	struct FString BuildString_Vector2d(struct FString AppendTo, struct FString Prefix, struct FVector2D InVector2D, struct FString Suffix); // Function Engine.KismetStringLibrary.BuildString_Vector2d // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b674c8
	struct FString BuildString_Vector(struct FString AppendTo, struct FString Prefix, struct FVector InVector, struct FString Suffix); // Function Engine.KismetStringLibrary.BuildString_Vector // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b67700
	struct FString BuildString_Rotator(struct FString AppendTo, struct FString Prefix, struct FRotator InRot, struct FString Suffix); // Function Engine.KismetStringLibrary.BuildString_Rotator // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b67274
	struct FString BuildString_Object(struct FString AppendTo, struct FString Prefix, struct UObject* InObj, struct FString Suffix); // Function Engine.KismetStringLibrary.BuildString_Object // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b67038
	struct FString BuildString_Name(struct FString AppendTo, struct FString Prefix, struct FName InName, struct FString Suffix); // Function Engine.KismetStringLibrary.BuildString_Name // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b66dfc
	struct FString BuildString_IntVector(struct FString AppendTo, struct FString Prefix, struct FIntVector InIntVector, struct FString Suffix); // Function Engine.KismetStringLibrary.BuildString_IntVector // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b66ba8
	struct FString BuildString_Int(struct FString AppendTo, struct FString Prefix, int32 inInt, struct FString Suffix); // Function Engine.KismetStringLibrary.BuildString_Int // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b6696c
	struct FString BuildString_Float(struct FString AppendTo, struct FString Prefix, float inFloat, struct FString Suffix); // Function Engine.KismetStringLibrary.BuildString_Float // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b6672c
	struct FString BuildString_Color(struct FString AppendTo, struct FString Prefix, struct FLinearColor InColor, struct FString Suffix); // Function Engine.KismetStringLibrary.BuildString_Color // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b664e0
	struct FString BuildString_Bool(struct FString AppendTo, struct FString Prefix, bool InBool, struct FString Suffix); // Function Engine.KismetStringLibrary.BuildString_Bool // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b66294
};

// Class Engine.KismetStringTableLibrary
// Size: 0x38 (Inherited: 0x38)
struct UKismetStringTableLibrary : UBlueprintFunctionLibrary {

	bool IsRegisteredTableId(struct FName TableId); // Function Engine.KismetStringTableLibrary.IsRegisteredTableId // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b6f614
	bool IsRegisteredTableEntry(struct FName TableId, struct FString Key); // Function Engine.KismetStringTableLibrary.IsRegisteredTableEntry // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b6f4f8
	struct FString GetTableNamespace(struct FName TableId); // Function Engine.KismetStringTableLibrary.GetTableNamespace // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b6e8c4
	struct FString GetTableEntrySourceString(struct FName TableId, struct FString Key); // Function Engine.KismetStringTableLibrary.GetTableEntrySourceString // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b6e758
	struct FString GetTableEntryMetaData(struct FName TableId, struct FString Key, struct FName MetaDataId); // Function Engine.KismetStringTableLibrary.GetTableEntryMetaData // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b6e5a8
	struct TArray<struct FName> GetRegisteredStringTables(); // Function Engine.KismetStringTableLibrary.GetRegisteredStringTables // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b6dd40
	struct TArray<struct FName> GetMetaDataIdsFromStringTableEntry(struct FName TableId, struct FString Key); // Function Engine.KismetStringTableLibrary.GetMetaDataIdsFromStringTableEntry // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b6d02c
	struct TArray<struct FString> GetKeysFromStringTable(struct FName TableId); // Function Engine.KismetStringTableLibrary.GetKeysFromStringTable // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b6cc94
};

// Class Engine.KismetTextLibrary
// Size: 0x38 (Inherited: 0x38)
struct UKismetTextLibrary : UBlueprintFunctionLibrary {

	struct FText TextTrimTrailing(struct FText InText); // Function Engine.KismetTextLibrary.TextTrimTrailing // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x5b77448
	struct FText TextTrimPrecedingAndTrailing(struct FText InText); // Function Engine.KismetTextLibrary.TextTrimPrecedingAndTrailing // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x5b77328
	struct FText TextTrimPreceding(struct FText InText); // Function Engine.KismetTextLibrary.TextTrimPreceding // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x5b77208
	struct FText TextToUpper(struct FText InText); // Function Engine.KismetTextLibrary.TextToUpper // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x5b770e8
	struct FText TextToLower(struct FText InText); // Function Engine.KismetTextLibrary.TextToLower // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x5b76fc8
	bool TextIsTransient(struct FText InText); // Function Engine.KismetTextLibrary.TextIsTransient // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x5b76eec
	bool TextIsFromStringTable(struct FText Text); // Function Engine.KismetTextLibrary.TextIsFromStringTable // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x5b76e10
	bool TextIsEmpty(struct FText InText); // Function Engine.KismetTextLibrary.TextIsEmpty // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x5b76d2c
	bool TextIsCultureInvariant(struct FText InText); // Function Engine.KismetTextLibrary.TextIsCultureInvariant // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x5b76c50
	struct FText TextFromStringTable(struct FName TableId, struct FString Key); // Function Engine.KismetTextLibrary.TextFromStringTable // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b76aec
	bool StringTableIdAndKeyFromText(struct FText Text, struct FName OutTableId, struct FString OutKey); // Function Engine.KismetTextLibrary.StringTableIdAndKeyFromText // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x5b767c0
	bool NotEqual_TextText(struct FText A, struct FText B); // Function Engine.KismetTextLibrary.NotEqual_TextText // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x5b737a4
	bool NotEqual_IgnoreCase_TextText(struct FText A, struct FText B); // Function Engine.KismetTextLibrary.NotEqual_IgnoreCase_TextText // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x5b73610
	struct FText GetEmptyText(); // Function Engine.KismetTextLibrary.GetEmptyText // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b6c2f0
	struct FText Format(struct FText InPattern, struct TArray<struct FFormatArgumentData> InArgs); // Function Engine.KismetTextLibrary.Format // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x796900
	bool FindTextInLocalizationTable(struct FString NameSpace, struct FString Key, struct FText OutText); // Function Engine.KismetTextLibrary.FindTextInLocalizationTable // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x5b6ba80
	bool EqualEqual_TextText(struct FText A, struct FText B); // Function Engine.KismetTextLibrary.EqualEqual_TextText // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x5b6af3c
	bool EqualEqual_IgnoreCase_TextText(struct FText A, struct FText B); // Function Engine.KismetTextLibrary.EqualEqual_IgnoreCase_TextText // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x5b6ac1c
	struct FText Conv_VectorToText(struct FVector InVec); // Function Engine.KismetTextLibrary.Conv_VectorToText // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b69898
	struct FText Conv_Vector2dToText(struct FVector2D InVec); // Function Engine.KismetTextLibrary.Conv_Vector2dToText // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b696c4
	struct FText Conv_TransformToText(struct FTransform InTrans); // Function Engine.KismetTextLibrary.Conv_TransformToText // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b6942c
	struct FString Conv_TextToString(struct FText InText); // Function Engine.KismetTextLibrary.Conv_TextToString // Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0xc79fa8
	struct FText Conv_StringToText(struct FString inString); // Function Engine.KismetTextLibrary.Conv_StringToText // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0xc97e58
	struct FText Conv_RotatorToText(struct FRotator InRot); // Function Engine.KismetTextLibrary.Conv_RotatorToText // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b68984
	struct FText Conv_ObjectToText(struct UObject* InObj); // Function Engine.KismetTextLibrary.Conv_ObjectToText // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b687ac
	struct FText Conv_NameToText(struct FName InName); // Function Engine.KismetTextLibrary.Conv_NameToText // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b685e8
	struct FText Conv_IntToText(int32 Value, bool bUseGrouping, int32 MinimumIntegralDigits, int32 MaximumIntegralDigits); // Function Engine.KismetTextLibrary.Conv_IntToText // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b6832c
	struct FText Conv_FloatToText(float Value, enum class ERoundingMode RoundingMode, bool bUseGrouping, int32 MinimumIntegralDigits, int32 MaximumIntegralDigits, int32 MinimumFractionalDigits, int32 MaximumFractionalDigits); // Function Engine.KismetTextLibrary.Conv_FloatToText // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0xccfd68
	struct FText Conv_ColorToText(struct FLinearColor InColor); // Function Engine.KismetTextLibrary.Conv_ColorToText // Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b6824c
	struct FText Conv_ByteToText(bool Value); // Function Engine.KismetTextLibrary.Conv_ByteToText // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b68080
	struct FText Conv_BoolToText(bool InBool); // Function Engine.KismetTextLibrary.Conv_BoolToText // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b67eb0
	struct FText AsTimeZoneTime_DateTime(struct FDateTime InDateTime, struct FString InTimeZone); // Function Engine.KismetTextLibrary.AsTimeZoneTime_DateTime // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b6533c
	struct FText AsTimeZoneDateTime_DateTime(struct FDateTime InDateTime, struct FString InTimeZone); // Function Engine.KismetTextLibrary.AsTimeZoneDateTime_DateTime // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b64fc8
	struct FText AsTimeZoneDate_DateTime(struct FDateTime InDateTime, struct FString InTimeZone); // Function Engine.KismetTextLibrary.AsTimeZoneDate_DateTime // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b65184
	struct FText AsTimespan_Timespan(struct FTimespan InTimespan); // Function Engine.KismetTextLibrary.AsTimespan_Timespan // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b655d4
	struct FText AsTime_DateTime(struct FDateTime In); // Function Engine.KismetTextLibrary.AsTime_DateTime // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b654f4
	struct FText AsPercent_Float(float Value, enum class ERoundingMode RoundingMode, bool bUseGrouping, int32 MinimumIntegralDigits, int32 MaximumIntegralDigits, int32 MinimumFractionalDigits, int32 MaximumFractionalDigits); // Function Engine.KismetTextLibrary.AsPercent_Float // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b64d08
	struct FText AsDateTime_DateTime(struct FDateTime In); // Function Engine.KismetTextLibrary.AsDateTime_DateTime // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b64b48
	struct FText AsDate_DateTime(struct FDateTime InDateTime); // Function Engine.KismetTextLibrary.AsDate_DateTime // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b64c28
	struct FText AsCurrencyBase(int32 BaseValue, struct FString CurrencyCode); // Function Engine.KismetTextLibrary.AsCurrencyBase // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b64300
	struct FText AsCurrency_Integer(int32 Value, enum class ERoundingMode RoundingMode, bool bUseGrouping, int32 MinimumIntegralDigits, int32 MaximumIntegralDigits, int32 MinimumFractionalDigits, int32 MaximumFractionalDigits, struct FString CurrencyCode); // Function Engine.KismetTextLibrary.AsCurrency_Integer // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b6480c
	struct FText AsCurrency_Float(float Value, enum class ERoundingMode RoundingMode, bool bUseGrouping, int32 MinimumIntegralDigits, int32 MaximumIntegralDigits, int32 MinimumFractionalDigits, int32 MaximumFractionalDigits, struct FString CurrencyCode); // Function Engine.KismetTextLibrary.AsCurrency_Float // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b644cc
};

// Class Engine.MeshVertexPainterKismetLibrary
// Size: 0x38 (Inherited: 0x38)
struct UMeshVertexPainterKismetLibrary : UBlueprintFunctionLibrary {

	void RemovePaintedVertices(struct UStaticMeshComponent* StaticMeshComponent); // Function Engine.MeshVertexPainterKismetLibrary.RemovePaintedVertices // Final|Native|Static|Public|BlueprintCallable // @ game+0x5b7427c
	void PaintVerticesSingleColor(struct UStaticMeshComponent* StaticMeshComponent, struct FLinearColor FillColor, bool bConvertToSRGB); // Function Engine.MeshVertexPainterKismetLibrary.PaintVerticesSingleColor // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b73c34
	void PaintVerticesLerpAlongAxis(struct UStaticMeshComponent* StaticMeshComponent, struct FLinearColor StartColor, struct FLinearColor EndColor, enum class EVertexPaintAxis Axis, bool bConvertToSRGB); // Function Engine.MeshVertexPainterKismetLibrary.PaintVerticesLerpAlongAxis // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b73a58
};

// Class Engine.World
// Size: 0xc40 (Inherited: 0x38)
struct UWorld : UObject {
	char pad_38[0x8]; // 0x38(0x08)
	struct UDirectionalLightComponent* HeightBufferFakeLight; // 0x40(0x08)
	char pad_48[0xb8]; // 0x48(0xb8)
	struct TArray<struct UObject*> ExtraReferencedObjects; // 0x100(0x10)
	char pad_110[0x8]; // 0x110(0x08)
	struct UNetDriver* NetDriver; // 0x118(0x08)
	char pad_120[0x8]; // 0x120(0x08)
	struct UCanvas* CanvasForDrawMaterialToRenderTarget; // 0x128(0x08)
	char pad_130[0x8]; // 0x130(0x08)
	struct ULineBatchComponent* ForegroundLineBatcher; // 0x138(0x08)
	char pad_140[0xd0]; // 0x140(0xd0)
	struct TArray<struct UObject*> PerModuleDataObjects; // 0x210(0x10)
	char pad_220[0xc8]; // 0x220(0xc8)
	struct UPhysicsCollisionHandler* PhysicsCollisionHandler; // 0x2e8(0x08)
	struct APhysicsVolume* DefaultPhysicsVolume; // 0x2f0(0x08)
	struct TArray<struct ULevelStreaming*> SortedStreamingLevels; // 0x2f8(0x10)
	struct TArray<struct ULevelStreaming*> StreamingLevels; // 0x308(0x10)
	char pad_318[0x58]; // 0x318(0x58)
	struct ULineBatchComponent* PersistentLineBatcher; // 0x370(0x08)
	char pad_378[0x10]; // 0x378(0x10)
	struct ULineBatchComponent* LineBatcher; // 0x388(0x08)
	char pad_390[0x18]; // 0x390(0x18)
	struct UWorldComposition* WorldComposition; // 0x3a8(0x08)
	char pad_3B0[0x10]; // 0x3b0(0x10)
	struct TArray<struct FLevelCollection> LevelCollections; // 0x3c0(0x10)
	struct AGameModeBase* AuthorityGameMode; // 0x3d0(0x08)
	char pad_3D8[0x10]; // 0x3d8(0x10)
	struct TArray<struct ULevel*> Levels; // 0x3e8(0x10)
	struct ULevel* CurrentLevel; // 0x3f8(0x08)
	char pad_400[0x3c8]; // 0x400(0x3c8)
	struct UCanvas* CanvasForRenderingToTarget; // 0x7c8(0x08)
	struct FString StreamingLevelsPrefix; // 0x7d0(0x10)
	char pad_7E0[0x38]; // 0x7e0(0x38)
	struct UAvoidanceManager* AvoidanceManager; // 0x818(0x08)
	struct UNavigationSystem* NavigationSystem; // 0x820(0x08)
	char pad_828[0x8]; // 0x828(0x08)
	struct ULevel* CurrentLevelPendingVisibility; // 0x830(0x08)
	char pad_838[0x20]; // 0x838(0x20)
	struct AGameNetworkManager* NetworkManager; // 0x858(0x08)
	struct AParticleEventManager* MyParticleEventManager; // 0x860(0x08)
	char pad_868[0x118]; // 0x868(0x118)
	struct UAISystemBase* AISystem; // 0x980(0x08)
	char pad_988[0x8]; // 0x988(0x08)
	struct UDemoNetDriver* DemoNetDriver; // 0x990(0x08)
	struct ULevel* CurrentLevelPendingInvisibility; // 0x998(0x08)
	char pad_9A0[0x18]; // 0x9a0(0x18)
	struct TArray<struct UMaterialParameterCollectionInstance*> ParameterCollectionInstances; // 0x9b8(0x10)
	char pad_9C8[0x4a]; // 0x9c8(0x4a)
	char bAreConstraintsDirty : 1; // 0xa12(0x01)
	char pad_A12_1 : 7; // 0xa12(0x01)
	char pad_A13[0x6d]; // 0xa13(0x6d)
	struct TMap<struct FLandscapeOverrideKey, struct FLandscapeOverrideData> LandscapeOverrideDatas; // 0xa80(0x50)
	char pad_AD0[0x170]; // 0xad0(0x170)
};

// Class Engine.NavigationSystem
// Size: 0x4e0 (Inherited: 0x38)
struct UNavigationSystem : UBlueprintFunctionLibrary {
	struct ANavigationData* MainNavData; // 0x38(0x08)
	struct ANavigationData* AbstractNavData; // 0x40(0x08)
	char bAutoCreateNavigationData : 1; // 0x48(0x01)
	char bAllowClientSideNavigation : 1; // 0x48(0x01)
	char bSupportRebuilding : 1; // 0x48(0x01)
	char bInitialBuildingLocked : 1; // 0x48(0x01)
	char pad_48_4 : 1; // 0x48(0x01)
	char bSkipAgentHeightCheckWhenPickingNavData : 1; // 0x48(0x01)
	char pad_48_6 : 2; // 0x48(0x01)
	char pad_49[0x3]; // 0x49(0x03)
	enum class ENavDataGatheringModeConfig DataGatheringMode; // 0x4c(0x01)
	char pad_4D[0x3]; // 0x4d(0x03)
	char bGenerateNavigationOnlyAroundNavigationInvokers : 1; // 0x50(0x01)
	char pad_50_1 : 7; // 0x50(0x01)
	char pad_51[0x3]; // 0x51(0x03)
	float ActiveTilesUpdateInterval; // 0x54(0x04)
	struct TArray<struct FNavDataConfig> SupportedAgents; // 0x58(0x10)
	float DirtyAreasUpdateFreq; // 0x68(0x04)
	char pad_6C[0x4]; // 0x6c(0x04)
	struct TArray<struct ANavigationData*> NavDataSet; // 0x70(0x10)
	struct TArray<struct FBox> SubNavMeshBoundsArr; // 0x80(0x10)
	struct TMap<int32, struct ANavigationData*> SubNavDataMap; // 0x90(0x50)
	struct TArray<struct ANavigationData*> NavDataRegistrationQueue; // 0xe0(0x10)
	char pad_F0[0x60]; // 0xf0(0x60)
	struct FMulticastDelegate OnNavDataRegisteredEvent; // 0x150(0x10)
	struct FMulticastDelegate OnNavigationGenerationFinishedDelegate; // 0x160(0x10)
	char pad_170[0x124]; // 0x170(0x124)
	enum class FNavigationSystemRunMode OperationMode; // 0x294(0x01)
	char pad_295[0x243]; // 0x295(0x243)
	uint32 DynamicNavThreadNum; // 0x4d8(0x04)
	char pad_4DC[0x4]; // 0x4dc(0x04)

	void UpdateDynamicGenerateTargetNav(bool IsAdd, struct FDynamicGenerateTargetNavigation GenerateTargetNav); // Function Engine.NavigationSystem.UpdateDynamicGenerateTargetNav // Final|Native|Public|BlueprintCallable // @ game+0x5b77e9c
	void UnregisterNavigationInvoker(struct AActor* Invoker); // Function Engine.NavigationSystem.UnregisterNavigationInvoker // Final|Native|Public|BlueprintCallable // @ game+0x5b77da8
	void SimpleMoveToLocation(struct AController* Controller, struct FVector Goal); // Function Engine.NavigationSystem.SimpleMoveToLocation // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b76020
	void SimpleMoveToActor(struct AController* Controller, struct AActor* Goal); // Function Engine.NavigationSystem.SimpleMoveToActor // Final|Native|Static|Public|BlueprintCallable // @ game+0x5b75f48
	void SetMaxSimultaneousTileGenerationJobsCount(int32 MaxNumberOfJobs); // Function Engine.NavigationSystem.SetMaxSimultaneousTileGenerationJobsCount // Final|Native|Public|BlueprintCallable // @ game+0x5b75218
	void SetGeometryGatheringMode(enum class ENavDataGatheringModeConfig NewMode); // Function Engine.NavigationSystem.SetGeometryGatheringMode // Final|Native|Public|BlueprintCallable // @ game+0x5b75180
	void ResetMaxSimultaneousTileGenerationJobsCount(); // Function Engine.NavigationSystem.ResetMaxSimultaneousTileGenerationJobsCount // Final|Native|Public|BlueprintCallable // @ game+0x5b74520
	void RegisterNavigationInvoker(struct AActor* Invoker, float TileGenerationRadius, float TileRemovalRadius); // Function Engine.NavigationSystem.RegisterNavigationInvoker // Final|Native|Public|BlueprintCallable // @ game+0x5b74154
	struct FVector ProjectPointToNavigation(struct UObject* WorldContext, struct FVector Point, struct ANavigationData* NavData, struct UClass* FilterClass, struct FVector QueryExtent); // Function Engine.NavigationSystem.ProjectPointToNavigation // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b73f5c
	void OnNavigationBoundsUpdated(struct ANavMeshBoundsVolume* NavVolume); // Function Engine.NavigationSystem.OnNavigationBoundsUpdated // Final|Native|Public|BlueprintCallable // @ game+0x5b73934
	bool NavigationRaycast(struct UObject* WorldContext, struct FVector RayStart, struct FVector RayEnd, struct FVector HitLocation, struct UClass* FilterClass, struct AController* Querier); // Function Engine.NavigationSystem.NavigationRaycast // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b733c4
	bool K2_ProjectPointToNavigation(struct UObject* WorldContext, struct FVector Point, struct FVector ProjectedLocation, struct ANavigationData* NavData, struct UClass* FilterClass, struct FVector QueryExtent); // Function Engine.NavigationSystem.K2_ProjectPointToNavigation // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b71930
	bool K2_GetRandomReachablePointInRadius(struct UObject* WorldContext, struct FVector Origin, struct FVector RandomLocation, float Radius, struct ANavigationData* NavData, struct UClass* FilterClass); // Function Engine.NavigationSystem.K2_GetRandomReachablePointInRadius // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b712fc
	bool K2_GetRandomPointInNavigableRadius(struct UObject* WorldContext, struct FVector Origin, struct FVector RandomLocation, float Radius, struct ANavigationData* NavData, struct UClass* FilterClass); // Function Engine.NavigationSystem.K2_GetRandomPointInNavigableRadius // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b710cc
	bool IsNavigationBeingBuiltOrLocked(struct UObject* WorldContext); // Function Engine.NavigationSystem.IsNavigationBeingBuiltOrLocked // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b6f34c
	bool IsNavigationBeingBuilt(struct UObject* WorldContext); // Function Engine.NavigationSystem.IsNavigationBeingBuilt // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b6f288
	struct FVector GetRandomReachablePointInRadius(struct UObject* WorldContext, struct FVector Origin, float Radius, struct ANavigationData* NavData, struct UClass* FilterClass); // Function Engine.NavigationSystem.GetRandomReachablePointInRadius // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b6da0c
	struct FVector GetRandomPointInNavigableRadius(struct UObject* WorldContext, struct FVector Origin, float Radius, struct ANavigationData* NavData, struct UClass* FilterClass); // Function Engine.NavigationSystem.GetRandomPointInNavigableRadius // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b6d81c
	enum class ENavigationQueryResult GetPathLength(struct UObject* WorldContext, struct FVector PathStart, struct FVector PathEnd, float PathLength, struct ANavigationData* NavData, struct UClass* FilterClass); // Function Engine.NavigationSystem.GetPathLength // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b6d598
	enum class ENavigationQueryResult GetPathCost(struct UObject* WorldContext, struct FVector PathStart, struct FVector PathEnd, float PathCost, struct ANavigationData* NavData, struct UClass* FilterClass); // Function Engine.NavigationSystem.GetPathCost // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x5b6d31c
	struct UNavigationSystem* GetNavigationSystem(struct UObject* WorldContext); // Function Engine.NavigationSystem.GetNavigationSystem // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b6d198
	struct UNavigationPath* FindPathToLocationSynchronously(struct UObject* WorldContext, struct FVector PathStart, struct FVector PathEnd, struct AActor* PathfindingContext, struct UClass* FilterClass); // Function Engine.NavigationSystem.FindPathToLocationSynchronously // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b6b688
	struct UNavigationPath* FindPathToActorSynchronously(struct UObject* WorldContext, struct FVector PathStart, struct AActor* GoalActor, float TetherDistance, struct AActor* PathfindingContext, struct UClass* FilterClass); // Function Engine.NavigationSystem.FindPathToActorSynchronously // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b6b45c
};

// Class Engine.StereoLayerFunctionLibrary
// Size: 0x38 (Inherited: 0x38)
struct UStereoLayerFunctionLibrary : UBlueprintFunctionLibrary {

	void ShowSplashScreen(); // Function Engine.StereoLayerFunctionLibrary.ShowSplashScreen // Final|Native|Static|Public|BlueprintCallable // @ game+0x5b75d48
	void SetSplashScreen(struct UTexture* Texture, struct FVector2D Scale, struct FVector2D Offset, bool bShowLoadingMovie, bool bShowOnSet); // Function Engine.StereoLayerFunctionLibrary.SetSplashScreen // Final|Native|Static|Public|HasDefaults|BlueprintCallable // @ game+0x5b758dc
	void HideSplashScreen(); // Function Engine.StereoLayerFunctionLibrary.HideSplashScreen // Final|Native|Static|Public|BlueprintCallable // @ game+0x5b6eff4
	void EnableAutoLoadingSplashScreen(bool InAutoShowEnabled); // Function Engine.StereoLayerFunctionLibrary.EnableAutoLoadingSplashScreen // Final|Native|Static|Public|BlueprintCallable // @ game+0x5b6a650
};

// Class Engine.EngineSubsystem
// Size: 0x40 (Inherited: 0x40)
struct UEngineSubsystem : UDynamicSubsystem {
};

// Class Engine.LocalPlayerSubsystem
// Size: 0x40 (Inherited: 0x40)
struct ULocalPlayerSubsystem : USubsystem {
};

// Class Engine.SubsystemBlueprintLibrary
// Size: 0x38 (Inherited: 0x38)
struct USubsystemBlueprintLibrary : UBlueprintFunctionLibrary {

	struct UWorldSubsystem* GetWorldSubsystem(struct UObject* ContextObject, struct UClass* Class); // Function Engine.SubsystemBlueprintLibrary.GetWorldSubsystem // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b6ed14
	struct ULocalPlayerSubsystem* GetLocalPlayerSubSystemFromPlayerController(struct APlayerController* PlayerController, struct UClass* Class); // Function Engine.SubsystemBlueprintLibrary.GetLocalPlayerSubSystemFromPlayerController // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b6ce74
	struct ULocalPlayerSubsystem* GetLocalPlayerSubsystem(struct UObject* ContextObject, struct UClass* Class); // Function Engine.SubsystemBlueprintLibrary.GetLocalPlayerSubsystem // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b6cf50
	struct UGameInstanceSubsystem* GetGameInstanceSubsystem(struct UObject* ContextObject, struct UClass* Class); // Function Engine.SubsystemBlueprintLibrary.GetGameInstanceSubsystem // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b6c8a0
	struct UEngineSubsystem* GetEngineSubsystem(struct UClass* Class); // Function Engine.SubsystemBlueprintLibrary.GetEngineSubsystem // Final|Native|Static|Public|BlueprintCallable|BlueprintPure // @ game+0x5b6c384
};

// Class Engine.VisualLoggerKismetLibrary
// Size: 0x38 (Inherited: 0x38)
struct UVisualLoggerKismetLibrary : UBlueprintFunctionLibrary {

	void LogText(struct UObject* WorldContextObject, struct FString Text, struct FName LogCategory); // Function Engine.VisualLoggerKismetLibrary.LogText // Final|Native|Static|Public|BlueprintCallable // @ game+0x5b72ac0
	void LogLocation(struct UObject* WorldContextObject, struct FVector Location, struct FString Text, struct FLinearColor ObjectColor, float Radius, struct FName LogCategory); // Function Engine.VisualLoggerKismetLibrary.LogLocation // Final|Native|Static|Public|HasDefaults|BlueprintCallable // @ game+0x5b72858
	void LogBox(struct UObject* WorldContextObject, struct FBox BoxShape, struct FString Text, struct FLinearColor ObjectColor, struct FName LogCategory); // Function Engine.VisualLoggerKismetLibrary.LogBox // Final|Native|Static|Public|HasDefaults|BlueprintCallable // @ game+0x5b72628
};

// Class Engine.PoseWatch
// Size: 0x48 (Inherited: 0x38)
struct UPoseWatch : UObject {
	struct UEdGraphNode* Node; // 0x38(0x08)
	struct FColor PoseWatchColour; // 0x40(0x04)
	char pad_44[0x4]; // 0x44(0x04)
};

// Class Engine.AnimBlueprintGeneratedClass
// Size: 0x460 (Inherited: 0x3f0)
struct UAnimBlueprintGeneratedClass : UBlueprintGeneratedClass {
	char pad_3F0[0x8]; // 0x3f0(0x08)
	struct TArray<struct FBakedAnimationStateMachine> BakedStateMachines; // 0x3f8(0x10)
	struct USkeleton* TargetSkeleton; // 0x408(0x08)
	struct TArray<struct FAnimNotifyEvent> AnimNotifies; // 0x410(0x10)
	int32 RootAnimNodeIndex; // 0x420(0x04)
	char pad_424[0x4]; // 0x424(0x04)
	struct TArray<int32> OrderedSavedPoseIndices; // 0x428(0x10)
	char pad_438[0x18]; // 0x438(0x18)
	struct TArray<struct FName> SyncGroupNames; // 0x450(0x10)
};

// Class Engine.BodySetup
// Size: 0x3b0 (Inherited: 0x38)
struct UBodySetup : UObject {
	struct FKAggregateGeom AggGeom; // 0x38(0x48)
	struct FName BoneName; // 0x80(0x08)
	enum class EPhysicsType PhysicsType; // 0x88(0x01)
	char pad_89[0x3]; // 0x89(0x03)
	char bAlwaysFullAnimWeight : 1; // 0x8c(0x01)
	char bConsiderForBounds : 1; // 0x8c(0x01)
	char bMeshCollideAll : 1; // 0x8c(0x01)
	char bDoubleSidedGeometry : 1; // 0x8c(0x01)
	char bGenerateNonMirroredCollision : 1; // 0x8c(0x01)
	char bSharedCookedData : 1; // 0x8c(0x01)
	char bGenerateMirroredCollision : 1; // 0x8c(0x01)
	char pad_8C_7 : 1; // 0x8c(0x01)
	char pad_8D[0x3]; // 0x8d(0x03)
	struct UPhysicalMaterial* PhysMaterial; // 0x90(0x08)
	enum class EBodyCollisionResponse CollisionReponse; // 0x98(0x01)
	enum class ECollisionTraceFlag CollisionTraceFlag; // 0x99(0x01)
	char pad_9A[0x6]; // 0x9a(0x06)
	struct FBodyInstance DefaultInstance; // 0xa0(0x230)
	struct FWalkableSlopeOverride WalkableSlopeOverride; // 0x2d0(0x10)
	float MinContactOffset; // 0x2e0(0x04)
	float BuildScale; // 0x2e4(0x04)
	struct FVector BuildScale3D; // 0x2e8(0x0c)
	char pad_2F4[0xbc]; // 0x2f4(0xbc)
};

// Class Engine.BodySetup2D
// Size: 0x3e0 (Inherited: 0x3b0)
struct UBodySetup2D : UBodySetup {
	struct FAggregateGeometry2D AggGeom2D; // 0x3b0(0x30)
};

// Class Engine.PhysicsAsset
// Size: 0x118 (Inherited: 0x38)
struct UPhysicsAsset : UObject {
	struct TArray<int32> BoundsBodies; // 0x38(0x10)
	struct TArray<struct USkeletalBodySetup*> SkeletalBodySetups; // 0x48(0x10)
	struct TArray<struct UPhysicsConstraintTemplate*> ConstraintSetup; // 0x58(0x10)
	char pad_68[0xa0]; // 0x68(0xa0)
	struct TArray<struct UBodySetup*> BodySetup; // 0x108(0x10)
};

// Class Engine.SkeletalBodySetup
// Size: 0x3c0 (Inherited: 0x3b0)
struct USkeletalBodySetup : UBodySetup {
	struct TArray<struct FPhysicalAnimationProfile> PhysicalAnimationData; // 0x3b0(0x10)
};

// Class Engine.BoneMaskFilter
// Size: 0x48 (Inherited: 0x38)
struct UBoneMaskFilter : UObject {
	struct TArray<struct FInputBlendPose> BlendPoses; // 0x38(0x10)
};

// Class Engine.BookMark
// Size: 0x60 (Inherited: 0x38)
struct UBookMark : UObject {
	struct FVector Location; // 0x38(0x0c)
	struct FRotator Rotation; // 0x44(0x0c)
	struct TArray<struct FString> HiddenLevels; // 0x50(0x10)
};

// Class Engine.BookMark2D
// Size: 0x48 (Inherited: 0x38)
struct UBookMark2D : UObject {
	float Zoom2D; // 0x38(0x04)
	struct FIntPoint Location; // 0x3c(0x08)
	char pad_44[0x4]; // 0x44(0x04)
};

// Class Engine.Breakpoint
// Size: 0x50 (Inherited: 0x38)
struct UBreakpoint : UObject {
	char bEnabled : 1; // 0x38(0x01)
	char pad_38_1 : 7; // 0x38(0x01)
	char pad_39[0x7]; // 0x39(0x07)
	struct UEdGraphNode* Node; // 0x40(0x08)
	char bStepOnce : 1; // 0x48(0x01)
	char bStepOnce_WasPreviouslyDisabled : 1; // 0x48(0x01)
	char bStepOnce_RemoveAfterHit : 1; // 0x48(0x01)
	char pad_48_3 : 5; // 0x48(0x01)
	char pad_49[0x7]; // 0x49(0x07)
};

// Class Engine.BrushBuilder
// Size: 0x90 (Inherited: 0x38)
struct UBrushBuilder : UObject {
	struct FString BitmapFilename; // 0x38(0x10)
	struct FString Tooltip; // 0x48(0x10)
	char NotifyBadParams : 1; // 0x58(0x01)
	char pad_58_1 : 7; // 0x58(0x01)
	char pad_59[0x7]; // 0x59(0x07)
	struct TArray<struct FVector> Vertices; // 0x60(0x10)
	struct TArray<struct FBuilderPoly> Polys; // 0x70(0x10)
	struct FName Layer; // 0x80(0x08)
	char MergeCoplanars : 1; // 0x88(0x01)
	char pad_88_1 : 7; // 0x88(0x01)
	char pad_89[0x7]; // 0x89(0x07)
};

// Class Engine.ButtonStyleAsset
// Size: 0x2e0 (Inherited: 0x38)
struct UButtonStyleAsset : UObject {
	struct FButtonStyle ButtonStyle; // 0x38(0x2a8)
};

// Class Engine.CameraAnim
// Size: 0x5f0 (Inherited: 0x38)
struct UCameraAnim : UObject {
	struct UInterpGroup* CameraInterpGroup; // 0x38(0x08)
	float AnimLength; // 0x40(0x04)
	struct FBox BoundingBox; // 0x44(0x1c)
	char bRelativeToInitialTransform : 1; // 0x60(0x01)
	char bRelativeToInitialFOV : 1; // 0x60(0x01)
	char pad_60_2 : 6; // 0x60(0x01)
	char pad_61[0x3]; // 0x61(0x03)
	float BaseFOV; // 0x64(0x04)
	char pad_68[0x8]; // 0x68(0x08)
	struct FPostProcessSettings BasePostProcessSettings; // 0x70(0x570)
	float BasePostProcessBlendWeight; // 0x5e0(0x04)
	char pad_5E4[0xc]; // 0x5e4(0x0c)
};

// Class Engine.CameraAnimInst
// Size: 0x120 (Inherited: 0x38)
struct UCameraAnimInst : UObject {
	struct UCameraAnim* CamAnim; // 0x38(0x08)
	struct UInterpGroupInst* InterpGroupInst; // 0x40(0x08)
	char pad_48[0x18]; // 0x48(0x18)
	float PlayRate; // 0x60(0x04)
	char pad_64[0x14]; // 0x64(0x14)
	struct UInterpTrackMove* MoveTrack; // 0x78(0x08)
	struct UInterpTrackInstMove* MoveInst; // 0x80(0x08)
	enum class ECameraAnimPlaySpace PlaySpace; // 0x88(0x01)
	char pad_89[0x97]; // 0x89(0x97)

	void Stop(bool bImmediate); // Function Engine.CameraAnimInst.Stop // Final|Native|Public|BlueprintCallable // @ game+0x5b76604
	void SetScale(float NewDuration); // Function Engine.CameraAnimInst.SetScale // Final|Native|Public|BlueprintCallable // @ game+0x5b75730
	void SetDuration(float NewDuration); // Function Engine.CameraAnimInst.SetDuration // Final|Native|Public|BlueprintCallable // @ game+0x5b74e94
};

// Class Engine.CameraModifier
// Size: 0x58 (Inherited: 0x38)
struct UCameraModifier : UObject {
	char bDebug : 1; // 0x38(0x01)
	char bExclusive : 1; // 0x38(0x01)
	char pad_38_2 : 6; // 0x38(0x01)
	char pad_39[0x3]; // 0x39(0x03)
	bool Priority; // 0x3c(0x01)
	char pad_3D[0x3]; // 0x3d(0x03)
	struct APlayerCameraManager* CameraOwner; // 0x40(0x08)
	float AlphaInTime; // 0x48(0x04)
	float AlphaOutTime; // 0x4c(0x04)
	float ALPHA; // 0x50(0x04)
	char pad_54[0x4]; // 0x54(0x04)

	bool IsDisabled(); // Function Engine.CameraModifier.IsDisabled // Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b67954
	struct AActor* GetViewTarget(); // Function Engine.CameraModifier.GetViewTarget // Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x2d23b0
	void EnableModifier(); // Function Engine.CameraModifier.EnableModifier // Native|Public|BlueprintCallable // @ game+0x5b6a8c8
	void DisableModifier(bool bImmediate); // Function Engine.CameraModifier.DisableModifier // Native|Public|BlueprintCallable // @ game+0x5b6a440
	void BlueprintModifyPostProcess(float DeltaTime, float PostProcessBlendWeight, struct FPostProcessSettings PostProcessSettings); // Function Engine.CameraModifier.BlueprintModifyPostProcess // BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent // @ game+0x33e45c
	void BlueprintModifyCamera(float DeltaTime, struct FVector ViewLocation, struct FRotator ViewRotation, float FOV, struct FVector NewViewLocation, struct FRotator NewViewRotation, float NewFOV); // Function Engine.CameraModifier.BlueprintModifyCamera // BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintEvent // @ game+0x33e45c
};

// Class Engine.CameraModifier_CameraShake
// Size: 0x70 (Inherited: 0x58)
struct UCameraModifier_CameraShake : UCameraModifier {
	struct TArray<struct UCameraShake*> ActiveShakes; // 0x58(0x10)
	float SplitScreenShakeScale; // 0x68(0x04)
	char pad_6C[0x4]; // 0x6c(0x04)
};

// Class Engine.Canvas
// Size: 0x300 (Inherited: 0x38)
struct UCanvas : UObject {
	float OrgX; // 0x38(0x04)
	float OrgY; // 0x3c(0x04)
	float ClipX; // 0x40(0x04)
	float ClipY; // 0x44(0x04)
	struct FColor DrawColor; // 0x48(0x04)
	char bCenterX : 1; // 0x4c(0x01)
	char bCenterY : 1; // 0x4c(0x01)
	char bNoSmooth : 1; // 0x4c(0x01)
	char pad_4C_3 : 5; // 0x4c(0x01)
	char pad_4D[0x3]; // 0x4d(0x03)
	int32 SizeX; // 0x50(0x04)
	int32 SizeY; // 0x54(0x04)
	char pad_58[0x8]; // 0x58(0x08)
	struct FPlane ColorModulate; // 0x60(0x10)
	struct UTexture2D* DefaultTexture; // 0x70(0x08)
	struct UTexture2D* GradientTexture0; // 0x78(0x08)
	struct UReporterGraph* ReporterGraph; // 0x80(0x08)
	char pad_88[0x278]; // 0x88(0x278)

	struct FVector2D K2_TextSize(struct UFont* RenderFont, struct FString RenderText, struct FVector2D Scale); // Function Engine.Canvas.K2_TextSize // Final|Native|Public|HasDefaults|BlueprintCallable // @ game+0x5b71c94
	struct FVector2D K2_StrLen(struct UFont* RenderFont, struct FString RenderText); // Function Engine.Canvas.K2_StrLen // Final|Native|Public|HasDefaults|BlueprintCallable // @ game+0x5b71b68
	struct FVector K2_Project(struct FVector WorldLocation); // Function Engine.Canvas.K2_Project // Final|Native|Public|HasDefaults|BlueprintCallable // @ game+0x5b7186c
	void K2_DrawTriangle(struct UTexture* RenderTexture, struct TArray<struct FCanvasUVTri> Triangles); // Function Engine.Canvas.K2_DrawTriangle // Final|Native|Public|BlueprintCallable // @ game+0x5b70f94
	void K2_DrawTexture(struct UTexture* RenderTexture, struct FVector2D ScreenPosition, struct FVector2D ScreenSize, struct FVector2D CoordinatePosition, struct FVector2D CoordinateSize, struct FLinearColor RenderColor, enum class EBlendMode BlendMode, float Rotation, struct FVector2D PivotPoint); // Function Engine.Canvas.K2_DrawTexture // Final|Native|Public|HasDefaults|BlueprintCallable // @ game+0x5b70c78
	void K2_DrawText(struct UFont* RenderFont, struct FString RenderText, struct FVector2D ScreenPosition, struct FLinearColor RenderColor, float Kerning, struct FLinearColor ShadowColor, struct FVector2D ShadowOffset, bool bCentreX, bool bCentreY, bool bOutlined, struct FLinearColor OutlineColor); // Function Engine.Canvas.K2_DrawText // Final|Native|Public|HasDefaults|BlueprintCallable // @ game+0x5b70854
	void K2_DrawPolygon(struct UTexture* RenderTexture, struct FVector2D ScreenPosition, struct FVector2D Radius, int32 NumberOfSides, struct FLinearColor RenderColor); // Function Engine.Canvas.K2_DrawPolygon // Final|Native|Public|HasDefaults|BlueprintCallable // @ game+0x5b70688
	void K2_DrawMaterialTriangle(struct UMaterialInterface* RenderMaterial, struct TArray<struct FCanvasUVTri> Triangles); // Function Engine.Canvas.K2_DrawMaterialTriangle // Final|Native|Public|BlueprintCallable // @ game+0x5b70550
	void K2_DrawMaterial(struct UMaterialInterface* RenderMaterial, struct FVector2D ScreenPosition, struct FVector2D ScreenSize, struct FVector2D CoordinatePosition, struct FVector2D CoordinateSize, float Rotation, struct FVector2D PivotPoint); // Function Engine.Canvas.K2_DrawMaterial // Final|Native|Public|HasDefaults|BlueprintCallable // @ game+0x5b702e4
	void K2_DrawLine(struct FVector2D ScreenPositionA, struct FVector2D ScreenPositionB, float Thickness, struct FLinearColor RenderColor); // Function Engine.Canvas.K2_DrawLine // Final|Native|Public|HasDefaults|BlueprintCallable // @ game+0x5b70190
	void K2_DrawBox(struct FVector2D ScreenPosition, struct FVector2D ScreenSize, float Thickness); // Function Engine.Canvas.K2_DrawBox // Final|Native|Public|HasDefaults|BlueprintCallable // @ game+0x5b70068
	void K2_DrawBorder(struct UTexture* BorderTexture, struct UTexture* BackgroundTexture, struct UTexture* LeftBorderTexture, struct UTexture* RightBorderTexture, struct UTexture* TopBorderTexture, struct UTexture* BottomBorderTexture, struct FVector2D ScreenPosition, struct FVector2D ScreenSize, struct FVector2D CoordinatePosition, struct FVector2D CoordinateSize, struct FLinearColor RenderColor, struct FVector2D BorderScale, struct FVector2D BackgroundScale, float Rotation, struct FVector2D PivotPoint, struct FVector2D CornerSize); // Function Engine.Canvas.K2_DrawBorder // Final|Native|Public|HasDefaults|BlueprintCallable // @ game+0x5b6fb14
	void K2_Deproject(struct FVector2D ScreenPosition, struct FVector WorldOrigin, struct FVector WorldDirection); // Function Engine.Canvas.K2_Deproject // Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b6f9c0
};

// Class Engine.ControlChannel
// Size: 0x90 (Inherited: 0x78)
struct UControlChannel : UChannel {
	char pad_78[0x18]; // 0x78(0x18)
};

// Class Engine.VoiceChannel
// Size: 0x88 (Inherited: 0x78)
struct UVoiceChannel : UChannel {
	char pad_78[0x10]; // 0x78(0x10)
};

// Class Engine.CheckBoxStyleAsset
// Size: 0x618 (Inherited: 0x38)
struct UCheckBoxStyleAsset : UObject {
	struct FCheckBoxStyle CheckBoxStyle; // 0x38(0x5e0)
};

// Class Engine.Commandlet
// Size: 0x90 (Inherited: 0x38)
struct UCommandlet : UObject {
	struct FString HelpDescription; // 0x38(0x10)
	struct FString HelpUsage; // 0x48(0x10)
	struct FString HelpWebLink; // 0x58(0x10)
	struct TArray<struct FString> HelpParamNames; // 0x68(0x10)
	struct TArray<struct FString> HelpParamDescriptions; // 0x78(0x10)
	char IsServer : 1; // 0x88(0x01)
	char IsClient : 1; // 0x88(0x01)
	char IsEditor : 1; // 0x88(0x01)
	char LogToConsole : 1; // 0x88(0x01)
	char ShowErrorCount : 1; // 0x88(0x01)
	char pad_88_5 : 3; // 0x88(0x01)
	char pad_89[0x7]; // 0x89(0x07)
};

// Class Engine.PluginCommandlet
// Size: 0xb0 (Inherited: 0x90)
struct UPluginCommandlet : UCommandlet {
	char pad_90[0x20]; // 0x90(0x20)
};

// Class Engine.SmokeTestCommandlet
// Size: 0x90 (Inherited: 0x90)
struct USmokeTestCommandlet : UCommandlet {
};

// Class Engine.ControlRigInterface
// Size: 0x38 (Inherited: 0x38)
struct UControlRigInterface : UInterface {
};

// Class Engine.CurveLinearColor
// Size: 0x200 (Inherited: 0x40)
struct UCurveLinearColor : UCurveBase {
	struct FRichCurve FloatCurves[0x04]; // 0x40(0x1c0)

	struct FLinearColor GetLinearColorValue(float InTime); // Function Engine.CurveLinearColor.GetLinearColorValue // Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5b6cdc4
};

// Class Engine.CurveVector
// Size: 0x190 (Inherited: 0x40)
struct UCurveVector : UCurveBase {
	struct FRichCurve FloatCurves[0x03]; // 0x40(0x150)

	struct FVector GetVectorValue(float InTime); // Function Engine.CurveVector.GetVectorValue // Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5b6ec34
};

// Class Engine.CurveEdPresetCurve
// Size: 0x38 (Inherited: 0x38)
struct UCurveEdPresetCurve : UObject {
};

// Class Engine.CurveSourceInterface
// Size: 0x38 (Inherited: 0x38)
struct UCurveSourceInterface : UInterface {

	float GetCurveValue(struct FName CurveName); // Function Engine.CurveSourceInterface.GetCurveValue // Native|Event|Public|BlueprintEvent|Const // @ game+0x5b6c068
	void GetCurves(struct TArray<struct FNamedCurveValue> OutValues); // Function Engine.CurveSourceInterface.GetCurves // Native|Event|Public|HasOutParms|BlueprintEvent|Const // @ game+0x5b6c10c
	struct FName GetBindingName(); // Function Engine.CurveSourceInterface.GetBindingName // Native|Event|Public|BlueprintEvent|Const // @ game+0x4d23a30
};

// Class Engine.CurveTable
// Size: 0x90 (Inherited: 0x38)
struct UCurveTable : UObject {
	char pad_38[0x58]; // 0x38(0x58)
};

// Class Engine.PreviewMeshCollection
// Size: 0x58 (Inherited: 0x40)
struct UPreviewMeshCollection : UDataAsset {
	struct USkeleton* Skeleton; // 0x40(0x08)
	struct TArray<struct FPreviewMeshCollectionEntry> SkeletalMeshes; // 0x48(0x10)
};

// Class Engine.PrimaryAssetLabel
// Size: 0x78 (Inherited: 0x40)
struct UPrimaryAssetLabel : UPrimaryDataAsset {
	struct FPrimaryAssetRules Rules; // 0x40(0x10)
	char bLabelAssetsInMyDirectory : 1; // 0x50(0x01)
	char pad_50_1 : 7; // 0x50(0x01)
	char pad_51[0x7]; // 0x51(0x07)
	struct TArray<struct UObject*> ExplicitAssets; // 0x58(0x10)
	struct TArray<struct UClass*> ExplicitBlueprints; // 0x68(0x10)
};

// Class Engine.TireType
// Size: 0x48 (Inherited: 0x40)
struct UTireType : UDataAsset {
	float FrictionScale; // 0x40(0x04)
	char pad_44[0x4]; // 0x44(0x04)
};

// Class Engine.DestructibleFractureSettings
// Size: 0xc8 (Inherited: 0x38)
struct UDestructibleFractureSettings : UObject {
	int32 CellSiteCount; // 0x38(0x04)
	struct FFractureMaterial FractureMaterialDesc; // 0x3c(0x24)
	int32 RandomSeed; // 0x60(0x04)
	char pad_64[0x4]; // 0x64(0x04)
	struct TArray<struct FVector> VoronoiSites; // 0x68(0x10)
	int32 OriginalSubmeshCount; // 0x78(0x04)
	char pad_7C[0x4]; // 0x7c(0x04)
	struct TArray<struct UMaterialInterface*> Materials; // 0x80(0x10)
	struct TArray<struct FDestructibleChunkParameters> ChunkParameters; // 0x90(0x10)
	char pad_A0[0x28]; // 0xa0(0x28)
};

// Class Engine.AnimationSettings
// Size: 0x80 (Inherited: 0x48)
struct UAnimationSettings : UDeveloperSettings {
	int32 CompressCommandletVersion; // 0x48(0x04)
	char pad_4C[0x4]; // 0x4c(0x04)
	struct TArray<struct FString> KeyEndEffectorsMatchNameArray; // 0x50(0x10)
	struct UClass* DefaultCompressionAlgorithm; // 0x60(0x08)
	enum class AnimationCompressionFormat RotationCompressionFormat; // 0x68(0x01)
	enum class AnimationCompressionFormat TranslationCompressionFormat; // 0x69(0x01)
	char pad_6A[0x2]; // 0x6a(0x02)
	float MaxCurveError; // 0x6c(0x04)
	float AlternativeCompressionThreshold; // 0x70(0x04)
	bool ForceRecompression; // 0x74(0x01)
	bool bOnlyCheckForMissingSkeletalMeshes; // 0x75(0x01)
	bool bForceBelowThreshold; // 0x76(0x01)
	bool bFirstRecompressUsingCurrentOrDefault; // 0x77(0x01)
	bool bRaiseMaxErrorToExisting; // 0x78(0x01)
	bool bTryFixedBitwiseCompression; // 0x79(0x01)
	bool bTryPerTrackBitwiseCompression; // 0x7a(0x01)
	bool bTryLinearKeyRemovalCompression; // 0x7b(0x01)
	bool bTryIntervalKeyRemoval; // 0x7c(0x01)
	bool bEnablePerformanceLog; // 0x7d(0x01)
	bool bStripAnimationDataOnDedicatedServer; // 0x7e(0x01)
	char pad_7F[0x1]; // 0x7f(0x01)
};

// Class Engine.AssetManagerSettings
// Size: 0xb0 (Inherited: 0x48)
struct UAssetManagerSettings : UDeveloperSettings {
	struct TArray<struct FPrimaryAssetTypeInfo> PrimaryAssetTypesToScan; // 0x48(0x10)
	struct TArray<struct FDirectoryPath> DirectoriesToExclude; // 0x58(0x10)
	struct TArray<struct FPrimaryAssetRulesOverride> PrimaryAssetRules; // 0x68(0x10)
	bool bOnlyCookProductionAssets; // 0x78(0x01)
	char pad_79[0x7]; // 0x79(0x07)
	struct TArray<struct FAssetManagerRedirect> PrimaryAssetIdRedirects; // 0x80(0x10)
	struct TArray<struct FAssetManagerRedirect> PrimaryAssetTypeRedirects; // 0x90(0x10)
	struct TArray<struct FAssetManagerRedirect> AssetPathRedirects; // 0xa0(0x10)
};

// Class Engine.AudioSettings
// Size: 0xc0 (Inherited: 0x48)
struct UAudioSettings : UDeveloperSettings {
	struct FStringAssetReference DefaultSoundClassName; // 0x48(0x10)
	struct FStringAssetReference DefaultSoundConcurrencyName; // 0x58(0x10)
	struct FStringAssetReference DefaultBaseSoundMix; // 0x68(0x10)
	struct FStringAssetReference VoiPSoundClass; // 0x78(0x10)
	float LowPassFilterResonance; // 0x88(0x04)
	int32 MaximumConcurrentStreams; // 0x8c(0x04)
	struct TArray<struct FAudioQualitySettings> QualityLevels; // 0x90(0x10)
	char bAllowVirtualizedSounds : 1; // 0xa0(0x01)
	char bDisableMasterEQ : 1; // 0xa0(0x01)
	char bDisableMasterReverb : 1; // 0xa0(0x01)
	char bAllowCenterChannel3DPanning : 1; // 0xa0(0x01)
	char pad_A0_4 : 4; // 0xa0(0x01)
	char pad_A1[0x7]; // 0xa1(0x07)
	struct FString DialogueFilenameFormat; // 0xa8(0x10)
	char pad_B8[0x8]; // 0xb8(0x08)
};

// Class Engine.ExcludedPackageSettings
// Size: 0x68 (Inherited: 0x48)
struct UExcludedPackageSettings : UDeveloperSettings {
	struct TArray<struct FString> CommonExcludedPackages; // 0x48(0x10)
	struct TArray<struct FString> MinSpecExcludedPackages; // 0x58(0x10)
};

// Class Engine.StreamingSettings
// Size: 0x80 (Inherited: 0x48)
struct UStreamingSettings : UDeveloperSettings {
	char AsyncLoadingThreadEnabled : 1; // 0x48(0x01)
	char WarnIfTimeLimitExceeded : 1; // 0x48(0x01)
	char pad_48_2 : 6; // 0x48(0x01)
	char pad_49[0x3]; // 0x49(0x03)
	float TimeLimitExceededMultiplier; // 0x4c(0x04)
	float TimeLimitExceededMinTime; // 0x50(0x04)
	int32 MinBulkDataSizeForAsyncLoading; // 0x54(0x04)
	float AsyncIOBandwidthLimit; // 0x58(0x04)
	char UseBackgroundLevelStreaming : 1; // 0x5c(0x01)
	char AsyncLoadingUseFullTimeLimit : 1; // 0x5c(0x01)
	char LoadAllStreamingLevels : 1; // 0x5c(0x01)
	char pad_5C_3 : 5; // 0x5c(0x01)
	char pad_5D[0x3]; // 0x5d(0x03)
	float AsyncLoadingTimeLimit; // 0x60(0x04)
	float PriorityAsyncLoadingExtraTime; // 0x64(0x04)
	float LevelStreamingActorsUpdateTimeLimit; // 0x68(0x04)
	int32 LevelStreamingComponentsRegistrationGranularity; // 0x6c(0x04)
	float LevelStreamingUnregisterComponentsTimeLimit; // 0x70(0x04)
	int32 LevelStreamingComponentsUnregistrationGranularity; // 0x74(0x04)
	char EventDrivenLoaderEnabled : 1; // 0x78(0x01)
	char pad_78_1 : 7; // 0x78(0x01)
	char pad_79[0x7]; // 0x79(0x07)
};

// Class Engine.GarbageCollectionSettings
// Size: 0x68 (Inherited: 0x48)
struct UGarbageCollectionSettings : UDeveloperSettings {
	float TimeBetweenPurgingPendingKillObjects; // 0x48(0x04)
	char FlushStreamingOnGC : 1; // 0x4c(0x01)
	char AllowParallelGC : 1; // 0x4c(0x01)
	char CreateGCClusters : 1; // 0x4c(0x01)
	char MergeGCClusters : 1; // 0x4c(0x01)
	char ActorClusteringEnabled : 1; // 0x4c(0x01)
	char BlueprintClusteringEnabled : 1; // 0x4c(0x01)
	char pad_4C_6 : 2; // 0x4c(0x01)
	char pad_4D[0x3]; // 0x4d(0x03)
	int32 NumRetriesBeforeForcingGC; // 0x50(0x04)
	int32 MaxObjectsNotConsideredByGC; // 0x54(0x04)
	int32 SizeOfPermanentObjectPool; // 0x58(0x04)
	int32 MaxObjectsInGame; // 0x5c(0x04)
	int32 MaxObjectsInEditor; // 0x60(0x04)
	char pad_64[0x4]; // 0x64(0x04)
};

// Class Engine.MeshSimplificationSettings
// Size: 0x50 (Inherited: 0x48)
struct UMeshSimplificationSettings : UDeveloperSettings {
	struct FName MeshReductionModuleName; // 0x48(0x08)
};

// Class Engine.NetworkSettings
// Size: 0x58 (Inherited: 0x48)
struct UNetworkSettings : UDeveloperSettings {
	char bVerifyPeer : 1; // 0x48(0x01)
	char bEnableMultiplayerWorldOriginRebasing : 1; // 0x48(0x01)
	char pad_48_2 : 6; // 0x48(0x01)
	char pad_49[0x3]; // 0x49(0x03)
	int32 MaxRepArraySize; // 0x4c(0x04)
	int32 MaxRepArrayMemory; // 0x50(0x04)
	char pad_54[0x4]; // 0x54(0x04)
};

// Class Engine.PhysicsSettings
// Size: 0xf8 (Inherited: 0x48)
struct UPhysicsSettings : UDeveloperSettings {
	float DefaultGravityZ; // 0x48(0x04)
	float DefaultTerminalVelocity; // 0x4c(0x04)
	float DefaultFluidFriction; // 0x50(0x04)
	int32 SimulateScratchMemorySize; // 0x54(0x04)
	int32 RagdollAggregateThreshold; // 0x58(0x04)
	float TriangleMeshTriangleMinAreaThreshold; // 0x5c(0x04)
	bool bEnableComplexForSim; // 0x60(0x01)
	bool bEnableComplexForSimOnDedicatedServer; // 0x61(0x01)
	bool bEnablePCM; // 0x62(0x01)
	bool bEnableStabilization; // 0x63(0x01)
	bool bWarnMissingLocks; // 0x64(0x01)
	bool bEnable2DPhysics; // 0x65(0x01)
	enum class ESettingsLockedAxis LockedAxis; // 0x66(0x01)
	enum class ESettingsDOF DefaultDegreesOfFreedom; // 0x67(0x01)
	float BounceThresholdVelocity; // 0x68(0x04)
	enum class EFrictionCombineMode FrictionCombineMode; // 0x6c(0x01)
	enum class EFrictionCombineMode RestitutionCombineMode; // 0x6d(0x01)
	char pad_6E[0x2]; // 0x6e(0x02)
	float MaxAngularVelocity; // 0x70(0x04)
	float MaxDepenetrationVelocity; // 0x74(0x04)
	float ContactOffsetMultiplier; // 0x78(0x04)
	float MinContactOffset; // 0x7c(0x04)
	float MaxContactOffset; // 0x80(0x04)
	bool bSimulateSkeletalMeshOnDedicatedServer; // 0x84(0x01)
	enum class ECollisionTraceFlag DefaultShapeComplexity; // 0x85(0x01)
	bool bDefaultHasComplexCollision; // 0x86(0x01)
	bool bSuppressFaceRemapTable; // 0x87(0x01)
	bool bSupportUVFromHitResults; // 0x88(0x01)
	bool bDisableActiveActors; // 0x89(0x01)
	bool bDisableCCD; // 0x8a(0x01)
	char pad_8B[0x1]; // 0x8b(0x01)
	float MaxPhysicsDeltaTime; // 0x8c(0x04)
	bool bSubstepping; // 0x90(0x01)
	char pad_91[0x3]; // 0x91(0x03)
	float MaxSubstepDeltaTime; // 0x94(0x04)
	int32 MaxSubsteps; // 0x98(0x04)
	float SyncSceneSmoothingFactor; // 0x9c(0x04)
	float InitialAverageFrameRate; // 0xa0(0x04)
	float MaxPhysicsDeltaTimeOnDedicatedServer; // 0xa4(0x04)
	bool bSubsteppingOnDedicatedServer; // 0xa8(0x01)
	char pad_A9[0x3]; // 0xa9(0x03)
	float MaxSubstepDeltaTimeOnDedicatedServer; // 0xac(0x04)
	int32 MaxSubstepsOnDedicatedServer; // 0xb0(0x04)
	float SyncSceneSmoothingFactorOnDedicatedServer; // 0xb4(0x04)
	float InitialAverageFrameRateOnDedicatedServer; // 0xb8(0x04)
	char pad_BC[0x4]; // 0xbc(0x04)
	struct TArray<struct FPhysicalSurfaceName> PhysicalSurfaces; // 0xc0(0x10)
	struct FBroadphaseSettings DefaultBroadphaseSettings; // 0xd0(0x28)
};

// Class Engine.RendererSettings
// Size: 0xd0 (Inherited: 0x48)
struct URendererSettings : UDeveloperSettings {
	char bMobileHDR : 1; // 0x48(0x01)
	char bMobileDisableVertexFog : 1; // 0x48(0x01)
	char pad_48_2 : 6; // 0x48(0x01)
	char pad_49[0x3]; // 0x49(0x03)
	int32 MaxMobileCascades; // 0x4c(0x04)
	enum class EMobileMSAASampleCount MobileMSAASampleCount; // 0x50(0x01)
	char pad_51[0x3]; // 0x51(0x03)
	char bDiscardUnusedQualityLevels : 1; // 0x54(0x01)
	char bOcclusionCulling : 1; // 0x54(0x01)
	char pad_54_2 : 6; // 0x54(0x01)
	char pad_55[0x3]; // 0x55(0x03)
	float MinScreenRadiusForLights; // 0x58(0x04)
	float MinScreenRadiusForEarlyZPass; // 0x5c(0x04)
	float MinScreenRadiusForCSMdepth; // 0x60(0x04)
	char bPrecomputedVisibilityWarning : 1; // 0x64(0x01)
	char bTextureStreaming : 1; // 0x64(0x01)
	char bUseDXT5NormalMaps : 1; // 0x64(0x01)
	char bClearCoatEnableSecondNormal : 1; // 0x64(0x01)
	char pad_64_4 : 4; // 0x64(0x01)
	char pad_65[0x3]; // 0x65(0x03)
	int32 ReflectionCaptureResolution; // 0x68(0x04)
	char ReflectionEnvironmentLightmapMixBasedOnRoughness : 1; // 0x6c(0x01)
	char bForwardShading : 1; // 0x6c(0x01)
	char bVertexFoggingForOpaque : 1; // 0x6c(0x01)
	char bAllowStaticLighting : 1; // 0x6c(0x01)
	char bUseNormalMapsForStaticLighting : 1; // 0x6c(0x01)
	char bGenerateMeshDistanceFields : 1; // 0x6c(0x01)
	char bEightBitMeshDistanceFields : 1; // 0x6c(0x01)
	char bGenerateLandscapeGIData : 1; // 0x6c(0x01)
	char bCompressMeshDistanceFields : 1; // 0x6d(0x01)
	char pad_6D_1 : 7; // 0x6d(0x01)
	char pad_6E[0x2]; // 0x6e(0x02)
	float TessellationAdaptivePixelsPerTriangle; // 0x70(0x04)
	char bSeparateTranslucency : 1; // 0x74(0x01)
	char pad_74_1 : 7; // 0x74(0x01)
	char pad_75[0x3]; // 0x75(0x03)
	enum class ETranslucentSortPolicy TranslucentSortPolicy; // 0x78(0x01)
	char pad_79[0x3]; // 0x79(0x03)
	struct FVector TranslucentSortAxis; // 0x7c(0x0c)
	enum class ECustomDepthStencil CustomDepthStencil; // 0x88(0x01)
	char pad_89[0x3]; // 0x89(0x03)
	char bCustomDepthTaaJitter : 1; // 0x8c(0x01)
	char bDefaultFeatureBloom : 1; // 0x8c(0x01)
	char bDefaultFeatureAmbientOcclusion : 1; // 0x8c(0x01)
	char bDefaultFeatureAmbientOcclusionStaticFraction : 1; // 0x8c(0x01)
	char bDefaultFeatureAutoExposure : 1; // 0x8c(0x01)
	char pad_8C_5 : 3; // 0x8c(0x01)
	char pad_8D[0x3]; // 0x8d(0x03)
	enum class EAutoExposureMethodUI DefaultFeatureAutoExposure; // 0x90(0x01)
	char pad_91[0x3]; // 0x91(0x03)
	char bDefaultFeatureMotionBlur : 1; // 0x94(0x01)
	char bDefaultFeatureLensFlare : 1; // 0x94(0x01)
	char bTemporalUpsampling : 1; // 0x94(0x01)
	char pad_94_3 : 5; // 0x94(0x01)
	char pad_95[0x3]; // 0x95(0x03)
	enum class EAntiAliasingMethod DefaultFeatureAntiAliasing; // 0x98(0x01)
	char pad_99[0x3]; // 0x99(0x03)
	char bStencilForLODDither : 1; // 0x9c(0x01)
	char pad_9C_1 : 7; // 0x9c(0x01)
	char pad_9D[0x3]; // 0x9d(0x03)
	enum class EEarlyZPass EarlyZPass; // 0xa0(0x01)
	char pad_A1[0x3]; // 0xa1(0x03)
	char bEarlyZPassMovable : 1; // 0xa4(0x01)
	char bEarlyZPassOnlyMaterialMasking : 1; // 0xa4(0x01)
	char bEarlyZPassForceFull : 1; // 0xa4(0x01)
	char bDBuffer : 1; // 0xa4(0x01)
	char pad_A4_4 : 4; // 0xa4(0x01)
	char pad_A5[0x3]; // 0xa5(0x03)
	enum class EClearSceneOptions ClearSceneMethod; // 0xa8(0x01)
	char pad_A9[0x3]; // 0xa9(0x03)
	char bBasePassOutputsVelocity : 1; // 0xac(0x01)
	char bSelectiveBasePassOutputs : 1; // 0xac(0x01)
	char bDefaultParticleCutouts : 1; // 0xac(0x01)
	char bGlobalClipPlane : 1; // 0xac(0x01)
	char pad_AC_4 : 4; // 0xac(0x01)
	char pad_AD[0x3]; // 0xad(0x03)
	enum class EGBufferFormat GBufferFormat; // 0xb0(0x01)
	char pad_B1[0x3]; // 0xb1(0x03)
	char bUseGPUMorphTargets : 1; // 0xb4(0x01)
	char bNvidiaAftermathEnabled : 1; // 0xb4(0x01)
	char bInstancedStereo : 1; // 0xb4(0x01)
	char bMultiView : 1; // 0xb4(0x01)
	char bMobileMultiView : 1; // 0xb4(0x01)
	char bMobileMultiViewDirect : 1; // 0xb4(0x01)
	char bMonoscopicFarField : 1; // 0xb4(0x01)
	char pad_B4_7 : 1; // 0xb4(0x01)
	char pad_B5[0x3]; // 0xb5(0x03)
	float WireframeCullThreshold; // 0xb8(0x04)
	char bSupportStationarySkylight : 1; // 0xbc(0x01)
	char bSupportLowQualityLightmaps : 1; // 0xbc(0x01)
	char bSupportPointLightWholeSceneShadows : 1; // 0xbc(0x01)
	char bSupportAtmosphericFog : 1; // 0xbc(0x01)
	char bSupportSkinCacheShaders : 1; // 0xbc(0x01)
	char bMobileEnableStaticAndCSMShadowReceivers : 1; // 0xbc(0x01)
	char bMobileAllowDistanceFieldShadows : 1; // 0xbc(0x01)
	char bMobileAllowMovableDirectionalLights : 1; // 0xbc(0x01)
	char pad_BD[0x3]; // 0xbd(0x03)
	uint32 MobileNumDynamicPointLights; // 0xc0(0x04)
	char bMobileDynamicPointLightsUseStaticBranch : 1; // 0xc4(0x01)
	char pad_C4_1 : 7; // 0xc4(0x01)
	char pad_C5[0x3]; // 0xc5(0x03)
	float SkinCacheSceneMemoryLimitInMB; // 0xc8(0x04)
	char pad_CC[0x4]; // 0xcc(0x04)
};

// Class Engine.RendererOverrideSettings
// Size: 0x50 (Inherited: 0x48)
struct URendererOverrideSettings : UDeveloperSettings {
	char bSupportAllShaderPermutations : 1; // 0x48(0x01)
	char bForceRecomputeTangents : 1; // 0x48(0x01)
	char pad_48_2 : 6; // 0x48(0x01)
	char pad_49[0x7]; // 0x49(0x07)
};

// Class Engine.UserInterfaceSettings
// Size: 0x218 (Inherited: 0x48)
struct UUserInterfaceSettings : UDeveloperSettings {
	enum class ERenderFocusRule RenderFocusRule; // 0x48(0x01)
	char pad_49[0x7]; // 0x49(0x07)
	struct TMap<enum class EMouseCursor, struct FHardwareCursorReference> HardwareCursors; // 0x50(0x50)
	struct TMap<enum class EMouseCursor, struct FStringClassReference> SoftwareCursors; // 0xa0(0x50)
	struct FStringClassReference DefaultCursor; // 0xf0(0x10)
	struct FStringClassReference TextEditBeamCursor; // 0x100(0x10)
	struct FStringClassReference CrosshairsCursor; // 0x110(0x10)
	struct FStringClassReference HandCursor; // 0x120(0x10)
	struct FStringClassReference GrabHandCursor; // 0x130(0x10)
	struct FStringClassReference GrabHandClosedCursor; // 0x140(0x10)
	struct FStringClassReference SlashedCircleCursor; // 0x150(0x10)
	float ApplicationScale; // 0x160(0x04)
	enum class EUIScalingRule UIScaleRule; // 0x164(0x01)
	char pad_165[0x3]; // 0x165(0x03)
	struct FStringClassReference CustomScalingRuleClass; // 0x168(0x10)
	struct FRuntimeFloatCurve UIScaleCurve; // 0x178(0x78)
	bool bLoadWidgetsOnDedicatedServer; // 0x1f0(0x01)
	char pad_1F1[0x7]; // 0x1f1(0x07)
	struct TArray<struct UObject*> CursorClasses; // 0x1f8(0x10)
	struct UClass* CustomScalingRuleClassInstance; // 0x208(0x08)
	struct UDPICustomScalingRule* CustomScalingRule; // 0x210(0x08)
};

// Class Engine.DeviceProfileManager
// Size: 0x120 (Inherited: 0x38)
struct UDeviceProfileManager : UObject {
	struct TArray<struct UObject*> Profiles; // 0x38(0x10)
	char pad_48[0xd8]; // 0x48(0xd8)
};

// Class Engine.DialogueVoice
// Size: 0x50 (Inherited: 0x38)
struct UDialogueVoice : UObject {
	enum class EGrammaticalGender Gender; // 0x38(0x01)
	enum class EGrammaticalNumber Plurality; // 0x39(0x01)
	char pad_3A[0x2]; // 0x3a(0x02)
	struct FGuid LocalizationGUID; // 0x3c(0x10)
	char pad_4C[0x4]; // 0x4c(0x04)
};

// Class Engine.DialogueWave
// Size: 0x80 (Inherited: 0x38)
struct UDialogueWave : UObject {
	char bMature : 1; // 0x38(0x01)
	char bOverride_SubtitleOverride : 1; // 0x38(0x01)
	char pad_38_2 : 6; // 0x38(0x01)
	char pad_39[0x7]; // 0x39(0x07)
	struct FString SpokenText; // 0x40(0x10)
	struct FString SubtitleOverride; // 0x50(0x10)
	struct TArray<struct FDialogueContextMapping> ContextMappings; // 0x60(0x10)
	struct FGuid LocalizationGUID; // 0x70(0x10)
};

// Class Engine.Distribution
// Size: 0x40 (Inherited: 0x38)
struct UDistribution : UObject {
	char pad_38[0x8]; // 0x38(0x08)
};

// Class Engine.DistributionFloat
// Size: 0x48 (Inherited: 0x40)
struct UDistributionFloat : UDistribution {
	char bCanBeBaked : 1; // 0x40(0x01)
	char pad_40_1 : 1; // 0x40(0x01)
	char bBakedDataSuccesfully : 1; // 0x40(0x01)
	char pad_40_3 : 5; // 0x40(0x01)
	char pad_41[0x7]; // 0x41(0x07)
};

// Class Engine.DistributionFloatConstant
// Size: 0x50 (Inherited: 0x48)
struct UDistributionFloatConstant : UDistributionFloat {
	float Constant; // 0x48(0x04)
	char pad_4C[0x4]; // 0x4c(0x04)
};

// Class Engine.DistributionFloatParameterBase
// Size: 0x70 (Inherited: 0x50)
struct UDistributionFloatParameterBase : UDistributionFloatConstant {
	struct FName ParameterName; // 0x50(0x08)
	float MinInput; // 0x58(0x04)
	float MaxInput; // 0x5c(0x04)
	float MinOutput; // 0x60(0x04)
	float MaxOutput; // 0x64(0x04)
	enum class DistributionParamMode ParamMode; // 0x68(0x01)
	char pad_69[0x7]; // 0x69(0x07)
};

// Class Engine.DistributionFloatParticleParameter
// Size: 0x70 (Inherited: 0x70)
struct UDistributionFloatParticleParameter : UDistributionFloatParameterBase {
};

// Class Engine.DistributionFloatConstantCurve
// Size: 0x60 (Inherited: 0x48)
struct UDistributionFloatConstantCurve : UDistributionFloat {
	struct FInterpCurveFloat ConstantCurve; // 0x48(0x18)
};

// Class Engine.DistributionFloatUniform
// Size: 0x50 (Inherited: 0x48)
struct UDistributionFloatUniform : UDistributionFloat {
	float Min; // 0x48(0x04)
	float Max; // 0x4c(0x04)
};

// Class Engine.DistributionFloatUniformCurve
// Size: 0x60 (Inherited: 0x48)
struct UDistributionFloatUniformCurve : UDistributionFloat {
	struct FInterpCurveVector2D ConstantCurve; // 0x48(0x18)
};

// Class Engine.DistributionVector
// Size: 0x48 (Inherited: 0x40)
struct UDistributionVector : UDistribution {
	char bCanBeBaked : 1; // 0x40(0x01)
	char bIsDirty : 1; // 0x40(0x01)
	char bBakedDataSuccesfully : 1; // 0x40(0x01)
	char pad_40_3 : 5; // 0x40(0x01)
	char pad_41[0x7]; // 0x41(0x07)
};

// Class Engine.DistributionVectorConstant
// Size: 0x60 (Inherited: 0x48)
struct UDistributionVectorConstant : UDistributionVector {
	struct FVector Constant; // 0x48(0x0c)
	char bLockAxes : 1; // 0x54(0x01)
	char pad_54_1 : 7; // 0x54(0x01)
	char pad_55[0x3]; // 0x55(0x03)
	enum class EDistributionVectorLockFlags LockedAxes; // 0x58(0x01)
	char pad_59[0x7]; // 0x59(0x07)
};

// Class Engine.DistributionVectorParameterBase
// Size: 0xa0 (Inherited: 0x60)
struct UDistributionVectorParameterBase : UDistributionVectorConstant {
	struct FName ParameterName; // 0x60(0x08)
	struct FVector MinInput; // 0x68(0x0c)
	struct FVector MaxInput; // 0x74(0x0c)
	struct FVector MinOutput; // 0x80(0x0c)
	struct FVector MaxOutput; // 0x8c(0x0c)
	enum class DistributionParamMode ParamModes[0x03]; // 0x98(0x03)
	char pad_9B[0x5]; // 0x9b(0x05)
};

// Class Engine.DistributionVectorParticleParameter
// Size: 0xa0 (Inherited: 0xa0)
struct UDistributionVectorParticleParameter : UDistributionVectorParameterBase {
};

// Class Engine.DistributionVectorConstantCurve
// Size: 0x68 (Inherited: 0x48)
struct UDistributionVectorConstantCurve : UDistributionVector {
	struct FInterpCurveVector ConstantCurve; // 0x48(0x18)
	char bLockAxes : 1; // 0x60(0x01)
	char pad_60_1 : 7; // 0x60(0x01)
	char pad_61[0x3]; // 0x61(0x03)
	enum class EDistributionVectorLockFlags LockedAxes; // 0x64(0x01)
	char pad_65[0x3]; // 0x65(0x03)
};

// Class Engine.DistributionVectorUniform
// Size: 0x70 (Inherited: 0x48)
struct UDistributionVectorUniform : UDistributionVector {
	struct FVector Max; // 0x48(0x0c)
	struct FVector Min; // 0x54(0x0c)
	char bLockAxes : 1; // 0x60(0x01)
	char pad_60_1 : 7; // 0x60(0x01)
	char pad_61[0x3]; // 0x61(0x03)
	enum class EDistributionVectorLockFlags LockedAxes; // 0x64(0x01)
	enum class EDistributionVectorMirrorFlags MirrorFlags[0x03]; // 0x65(0x03)
	char bUseExtremes : 1; // 0x68(0x01)
	char pad_68_1 : 7; // 0x68(0x01)
	char pad_69[0x7]; // 0x69(0x07)
};

// Class Engine.DistributionVectorUniformCurve
// Size: 0x70 (Inherited: 0x48)
struct UDistributionVectorUniformCurve : UDistributionVector {
	struct FInterpCurveTwoVectors ConstantCurve; // 0x48(0x18)
	char bLockAxes1 : 1; // 0x60(0x01)
	char bLockAxes2 : 1; // 0x60(0x01)
	char pad_60_2 : 6; // 0x60(0x01)
	char pad_61[0x3]; // 0x61(0x03)
	enum class EDistributionVectorLockFlags LockedAxes[0x02]; // 0x64(0x02)
	enum class EDistributionVectorMirrorFlags MirrorFlags[0x03]; // 0x66(0x03)
	char pad_69[0x3]; // 0x69(0x03)
	char bUseExtremes : 1; // 0x6c(0x01)
	char pad_6C_1 : 7; // 0x6c(0x01)
	char pad_6D[0x3]; // 0x6d(0x03)
};

// Class Engine.DPICustomScalingRule
// Size: 0x38 (Inherited: 0x38)
struct UDPICustomScalingRule : UObject {
};

// Class Engine.DynamicBlueprintBinding
// Size: 0x38 (Inherited: 0x38)
struct UDynamicBlueprintBinding : UObject {
};

// Class Engine.ComponentDelegateBinding
// Size: 0x48 (Inherited: 0x38)
struct UComponentDelegateBinding : UDynamicBlueprintBinding {
	struct TArray<struct FBlueprintComponentDelegateBinding> ComponentDelegateBindings; // 0x38(0x10)
};

// Class Engine.InputDelegateBinding
// Size: 0x38 (Inherited: 0x38)
struct UInputDelegateBinding : UDynamicBlueprintBinding {
};

// Class Engine.InputActionDelegateBinding
// Size: 0x48 (Inherited: 0x38)
struct UInputActionDelegateBinding : UInputDelegateBinding {
	struct TArray<struct FBlueprintInputActionDelegateBinding> InputActionDelegateBindings; // 0x38(0x10)
};

// Class Engine.InputAxisDelegateBinding
// Size: 0x48 (Inherited: 0x38)
struct UInputAxisDelegateBinding : UInputDelegateBinding {
	struct TArray<struct FBlueprintInputAxisDelegateBinding> InputAxisDelegateBindings; // 0x38(0x10)
};

// Class Engine.InputAxisKeyDelegateBinding
// Size: 0x48 (Inherited: 0x38)
struct UInputAxisKeyDelegateBinding : UInputDelegateBinding {
	struct TArray<struct FBlueprintInputAxisKeyDelegateBinding> InputAxisKeyDelegateBindings; // 0x38(0x10)
};

// Class Engine.InputVectorAxisDelegateBinding
// Size: 0x48 (Inherited: 0x48)
struct UInputVectorAxisDelegateBinding : UInputAxisKeyDelegateBinding {
};

// Class Engine.InputKeyDelegateBinding
// Size: 0x48 (Inherited: 0x38)
struct UInputKeyDelegateBinding : UInputDelegateBinding {
	struct TArray<struct FBlueprintInputKeyDelegateBinding> InputKeyDelegateBindings; // 0x38(0x10)
};

// Class Engine.InputTouchDelegateBinding
// Size: 0x48 (Inherited: 0x38)
struct UInputTouchDelegateBinding : UInputDelegateBinding {
	struct TArray<struct FBlueprintInputTouchDelegateBinding> InputTouchDelegateBindings; // 0x38(0x10)
};

// Class Engine.EdGraph
// Size: 0xd0 (Inherited: 0x38)
struct UEdGraph : UObject {
	struct UClass* Schema; // 0x38(0x08)
	struct TArray<struct UEdGraphNode*> Nodes; // 0x40(0x10)
	char bEditable : 1; // 0x50(0x01)
	char bAllowDeletion : 1; // 0x50(0x01)
	char bAllowRenaming : 1; // 0x50(0x01)
	char pad_50_3 : 5; // 0x50(0x01)
	char pad_51[0x7f]; // 0x51(0x7f)
};

// Class Engine.EdGraphNode_Documentation
// Size: 0xd0 (Inherited: 0xb0)
struct UEdGraphNode_Documentation : UEdGraphNode {
	struct FString Link; // 0xb0(0x10)
	struct FString Excerpt; // 0xc0(0x10)
};

// Class Engine.EdGraphSchema
// Size: 0x38 (Inherited: 0x38)
struct UEdGraphSchema : UObject {
};

// Class Engine.ImportantToggleSettingInterface
// Size: 0x38 (Inherited: 0x38)
struct UImportantToggleSettingInterface : UInterface {
};

// Class Engine.EndUserSettings
// Size: 0x48 (Inherited: 0x38)
struct UEndUserSettings : UObject {
	char pad_38[0x8]; // 0x38(0x08)
	bool bSendAnonymousUsageDataToEpic; // 0x40(0x01)
	bool bSendMeanTimeBetweenFailureDataToEpic; // 0x41(0x01)
	bool bAllowUserIdInUsageData; // 0x42(0x01)
	char pad_43[0x5]; // 0x43(0x05)
};

// Class Engine.PendingNetGame
// Size: 0xd8 (Inherited: 0x38)
struct UPendingNetGame : UObject {
	char pad_38[0x8]; // 0x38(0x08)
	struct UNetDriver* NetDriver; // 0x40(0x08)
	struct UDemoNetDriver* DemoNetDriver; // 0x48(0x08)
	char pad_50[0x88]; // 0x50(0x88)
};

// Class Engine.EngineHandlerComponentFactory
// Size: 0x38 (Inherited: 0x38)
struct UEngineHandlerComponentFactory : UHandlerComponentFactory {
};

// Class Engine.Exporter
// Size: 0x78 (Inherited: 0x38)
struct UExporter : UObject {
	struct UClass* SupportedClass; // 0x38(0x08)
	struct UObject* ExportRootScope; // 0x40(0x08)
	struct TArray<struct FString> FormatExtension; // 0x48(0x10)
	struct TArray<struct FString> FormatDescription; // 0x58(0x10)
	int32 PreferredFormatIndex; // 0x68(0x04)
	int32 TextIndent; // 0x6c(0x04)
	char bText : 1; // 0x70(0x01)
	char bSelectedOnly : 1; // 0x70(0x01)
	char bForceFileOperations : 1; // 0x70(0x01)
	char pad_70_3 : 5; // 0x70(0x01)
	char pad_71[0x7]; // 0x71(0x07)
};

// Class Engine.ExtendedReflectionSettings
// Size: 0xb8 (Inherited: 0x38)
struct UExtendedReflectionSettings : UObject {
	float GlobalOverrideIntensity; // 0x38(0x04)
	int32 StreamingSectionSize; // 0x3c(0x04)
	struct TArray<struct FExtendedReflectionSharedCubemap> SharedCubemaps; // 0x40(0x10)
	struct TArray<struct UTextureCube*> ReferencedCubemaps; // 0x50(0x10)
	char pad_60[0x58]; // 0x60(0x58)
};

// Class Engine.FoliageBlockingVolumeManager
// Size: 0x60 (Inherited: 0x38)
struct UFoliageBlockingVolumeManager : UObject {
	char pad_38[0x28]; // 0x38(0x28)
};

// Class Engine.FoliageBlockingVolumeContainer
// Size: 0x60 (Inherited: 0x38)
struct UFoliageBlockingVolumeContainer : ULevelBlockResourceContainer {
	struct TArray<struct FVector2D> Points; // 0x38(0x10)
	struct TArray<struct FFoliageBlockingVolumeInstance> Instances; // 0x48(0x10)
	struct UFoliageBlockingVolumeManager* Manager; // 0x58(0x08)
};

// Class Engine.FontImportOptions
// Size: 0xe8 (Inherited: 0x38)
struct UFontImportOptions : UObject {
	struct FFontImportOptionsData Data; // 0x38(0xb0)
};

// Class Engine.Font
// Size: 0x1d0 (Inherited: 0x38)
struct UFont : UObject {
	char pad_38[0x8]; // 0x38(0x08)
	enum class EFontCacheType FontCacheType; // 0x40(0x01)
	char pad_41[0x7]; // 0x41(0x07)
	struct TArray<struct FFontCharacter> Characters; // 0x48(0x10)
	struct TArray<struct UTexture2D*> Textures; // 0x58(0x10)
	int32 IsRemapped; // 0x68(0x04)
	float EmScale; // 0x6c(0x04)
	float Ascent; // 0x70(0x04)
	float Descent; // 0x74(0x04)
	float Leading; // 0x78(0x04)
	int32 Kerning; // 0x7c(0x04)
	struct FFontImportOptionsData ImportOptions; // 0x80(0xb0)
	int32 NumCharacters; // 0x130(0x04)
	char pad_134[0x4]; // 0x134(0x04)
	struct TArray<int32> MaxCharHeight; // 0x138(0x10)
	float ScalingFactor; // 0x148(0x04)
	int32 LegacyFontSize; // 0x14c(0x04)
	struct FName LegacyFontName; // 0x150(0x08)
	struct FCompositeFont CompositeFont; // 0x158(0x28)
	char pad_180[0x50]; // 0x180(0x50)
};

// Class Engine.FontFace
// Size: 0x68 (Inherited: 0x38)
struct UFontFace : UObject {
	char pad_38[0x8]; // 0x38(0x08)
	struct FString SourceFilename; // 0x40(0x10)
	enum class EFontHinting Hinting; // 0x50(0x01)
	enum class EFontLoadingPolicy LoadingPolicy; // 0x51(0x01)
	enum class EFontLoadingPolicy LoadingPolicyConsole; // 0x52(0x01)
	enum class EFontLayoutMethod LayoutMethod; // 0x53(0x01)
	char pad_54[0x14]; // 0x54(0x14)
};

// Class Engine.HapticFeedbackEffect_Base
// Size: 0x38 (Inherited: 0x38)
struct UHapticFeedbackEffect_Base : UObject {
};

// Class Engine.HapticFeedbackEffect_Buffer
// Size: 0x78 (Inherited: 0x38)
struct UHapticFeedbackEffect_Buffer : UHapticFeedbackEffect_Base {
	struct TArray<bool> Amplitudes; // 0x38(0x10)
	int32 SampleRate; // 0x48(0x04)
	char pad_4C[0x2c]; // 0x4c(0x2c)
};

// Class Engine.HapticFeedbackEffect_Curve
// Size: 0x128 (Inherited: 0x38)
struct UHapticFeedbackEffect_Curve : UHapticFeedbackEffect_Base {
	struct FHapticFeedbackDetails_Curve HapticDetails; // 0x38(0xf0)
};

// Class Engine.HapticFeedbackEffect_SoundWave
// Size: 0x70 (Inherited: 0x38)
struct UHapticFeedbackEffect_SoundWave : UHapticFeedbackEffect_Base {
	struct USoundWave* SoundWave; // 0x38(0x08)
	char pad_40[0x30]; // 0x40(0x30)
};

// Class Engine.InheritableComponentHandler
// Size: 0x58 (Inherited: 0x38)
struct UInheritableComponentHandler : UObject {
	struct TArray<struct FComponentOverrideRecord> Records; // 0x38(0x10)
	struct TArray<struct UActorComponent*> UnnecessaryComponents; // 0x48(0x10)
};

// Class Engine.InputSettings
// Size: 0xb8 (Inherited: 0x38)
struct UInputSettings : UObject {
	struct TArray<struct FInputAxisConfigEntry> AxisConfig; // 0x38(0x10)
	char bAltEnterTogglesFullscreen : 1; // 0x48(0x01)
	char bF11TogglesFullscreen : 1; // 0x48(0x01)
	char bUseMouseForTouch : 1; // 0x48(0x01)
	char bEnableMouseSmoothing : 1; // 0x48(0x01)
	char bEnableFOVScaling : 1; // 0x48(0x01)
	char pad_48_5 : 3; // 0x48(0x01)
	char pad_49[0x3]; // 0x49(0x03)
	float FOVScale; // 0x4c(0x04)
	float DoubleClickTime; // 0x50(0x04)
	bool bCaptureMouseOnLaunch; // 0x54(0x01)
	enum class EMouseCaptureMode DefaultViewportMouseCaptureMode; // 0x55(0x01)
	bool bDefaultViewportMouseLock; // 0x56(0x01)
	enum class EMouseLockMode DefaultViewportMouseLockMode; // 0x57(0x01)
	struct TArray<struct FInputActionKeyMapping> ActionMappings; // 0x58(0x10)
	struct TArray<struct FInputAxisKeyMapping> AxisMappings; // 0x68(0x10)
	bool bAlwaysShowTouchInterface; // 0x78(0x01)
	bool bShowConsoleOnFourFingerTap; // 0x79(0x01)
	char pad_7A[0x6]; // 0x7a(0x06)
	struct FStringAssetReference DefaultTouchInterface; // 0x80(0x10)
	struct FKey ConsoleKey; // 0x90(0x18)
	struct TArray<struct FKey> ConsoleKeys; // 0xa8(0x10)
};

// Class Engine.InterpCurveEdSetup
// Size: 0x50 (Inherited: 0x38)
struct UInterpCurveEdSetup : UObject {
	struct TArray<struct FCurveEdTab> Tabs; // 0x38(0x10)
	int32 ActiveTab; // 0x48(0x04)
	char pad_4C[0x4]; // 0x4c(0x04)
};

// Class Engine.InterpData
// Size: 0x80 (Inherited: 0x38)
struct UInterpData : UObject {
	float InterpLength; // 0x38(0x04)
	float PathBuildTime; // 0x3c(0x04)
	struct TArray<struct UInterpGroup*> InterpGroups; // 0x40(0x10)
	struct UInterpCurveEdSetup* CurveEdSetup; // 0x50(0x08)
	float EdSectionStart; // 0x58(0x04)
	float EdSectionEnd; // 0x5c(0x04)
	char bShouldBakeAndPrune : 1; // 0x60(0x01)
	char pad_60_1 : 7; // 0x60(0x01)
	char pad_61[0x7]; // 0x61(0x07)
	struct UInterpGroupDirector* CachedDirectorGroup; // 0x68(0x08)
	struct TArray<struct FName> AllEventNames; // 0x70(0x10)
};

// Class Engine.InterpFilter
// Size: 0x48 (Inherited: 0x38)
struct UInterpFilter : UObject {
	struct FString Caption; // 0x38(0x10)
};

// Class Engine.InterpFilter_Classes
// Size: 0x48 (Inherited: 0x48)
struct UInterpFilter_Classes : UInterpFilter {
};

// Class Engine.InterpFilter_Custom
// Size: 0x48 (Inherited: 0x48)
struct UInterpFilter_Custom : UInterpFilter {
};

// Class Engine.InterpGroup
// Size: 0x60 (Inherited: 0x38)
struct UInterpGroup : UObject {
	char pad_38[0x8]; // 0x38(0x08)
	struct TArray<struct UInterpTrack*> InterpTracks; // 0x40(0x10)
	struct FName GroupName; // 0x50(0x08)
	struct FColor GroupColor; // 0x58(0x04)
	char bCollapsed : 1; // 0x5c(0x01)
	char bVisible : 1; // 0x5c(0x01)
	char bIsFolder : 1; // 0x5c(0x01)
	char bIsParented : 1; // 0x5c(0x01)
	char bIsSelected : 1; // 0x5c(0x01)
	char pad_5C_5 : 3; // 0x5c(0x01)
	char pad_5D[0x3]; // 0x5d(0x03)
};

// Class Engine.InterpGroupCamera
// Size: 0x70 (Inherited: 0x60)
struct UInterpGroupCamera : UInterpGroup {
	struct UCameraAnim* CameraAnimInst; // 0x60(0x08)
	float CompressTolerance; // 0x68(0x04)
	char pad_6C[0x4]; // 0x6c(0x04)
};

// Class Engine.InterpGroupDirector
// Size: 0x60 (Inherited: 0x60)
struct UInterpGroupDirector : UInterpGroup {
};

// Class Engine.InterpGroupInst
// Size: 0x58 (Inherited: 0x38)
struct UInterpGroupInst : UObject {
	struct UInterpGroup* Group; // 0x38(0x08)
	struct AActor* GroupActor; // 0x40(0x08)
	struct TArray<struct UInterpTrackInst*> TrackInst; // 0x48(0x10)
};

// Class Engine.InterpGroupInstCamera
// Size: 0x58 (Inherited: 0x58)
struct UInterpGroupInstCamera : UInterpGroupInst {
};

// Class Engine.InterpGroupInstDirector
// Size: 0x58 (Inherited: 0x58)
struct UInterpGroupInstDirector : UInterpGroupInst {
};

// Class Engine.InterpTrack
// Size: 0x80 (Inherited: 0x38)
struct UInterpTrack : UObject {
	char pad_38[0x10]; // 0x38(0x10)
	struct TArray<struct UInterpTrack*> SubTracks; // 0x48(0x10)
	struct UClass* TrackInstClass; // 0x58(0x08)
	enum class ETrackActiveCondition ActiveCondition; // 0x60(0x01)
	char pad_61[0x7]; // 0x61(0x07)
	struct FString TrackTitle; // 0x68(0x10)
	char bOnePerGroup : 1; // 0x78(0x01)
	char bDirGroupOnly : 1; // 0x78(0x01)
	char bDisableTrack : 1; // 0x78(0x01)
	char bIsSelected : 1; // 0x78(0x01)
	char bIsAnimControlTrack : 1; // 0x78(0x01)
	char bSubTrackOnly : 1; // 0x78(0x01)
	char bVisible : 1; // 0x78(0x01)
	char bIsRecording : 1; // 0x78(0x01)
	char pad_79[0x7]; // 0x79(0x07)
};

// Class Engine.InterpTrackBoolProp
// Size: 0x98 (Inherited: 0x80)
struct UInterpTrackBoolProp : UInterpTrack {
	struct TArray<struct FBoolTrackKey> BoolTrack; // 0x80(0x10)
	struct FName PropertyName; // 0x90(0x08)
};

// Class Engine.InterpTrackDirector
// Size: 0x98 (Inherited: 0x80)
struct UInterpTrackDirector : UInterpTrack {
	struct TArray<struct FDirectorTrackCut> CutTrack; // 0x80(0x10)
	char bSimulateCameraCutsOnClients : 1; // 0x90(0x01)
	char pad_90_1 : 7; // 0x90(0x01)
	char pad_91[0x7]; // 0x91(0x07)
};

// Class Engine.InterpTrackEvent
// Size: 0x98 (Inherited: 0x80)
struct UInterpTrackEvent : UInterpTrack {
	struct TArray<struct FEventTrackKey> EventTrack; // 0x80(0x10)
	char bFireEventsWhenForwards : 1; // 0x90(0x01)
	char bFireEventsWhenBackwards : 1; // 0x90(0x01)
	char bFireEventsWhenJumpingForwards : 1; // 0x90(0x01)
	char bUseCustomEventName : 1; // 0x90(0x01)
	char pad_90_4 : 4; // 0x90(0x01)
	char pad_91[0x7]; // 0x91(0x07)
};

// Class Engine.InterpTrackFloatBase
// Size: 0xa0 (Inherited: 0x80)
struct UInterpTrackFloatBase : UInterpTrack {
	struct FInterpCurveFloat FloatTrack; // 0x80(0x18)
	float CurveTension; // 0x98(0x04)
	char pad_9C[0x4]; // 0x9c(0x04)
};

// Class Engine.InterpTrackAnimControl
// Size: 0xc0 (Inherited: 0xa0)
struct UInterpTrackAnimControl : UInterpTrackFloatBase {
	struct FName SlotName; // 0xa0(0x08)
	struct TArray<struct FAnimControlTrackKey> AnimSeqs; // 0xa8(0x10)
	char bSkipAnimNotifiers : 1; // 0xb8(0x01)
	char pad_B8_1 : 7; // 0xb8(0x01)
	char pad_B9[0x7]; // 0xb9(0x07)
};

// Class Engine.InterpTrackFade
// Size: 0xb8 (Inherited: 0xa0)
struct UInterpTrackFade : UInterpTrackFloatBase {
	char bPersistFade : 1; // 0xa0(0x01)
	char bFadeAudio : 1; // 0xa0(0x01)
	char pad_A0_2 : 6; // 0xa0(0x01)
	char pad_A1[0x3]; // 0xa1(0x03)
	struct FLinearColor FadeColor; // 0xa4(0x10)
	char pad_B4[0x4]; // 0xb4(0x04)
};

// Class Engine.InterpTrackFloatAnimBPParam
// Size: 0xc0 (Inherited: 0xa0)
struct UInterpTrackFloatAnimBPParam : UInterpTrackFloatBase {
	struct UAnimBlueprintGeneratedClass* AnimBlueprintClass; // 0xa0(0x08)
	struct UClass* AnimClass; // 0xa8(0x08)
	struct FName ParamName; // 0xb0(0x08)
	char pad_B8[0x8]; // 0xb8(0x08)
};

// Class Engine.InterpTrackFloatMaterialParam
// Size: 0xb8 (Inherited: 0xa0)
struct UInterpTrackFloatMaterialParam : UInterpTrackFloatBase {
	struct TArray<struct UMaterialInterface*> TargetMaterials; // 0xa0(0x10)
	struct FName ParamName; // 0xb0(0x08)
};

// Class Engine.InterpTrackFloatParticleParam
// Size: 0xa8 (Inherited: 0xa0)
struct UInterpTrackFloatParticleParam : UInterpTrackFloatBase {
	struct FName ParamName; // 0xa0(0x08)
};

// Class Engine.InterpTrackFloatProp
// Size: 0xa8 (Inherited: 0xa0)
struct UInterpTrackFloatProp : UInterpTrackFloatBase {
	struct FName PropertyName; // 0xa0(0x08)
};

// Class Engine.InterpTrackMove
// Size: 0xd8 (Inherited: 0x80)
struct UInterpTrackMove : UInterpTrack {
	struct FInterpCurveVector PosTrack; // 0x80(0x18)
	struct FInterpCurveVector EulerTrack; // 0x98(0x18)
	struct FInterpLookupTrack LookupTrack; // 0xb0(0x10)
	struct FName LookAtGroupName; // 0xc0(0x08)
	float LinCurveTension; // 0xc8(0x04)
	float AngCurveTension; // 0xcc(0x04)
	char bUseQuatInterpolation : 1; // 0xd0(0x01)
	char bShowArrowAtKeys : 1; // 0xd0(0x01)
	char bDisableMovement : 1; // 0xd0(0x01)
	char bShowTranslationOnCurveEd : 1; // 0xd0(0x01)
	char bShowRotationOnCurveEd : 1; // 0xd0(0x01)
	char bHide3DTrack : 1; // 0xd0(0x01)
	char pad_D0_6 : 2; // 0xd0(0x01)
	char pad_D1[0x3]; // 0xd1(0x03)
	enum class EInterpTrackMoveRotMode RotMode; // 0xd4(0x01)
	char pad_D5[0x3]; // 0xd5(0x03)
};

// Class Engine.InterpTrackMoveAxis
// Size: 0xb8 (Inherited: 0xa0)
struct UInterpTrackMoveAxis : UInterpTrackFloatBase {
	enum class EInterpMoveAxis MoveAxis; // 0xa0(0x01)
	char pad_A1[0x7]; // 0xa1(0x07)
	struct FInterpLookupTrack LookupTrack; // 0xa8(0x10)
};

// Class Engine.InterpTrackSlomo
// Size: 0xa0 (Inherited: 0xa0)
struct UInterpTrackSlomo : UInterpTrackFloatBase {
};

// Class Engine.InterpTrackLinearColorBase
// Size: 0xa0 (Inherited: 0x80)
struct UInterpTrackLinearColorBase : UInterpTrack {
	struct FInterpCurveLinearColor LinearColorTrack; // 0x80(0x18)
	float CurveTension; // 0x98(0x04)
	char pad_9C[0x4]; // 0x9c(0x04)
};

// Class Engine.InterpTrackLinearColorProp
// Size: 0xa8 (Inherited: 0xa0)
struct UInterpTrackLinearColorProp : UInterpTrackLinearColorBase {
	struct FName PropertyName; // 0xa0(0x08)
};

// Class Engine.InterpTrackParticleReplay
// Size: 0x90 (Inherited: 0x80)
struct UInterpTrackParticleReplay : UInterpTrack {
	struct TArray<struct FParticleReplayTrackKey> TrackKeys; // 0x80(0x10)
};

// Class Engine.InterpTrackToggle
// Size: 0x98 (Inherited: 0x80)
struct UInterpTrackToggle : UInterpTrack {
	struct TArray<struct FToggleTrackKey> ToggleTrack; // 0x80(0x10)
	char bActivateSystemEachUpdate : 1; // 0x90(0x01)
	char bActivateWithJustAttachedFlag : 1; // 0x90(0x01)
	char bFireEventsWhenForwards : 1; // 0x90(0x01)
	char bFireEventsWhenBackwards : 1; // 0x90(0x01)
	char bFireEventsWhenJumpingForwards : 1; // 0x90(0x01)
	char pad_90_5 : 3; // 0x90(0x01)
	char pad_91[0x7]; // 0x91(0x07)
};

// Class Engine.InterpTrackVectorBase
// Size: 0xa0 (Inherited: 0x80)
struct UInterpTrackVectorBase : UInterpTrack {
	struct FInterpCurveVector VectorTrack; // 0x80(0x18)
	float CurveTension; // 0x98(0x04)
	char pad_9C[0x4]; // 0x9c(0x04)
};

// Class Engine.InterpTrackAudioMaster
// Size: 0xa0 (Inherited: 0xa0)
struct UInterpTrackAudioMaster : UInterpTrackVectorBase {
};

// Class Engine.InterpTrackColorProp
// Size: 0xa8 (Inherited: 0xa0)
struct UInterpTrackColorProp : UInterpTrackVectorBase {
	struct FName PropertyName; // 0xa0(0x08)
};

// Class Engine.InterpTrackColorScale
// Size: 0xa0 (Inherited: 0xa0)
struct UInterpTrackColorScale : UInterpTrackVectorBase {
};

// Class Engine.InterpTrackSound
// Size: 0xb8 (Inherited: 0xa0)
struct UInterpTrackSound : UInterpTrackVectorBase {
	struct TArray<struct FSoundTrackKey> Sounds; // 0xa0(0x10)
	char bPlayOnReverse : 1; // 0xb0(0x01)
	char bContinueSoundOnMatineeEnd : 1; // 0xb0(0x01)
	char bSuppressSubtitles : 1; // 0xb0(0x01)
	char bTreatAsDialogue : 1; // 0xb0(0x01)
	char bAttach : 1; // 0xb0(0x01)
	char pad_B0_5 : 3; // 0xb0(0x01)
	char pad_B1[0x7]; // 0xb1(0x07)
};

// Class Engine.InterpTrackVectorMaterialParam
// Size: 0xb8 (Inherited: 0xa0)
struct UInterpTrackVectorMaterialParam : UInterpTrackVectorBase {
	struct TArray<struct UMaterialInterface*> TargetMaterials; // 0xa0(0x10)
	struct FName ParamName; // 0xb0(0x08)
};

// Class Engine.InterpTrackVectorProp
// Size: 0xa8 (Inherited: 0xa0)
struct UInterpTrackVectorProp : UInterpTrackVectorBase {
	struct FName PropertyName; // 0xa0(0x08)
};

// Class Engine.InterpTrackVisibility
// Size: 0x98 (Inherited: 0x80)
struct UInterpTrackVisibility : UInterpTrack {
	struct TArray<struct FVisibilityTrackKey> VisibilityTrack; // 0x80(0x10)
	char bFireEventsWhenForwards : 1; // 0x90(0x01)
	char bFireEventsWhenBackwards : 1; // 0x90(0x01)
	char bFireEventsWhenJumpingForwards : 1; // 0x90(0x01)
	char pad_90_3 : 5; // 0x90(0x01)
	char pad_91[0x7]; // 0x91(0x07)
};

// Class Engine.InterpTrackInst
// Size: 0x38 (Inherited: 0x38)
struct UInterpTrackInst : UObject {
};

// Class Engine.InterpTrackInstAnimControl
// Size: 0x40 (Inherited: 0x38)
struct UInterpTrackInstAnimControl : UInterpTrackInst {
	float LastUpdatePosition; // 0x38(0x04)
	char pad_3C[0x4]; // 0x3c(0x04)
};

// Class Engine.InterpTrackInstAudioMaster
// Size: 0x38 (Inherited: 0x38)
struct UInterpTrackInstAudioMaster : UInterpTrackInst {
};

// Class Engine.InterpTrackInstColorScale
// Size: 0x38 (Inherited: 0x38)
struct UInterpTrackInstColorScale : UInterpTrackInst {
};

// Class Engine.InterpTrackInstDirector
// Size: 0x40 (Inherited: 0x38)
struct UInterpTrackInstDirector : UInterpTrackInst {
	struct AActor* OldViewTarget; // 0x38(0x08)
};

// Class Engine.InterpTrackInstEvent
// Size: 0x40 (Inherited: 0x38)
struct UInterpTrackInstEvent : UInterpTrackInst {
	float LastUpdatePosition; // 0x38(0x04)
	char pad_3C[0x4]; // 0x3c(0x04)
};

// Class Engine.InterpTrackInstFade
// Size: 0x38 (Inherited: 0x38)
struct UInterpTrackInstFade : UInterpTrackInst {
};

// Class Engine.InterpTrackInstFloatAnimBPParam
// Size: 0x50 (Inherited: 0x38)
struct UInterpTrackInstFloatAnimBPParam : UInterpTrackInst {
	struct UAnimInstance* AnimScriptInstance; // 0x38(0x08)
	float ResetFloat; // 0x40(0x04)
	char pad_44[0xc]; // 0x44(0x0c)
};

// Class Engine.InterpTrackInstFloatMaterialParam
// Size: 0x70 (Inherited: 0x38)
struct UInterpTrackInstFloatMaterialParam : UInterpTrackInst {
	struct TArray<struct UMaterialInstanceDynamic*> MaterialInstances; // 0x38(0x10)
	struct TArray<float> ResetFloats; // 0x48(0x10)
	struct TArray<struct FPrimitiveMaterialRef> PrimitiveMaterialRefs; // 0x58(0x10)
	struct UInterpTrackFloatMaterialParam* InstancedTrack; // 0x68(0x08)
};

// Class Engine.InterpTrackInstFloatParticleParam
// Size: 0x40 (Inherited: 0x38)
struct UInterpTrackInstFloatParticleParam : UInterpTrackInst {
	float ResetFloat; // 0x38(0x04)
	char pad_3C[0x4]; // 0x3c(0x04)
};

// Class Engine.InterpTrackInstMove
// Size: 0x50 (Inherited: 0x38)
struct UInterpTrackInstMove : UInterpTrackInst {
	struct FVector ResetLocation; // 0x38(0x0c)
	struct FRotator ResetRotation; // 0x44(0x0c)
};

// Class Engine.InterpTrackInstParticleReplay
// Size: 0x40 (Inherited: 0x38)
struct UInterpTrackInstParticleReplay : UInterpTrackInst {
	float LastUpdatePosition; // 0x38(0x04)
	char pad_3C[0x4]; // 0x3c(0x04)
};

// Class Engine.InterpTrackInstProperty
// Size: 0x48 (Inherited: 0x38)
struct UInterpTrackInstProperty : UInterpTrackInst {
	struct UProperty* InterpProperty; // 0x38(0x08)
	struct UObject* PropertyOuterObjectInst; // 0x40(0x08)
};

// Class Engine.InterpTrackInstBoolProp
// Size: 0x60 (Inherited: 0x48)
struct UInterpTrackInstBoolProp : UInterpTrackInstProperty {
	char pad_48[0x8]; // 0x48(0x08)
	struct UBoolProperty* BoolProperty; // 0x50(0x08)
	bool ResetBool; // 0x58(0x01)
	char pad_59[0x7]; // 0x59(0x07)
};

// Class Engine.InterpTrackInstColorProp
// Size: 0x58 (Inherited: 0x48)
struct UInterpTrackInstColorProp : UInterpTrackInstProperty {
	char pad_48[0x8]; // 0x48(0x08)
	struct FColor ResetColor; // 0x50(0x04)
	char pad_54[0x4]; // 0x54(0x04)
};

// Class Engine.InterpTrackInstFloatProp
// Size: 0x58 (Inherited: 0x48)
struct UInterpTrackInstFloatProp : UInterpTrackInstProperty {
	char pad_48[0x8]; // 0x48(0x08)
	float ResetFloat; // 0x50(0x04)
	char pad_54[0x4]; // 0x54(0x04)
};

// Class Engine.InterpTrackInstLinearColorProp
// Size: 0x60 (Inherited: 0x48)
struct UInterpTrackInstLinearColorProp : UInterpTrackInstProperty {
	char pad_48[0x8]; // 0x48(0x08)
	struct FLinearColor ResetColor; // 0x50(0x10)
};

// Class Engine.InterpTrackInstVectorProp
// Size: 0x60 (Inherited: 0x48)
struct UInterpTrackInstVectorProp : UInterpTrackInstProperty {
	char pad_48[0x8]; // 0x48(0x08)
	struct FVector ResetVector; // 0x50(0x0c)
	char pad_5C[0x4]; // 0x5c(0x04)
};

// Class Engine.InterpTrackInstSlomo
// Size: 0x40 (Inherited: 0x38)
struct UInterpTrackInstSlomo : UInterpTrackInst {
	float OldTimeDilation; // 0x38(0x04)
	char pad_3C[0x4]; // 0x3c(0x04)
};

// Class Engine.InterpTrackInstSound
// Size: 0x48 (Inherited: 0x38)
struct UInterpTrackInstSound : UInterpTrackInst {
	float LastUpdatePosition; // 0x38(0x04)
	char pad_3C[0x4]; // 0x3c(0x04)
	struct UAudioComponent* PlayAudioComp; // 0x40(0x08)
};

// Class Engine.InterpTrackInstToggle
// Size: 0x48 (Inherited: 0x38)
struct UInterpTrackInstToggle : UInterpTrackInst {
	enum class ETrackToggleAction Action; // 0x38(0x01)
	char pad_39[0x3]; // 0x39(0x03)
	float LastUpdatePosition; // 0x3c(0x04)
	char bSavedActiveState : 1; // 0x40(0x01)
	char pad_40_1 : 7; // 0x40(0x01)
	char pad_41[0x7]; // 0x41(0x07)
};

// Class Engine.InterpTrackInstVectorMaterialParam
// Size: 0x70 (Inherited: 0x38)
struct UInterpTrackInstVectorMaterialParam : UInterpTrackInst {
	struct TArray<struct UMaterialInstanceDynamic*> MaterialInstances; // 0x38(0x10)
	struct TArray<struct FVector> ResetVectors; // 0x48(0x10)
	struct TArray<struct FPrimitiveMaterialRef> PrimitiveMaterialRefs; // 0x58(0x10)
	struct UInterpTrackVectorMaterialParam* InstancedTrack; // 0x68(0x08)
};

// Class Engine.InterpTrackInstVisibility
// Size: 0x40 (Inherited: 0x38)
struct UInterpTrackInstVisibility : UInterpTrackInst {
	enum class EVisibilityTrackAction Action; // 0x38(0x01)
	char pad_39[0x3]; // 0x39(0x03)
	float LastUpdatePosition; // 0x3c(0x04)
};

// Class Engine.IntSerialization
// Size: 0x60 (Inherited: 0x38)
struct UIntSerialization : UObject {
	uint16 UnsignedInt16Variable; // 0x38(0x02)
	char pad_3A[0x2]; // 0x3a(0x02)
	uint32 UnsignedInt32Variable; // 0x3c(0x04)
	uint64 UnsignedInt64Variable; // 0x40(0x08)
	int8 SignedInt8Variable; // 0x48(0x01)
	char pad_49[0x1]; // 0x49(0x01)
	int16 SignedInt16Variable; // 0x4a(0x02)
	char pad_4C[0x4]; // 0x4c(0x04)
	int64 SignedInt64Variable; // 0x50(0x08)
	bool UnsignedInt8Variable; // 0x58(0x01)
	char pad_59[0x3]; // 0x59(0x03)
	int32 SignedInt32Variable; // 0x5c(0x04)
};

// Class Engine.LevelBlockLandscapeContainer
// Size: 0x58 (Inherited: 0x38)
struct ULevelBlockLandscapeContainer : ULevelBlockResourceContainer {
	struct TArray<struct ULandscapeOverrideManager*> OverrideManagers; // 0x38(0x10)
	struct TArray<struct FLevelBlockLandscapeData> Instances; // 0x48(0x10)
};

// Class Engine.LandscapeOverrideManager
// Size: 0x1d0 (Inherited: 0x38)
struct ULandscapeOverrideManager : UObject {
	struct UWorld* World; // 0x38(0x08)
	struct ALandscape* Landscape; // 0x40(0x1c)
	struct FGuid LandscapeGuid; // 0x5c(0x10)
	struct FIntRect LandscapeDataRect; // 0x6c(0x10)
	char pad_7C[0x4]; // 0x7c(0x04)
	struct FLevelBlockLandscapeData LandscapeData; // 0x80(0x110)
	struct UMaterialInterface* LandscapeMaterial; // 0x190(0x08)
	struct UMaterialInterface* LandscapeHoleMaterial; // 0x198(0x08)
	uint32 BlendLayersMask; // 0x1a0(0x04)
	int32 VisibilityLayerIndex; // 0x1a4(0x04)
	struct TArray<struct FWeightmapLayerAllocationInfo> WeightmapLayerAllocations; // 0x1a8(0x10)
	struct TArray<struct FLandscapeOverrideInstance> GeneratedInstances; // 0x1b8(0x10)
	char pad_1C8[0x8]; // 0x1c8(0x08)
};

// Class Engine.Layer
// Size: 0x58 (Inherited: 0x38)
struct ULayer : UObject {
	struct FName LayerName; // 0x38(0x08)
	char bIsVisible : 1; // 0x40(0x01)
	char pad_40_1 : 7; // 0x40(0x01)
	char pad_41[0x7]; // 0x41(0x07)
	struct TArray<struct FLayerActorStats> ActorStats; // 0x48(0x10)
};

// Class Engine.LevelActorContainer
// Size: 0x48 (Inherited: 0x38)
struct ULevelActorContainer : UObject {
	struct TArray<struct AActor*> Actors; // 0x38(0x10)
};

// Class Engine.DecalResourceContainer
// Size: 0x68 (Inherited: 0x38)
struct UDecalResourceContainer : ULevelBlockResourceContainer {
	struct TArray<struct FDecalVariant> Variants; // 0x38(0x10)
	struct TArray<struct FTransform> Instances; // 0x48(0x10)
	struct TArray<struct FLevelBlockInstance> LevelBlockInstances; // 0x58(0x10)
};

// Class Engine.GrassVolumeResourceContainer
// Size: 0x48 (Inherited: 0x38)
struct UGrassVolumeResourceContainer : ULevelBlockResourceContainer {
	struct TArray<struct FGrassVolumeInstance> Instances; // 0x38(0x10)
};

// Class Engine.LevelBlockSpawnPointContainer
// Size: 0x58 (Inherited: 0x38)
struct ULevelBlockSpawnPointContainer : ULevelBlockResourceContainer {
	struct TArray<struct FLevelBlockSpawnPointTypes> LevelBlockTypes; // 0x38(0x10)
	struct TArray<struct FLevelBlockSpawnPointInstance> Instances; // 0x48(0x10)
};

// Class Engine.TextureRenderTarget
// Size: 0xd0 (Inherited: 0xc8)
struct UTextureRenderTarget : UTexture {
	float TargetGamma; // 0xc8(0x04)
	char pad_CC[0x4]; // 0xcc(0x04)
};

// Class Engine.TextureRenderTarget2D
// Size: 0xf8 (Inherited: 0xd0)
struct UTextureRenderTarget2D : UTextureRenderTarget {
	int32 SizeX; // 0xd0(0x04)
	int32 SizeY; // 0xd4(0x04)
	struct FLinearColor ClearColor; // 0xd8(0x10)
	enum class TextureAddress AddressX; // 0xe8(0x01)
	enum class TextureAddress AddressY; // 0xe9(0x01)
	char pad_EA[0x2]; // 0xea(0x02)
	char bForceLinearGamma : 1; // 0xec(0x01)
	char bCreateUAV : 1; // 0xec(0x01)
	char bHDR : 1; // 0xec(0x01)
	char bGPUSharedFlag : 1; // 0xec(0x01)
	char bAutoGenerateMips : 1; // 0xec(0x01)
	char pad_EC_5 : 3; // 0xec(0x01)
	char pad_ED[0x3]; // 0xed(0x03)
	enum class EPixelFormat OverrideFormat; // 0xf0(0x01)
	char pad_F1[0x7]; // 0xf1(0x07)
};

// Class Engine.MinimapManager
// Size: 0xa8 (Inherited: 0x38)
struct UMinimapManager : UObject {
	char pad_38[0x30]; // 0x38(0x30)
	struct UTexture2D* BaseMinimap; // 0x68(0x08)
	struct UTextureRenderTarget2D* MinimapRenderTarget; // 0x70(0x08)
	struct TArray<struct FMinimapObjectInstance> GeneratedObjects; // 0x78(0x10)
	struct TArray<struct FMinimapLabelInstance> GeneratedLabels; // 0x88(0x10)
	struct TArray<struct UObject*> LoadedDatas; // 0x98(0x10)
};

// Class Engine.MinimapResourceContainer
// Size: 0x60 (Inherited: 0x38)
struct UMinimapResourceContainer : ULevelBlockResourceContainer {
	struct TArray<struct FMinimapObjectInstance> ObjectInstances; // 0x38(0x10)
	struct TArray<struct FMinimapLabelInstance> LabelInstances; // 0x48(0x10)
	struct UMinimapManager* Manager; // 0x58(0x08)
};

// Class Engine.NavigationDataContainer
// Size: 0x70 (Inherited: 0x38)
struct UNavigationDataContainer : ULevelBlockResourceContainer {
	char pad_38[0x38]; // 0x38(0x38)
};

// Class Engine.PointLightContainer
// Size: 0x68 (Inherited: 0x38)
struct UPointLightContainer : ULevelBlockResourceContainer {
	struct TArray<struct FPointLightVariant> Variants; // 0x38(0x10)
	struct TArray<struct FTransform> Instances; // 0x48(0x10)
	struct TArray<struct FLevelBlockInstance> LevelBlockInstances; // 0x58(0x10)
};

// Class Engine.SplineMeshContainer
// Size: 0x48 (Inherited: 0x38)
struct USplineMeshContainer : ULevelBlockResourceContainer {
	struct TArray<struct FLevelBlockInstance> LevelBlockInstances; // 0x38(0x10)
};

// Class Engine.StaticMeshContainer
// Size: 0x68 (Inherited: 0x38)
struct UStaticMeshContainer : ULevelBlockResourceContainer {
	struct TArray<struct FStaticMeshVariant> Variants; // 0x38(0x10)
	struct TArray<struct FStaticMeshInstance> Instances; // 0x48(0x10)
	struct TArray<struct FLevelBlockInstance> LevelBlockInstances; // 0x58(0x10)
};

// Class Engine.LevelStreaming
// Size: 0x190 (Inherited: 0x38)
struct ULevelStreaming : UObject {
	struct FName PackageName; // 0x38(0x08)
	struct UWorld* WorldAsset; // 0x40(0x20)
	struct FName PackageNameToLoad; // 0x60(0x08)
	struct TArray<struct FName> LODPackageNames; // 0x68(0x10)
	char pad_78[0x18]; // 0x78(0x18)
	struct FTransform LevelTransform; // 0x90(0x30)
	char pad_C0[0x14]; // 0xc0(0x14)
	char pad_D4_0 : 4; // 0xd4(0x01)
	char bShouldBeVisibleInEditor : 1; // 0xd4(0x01)
	char bLocked : 1; // 0xd4(0x01)
	char bShouldBeLoaded : 1; // 0xd4(0x01)
	char bShouldBeVisible : 1; // 0xd4(0x01)
	char bIsStatic : 1; // 0xd5(0x01)
	char bShouldBlockOnLoad : 1; // 0xd5(0x01)
	char pad_D5_2 : 6; // 0xd5(0x01)
	char pad_D6[0x2]; // 0xd6(0x02)
	int32 LevelLODIndex; // 0xd8(0x04)
	char pad_DC[0x4]; // 0xdc(0x04)
	char bDisableDistanceStreaming : 1; // 0xe0(0x01)
	char pad_E0_1 : 1; // 0xe0(0x01)
	char bDrawOnLevelStatusMap : 1; // 0xe0(0x01)
	char pad_E0_3 : 5; // 0xe0(0x01)
	char pad_E1[0x3]; // 0xe1(0x03)
	struct FColor DrawColor; // 0xe4(0x04)
	struct FLinearColor LevelColor; // 0xe8(0x10)
	struct TArray<struct ALevelStreamingVolume*> EditorStreamingVolumes; // 0xf8(0x10)
	float MinTimeBetweenVolumeUnloadRequests; // 0x108(0x04)
	char pad_10C[0xc]; // 0x10c(0x0c)
	struct TArray<struct FString> Keywords; // 0x118(0x10)
	struct FMulticastDelegate OnLevelLoaded; // 0x128(0x10)
	struct FMulticastDelegate OnLevelUnloaded; // 0x138(0x10)
	struct FMulticastDelegate OnLevelShown; // 0x148(0x10)
	struct FMulticastDelegate OnLevelHidden; // 0x158(0x10)
	struct ULevel* LoadedLevel; // 0x168(0x08)
	struct ULevel* PendingUnloadLevel; // 0x170(0x08)
	char pad_178[0x18]; // 0x178(0x18)

	bool IsStreamingStatePending(); // Function Engine.LevelStreaming.IsStreamingStatePending // Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b6f718
	bool IsLevelVisible(); // Function Engine.LevelStreaming.IsLevelVisible // Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b6f268
	bool IsLevelLoaded(); // Function Engine.LevelStreaming.IsLevelLoaded // Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b6f24c
	struct ALevelScriptActor* GetLevelScriptActor(); // Function Engine.LevelStreaming.GetLevelScriptActor // Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure // @ game+0x5b6cd9c
	struct ULevelStreaming* CreateInstance(struct FString UniqueInstanceName); // Function Engine.LevelStreaming.CreateInstance // Final|Native|Public|BlueprintCallable // @ game+0x5b69d20
};

// Class Engine.LevelStreamingAlwaysLoaded
// Size: 0x190 (Inherited: 0x190)
struct ULevelStreamingAlwaysLoaded : ULevelStreaming {
};

// Class Engine.LevelStreamingKismet
// Size: 0x190 (Inherited: 0x190)
struct ULevelStreamingKismet : ULevelStreaming {
	char bInitiallyLoaded : 1; // 0x188(0x01)
	char bInitiallyVisible : 1; // 0x188(0x01)

	struct ULevelStreamingKismet* LoadLevelInstance(struct UObject* WorldContextObject, struct FString LevelName, struct FVector Location, struct FRotator Rotation, bool bOutSuccess); // Function Engine.LevelStreamingKismet.LoadLevelInstance // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable // @ game+0x5b72404
};

// Class Engine.LevelStreamingPersistent
// Size: 0x190 (Inherited: 0x190)
struct ULevelStreamingPersistent : ULevelStreaming {
};

// Class Engine.LightmappedSurfaceCollection
// Size: 0x50 (Inherited: 0x38)
struct ULightmappedSurfaceCollection : UObject {
	struct UModel* SourceModel; // 0x38(0x08)
	struct TArray<int32> Surfaces; // 0x40(0x10)
};

// Class Engine.LightmassPrimitiveSettingsObject
// Size: 0x50 (Inherited: 0x38)
struct ULightmassPrimitiveSettingsObject : UObject {
	struct FLightmassPrimitiveSettings LightmassSettings; // 0x38(0x18)
};

// Class Engine.LocalMessage
// Size: 0x38 (Inherited: 0x38)
struct ULocalMessage : UObject {
};

// Class Engine.EngineMessage
// Size: 0xb8 (Inherited: 0x38)
struct UEngineMessage : ULocalMessage {
	struct FString FailedPlaceMessage; // 0x38(0x10)
	struct FString MaxedOutMessage; // 0x48(0x10)
	struct FString EnteredMessage; // 0x58(0x10)
	struct FString LeftMessage; // 0x68(0x10)
	struct FString GlobalNameChange; // 0x78(0x10)
	struct FString SpecEnteredMessage; // 0x88(0x10)
	struct FString NewPlayerMessage; // 0x98(0x10)
	struct FString NewSpecMessage; // 0xa8(0x10)
};

// Class Engine.MapBuildDataRegistry
// Size: 0x130 (Inherited: 0x38)
struct UMapBuildDataRegistry : UObject {
	enum class ELightingBuildQuality LevelLightingQuality; // 0x38(0x01)
	char pad_39[0xf7]; // 0x39(0xf7)
};

// Class Engine.MaterialExpressionAbs
// Size: 0xa8 (Inherited: 0x70)
struct UMaterialExpressionAbs : UMaterialExpression {
	struct FExpressionInput Input; // 0x70(0x38)
};

// Class Engine.MaterialExpressionActorPositionWS
// Size: 0x70 (Inherited: 0x70)
struct UMaterialExpressionActorPositionWS : UMaterialExpression {
};

// Class Engine.MaterialExpressionAdd
// Size: 0xe8 (Inherited: 0x70)
struct UMaterialExpressionAdd : UMaterialExpression {
	struct FExpressionInput A; // 0x70(0x38)
	struct FExpressionInput B; // 0xa8(0x38)
	float ConstA; // 0xe0(0x04)
	float ConstB; // 0xe4(0x04)
};

// Class Engine.MaterialExpressionAppendVector
// Size: 0xe0 (Inherited: 0x70)
struct UMaterialExpressionAppendVector : UMaterialExpression {
	struct FExpressionInput A; // 0x70(0x38)
	struct FExpressionInput B; // 0xa8(0x38)
};

// Class Engine.MaterialExpressionArccosine
// Size: 0xa8 (Inherited: 0x70)
struct UMaterialExpressionArccosine : UMaterialExpression {
	struct FExpressionInput Input; // 0x70(0x38)
};

// Class Engine.MaterialExpressionArccosineFast
// Size: 0xa8 (Inherited: 0x70)
struct UMaterialExpressionArccosineFast : UMaterialExpression {
	struct FExpressionInput Input; // 0x70(0x38)
};

// Class Engine.MaterialExpressionArcsine
// Size: 0xa8 (Inherited: 0x70)
struct UMaterialExpressionArcsine : UMaterialExpression {
	struct FExpressionInput Input; // 0x70(0x38)
};

// Class Engine.MaterialExpressionArcsineFast
// Size: 0xa8 (Inherited: 0x70)
struct UMaterialExpressionArcsineFast : UMaterialExpression {
	struct FExpressionInput Input; // 0x70(0x38)
};

// Class Engine.MaterialExpressionArctangent
// Size: 0xa8 (Inherited: 0x70)
struct UMaterialExpressionArctangent : UMaterialExpression {
	struct FExpressionInput Input; // 0x70(0x38)
};

// Class Engine.MaterialExpressionArctangent2
// Size: 0xe0 (Inherited: 0x70)
struct UMaterialExpressionArctangent2 : UMaterialExpression {
	struct FExpressionInput Y; // 0x70(0x38)
	struct FExpressionInput X; // 0xa8(0x38)
};

// Class Engine.MaterialExpressionArctangent2Fast
// Size: 0xe0 (Inherited: 0x70)
struct UMaterialExpressionArctangent2Fast : UMaterialExpression {
	struct FExpressionInput Y; // 0x70(0x38)
	struct FExpressionInput X; // 0xa8(0x38)
};

// Class Engine.MaterialExpressionArctangentFast
// Size: 0xa8 (Inherited: 0x70)
struct UMaterialExpressionArctangentFast : UMaterialExpression {
	struct FExpressionInput Input; // 0x70(0x38)
};

// Class Engine.MaterialExpressionAtmosphericFogColor
// Size: 0xa8 (Inherited: 0x70)
struct UMaterialExpressionAtmosphericFogColor : UMaterialExpression {
	struct FExpressionInput WorldPosition; // 0x70(0x38)
};

// Class Engine.MaterialExpressionAtmosphericLightColor
// Size: 0x70 (Inherited: 0x70)
struct UMaterialExpressionAtmosphericLightColor : UMaterialExpression {
};

// Class Engine.MaterialExpressionAtmosphericLightVector
// Size: 0x70 (Inherited: 0x70)
struct UMaterialExpressionAtmosphericLightVector : UMaterialExpression {
};

// Class Engine.MaterialExpressionBlackBody
// Size: 0xa8 (Inherited: 0x70)
struct UMaterialExpressionBlackBody : UMaterialExpression {
	struct FExpressionInput Temp; // 0x70(0x38)
};

// Class Engine.MaterialExpressionBlendMaterialAttributes
// Size: 0x130 (Inherited: 0x70)
struct UMaterialExpressionBlendMaterialAttributes : UMaterialExpression {
	struct FMaterialAttributesInput A; // 0x70(0x40)
	struct FMaterialAttributesInput B; // 0xb0(0x40)
	struct FExpressionInput ALPHA; // 0xf0(0x38)
	enum class EMaterialAttributeBlend PixelAttributeBlendType; // 0x128(0x01)
	enum class EMaterialAttributeBlend VertexAttributeBlendType; // 0x129(0x01)
	char pad_12A[0x6]; // 0x12a(0x06)
};

// Class Engine.MaterialExpressionBreakMaterialAttributes
// Size: 0xb0 (Inherited: 0x70)
struct UMaterialExpressionBreakMaterialAttributes : UMaterialExpression {
	struct FMaterialAttributesInput MaterialAttributes; // 0x70(0x40)
};

// Class Engine.MaterialExpressionBumpOffset
// Size: 0x128 (Inherited: 0x70)
struct UMaterialExpressionBumpOffset : UMaterialExpression {
	struct FExpressionInput Coordinate; // 0x70(0x38)
	struct FExpressionInput Height; // 0xa8(0x38)
	struct FExpressionInput HeightRatioInput; // 0xe0(0x38)
	float HeightRatio; // 0x118(0x04)
	float ReferencePlane; // 0x11c(0x04)
	uint32 ConstCoordinate; // 0x120(0x04)
	char pad_124[0x4]; // 0x124(0x04)
};

// Class Engine.MaterialExpressionCameraPositionWS
// Size: 0x70 (Inherited: 0x70)
struct UMaterialExpressionCameraPositionWS : UMaterialExpression {
};

// Class Engine.MaterialExpressionCameraVectorWS
// Size: 0x70 (Inherited: 0x70)
struct UMaterialExpressionCameraVectorWS : UMaterialExpression {
};

// Class Engine.MaterialExpressionCeil
// Size: 0xa8 (Inherited: 0x70)
struct UMaterialExpressionCeil : UMaterialExpression {
	struct FExpressionInput Input; // 0x70(0x38)
};

// Class Engine.MaterialExpressionClamp
// Size: 0x128 (Inherited: 0x70)
struct UMaterialExpressionClamp : UMaterialExpression {
	struct FExpressionInput Input; // 0x70(0x38)
	struct FExpressionInput Min; // 0xa8(0x38)
	struct FExpressionInput Max; // 0xe0(0x38)
	enum class EClampMode ClampMode; // 0x118(0x01)
	char pad_119[0x3]; // 0x119(0x03)
	float MinDefault; // 0x11c(0x04)
	float MaxDefault; // 0x120(0x04)
	char pad_124[0x4]; // 0x124(0x04)
};

// Class Engine.MaterialExpressionCollectionParameter
// Size: 0x90 (Inherited: 0x70)
struct UMaterialExpressionCollectionParameter : UMaterialExpression {
	struct UMaterialParameterCollection* Collection; // 0x70(0x08)
	struct FName ParameterName; // 0x78(0x08)
	struct FGuid ParameterId; // 0x80(0x10)
};

// Class Engine.MaterialExpressionComment
// Size: 0x98 (Inherited: 0x70)
struct UMaterialExpressionComment : UMaterialExpression {
	int32 SizeX; // 0x70(0x04)
	int32 SizeY; // 0x74(0x04)
	struct FString Text; // 0x78(0x10)
	struct FLinearColor CommentColor; // 0x88(0x10)
};

// Class Engine.MaterialExpressionComponentMask
// Size: 0xb0 (Inherited: 0x70)
struct UMaterialExpressionComponentMask : UMaterialExpression {
	struct FExpressionInput Input; // 0x70(0x38)
	char R : 1; // 0xa8(0x01)
	char G : 1; // 0xa8(0x01)
	char B : 1; // 0xa8(0x01)
	char A : 1; // 0xa8(0x01)
	char pad_A8_4 : 4; // 0xa8(0x01)
	char pad_A9[0x7]; // 0xa9(0x07)
};

// Class Engine.MaterialExpressionConstant
// Size: 0x78 (Inherited: 0x70)
struct UMaterialExpressionConstant : UMaterialExpression {
	float R; // 0x70(0x04)
	char pad_74[0x4]; // 0x74(0x04)
};

// Class Engine.MaterialExpressionConstant2Vector
// Size: 0x78 (Inherited: 0x70)
struct UMaterialExpressionConstant2Vector : UMaterialExpression {
	float R; // 0x70(0x04)
	float G; // 0x74(0x04)
};

// Class Engine.MaterialExpressionConstant3Vector
// Size: 0x80 (Inherited: 0x70)
struct UMaterialExpressionConstant3Vector : UMaterialExpression {
	struct FLinearColor Constant; // 0x70(0x10)
};

// Class Engine.MaterialExpressionConstant4Vector
// Size: 0x80 (Inherited: 0x70)
struct UMaterialExpressionConstant4Vector : UMaterialExpression {
	struct FLinearColor Constant; // 0x70(0x10)
};

// Class Engine.MaterialExpressionConstantBiasScale
// Size: 0xb0 (Inherited: 0x70)
struct UMaterialExpressionConstantBiasScale : UMaterialExpression {
	struct FExpressionInput Input; // 0x70(0x38)
	float Bias; // 0xa8(0x04)
	float Scale; // 0xac(0x04)
};

// Class Engine.MaterialExpressionCosine
// Size: 0xb0 (Inherited: 0x70)
struct UMaterialExpressionCosine : UMaterialExpression {
	struct FExpressionInput Input; // 0x70(0x38)
	float Period; // 0xa8(0x04)
	char pad_AC[0x4]; // 0xac(0x04)
};

// Class Engine.MaterialExpressionCrossProduct
// Size: 0xe0 (Inherited: 0x70)
struct UMaterialExpressionCrossProduct : UMaterialExpression {
	struct FExpressionInput A; // 0x70(0x38)
	struct FExpressionInput B; // 0xa8(0x38)
};

// Class Engine.MaterialExpressionCustom
// Size: 0xa8 (Inherited: 0x70)
struct UMaterialExpressionCustom : UMaterialExpression {
	struct FString Code; // 0x70(0x10)
	enum class ECustomMaterialOutputType OutputType; // 0x80(0x01)
	char pad_81[0x7]; // 0x81(0x07)
	struct FString Description; // 0x88(0x10)
	struct TArray<struct FCustomInput> Inputs; // 0x98(0x10)
};

// Class Engine.MaterialExpressionClearCoatNormalCustomOutput
// Size: 0xa8 (Inherited: 0x70)
struct UMaterialExpressionClearCoatNormalCustomOutput : UMaterialExpressionCustomOutput {
	struct FExpressionInput Input; // 0x70(0x38)
};

// Class Engine.MaterialExpressionTangentOutput
// Size: 0xa8 (Inherited: 0x70)
struct UMaterialExpressionTangentOutput : UMaterialExpressionCustomOutput {
	struct FExpressionInput Input; // 0x70(0x38)
};

// Class Engine.MaterialExpressionVertexInterpolator
// Size: 0xb8 (Inherited: 0x70)
struct UMaterialExpressionVertexInterpolator : UMaterialExpressionCustomOutput {
	struct FExpressionInput Input; // 0x70(0x38)
	char pad_A8[0x10]; // 0xa8(0x10)
};

// Class Engine.MaterialExpressionDDX
// Size: 0xa8 (Inherited: 0x70)
struct UMaterialExpressionDDX : UMaterialExpression {
	struct FExpressionInput Value; // 0x70(0x38)
};

// Class Engine.MaterialExpressionDDY
// Size: 0xa8 (Inherited: 0x70)
struct UMaterialExpressionDDY : UMaterialExpression {
	struct FExpressionInput Value; // 0x70(0x38)
};

// Class Engine.MaterialExpressionDecalDerivative
// Size: 0x70 (Inherited: 0x70)
struct UMaterialExpressionDecalDerivative : UMaterialExpression {
};

// Class Engine.MaterialExpressionDecalLifetimeOpacity
// Size: 0x70 (Inherited: 0x70)
struct UMaterialExpressionDecalLifetimeOpacity : UMaterialExpression {
};

// Class Engine.MaterialExpressionDecalMipmapLevel
// Size: 0xb0 (Inherited: 0x70)
struct UMaterialExpressionDecalMipmapLevel : UMaterialExpression {
	struct FExpressionInput TextureSize; // 0x70(0x38)
	float ConstWidth; // 0xa8(0x04)
	float ConstHeight; // 0xac(0x04)
};

// Class Engine.MaterialExpressionDepthFade
// Size: 0xe8 (Inherited: 0x70)
struct UMaterialExpressionDepthFade : UMaterialExpression {
	struct FExpressionInput InOpacity; // 0x70(0x38)
	struct FExpressionInput FadeDistance; // 0xa8(0x38)
	float OpacityDefault; // 0xe0(0x04)
	float FadeDistanceDefault; // 0xe4(0x04)
};

// Class Engine.MaterialExpressionDepthOfFieldFunction
// Size: 0xb0 (Inherited: 0x70)
struct UMaterialExpressionDepthOfFieldFunction : UMaterialExpression {
	enum class EDepthOfFieldFunctionValue FunctionValue; // 0x70(0x01)
	char pad_71[0x7]; // 0x71(0x07)
	struct FExpressionInput Depth; // 0x78(0x38)
};

// Class Engine.MaterialExpressionDeriveNormalZ
// Size: 0xa8 (Inherited: 0x70)
struct UMaterialExpressionDeriveNormalZ : UMaterialExpression {
	struct FExpressionInput InXY; // 0x70(0x38)
};

// Class Engine.MaterialExpressionDesaturation
// Size: 0xf0 (Inherited: 0x70)
struct UMaterialExpressionDesaturation : UMaterialExpression {
	struct FExpressionInput Input; // 0x70(0x38)
	struct FExpressionInput Fraction; // 0xa8(0x38)
	struct FLinearColor LuminanceFactors; // 0xe0(0x10)
};

// Class Engine.MaterialExpressionDistance
// Size: 0xe0 (Inherited: 0x70)
struct UMaterialExpressionDistance : UMaterialExpression {
	struct FExpressionInput A; // 0x70(0x38)
	struct FExpressionInput B; // 0xa8(0x38)
};

// Class Engine.MaterialExpressionDistanceCullFade
// Size: 0x70 (Inherited: 0x70)
struct UMaterialExpressionDistanceCullFade : UMaterialExpression {
};

// Class Engine.MaterialExpressionDistanceFieldGradient
// Size: 0xa8 (Inherited: 0x70)
struct UMaterialExpressionDistanceFieldGradient : UMaterialExpression {
	struct FExpressionInput Position; // 0x70(0x38)
};

// Class Engine.MaterialExpressionDistanceToNearestSurface
// Size: 0xa8 (Inherited: 0x70)
struct UMaterialExpressionDistanceToNearestSurface : UMaterialExpression {
	struct FExpressionInput Position; // 0x70(0x38)
};

// Class Engine.MaterialExpressionDivide
// Size: 0xe8 (Inherited: 0x70)
struct UMaterialExpressionDivide : UMaterialExpression {
	struct FExpressionInput A; // 0x70(0x38)
	struct FExpressionInput B; // 0xa8(0x38)
	float ConstA; // 0xe0(0x04)
	float ConstB; // 0xe4(0x04)
};

// Class Engine.MaterialExpressionDotProduct
// Size: 0xe0 (Inherited: 0x70)
struct UMaterialExpressionDotProduct : UMaterialExpression {
	struct FExpressionInput A; // 0x70(0x38)
	struct FExpressionInput B; // 0xa8(0x38)
};

// Class Engine.MaterialExpressionDynamicParameter
// Size: 0x90 (Inherited: 0x70)
struct UMaterialExpressionDynamicParameter : UMaterialExpression {
	struct TArray<struct FString> ParamNames; // 0x70(0x10)
	struct FLinearColor DefaultValue; // 0x80(0x10)
};

// Class Engine.MaterialExpressionEyeAdaptation
// Size: 0x70 (Inherited: 0x70)
struct UMaterialExpressionEyeAdaptation : UMaterialExpression {
};

// Class Engine.MaterialExpressionFeatureLevelSwitch
// Size: 0x188 (Inherited: 0x70)
struct UMaterialExpressionFeatureLevelSwitch : UMaterialExpression {
	struct FExpressionInput Default; // 0x70(0x38)
	struct FExpressionInput Inputs[0x04]; // 0xa8(0xe0)
};

// Class Engine.MaterialExpressionFloor
// Size: 0xa8 (Inherited: 0x70)
struct UMaterialExpressionFloor : UMaterialExpression {
	struct FExpressionInput Input; // 0x70(0x38)
};

// Class Engine.MaterialExpressionFmod
// Size: 0xe0 (Inherited: 0x70)
struct UMaterialExpressionFmod : UMaterialExpression {
	struct FExpressionInput A; // 0x70(0x38)
	struct FExpressionInput B; // 0xa8(0x38)
};

// Class Engine.MaterialExpressionFontSample
// Size: 0x80 (Inherited: 0x70)
struct UMaterialExpressionFontSample : UMaterialExpression {
	struct UFont* Font; // 0x70(0x08)
	int32 FontTexturePage; // 0x78(0x04)
	char pad_7C[0x4]; // 0x7c(0x04)
};

// Class Engine.MaterialExpressionFontSampleParameter
// Size: 0xa0 (Inherited: 0x80)
struct UMaterialExpressionFontSampleParameter : UMaterialExpressionFontSample {
	struct FName ParameterName; // 0x80(0x08)
	struct FGuid ExpressionGUID; // 0x88(0x10)
	struct FName Group; // 0x98(0x08)
};

// Class Engine.MaterialExpressionFrac
// Size: 0xa8 (Inherited: 0x70)
struct UMaterialExpressionFrac : UMaterialExpression {
	struct FExpressionInput Input; // 0x70(0x38)
};

// Class Engine.MaterialExpressionFresnel
// Size: 0x128 (Inherited: 0x70)
struct UMaterialExpressionFresnel : UMaterialExpression {
	struct FExpressionInput ExponentIn; // 0x70(0x38)
	float Exponent; // 0xa8(0x04)
	char pad_AC[0x4]; // 0xac(0x04)
	struct FExpressionInput BaseReflectFractionIn; // 0xb0(0x38)
	float BaseReflectFraction; // 0xe8(0x04)
	char pad_EC[0x4]; // 0xec(0x04)
	struct FExpressionInput Normal; // 0xf0(0x38)
};

// Class Engine.MaterialExpressionFunctionInput
// Size: 0x140 (Inherited: 0x70)
struct UMaterialExpressionFunctionInput : UMaterialExpression {
	struct FExpressionInput Preview; // 0x70(0x38)
	struct FString InputName; // 0xa8(0x10)
	struct FString Description; // 0xb8(0x10)
	struct FGuid ID; // 0xc8(0x10)
	enum class EFunctionInputType InputType; // 0xd8(0x01)
	char pad_D9[0x7]; // 0xd9(0x07)
	struct FVector4 PreviewValue; // 0xe0(0x10)
	char bUsePreviewValueAsDefault : 1; // 0xf0(0x01)
	char pad_F0_1 : 7; // 0xf0(0x01)
	char pad_F1[0x3]; // 0xf1(0x03)
	int32 SortPriority; // 0xf4(0x04)
	char bCompilingFunctionPreview : 1; // 0xf8(0x01)
	char pad_F8_1 : 7; // 0xf8(0x01)
	char pad_F9[0x47]; // 0xf9(0x47)
};

// Class Engine.MaterialExpressionFunctionOutput
// Size: 0xe8 (Inherited: 0x70)
struct UMaterialExpressionFunctionOutput : UMaterialExpression {
	struct FString OutputName; // 0x70(0x10)
	struct FString Description; // 0x80(0x10)
	int32 SortPriority; // 0x90(0x04)
	char pad_94[0x4]; // 0x94(0x04)
	struct FExpressionInput A; // 0x98(0x38)
	char bLastPreviewed : 1; // 0xd0(0x01)
	char pad_D0_1 : 7; // 0xd0(0x01)
	char pad_D1[0x3]; // 0xd1(0x03)
	struct FGuid ID; // 0xd4(0x10)
	char pad_E4[0x4]; // 0xe4(0x04)
};

// Class Engine.MaterialExpressionGetMaterialAttributes
// Size: 0xc0 (Inherited: 0x70)
struct UMaterialExpressionGetMaterialAttributes : UMaterialExpression {
	struct FMaterialAttributesInput MaterialAttributes; // 0x70(0x40)
	struct TArray<struct FGuid> AttributeGetTypes; // 0xb0(0x10)
};

// Class Engine.MaterialExpressionGIReplace
// Size: 0x118 (Inherited: 0x70)
struct UMaterialExpressionGIReplace : UMaterialExpression {
	struct FExpressionInput Default; // 0x70(0x38)
	struct FExpressionInput StaticIndirect; // 0xa8(0x38)
	struct FExpressionInput DynamicIndirect; // 0xe0(0x38)
};

// Class Engine.MaterialExpressionIf
// Size: 0x198 (Inherited: 0x70)
struct UMaterialExpressionIf : UMaterialExpression {
	struct FExpressionInput A; // 0x70(0x38)
	struct FExpressionInput B; // 0xa8(0x38)
	struct FExpressionInput AGreaterThanB; // 0xe0(0x38)
	struct FExpressionInput AEqualsB; // 0x118(0x38)
	struct FExpressionInput ALessThanB; // 0x150(0x38)
	float EqualsThreshold; // 0x188(0x04)
	float ConstB; // 0x18c(0x04)
	float ConstAEqualsB; // 0x190(0x04)
	char pad_194[0x4]; // 0x194(0x04)
};

// Class Engine.MaterialExpressionLightmapUVs
// Size: 0x70 (Inherited: 0x70)
struct UMaterialExpressionLightmapUVs : UMaterialExpression {
};

// Class Engine.MaterialExpressionLightmassReplace
// Size: 0xe0 (Inherited: 0x70)
struct UMaterialExpressionLightmassReplace : UMaterialExpression {
	struct FExpressionInput RealTime; // 0x70(0x38)
	struct FExpressionInput Lightmass; // 0xa8(0x38)
};

// Class Engine.MaterialExpressionLightVector
// Size: 0x70 (Inherited: 0x70)
struct UMaterialExpressionLightVector : UMaterialExpression {
};

// Class Engine.MaterialExpressionLinearInterpolate
// Size: 0x128 (Inherited: 0x70)
struct UMaterialExpressionLinearInterpolate : UMaterialExpression {
	struct FExpressionInput A; // 0x70(0x38)
	struct FExpressionInput B; // 0xa8(0x38)
	struct FExpressionInput ALPHA; // 0xe0(0x38)
	float ConstA; // 0x118(0x04)
	float ConstB; // 0x11c(0x04)
	float ConstAlpha; // 0x120(0x04)
	char pad_124[0x4]; // 0x124(0x04)
};

// Class Engine.MaterialExpressionLogarithm2
// Size: 0xa8 (Inherited: 0x70)
struct UMaterialExpressionLogarithm2 : UMaterialExpression {
	struct FExpressionInput X; // 0x70(0x38)
};

// Class Engine.MaterialExpressionMakeMaterialAttributes
// Size: 0x5e8 (Inherited: 0x70)
struct UMaterialExpressionMakeMaterialAttributes : UMaterialExpression {
	struct FExpressionInput BaseColor; // 0x70(0x38)
	struct FExpressionInput Metallic; // 0xa8(0x38)
	struct FExpressionInput Specular; // 0xe0(0x38)
	struct FExpressionInput Roughness; // 0x118(0x38)
	struct FExpressionInput EmissiveColor; // 0x150(0x38)
	struct FExpressionInput Opacity; // 0x188(0x38)
	struct FExpressionInput OpacityMask; // 0x1c0(0x38)
	struct FExpressionInput Normal; // 0x1f8(0x38)
	struct FExpressionInput WorldPositionOffset; // 0x230(0x38)
	struct FExpressionInput WorldDisplacement; // 0x268(0x38)
	struct FExpressionInput TessellationMultiplier; // 0x2a0(0x38)
	struct FExpressionInput SubsurfaceColor; // 0x2d8(0x38)
	struct FExpressionInput ClearCoat; // 0x310(0x38)
	struct FExpressionInput ClearCoatRoughness; // 0x348(0x38)
	struct FExpressionInput AmbientOcclusion; // 0x380(0x38)
	struct FExpressionInput Refraction; // 0x3b8(0x38)
	struct FExpressionInput CustomizedUVs[0x08]; // 0x3f0(0x1c0)
	struct FExpressionInput PixelDepthOffset; // 0x5b0(0x38)
};

// Class Engine.MaterialExpressionMaterialFunctionCall
// Size: 0x98 (Inherited: 0x70)
struct UMaterialExpressionMaterialFunctionCall : UMaterialExpression {
	struct UMaterialFunction* MaterialFunction; // 0x70(0x08)
	struct TArray<struct FFunctionExpressionInput> FunctionInputs; // 0x78(0x10)
	struct TArray<struct FFunctionExpressionOutput> FunctionOutputs; // 0x88(0x10)
};

// Class Engine.MaterialExpressionMaterialProxyReplace
// Size: 0xe0 (Inherited: 0x70)
struct UMaterialExpressionMaterialProxyReplace : UMaterialExpression {
	struct FExpressionInput RealTime; // 0x70(0x38)
	struct FExpressionInput MaterialProxy; // 0xa8(0x38)
};

// Class Engine.MaterialExpressionMax
// Size: 0xe8 (Inherited: 0x70)
struct UMaterialExpressionMax : UMaterialExpression {
	struct FExpressionInput A; // 0x70(0x38)
	struct FExpressionInput B; // 0xa8(0x38)
	float ConstA; // 0xe0(0x04)
	float ConstB; // 0xe4(0x04)
};

// Class Engine.MaterialExpressionMin
// Size: 0xe8 (Inherited: 0x70)
struct UMaterialExpressionMin : UMaterialExpression {
	struct FExpressionInput A; // 0x70(0x38)
	struct FExpressionInput B; // 0xa8(0x38)
	float ConstA; // 0xe0(0x04)
	float ConstB; // 0xe4(0x04)
};

// Class Engine.MaterialExpressionMultiply
// Size: 0xe8 (Inherited: 0x70)
struct UMaterialExpressionMultiply : UMaterialExpression {
	struct FExpressionInput A; // 0x70(0x38)
	struct FExpressionInput B; // 0xa8(0x38)
	float ConstA; // 0xe0(0x04)
	float ConstB; // 0xe4(0x04)
};

// Class Engine.MaterialExpressionNoise
// Size: 0x108 (Inherited: 0x70)
struct UMaterialExpressionNoise : UMaterialExpression {
	struct FExpressionInput Position; // 0x70(0x38)
	struct FExpressionInput FilterWidth; // 0xa8(0x38)
	float Scale; // 0xe0(0x04)
	int32 Quality; // 0xe4(0x04)
	enum class ENoiseFunction NoiseFunction; // 0xe8(0x01)
	char pad_E9[0x3]; // 0xe9(0x03)
	char bTurbulence : 1; // 0xec(0x01)
	char pad_EC_1 : 7; // 0xec(0x01)
	char pad_ED[0x3]; // 0xed(0x03)
	int32 Levels; // 0xf0(0x04)
	float OutputMin; // 0xf4(0x04)
	float OutputMax; // 0xf8(0x04)
	float LevelScale; // 0xfc(0x04)
	char bTiling : 1; // 0x100(0x01)
	char pad_100_1 : 7; // 0x100(0x01)
	char pad_101[0x3]; // 0x101(0x03)
	uint32 RepeatSize; // 0x104(0x04)
};

// Class Engine.MaterialExpressionNormalize
// Size: 0xa8 (Inherited: 0x70)
struct UMaterialExpressionNormalize : UMaterialExpression {
	struct FExpressionInput VectorInput; // 0x70(0x38)
};

// Class Engine.MaterialExpressionObjectBounds
// Size: 0x70 (Inherited: 0x70)
struct UMaterialExpressionObjectBounds : UMaterialExpression {
};

// Class Engine.MaterialExpressionObjectOrientation
// Size: 0x70 (Inherited: 0x70)
struct UMaterialExpressionObjectOrientation : UMaterialExpression {
};

// Class Engine.MaterialExpressionObjectPositionWS
// Size: 0x78 (Inherited: 0x70)
struct UMaterialExpressionObjectPositionWS : UMaterialExpression {
	enum class EObjectPositionIncludedOffsets ObjectPositionShaderOffset; // 0x70(0x01)
	char pad_71[0x7]; // 0x71(0x07)
};

// Class Engine.MaterialExpressionObjectRadius
// Size: 0x70 (Inherited: 0x70)
struct UMaterialExpressionObjectRadius : UMaterialExpression {
};

// Class Engine.MaterialExpressionOneMinus
// Size: 0xa8 (Inherited: 0x70)
struct UMaterialExpressionOneMinus : UMaterialExpression {
	struct FExpressionInput Input; // 0x70(0x38)
};

// Class Engine.MaterialExpressionPanner
// Size: 0x128 (Inherited: 0x70)
struct UMaterialExpressionPanner : UMaterialExpression {
	struct FExpressionInput Coordinate; // 0x70(0x38)
	struct FExpressionInput Time; // 0xa8(0x38)
	struct FExpressionInput Speed; // 0xe0(0x38)
	float SpeedX; // 0x118(0x04)
	float SpeedY; // 0x11c(0x04)
	uint32 ConstCoordinate; // 0x120(0x04)
	bool bFractionalPart; // 0x124(0x01)
	char pad_125[0x3]; // 0x125(0x03)
};

// Class Engine.MaterialExpressionParameter
// Size: 0x90 (Inherited: 0x70)
struct UMaterialExpressionParameter : UMaterialExpression {
	struct FName ParameterName; // 0x70(0x08)
	struct FGuid ExpressionGUID; // 0x78(0x10)
	struct FName Group; // 0x88(0x08)
};

// Class Engine.MaterialExpressionScalarParameter
// Size: 0xa0 (Inherited: 0x90)
struct UMaterialExpressionScalarParameter : UMaterialExpressionParameter {
	float DefaultValue; // 0x90(0x04)
	float SliderMin; // 0x94(0x04)
	float SliderMax; // 0x98(0x04)
	char pad_9C[0x4]; // 0x9c(0x04)
};

// Class Engine.MaterialExpressionStaticBoolParameter
// Size: 0x98 (Inherited: 0x90)
struct UMaterialExpressionStaticBoolParameter : UMaterialExpressionParameter {
	char DefaultValue : 1; // 0x90(0x01)
	char pad_90_1 : 7; // 0x90(0x01)
	char pad_91[0x7]; // 0x91(0x07)
};

// Class Engine.MaterialExpressionStaticSwitchParameter
// Size: 0x108 (Inherited: 0x98)
struct UMaterialExpressionStaticSwitchParameter : UMaterialExpressionStaticBoolParameter {
	struct FExpressionInput A; // 0x98(0x38)
	struct FExpressionInput B; // 0xd0(0x38)
};

// Class Engine.MaterialExpressionStaticComponentMaskParameter
// Size: 0xd0 (Inherited: 0x90)
struct UMaterialExpressionStaticComponentMaskParameter : UMaterialExpressionParameter {
	struct FExpressionInput Input; // 0x90(0x38)
	char DefaultR : 1; // 0xc8(0x01)
	char DefaultG : 1; // 0xc8(0x01)
	char DefaultB : 1; // 0xc8(0x01)
	char DefaultA : 1; // 0xc8(0x01)
	char pad_C8_4 : 4; // 0xc8(0x01)
	char pad_C9[0x7]; // 0xc9(0x07)
};

// Class Engine.MaterialExpressionVectorParameter
// Size: 0xa0 (Inherited: 0x90)
struct UMaterialExpressionVectorParameter : UMaterialExpressionParameter {
	struct FLinearColor DefaultValue; // 0x90(0x10)
};

// Class Engine.MaterialExpressionParticleColor
// Size: 0x70 (Inherited: 0x70)
struct UMaterialExpressionParticleColor : UMaterialExpression {
};

// Class Engine.MaterialExpressionParticleDirection
// Size: 0x70 (Inherited: 0x70)
struct UMaterialExpressionParticleDirection : UMaterialExpression {
};

// Class Engine.MaterialExpressionParticleMacroUV
// Size: 0x70 (Inherited: 0x70)
struct UMaterialExpressionParticleMacroUV : UMaterialExpression {
};

// Class Engine.MaterialExpressionParticleMotionBlurFade
// Size: 0x70 (Inherited: 0x70)
struct UMaterialExpressionParticleMotionBlurFade : UMaterialExpression {
};

// Class Engine.MaterialExpressionParticlePositionWS
// Size: 0x70 (Inherited: 0x70)
struct UMaterialExpressionParticlePositionWS : UMaterialExpression {
};

// Class Engine.MaterialExpressionParticleRadius
// Size: 0x70 (Inherited: 0x70)
struct UMaterialExpressionParticleRadius : UMaterialExpression {
};

// Class Engine.MaterialExpressionParticleRandom
// Size: 0x70 (Inherited: 0x70)
struct UMaterialExpressionParticleRandom : UMaterialExpression {
};

// Class Engine.MaterialExpressionParticleRelativeTime
// Size: 0x70 (Inherited: 0x70)
struct UMaterialExpressionParticleRelativeTime : UMaterialExpression {
};

// Class Engine.MaterialExpressionParticleSize
// Size: 0x70 (Inherited: 0x70)
struct UMaterialExpressionParticleSize : UMaterialExpression {
};

// Class Engine.MaterialExpressionParticleSpeed
// Size: 0x70 (Inherited: 0x70)
struct UMaterialExpressionParticleSpeed : UMaterialExpression {
};

// Class Engine.MaterialExpressionPerInstanceCustomData
// Size: 0x70 (Inherited: 0x70)
struct UMaterialExpressionPerInstanceCustomData : UMaterialExpression {
};

// Class Engine.MaterialExpressionPerInstanceFadeAmount
// Size: 0x70 (Inherited: 0x70)
struct UMaterialExpressionPerInstanceFadeAmount : UMaterialExpression {
};

// Class Engine.MaterialExpressionPerInstanceRandom
// Size: 0x70 (Inherited: 0x70)
struct UMaterialExpressionPerInstanceRandom : UMaterialExpression {
};

// Class Engine.MaterialExpressionPixelDepth
// Size: 0x70 (Inherited: 0x70)
struct UMaterialExpressionPixelDepth : UMaterialExpression {
};

// Class Engine.MaterialExpressionPixelNormalWS
// Size: 0x70 (Inherited: 0x70)
struct UMaterialExpressionPixelNormalWS : UMaterialExpression {
};

// Class Engine.MaterialExpressionPower
// Size: 0xe8 (Inherited: 0x70)
struct UMaterialExpressionPower : UMaterialExpression {
	struct FExpressionInput Base; // 0x70(0x38)
	struct FExpressionInput Exponent; // 0xa8(0x38)
	float ConstExponent; // 0xe0(0x04)
	char pad_E4[0x4]; // 0xe4(0x04)
};

// Class Engine.MaterialExpressionPrecomputedAOMask
// Size: 0x70 (Inherited: 0x70)
struct UMaterialExpressionPrecomputedAOMask : UMaterialExpression {
};

// Class Engine.MaterialExpressionPreSkinnedNormal
// Size: 0x70 (Inherited: 0x70)
struct UMaterialExpressionPreSkinnedNormal : UMaterialExpression {
};

// Class Engine.MaterialExpressionPreSkinnedPosition
// Size: 0x70 (Inherited: 0x70)
struct UMaterialExpressionPreSkinnedPosition : UMaterialExpression {
};

// Class Engine.MaterialExpressionPreviousFrameSwitch
// Size: 0xe0 (Inherited: 0x70)
struct UMaterialExpressionPreviousFrameSwitch : UMaterialExpression {
	struct FExpressionInput CurrentFrame; // 0x70(0x38)
	struct FExpressionInput PreviousFrame; // 0xa8(0x38)
};

// Class Engine.MaterialExpressionQualitySwitch
// Size: 0x150 (Inherited: 0x70)
struct UMaterialExpressionQualitySwitch : UMaterialExpression {
	struct FExpressionInput Default; // 0x70(0x38)
	struct FExpressionInput Inputs[0x03]; // 0xa8(0xa8)
};

// Class Engine.MaterialExpressionReflectionVectorWS
// Size: 0xb0 (Inherited: 0x70)
struct UMaterialExpressionReflectionVectorWS : UMaterialExpression {
	struct FExpressionInput CustomWorldNormal; // 0x70(0x38)
	char bNormalizeCustomWorldNormal : 1; // 0xa8(0x01)
	char pad_A8_1 : 7; // 0xa8(0x01)
	char pad_A9[0x7]; // 0xa9(0x07)
};

// Class Engine.MaterialExpressionReroute
// Size: 0xa8 (Inherited: 0x70)
struct UMaterialExpressionReroute : UMaterialExpression {
	struct FExpressionInput Input; // 0x70(0x38)
};

// Class Engine.MaterialExpressionRotateAboutAxis
// Size: 0x158 (Inherited: 0x70)
struct UMaterialExpressionRotateAboutAxis : UMaterialExpression {
	struct FExpressionInput NormalizedRotationAxis; // 0x70(0x38)
	struct FExpressionInput RotationAngle; // 0xa8(0x38)
	struct FExpressionInput PivotPoint; // 0xe0(0x38)
	struct FExpressionInput Position; // 0x118(0x38)
	float Period; // 0x150(0x04)
	char pad_154[0x4]; // 0x154(0x04)
};

// Class Engine.MaterialExpressionRotator
// Size: 0xf0 (Inherited: 0x70)
struct UMaterialExpressionRotator : UMaterialExpression {
	struct FExpressionInput Coordinate; // 0x70(0x38)
	struct FExpressionInput Time; // 0xa8(0x38)
	float CenterX; // 0xe0(0x04)
	float CenterY; // 0xe4(0x04)
	float Speed; // 0xe8(0x04)
	uint32 ConstCoordinate; // 0xec(0x04)
};

// Class Engine.MaterialExpressionRound
// Size: 0xa8 (Inherited: 0x70)
struct UMaterialExpressionRound : UMaterialExpression {
	struct FExpressionInput Input; // 0x70(0x38)
};

// Class Engine.MaterialExpressionSaturate
// Size: 0xa8 (Inherited: 0x70)
struct UMaterialExpressionSaturate : UMaterialExpression {
	struct FExpressionInput Input; // 0x70(0x38)
};

// Class Engine.MaterialExpressionSceneColor
// Size: 0xf0 (Inherited: 0x70)
struct UMaterialExpressionSceneColor : UMaterialExpression {
	enum class EMaterialSceneAttributeInputMode InputMode; // 0x70(0x01)
	char pad_71[0x7]; // 0x71(0x07)
	struct FExpressionInput Input; // 0x78(0x38)
	struct FExpressionInput OffsetFraction; // 0xb0(0x38)
	struct FVector2D ConstInput; // 0xe8(0x08)
};

// Class Engine.MaterialExpressionSceneDepth
// Size: 0xf0 (Inherited: 0x70)
struct UMaterialExpressionSceneDepth : UMaterialExpression {
	enum class EMaterialSceneAttributeInputMode InputMode; // 0x70(0x01)
	char pad_71[0x7]; // 0x71(0x07)
	struct FExpressionInput Input; // 0x78(0x38)
	struct FExpressionInput Coordinates; // 0xb0(0x38)
	struct FVector2D ConstInput; // 0xe8(0x08)
};

// Class Engine.MaterialExpressionSceneTexelSize
// Size: 0x70 (Inherited: 0x70)
struct UMaterialExpressionSceneTexelSize : UMaterialExpression {
};

// Class Engine.MaterialExpressionSceneTexture
// Size: 0xb0 (Inherited: 0x70)
struct UMaterialExpressionSceneTexture : UMaterialExpression {
	struct FExpressionInput Coordinates; // 0x70(0x38)
	enum class ESceneTextureId SceneTextureId; // 0xa8(0x01)
	bool bFiltered; // 0xa9(0x01)
	char pad_AA[0x6]; // 0xaa(0x06)
};

// Class Engine.MaterialExpressionScreenPosition
// Size: 0x70 (Inherited: 0x70)
struct UMaterialExpressionScreenPosition : UMaterialExpression {
};

// Class Engine.MaterialExpressionSetMaterialAttributes
// Size: 0x90 (Inherited: 0x70)
struct UMaterialExpressionSetMaterialAttributes : UMaterialExpression {
	struct TArray<struct FExpressionInput> Inputs; // 0x70(0x10)
	struct TArray<struct FGuid> AttributeSetTypes; // 0x80(0x10)
};

// Class Engine.MaterialExpressionSign
// Size: 0xa8 (Inherited: 0x70)
struct UMaterialExpressionSign : UMaterialExpression {
	struct FExpressionInput Input; // 0x70(0x38)
};

// Class Engine.MaterialExpressionSine
// Size: 0xb0 (Inherited: 0x70)
struct UMaterialExpressionSine : UMaterialExpression {
	struct FExpressionInput Input; // 0x70(0x38)
	float Period; // 0xa8(0x04)
	char pad_AC[0x4]; // 0xac(0x04)
};

// Class Engine.MaterialExpressionSpeedTree
// Size: 0x160 (Inherited: 0x70)
struct UMaterialExpressionSpeedTree : UMaterialExpression {
	struct FExpressionInput GeometryInput; // 0x70(0x38)
	struct FExpressionInput WindInput; // 0xa8(0x38)
	struct FExpressionInput LODInput; // 0xe0(0x38)
	struct FExpressionInput ExtraBendWS; // 0x118(0x38)
	enum class ESpeedTreeGeometryType GeometryType; // 0x150(0x01)
	enum class ESpeedTreeWindType WindType; // 0x151(0x01)
	enum class ESpeedTreeLODType LODType; // 0x152(0x01)
	char pad_153[0x1]; // 0x153(0x01)
	float BillboardThreshold; // 0x154(0x04)
	bool bAccurateWindVelocities; // 0x158(0x01)
	char pad_159[0x7]; // 0x159(0x07)
};

// Class Engine.MaterialExpressionSphereMask
// Size: 0x158 (Inherited: 0x70)
struct UMaterialExpressionSphereMask : UMaterialExpression {
	struct FExpressionInput A; // 0x70(0x38)
	struct FExpressionInput B; // 0xa8(0x38)
	struct FExpressionInput Radius; // 0xe0(0x38)
	struct FExpressionInput Hardness; // 0x118(0x38)
	float AttenuationRadius; // 0x150(0x04)
	float HardnessPercent; // 0x154(0x04)
};

// Class Engine.MaterialExpressionSphericalParticleOpacity
// Size: 0xb0 (Inherited: 0x70)
struct UMaterialExpressionSphericalParticleOpacity : UMaterialExpression {
	struct FExpressionInput Density; // 0x70(0x38)
	float ConstantDensity; // 0xa8(0x04)
	char pad_AC[0x4]; // 0xac(0x04)
};

// Class Engine.MaterialExpressionSquareRoot
// Size: 0xa8 (Inherited: 0x70)
struct UMaterialExpressionSquareRoot : UMaterialExpression {
	struct FExpressionInput Input; // 0x70(0x38)
};

// Class Engine.MaterialExpressionStaticBool
// Size: 0x78 (Inherited: 0x70)
struct UMaterialExpressionStaticBool : UMaterialExpression {
	char Value : 1; // 0x70(0x01)
	char pad_70_1 : 7; // 0x70(0x01)
	char pad_71[0x7]; // 0x71(0x07)
};

// Class Engine.MaterialExpressionStaticSwitch
// Size: 0x120 (Inherited: 0x70)
struct UMaterialExpressionStaticSwitch : UMaterialExpression {
	char DefaultValue : 1; // 0x70(0x01)
	char pad_70_1 : 7; // 0x70(0x01)
	char pad_71[0x7]; // 0x71(0x07)
	struct FExpressionInput A; // 0x78(0x38)
	struct FExpressionInput B; // 0xb0(0x38)
	struct FExpressionInput Value; // 0xe8(0x38)
};

// Class Engine.MaterialExpressionSubtract
// Size: 0xe8 (Inherited: 0x70)
struct UMaterialExpressionSubtract : UMaterialExpression {
	struct FExpressionInput A; // 0x70(0x38)
	struct FExpressionInput B; // 0xa8(0x38)
	float ConstA; // 0xe0(0x04)
	float ConstB; // 0xe4(0x04)
};

// Class Engine.MaterialExpressionTangent
// Size: 0xb0 (Inherited: 0x70)
struct UMaterialExpressionTangent : UMaterialExpression {
	struct FExpressionInput Input; // 0x70(0x38)
	float Period; // 0xa8(0x04)
	char pad_AC[0x4]; // 0xac(0x04)
};

// Class Engine.MaterialExpressionTerrainBlend
// Size: 0xc8 (Inherited: 0x70)
struct UMaterialExpressionTerrainBlend : UMaterialExpressionTerrainBlendBase {
	struct FExpressionInput UV; // 0x70(0x38)
	struct TArray<struct FTerrainLayer> Inputs; // 0xa8(0x10)
	uint32 ConstCoordinate; // 0xb8(0x04)
	char pad_BC[0xc]; // 0xbc(0x0c)
};

// Class Engine.MaterialExpressionTerrainBlendDesert
// Size: 0xd0 (Inherited: 0x70)
struct UMaterialExpressionTerrainBlendDesert : UMaterialExpressionTerrainBlendBase {
	struct FExpressionInput UV; // 0x70(0x38)
	struct TArray<struct FTerrainLayerDesert> Inputs; // 0xa8(0x10)
	uint32 ConstCoordinate; // 0xb8(0x04)
	char pad_BC[0x14]; // 0xbc(0x14)
};

// Class Engine.MaterialExpressionTerrainBlendHeight
// Size: 0x108 (Inherited: 0x70)
struct UMaterialExpressionTerrainBlendHeight : UMaterialExpressionTerrainBlendBase {
	struct FExpressionInput UV; // 0x70(0x38)
	struct FExpressionInput CameraWeight; // 0xa8(0x38)
	struct TArray<struct FTerrainLayerHeight> Inputs; // 0xe0(0x10)
	uint32 ConstCoordinate; // 0xf0(0x04)
	char pad_F4[0x14]; // 0xf4(0x14)
};

// Class Engine.MaterialExpressionTextureBase
// Size: 0x80 (Inherited: 0x70)
struct UMaterialExpressionTextureBase : UMaterialExpression {
	struct UTexture* Texture; // 0x70(0x08)
	enum class EMaterialSamplerType SamplerType; // 0x78(0x01)
	char pad_79[0x3]; // 0x79(0x03)
	char IsDefaultMeshpaintTexture : 1; // 0x7c(0x01)
	char pad_7C_1 : 7; // 0x7c(0x01)
	char pad_7D[0x3]; // 0x7d(0x03)
};

// Class Engine.MaterialExpressionTextureObject
// Size: 0x80 (Inherited: 0x80)
struct UMaterialExpressionTextureObject : UMaterialExpressionTextureBase {
};

// Class Engine.MaterialExpressionTextureSample
// Size: 0x1f8 (Inherited: 0x80)
struct UMaterialExpressionTextureSample : UMaterialExpressionTextureBase {
	struct FExpressionInput Coordinates; // 0x80(0x38)
	struct FExpressionInput TextureObject; // 0xb8(0x38)
	struct FExpressionInput MipValue; // 0xf0(0x38)
	struct FExpressionInput CoordinatesDX; // 0x128(0x38)
	struct FExpressionInput CoordinatesDY; // 0x160(0x38)
	struct FExpressionInput SampleCondition; // 0x198(0x38)
	enum class ETextureMipValueMode MipValueMode; // 0x1d0(0x01)
	enum class ESamplerSourceMode SamplerSource; // 0x1d1(0x01)
	char pad_1D2[0x2]; // 0x1d2(0x02)
	uint32 ConstCoordinate; // 0x1d4(0x04)
	int32 ConstMipValue; // 0x1d8(0x04)
	char AutomaticViewMipBias : 1; // 0x1dc(0x01)
	char pad_1DC_1 : 7; // 0x1dc(0x01)
	char pad_1DD[0x3]; // 0x1dd(0x03)
	bool bConditional; // 0x1e0(0x01)
	char pad_1E1[0x3]; // 0x1e1(0x03)
	struct FLinearColor DefaultValue; // 0x1e4(0x10)
	char pad_1F4[0x4]; // 0x1f4(0x04)
};

// Class Engine.MaterialExpressionParticleSubUV
// Size: 0x200 (Inherited: 0x1f8)
struct UMaterialExpressionParticleSubUV : UMaterialExpressionTextureSample {
	char bBlend : 1; // 0x1f8(0x01)
	char pad_1F8_1 : 7; // 0x1f8(0x01)
	char pad_1F9[0x7]; // 0x1f9(0x07)
};

// Class Engine.MaterialExpressionTextureSampleParameter
// Size: 0x218 (Inherited: 0x1f8)
struct UMaterialExpressionTextureSampleParameter : UMaterialExpressionTextureSample {
	struct FName ParameterName; // 0x1f8(0x08)
	struct FGuid ExpressionGUID; // 0x200(0x10)
	struct FName Group; // 0x210(0x08)
};

// Class Engine.MaterialExpressionTextureObjectParameter
// Size: 0x218 (Inherited: 0x218)
struct UMaterialExpressionTextureObjectParameter : UMaterialExpressionTextureSampleParameter {
};

// Class Engine.MaterialExpressionTextureSampleParameter2D
// Size: 0x218 (Inherited: 0x218)
struct UMaterialExpressionTextureSampleParameter2D : UMaterialExpressionTextureSampleParameter {
};

// Class Engine.MaterialExpressionAntialiasedTextureMask
// Size: 0x220 (Inherited: 0x218)
struct UMaterialExpressionAntialiasedTextureMask : UMaterialExpressionTextureSampleParameter2D {
	float Threshold; // 0x218(0x04)
	enum class ETextureColorChannel Channel; // 0x21c(0x01)
	char pad_21D[0x3]; // 0x21d(0x03)
};

// Class Engine.MaterialExpressionTextureSampleParameterSubUV
// Size: 0x220 (Inherited: 0x218)
struct UMaterialExpressionTextureSampleParameterSubUV : UMaterialExpressionTextureSampleParameter2D {
	char bBlend : 1; // 0x218(0x01)
	char pad_218_1 : 7; // 0x218(0x01)
	char pad_219[0x7]; // 0x219(0x07)
};

// Class Engine.MaterialExpressionTextureSampleParameter2DArray
// Size: 0x218 (Inherited: 0x218)
struct UMaterialExpressionTextureSampleParameter2DArray : UMaterialExpressionTextureSampleParameter {
};

// Class Engine.MaterialExpressionTextureSampleParameterCube
// Size: 0x218 (Inherited: 0x218)
struct UMaterialExpressionTextureSampleParameterCube : UMaterialExpressionTextureSampleParameter {
};

// Class Engine.MaterialExpressionTextureCoordinate
// Size: 0x80 (Inherited: 0x70)
struct UMaterialExpressionTextureCoordinate : UMaterialExpression {
	int32 CoordinateIndex; // 0x70(0x04)
	float UTiling; // 0x74(0x04)
	float VTiling; // 0x78(0x04)
	char UnMirrorU : 1; // 0x7c(0x01)
	char UnMirrorV : 1; // 0x7c(0x01)
	char pad_7C_2 : 6; // 0x7c(0x01)
	char pad_7D[0x3]; // 0x7d(0x03)
};

// Class Engine.MaterialExpressionTextureProperty
// Size: 0xb0 (Inherited: 0x70)
struct UMaterialExpressionTextureProperty : UMaterialExpression {
	struct FExpressionInput TextureObject; // 0x70(0x38)
	enum class EMaterialExposedTextureProperty Property; // 0xa8(0x01)
	char pad_A9[0x7]; // 0xa9(0x07)
};

// Class Engine.MaterialExpressionTime
// Size: 0x78 (Inherited: 0x70)
struct UMaterialExpressionTime : UMaterialExpression {
	char bIgnorePause : 1; // 0x70(0x01)
	char bOverride_Period : 1; // 0x70(0x01)
	char pad_70_2 : 6; // 0x70(0x01)
	char pad_71[0x3]; // 0x71(0x03)
	float Period; // 0x74(0x04)
};

// Class Engine.MaterialExpressionTransform
// Size: 0xb0 (Inherited: 0x70)
struct UMaterialExpressionTransform : UMaterialExpression {
	struct FExpressionInput Input; // 0x70(0x38)
	enum class EMaterialVectorCoordTransformSource TransformSourceType; // 0xa8(0x01)
	enum class EMaterialVectorCoordTransform TransformType; // 0xa9(0x01)
	char pad_AA[0x6]; // 0xaa(0x06)
};

// Class Engine.MaterialExpressionTransformPosition
// Size: 0xb0 (Inherited: 0x70)
struct UMaterialExpressionTransformPosition : UMaterialExpression {
	struct FExpressionInput Input; // 0x70(0x38)
	enum class EMaterialPositionTransformSource TransformSourceType; // 0xa8(0x01)
	enum class EMaterialPositionTransformSource TransformType; // 0xa9(0x01)
	char pad_AA[0x6]; // 0xaa(0x06)
};

// Class Engine.MaterialExpressionTruncate
// Size: 0xa8 (Inherited: 0x70)
struct UMaterialExpressionTruncate : UMaterialExpression {
	struct FExpressionInput Input; // 0x70(0x38)
};

// Class Engine.MaterialExpressionTwoSidedSign
// Size: 0x70 (Inherited: 0x70)
struct UMaterialExpressionTwoSidedSign : UMaterialExpression {
};

// Class Engine.MaterialExpressionVectorNoise
// Size: 0xb8 (Inherited: 0x70)
struct UMaterialExpressionVectorNoise : UMaterialExpression {
	struct FExpressionInput Position; // 0x70(0x38)
	enum class EVectorNoiseFunction NoiseFunction; // 0xa8(0x01)
	char pad_A9[0x3]; // 0xa9(0x03)
	int32 Quality; // 0xac(0x04)
	char bTiling : 1; // 0xb0(0x01)
	char pad_B0_1 : 7; // 0xb0(0x01)
	char pad_B1[0x3]; // 0xb1(0x03)
	uint32 TileSize; // 0xb4(0x04)
};

// Class Engine.MaterialExpressionVertexColor
// Size: 0x70 (Inherited: 0x70)
struct UMaterialExpressionVertexColor : UMaterialExpression {
};

// Class Engine.MaterialExpressionVertexLocalPosition
// Size: 0x70 (Inherited: 0x70)
struct UMaterialExpressionVertexLocalPosition : UMaterialExpression {
};

// Class Engine.MaterialExpressionVertexNormalWS
// Size: 0x70 (Inherited: 0x70)
struct UMaterialExpressionVertexNormalWS : UMaterialExpression {
};

// Class Engine.MaterialExpressionViewProperty
// Size: 0x78 (Inherited: 0x70)
struct UMaterialExpressionViewProperty : UMaterialExpression {
	enum class EMaterialExposedViewProperty Property; // 0x70(0x01)
	char pad_71[0x7]; // 0x71(0x07)
};

// Class Engine.MaterialExpressionViewSize
// Size: 0x70 (Inherited: 0x70)
struct UMaterialExpressionViewSize : UMaterialExpression {
};

// Class Engine.MaterialExpressionWorldPosition
// Size: 0x78 (Inherited: 0x70)
struct UMaterialExpressionWorldPosition : UMaterialExpression {
	enum class EWorldPositionIncludedOffsets WorldPositionShaderOffset; // 0x70(0x01)
	char pad_71[0x7]; // 0x71(0x07)
};

// Class Engine.MaterialFunction
// Size: 0x78 (Inherited: 0x38)
struct UMaterialFunction : UObject {
	struct FGuid StateId; // 0x38(0x10)
	struct FString Description; // 0x48(0x10)
	char bExposeToLibrary : 1; // 0x58(0x01)
	char pad_58_1 : 7; // 0x58(0x01)
	char pad_59[0x7]; // 0x59(0x07)
	struct TArray<struct UMaterialExpression*> FunctionExpressions; // 0x60(0x10)
	char bReentrantFlag : 1; // 0x70(0x01)
	char pad_70_1 : 7; // 0x70(0x01)
	char pad_71[0x7]; // 0x71(0x07)
};

// Class Engine.Material
// Size: 0xa10 (Inherited: 0x80)
struct UMaterial : UMaterialInterface {
	struct UPhysicalMaterial* PhysMaterial; // 0x80(0x08)
	struct FColorMaterialInput DiffuseColor; // 0x88(0x40)
	struct FColorMaterialInput SpecularColor; // 0xc8(0x40)
	struct FColorMaterialInput BaseColor; // 0x108(0x40)
	struct FScalarMaterialInput Metallic; // 0x148(0x40)
	struct FScalarMaterialInput Specular; // 0x188(0x40)
	struct FScalarMaterialInput Roughness; // 0x1c8(0x40)
	struct FVectorMaterialInput Normal; // 0x208(0x48)
	struct FColorMaterialInput EmissiveColor; // 0x250(0x40)
	struct FScalarMaterialInput Opacity; // 0x290(0x40)
	struct FScalarMaterialInput OpacityMask; // 0x2d0(0x40)
	enum class EMaterialDomain MaterialDomain; // 0x310(0x01)
	enum class EBlendMode BlendMode; // 0x311(0x01)
	enum class EDecalBlendMode DecalBlendMode; // 0x312(0x01)
	enum class EMaterialDecalResponse MaterialDecalResponse; // 0x313(0x01)
	enum class EMaterialShadingModel ShadingModel; // 0x314(0x01)
	char pad_315[0x3]; // 0x315(0x03)
	float OpacityMaskClipValue; // 0x318(0x04)
	char pad_31C[0x4]; // 0x31c(0x04)
	struct FVectorMaterialInput WorldPositionOffset; // 0x320(0x48)
	struct FVectorMaterialInput WorldDisplacement; // 0x368(0x48)
	struct FScalarMaterialInput TessellationMultiplier; // 0x3b0(0x40)
	struct FColorMaterialInput SubsurfaceColor; // 0x3f0(0x40)
	struct FScalarMaterialInput ClearCoat; // 0x430(0x40)
	struct FScalarMaterialInput ClearCoatRoughness; // 0x470(0x40)
	struct FScalarMaterialInput AmbientOcclusion; // 0x4b0(0x40)
	struct FScalarMaterialInput Refraction; // 0x4f0(0x40)
	struct FVector2MaterialInput CustomizedUVs[0x08]; // 0x530(0x240)
	struct FMaterialAttributesInput MaterialAttributes; // 0x770(0x40)
	struct FScalarMaterialInput PixelDepthOffset; // 0x7b0(0x40)
	char bPrepassMasked : 1; // 0x7f0(0x01)
	char bEnableSeparateTranslucency : 1; // 0x7f0(0x01)
	char bEnableMobileSeparateTranslucency : 1; // 0x7f0(0x01)
	char bEnableResponsiveAA : 1; // 0x7f0(0x01)
	char bScreenSpaceReflections : 1; // 0x7f0(0x01)
	char TwoSided : 1; // 0x7f0(0x01)
	char DitheredLODTransition : 1; // 0x7f0(0x01)
	char DitherOpacityMask : 1; // 0x7f0(0x01)
	char bAllowNegativeEmissiveColor : 1; // 0x7f1(0x01)
	char bHasMaterialPermutations : 1; // 0x7f1(0x01)
	char pad_7F1_2 : 6; // 0x7f1(0x01)
	char pad_7F2[0x2]; // 0x7f2(0x02)
	int32 NumCustomizedUVs; // 0x7f4(0x04)
	enum class ETranslucencyLightingMode TranslucencyLightingMode; // 0x7f8(0x01)
	char pad_7F9[0x3]; // 0x7f9(0x03)
	float TranslucencyDirectionalLightingIntensity; // 0x7fc(0x04)
	char AllowTranslucentCustomDepthWrites : 1; // 0x800(0x01)
	char pad_800_1 : 7; // 0x800(0x01)
	char pad_801[0x3]; // 0x801(0x03)
	float TranslucentShadowDensityScale; // 0x804(0x04)
	float TranslucentSelfShadowDensityScale; // 0x808(0x04)
	float TranslucentSelfShadowSecondDensityScale; // 0x80c(0x04)
	float TranslucentSelfShadowSecondOpacity; // 0x810(0x04)
	float TranslucentBackscatteringExponent; // 0x814(0x04)
	struct FLinearColor TranslucentMultipleScatteringExtinction; // 0x818(0x10)
	float TranslucentShadowStartOffset; // 0x828(0x04)
	char bDisableDepthTest : 1; // 0x82c(0x01)
	char bGenerateSphericalParticleNormals : 1; // 0x82c(0x01)
	char bTangentSpaceNormal : 1; // 0x82c(0x01)
	char bUseEmissiveForDynamicAreaLighting : 1; // 0x82c(0x01)
	char bBlockGI : 1; // 0x82c(0x01)
	char bUsedAsSpecialEngineMaterial : 1; // 0x82c(0x01)
	char bUsedWithSkeletalMesh : 1; // 0x82c(0x01)
	char bUsedWithEditorCompositing : 1; // 0x82c(0x01)
	char bUsedWithParticleSprites : 1; // 0x82d(0x01)
	char bUsedWithBeamTrails : 1; // 0x82d(0x01)
	char bUsedWithMeshParticles : 1; // 0x82d(0x01)
	char bUsedWithNiagaraSprites : 1; // 0x82d(0x01)
	char bUsedWithNiagaraRibbons : 1; // 0x82d(0x01)
	char bUsedWithNiagaraMeshParticles : 1; // 0x82d(0x01)
	char bUsedWithStaticLighting : 1; // 0x82d(0x01)
	char bUsedWithMorphTargets : 1; // 0x82d(0x01)
	char bUsedWithSplineMeshes : 1; // 0x82e(0x01)
	char bUsedWithInstancedStaticMeshes : 1; // 0x82e(0x01)
	char bUsedWithInstancedSplineMeshes : 1; // 0x82e(0x01)
	char bUsedWithInstancedDeferredDecals : 1; // 0x82e(0x01)
	char bUsesDistortion : 1; // 0x82e(0x01)
	char bUsedWithClothing : 1; // 0x82e(0x01)
	char bUsedWithUI : 1; // 0x82e(0x01)
	char bAutomaticallySetUsageInEditor : 1; // 0x82e(0x01)
	char bFullyRough : 1; // 0x82f(0x01)
	char bUseFullPrecision : 1; // 0x82f(0x01)
	char bUseLightmapDirectionality : 1; // 0x82f(0x01)
	char bUseHQForwardReflections : 1; // 0x82f(0x01)
	char bUsePlanarForwardReflections : 1; // 0x82f(0x01)
	char bNormalCurvatureToRoughness : 1; // 0x82f(0x01)
	char pad_82F_6 : 2; // 0x82f(0x01)
	enum class EMaterialTessellationMode D3D11TessellationMode; // 0x830(0x01)
	char pad_831[0x3]; // 0x831(0x03)
	char bEnableCrackFreeDisplacement : 1; // 0x834(0x01)
	char bEnableAdaptiveTessellation : 1; // 0x834(0x01)
	char pad_834_2 : 6; // 0x834(0x01)
	char pad_835[0x3]; // 0x835(0x03)
	float MaxDisplacement; // 0x838(0x04)
	char Wireframe : 1; // 0x83c(0x01)
	char bOutputVelocityOnBasePass : 1; // 0x83c(0x01)
	char bIsTiledTranslucent : 1; // 0x83c(0x01)
	char bApplyMaterialClipVolumes : 1; // 0x83c(0x01)
	char pad_83C_4 : 4; // 0x83c(0x01)
	char pad_83D[0x3]; // 0x83d(0x03)
	struct FMaterialClipVolumeTypeMask MaterialClipVolumeTypes; // 0x840(0x04)
	enum class EMaterialClipVolumeImportance MaterialClipVolumeImportance; // 0x844(0x01)
	char pad_845[0x3]; // 0x845(0x03)
	float MaterialClipVolumeFadeRange; // 0x848(0x04)
	char bMaterialClipVolumesUseDiscardForTranslucent : 1; // 0x84c(0x01)
	char bIsMaterialClipVolumeWater : 1; // 0x84c(0x01)
	char bUseMeshClipping : 1; // 0x84c(0x01)
	char pad_84C_3 : 5; // 0x84c(0x01)
	char pad_84D[0x3]; // 0x84d(0x03)
	int32 EditorX; // 0x850(0x04)
	int32 EditorY; // 0x854(0x04)
	int32 EditorPitch; // 0x858(0x04)
	int32 EditorYaw; // 0x85c(0x04)
	struct TArray<struct UMaterialExpression*> Expressions; // 0x860(0x10)
	struct TArray<struct FMaterialFunctionInfo> MaterialFunctionInfos; // 0x870(0x10)
	struct TArray<struct FMaterialParameterCollectionInfo> MaterialParameterCollectionInfos; // 0x880(0x10)
	char bCanMaskedBeAssumedOpaque : 1; // 0x890(0x01)
	char bIsMasked : 1; // 0x890(0x01)
	char bIsPreviewMaterial : 1; // 0x890(0x01)
	char bUseMaterialAttributes : 1; // 0x890(0x01)
	char bUseTranslucencyVertexFog : 1; // 0x890(0x01)
	char bComputeFogPerPixel : 1; // 0x890(0x01)
	char bAllowDevelopmentShaderCompile : 1; // 0x890(0x01)
	char bIsMaterialEditorStatsMaterial : 1; // 0x890(0x01)
	char pad_891[0x3]; // 0x891(0x03)
	uint32 UsageFlagWarnings; // 0x894(0x04)
	enum class EBlendableLocation BlendableLocation; // 0x898(0x01)
	char pad_899[0x3]; // 0x899(0x03)
	int32 BlendablePriority; // 0x89c(0x04)
	bool BlendableOutputAlpha; // 0x8a0(0x01)
	enum class ERefractionMode RefractionMode; // 0x8a1(0x01)
	char pad_8A2[0x2]; // 0x8a2(0x02)
	float RefractionDepthBias; // 0x8a4(0x04)
	struct FGuid StateId; // 0x8a8(0x10)
	char pad_8B8[0x148]; // 0x8b8(0x148)
	struct TArray<struct UTexture*> ExpressionTextureReferences; // 0xa00(0x10)
};

// Class Engine.MaterialInstanceDynamic
// Size: 0x240 (Inherited: 0x1f0)
struct UMaterialInstanceDynamic : UMaterialInstance {
	char pad_1F0[0x50]; // 0x1f0(0x50)

	void SetVectorParameterValue(struct FName ParameterName, struct FLinearColor Value); // Function Engine.MaterialInstanceDynamic.SetVectorParameterValue // Final|Native|Public|HasDefaults|BlueprintCallable // @ game+0x5b75bb8
	void SetTextureParameterValue(struct FName ParameterName, struct UTexture* Value); // Function Engine.MaterialInstanceDynamic.SetTextureParameterValue // Final|Native|Public|BlueprintCallable // @ game+0x795cc8
	void SetScalarParameterValue(struct FName ParameterName, float Value); // Function Engine.MaterialInstanceDynamic.SetScalarParameterValue // Final|Native|Public|BlueprintCallable // @ game+0x5b75650
	void K2_InterpolateMaterialInstanceParams(struct UMaterialInstance* SourceA, struct UMaterialInstance* SourceB, float ALPHA); // Function Engine.MaterialInstanceDynamic.K2_InterpolateMaterialInstanceParams // Final|Native|Public|BlueprintCallable // @ game+0x5b71738
	struct FLinearColor K2_GetVectorParameterValue(struct FName ParameterName); // Function Engine.MaterialInstanceDynamic.K2_GetVectorParameterValue // Final|Native|Public|HasDefaults|BlueprintCallable // @ game+0x5b71680
	struct UTexture* K2_GetTextureParameterValue(struct FName ParameterName); // Function Engine.MaterialInstanceDynamic.K2_GetTextureParameterValue // Final|Native|Public|BlueprintCallable // @ game+0x5b715d4
	float K2_GetScalarParameterValue(struct FName ParameterName); // Function Engine.MaterialInstanceDynamic.K2_GetScalarParameterValue // Final|Native|Public|BlueprintCallable // @ game+0x5b7152c
	void K2_CopyMaterialInstanceParameters(struct UMaterialInterface* Source); // Function Engine.MaterialInstanceDynamic.K2_CopyMaterialInstanceParameters // Final|Native|Public|BlueprintCallable // @ game+0x5b6f930
	void CopyParameterOverrides(struct UMaterialInstance* MaterialInstance); // Function Engine.MaterialInstanceDynamic.CopyParameterOverrides // Final|Native|Public|BlueprintCallable // @ game+0x5b69b28
	void CopyInterpParameters(struct UMaterialInstance* Source); // Function Engine.MaterialInstanceDynamic.CopyInterpParameters // Final|Native|Public // @ game+0x5b69a98
};

// Class Engine.MaterialParameterCollection
// Size: 0x78 (Inherited: 0x38)
struct UMaterialParameterCollection : UObject {
	struct FGuid StateId; // 0x38(0x10)
	struct TArray<struct FCollectionScalarParameter> ScalarParameters; // 0x48(0x10)
	struct TArray<struct FCollectionVectorParameter> VectorParameters; // 0x58(0x10)
	char pad_68[0x10]; // 0x68(0x10)
};

// Class Engine.MaterialParameterCollectionInstance
// Size: 0xf8 (Inherited: 0x38)
struct UMaterialParameterCollectionInstance : UObject {
	char pad_38[0x8]; // 0x38(0x08)
	struct UMaterialParameterCollection* Collection; // 0x40(0x08)
	struct UWorld* World; // 0x48(0x08)
	char pad_50[0xa8]; // 0x50(0xa8)
};

// Class Engine.MatineeInterface
// Size: 0x38 (Inherited: 0x38)
struct UMatineeInterface : UInterface {
};

// Class Engine.MorphTarget
// Size: 0x50 (Inherited: 0x38)
struct UMorphTarget : UObject {
	struct USkeletalMesh* BaseSkelMesh; // 0x38(0x08)
	char pad_40[0x10]; // 0x40(0x10)
};

// Class Engine.NavArea_Default
// Size: 0x50 (Inherited: 0x50)
struct UNavArea_Default : UNavArea {
};

// Class Engine.NavArea_LowHeight
// Size: 0x50 (Inherited: 0x50)
struct UNavArea_LowHeight : UNavArea {
};

// Class Engine.NavArea_Null
// Size: 0x50 (Inherited: 0x50)
struct UNavArea_Null : UNavArea {
};

// Class Engine.NavArea_Obstacle
// Size: 0x50 (Inherited: 0x50)
struct UNavArea_Obstacle : UNavArea {
};

// Class Engine.NavAreaMeta
// Size: 0x50 (Inherited: 0x50)
struct UNavAreaMeta : UNavArea {
};

// Class Engine.NavAreaMeta_SwitchByAgent
// Size: 0xd0 (Inherited: 0x50)
struct UNavAreaMeta_SwitchByAgent : UNavAreaMeta {
	struct UClass* Agent0Area; // 0x50(0x08)
	struct UClass* Agent1Area; // 0x58(0x08)
	struct UClass* Agent2Area; // 0x60(0x08)
	struct UClass* Agent3Area; // 0x68(0x08)
	struct UClass* Agent4Area; // 0x70(0x08)
	struct UClass* Agent5Area; // 0x78(0x08)
	struct UClass* Agent6Area; // 0x80(0x08)
	struct UClass* Agent7Area; // 0x88(0x08)
	struct UClass* Agent8Area; // 0x90(0x08)
	struct UClass* Agent9Area; // 0x98(0x08)
	struct UClass* Agent10Area; // 0xa0(0x08)
	struct UClass* Agent11Area; // 0xa8(0x08)
	struct UClass* Agent12Area; // 0xb0(0x08)
	struct UClass* Agent13Area; // 0xb8(0x08)
	struct UClass* Agent14Area; // 0xc0(0x08)
	struct UClass* Agent15Area; // 0xc8(0x08)
};

// Class Engine.NavCollision
// Size: 0x120 (Inherited: 0x38)
struct UNavCollision : UObject {
	char pad_38[0x50]; // 0x38(0x50)
	struct TArray<struct FNavCollisionCylinder> CylinderCollision; // 0x88(0x10)
	struct TArray<struct FNavCollisionBox> BoxCollision; // 0x98(0x10)
	struct UClass* AreaClass; // 0xa8(0x08)
	char bIsDynamicObstacle : 1; // 0xb0(0x01)
	char bGatherConvexGeometry : 1; // 0xb0(0x01)
	char pad_B0_2 : 6; // 0xb0(0x01)
	char pad_B1[0x6f]; // 0xb1(0x6f)
};

// Class Engine.NavEdgeProviderInterface
// Size: 0x38 (Inherited: 0x38)
struct UNavEdgeProviderInterface : UInterface {
};

// Class Engine.NavigationDataChunk
// Size: 0x40 (Inherited: 0x38)
struct UNavigationDataChunk : UObject {
	struct FName NavigationDataName; // 0x38(0x08)
};

// Class Engine.RecastNavMeshDataChunk
// Size: 0x50 (Inherited: 0x40)
struct URecastNavMeshDataChunk : UNavigationDataChunk {
	char pad_40[0x10]; // 0x40(0x10)
};

// Class Engine.NavigationPath
// Size: 0xd0 (Inherited: 0x38)
struct UNavigationPath : UObject {
	struct FMulticastDelegate PathUpdatedNotifier; // 0x38(0x10)
	struct TArray<struct FVector> PathPoints; // 0x48(0x10)
	enum class ENavigationOptionFlag RecalculateOnInvalidation; // 0x58(0x01)
	char pad_59[0x77]; // 0x59(0x77)

	bool IsValid(); // Function Engine.NavigationPath.IsValid // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b6f774
	bool IsStringPulled(); // Function Engine.NavigationPath.IsStringPulled // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x2d3490
	bool IsPartial(); // Function Engine.NavigationPath.IsPartial // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b6f4cc
	float GetPathLength(); // Function Engine.NavigationPath.GetPathLength // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b6d570
	float GetPathCost(); // Function Engine.NavigationPath.GetPathCost // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b6d2e0
	struct FString GetDebugString(); // Function Engine.NavigationPath.GetDebugString // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x5b6c1d4
	void EnableRecalculationOnInvalidation(enum class ENavigationOptionFlag DoRecalculation); // Function Engine.NavigationPath.EnableRecalculationOnInvalidation // Final|Native|Public|BlueprintCallable // @ game+0x5b6a8e0
	void EnableDebugDrawing(bool bShouldDrawDebugData, struct FLinearColor PathColor); // Function Engine.NavigationPath.EnableDebugDrawing // Final|Native|Public|HasDefaults|BlueprintCallable // @ game+0x5b6a6e8
};

// Class Engine.NavigationPathGenerator
// Size: 0x38 (Inherited: 0x38)
struct UNavigationPathGenerator : UInterface {
};

// Class Engine.RecastFilter_UseDefaultArea
// Size: 0x58 (Inherited: 0x58)
struct URecastFilter_UseDefaultArea : UNavigationQueryFilter {
};

// Class Engine.NavLinkTrivial
// Size: 0x60 (Inherited: 0x60)
struct UNavLinkTrivial : UNavLinkDefinition {
};

// Class Engine.NavNodeInterface
// Size: 0x38 (Inherited: 0x38)
struct UNavNodeInterface : UInterface {
};

// Class Engine.NetDriver
// Size: 0x4d0 (Inherited: 0x38)
struct UNetDriver : UObject {
	char pad_38[0x8]; // 0x38(0x08)
	struct FString NetConnectionClassName; // 0x40(0x10)
	int32 MaxDownloadSize; // 0x50(0x04)
	char bClampListenServerTickRate : 1; // 0x54(0x01)
	char pad_54_1 : 7; // 0x54(0x01)
	char pad_55[0x3]; // 0x55(0x03)
	int32 NetServerMaxTickRate; // 0x58(0x04)
	int32 MaxInternetClientRate; // 0x5c(0x04)
	int32 MaxClientRate; // 0x60(0x04)
	float ServerTravelPause; // 0x64(0x04)
	float SpawnPrioritySeconds; // 0x68(0x04)
	float RelevantTimeout; // 0x6c(0x04)
	float KeepAliveTime; // 0x70(0x04)
	float InitialConnectTimeout; // 0x74(0x04)
	float ConnectionTimeout; // 0x78(0x04)
	float TimeoutMultiplierForUnoptimizedBuilds; // 0x7c(0x04)
	bool bNoTimeouts; // 0x80(0x01)
	char pad_81[0x7]; // 0x81(0x07)
	struct UNetConnection* ServerConnection; // 0x88(0x08)
	struct TArray<struct UNetConnection*> ClientConnections; // 0x90(0x10)
	char pad_A0[0x28]; // 0xa0(0x28)
	struct UWorld* World; // 0xc8(0x08)
	struct UPackage* WorldPackage; // 0xd0(0x08)
	char pad_D8[0x20]; // 0xd8(0x20)
	struct UClass* NetConnectionClass; // 0xf8(0x08)
	struct UProperty* RoleProperty; // 0x100(0x08)
	struct UProperty* RemoteRoleProperty; // 0x108(0x08)
	struct FName NetDriverName; // 0x110(0x08)
	char pad_118[0x8]; // 0x118(0x08)
	float Time; // 0x120(0x04)
	char pad_124[0x3ac]; // 0x124(0x3ac)
};

// Class Engine.PackageMapClient
// Size: 0x380 (Inherited: 0xf0)
struct UPackageMapClient : UPackageMap {
	char pad_F0[0x290]; // 0xf0(0x290)
};

// Class Engine.DemoNetConnection
// Size: 0x659b8 (Inherited: 0x65848)
struct UDemoNetConnection : UNetConnection {
	char pad_65848[0x20]; // 0x65848(0x20)
	struct FStringClassReference OverrideActorChannel; // 0x65868(0x10)
	char pad_65878[0x140]; // 0x65878(0x140)
};

// Class Engine.DemoNetDriver
// Size: 0xc00 (Inherited: 0x4d0)
struct UDemoNetDriver : UNetDriver {
	char pad_4D0[0xf8]; // 0x4d0(0xf8)
	struct TMap<struct FString, struct FRollbackNetStartupActorInfo> RollbackNetStartupActors; // 0x5c8(0x50)
	char pad_618[0x3e8]; // 0x618(0x3e8)
	bool bIsLocalReplay; // 0xa00(0x01)
	char pad_A01[0x1ff]; // 0xa01(0x1ff)
};

// Class Engine.NodeMappingProviderInterface
// Size: 0x38 (Inherited: 0x38)
struct UNodeMappingProviderInterface : UInterface {
};

// Class Engine.NodeMappingContainer
// Size: 0xa8 (Inherited: 0x38)
struct UNodeMappingContainer : UObject {
	struct TMap<struct FName, struct FNodeMap> NodeMapping; // 0x38(0x50)
	struct UBlueprint* SourceAsset; // 0x88(0x20)
};

// Class Engine.ObjectLibrary
// Size: 0x170 (Inherited: 0x38)
struct UObjectLibrary : UObject {
	struct UClass* ObjectBaseClass; // 0x38(0x08)
	bool bHasBlueprintClasses; // 0x40(0x01)
	char pad_41[0x7]; // 0x41(0x07)
	struct TArray<struct UObject*> Objects; // 0x48(0x10)
	struct TArray<struct UObject*> WeakObjects; // 0x58(0x10)
	bool bUseWeakReferences; // 0x68(0x01)
	bool bIsFullyLoaded; // 0x69(0x01)
	char pad_6A[0x106]; // 0x6a(0x106)
};

// Class Engine.ObjectReferencer
// Size: 0x48 (Inherited: 0x38)
struct UObjectReferencer : UObject {
	struct TArray<struct UObject*> ReferencedObjects; // 0x38(0x10)
};

// Class Engine.OnlineBlueprintCallProxyBase
// Size: 0x38 (Inherited: 0x38)
struct UOnlineBlueprintCallProxyBase : UObject {

	void Activate(); // Function Engine.OnlineBlueprintCallProxyBase.Activate // Native|Public|BlueprintCallable // @ game+0x4d80fd4
};

// Class Engine.OnlineEngineInterface
// Size: 0x38 (Inherited: 0x38)
struct UOnlineEngineInterface : UObject {
};

// Class Engine.OnlineSession
// Size: 0x38 (Inherited: 0x38)
struct UOnlineSession : UObject {
};

// Class Engine.ParticleEmitter
// Size: 0x188 (Inherited: 0x38)
struct UParticleEmitter : UObject {
	struct FName EmitterName; // 0x38(0x08)
	int32 SubUVDataOffset; // 0x40(0x04)
	enum class EEmitterRenderMode EmitterRenderMode; // 0x44(0x01)
	char pad_45[0x3]; // 0x45(0x03)
	struct TArray<struct UParticleLODLevel*> LODLevels; // 0x48(0x10)
	char ConvertedModules : 1; // 0x58(0x01)
	char pad_58_1 : 7; // 0x58(0x01)
	char pad_59[0x3]; // 0x59(0x03)
	int32 PeakActiveParticles; // 0x5c(0x04)
	int32 InitialAllocationCount; // 0x60(0x04)
	float MediumDetailSpawnRateScale; // 0x64(0x04)
	float QualityLevelSpawnRateScale; // 0x68(0x04)
	enum class EDetailMode DetailMode; // 0x6c(0x01)
	char pad_6D[0x3]; // 0x6d(0x03)
	char bIsSoloing : 1; // 0x70(0x01)
	char bCookedOut : 1; // 0x70(0x01)
	char bDisabledLODsKeepEmitterAlive : 1; // 0x70(0x01)
	char bDisableWhenInsignficant : 1; // 0x70(0x01)
	char pad_70_4 : 4; // 0x70(0x01)
	char pad_71[0x3]; // 0x71(0x03)
	enum class EParticleSignificanceLevel SignificanceLevel; // 0x74(0x01)
	char pad_75[0x3]; // 0x75(0x03)
	float DepthSliceThickness; // 0x78(0x04)
	char pad_7C[0x10c]; // 0x7c(0x10c)
};

// Class Engine.ParticleSpriteEmitter
// Size: 0x188 (Inherited: 0x188)
struct UParticleSpriteEmitter : UParticleEmitter {
};

// Class Engine.ParticleLODLevel
// Size: 0xc8 (Inherited: 0x38)
struct UParticleLODLevel : UObject {
	int32 Level; // 0x38(0x04)
	char bEnabled : 1; // 0x3c(0x01)
	char pad_3C_1 : 7; // 0x3c(0x01)
	char pad_3D[0x3]; // 0x3d(0x03)
	struct UParticleModuleRequired* RequiredModule; // 0x40(0x08)
	struct TArray<struct UParticleModule*> Modules; // 0x48(0x10)
	struct UParticleModuleTypeDataBase* TypeDataModule; // 0x58(0x08)
	struct UParticleModuleSpawn* SpawnModule; // 0x60(0x08)
	struct UParticleModuleEventGenerator* EventGenerator; // 0x68(0x08)
	struct TArray<struct UParticleModuleSpawnBase*> SpawningModules; // 0x70(0x10)
	struct TArray<struct UParticleModule*> SpawnModules; // 0x80(0x10)
	struct TArray<struct UParticleModule*> UpdateModules; // 0x90(0x10)
	struct TArray<struct UParticleModuleOrbit*> OrbitModules; // 0xa0(0x10)
	struct TArray<struct UParticleModuleEventReceiverBase*> EventReceiverModules; // 0xb0(0x10)
	char ConvertedModules : 1; // 0xc0(0x01)
	char pad_C0_1 : 7; // 0xc0(0x01)
	char pad_C1[0x3]; // 0xc1(0x03)
	int32 PeakActiveParticles; // 0xc4(0x04)
};

// Class Engine.ParticleModule
// Size: 0x40 (Inherited: 0x38)
struct UParticleModule : UObject {
	char bSpawnModule : 1; // 0x38(0x01)
	char bUpdateModule : 1; // 0x38(0x01)
	char bFinalUpdateModule : 1; // 0x38(0x01)
	char bUpdateForGPUEmitter : 1; // 0x38(0x01)
	char bCurvesAsColor : 1; // 0x38(0x01)
	char b3DDrawMode : 1; // 0x38(0x01)
	char bSupported3DDrawMode : 1; // 0x38(0x01)
	char bEnabled : 1; // 0x38(0x01)
	char bEditable : 1; // 0x39(0x01)
	char LODDuplicate : 1; // 0x39(0x01)
	char bSupportsRandomSeed : 1; // 0x39(0x01)
	char bRequiresLoopingNotification : 1; // 0x39(0x01)
	char pad_39_4 : 4; // 0x39(0x01)
	char pad_3A[0x2]; // 0x3a(0x02)
	bool LODValidity; // 0x3c(0x01)
	char pad_3D[0x3]; // 0x3d(0x03)
};

// Class Engine.ParticleModuleAccelerationBase
// Size: 0x48 (Inherited: 0x40)
struct UParticleModuleAccelerationBase : UParticleModule {
	char bAlwaysInWorldSpace : 1; // 0x40(0x01)
	char pad_40_1 : 7; // 0x40(0x01)
	char pad_41[0x7]; // 0x41(0x07)
};

// Class Engine.ParticleModuleAcceleration
// Size: 0xa0 (Inherited: 0x48)
struct UParticleModuleAcceleration : UParticleModuleAccelerationBase {
	struct FRawDistributionVector Acceleration; // 0x48(0x50)
	char bApplyOwnerScale : 1; // 0x98(0x01)
	char pad_98_1 : 7; // 0x98(0x01)
	char pad_99[0x7]; // 0x99(0x07)
};

// Class Engine.ParticleModuleAccelerationConstant
// Size: 0x58 (Inherited: 0x48)
struct UParticleModuleAccelerationConstant : UParticleModuleAccelerationBase {
	struct FVector Acceleration; // 0x48(0x0c)
	char pad_54[0x4]; // 0x54(0x04)
};

// Class Engine.ParticleModuleAccelerationDrag
// Size: 0x88 (Inherited: 0x48)
struct UParticleModuleAccelerationDrag : UParticleModuleAccelerationBase {
	struct UDistributionFloat* DragCoefficient; // 0x48(0x08)
	struct FRawDistributionFloat DragCoefficientRaw; // 0x50(0x38)
};

// Class Engine.ParticleModuleAccelerationDragScaleOverLife
// Size: 0x88 (Inherited: 0x48)
struct UParticleModuleAccelerationDragScaleOverLife : UParticleModuleAccelerationBase {
	struct UDistributionFloat* DragScale; // 0x48(0x08)
	struct FRawDistributionFloat DragScaleRaw; // 0x50(0x38)
};

// Class Engine.ParticleModuleAccelerationOverLifetime
// Size: 0x98 (Inherited: 0x48)
struct UParticleModuleAccelerationOverLifetime : UParticleModuleAccelerationBase {
	struct FRawDistributionVector AccelOverLife; // 0x48(0x50)
};

// Class Engine.ParticleModuleAttractorBase
// Size: 0x40 (Inherited: 0x40)
struct UParticleModuleAttractorBase : UParticleModule {
};

// Class Engine.ParticleModuleAttractorLine
// Size: 0xc8 (Inherited: 0x40)
struct UParticleModuleAttractorLine : UParticleModuleAttractorBase {
	struct FVector EndPoint0; // 0x40(0x0c)
	struct FVector EndPoint1; // 0x4c(0x0c)
	struct FRawDistributionFloat Range; // 0x58(0x38)
	struct FRawDistributionFloat Strength; // 0x90(0x38)
};

// Class Engine.ParticleModuleAttractorParticle
// Size: 0xd0 (Inherited: 0x40)
struct UParticleModuleAttractorParticle : UParticleModuleAttractorBase {
	struct FName EmitterName; // 0x40(0x08)
	struct FRawDistributionFloat Range; // 0x48(0x38)
	char bStrengthByDistance : 1; // 0x80(0x01)
	char pad_80_1 : 7; // 0x80(0x01)
	char pad_81[0x7]; // 0x81(0x07)
	struct FRawDistributionFloat Strength; // 0x88(0x38)
	char bAffectBaseVelocity : 1; // 0xc0(0x01)
	char pad_C0_1 : 7; // 0xc0(0x01)
	char pad_C1[0x3]; // 0xc1(0x03)
	enum class EAttractorParticleSelectionMethod SelectionMethod; // 0xc4(0x01)
	char pad_C5[0x3]; // 0xc5(0x03)
	char bRenewSource : 1; // 0xc8(0x01)
	char bInheritSourceVel : 1; // 0xc8(0x01)
	char pad_C8_2 : 6; // 0xc8(0x01)
	char pad_C9[0x3]; // 0xc9(0x03)
	int32 LastSelIndex; // 0xcc(0x04)
};

// Class Engine.ParticleModuleAttractorPoint
// Size: 0x108 (Inherited: 0x40)
struct UParticleModuleAttractorPoint : UParticleModuleAttractorBase {
	struct FRawDistributionVector Position; // 0x40(0x50)
	struct FRawDistributionFloat Range; // 0x90(0x38)
	struct FRawDistributionFloat Strength; // 0xc8(0x38)
	char StrengthByDistance : 1; // 0x100(0x01)
	char bAffectBaseVelocity : 1; // 0x100(0x01)
	char bOverrideVelocity : 1; // 0x100(0x01)
	char bUseWorldSpacePosition : 1; // 0x100(0x01)
	char Positive_X : 1; // 0x100(0x01)
	char Positive_Y : 1; // 0x100(0x01)
	char Positive_Z : 1; // 0x100(0x01)
	char Negative_X : 1; // 0x100(0x01)
	char Negative_Y : 1; // 0x101(0x01)
	char Negative_Z : 1; // 0x101(0x01)
	char pad_101_2 : 6; // 0x101(0x01)
	char pad_102[0x6]; // 0x102(0x06)
};

// Class Engine.ParticleModuleAttractorPointGravity
// Size: 0x90 (Inherited: 0x40)
struct UParticleModuleAttractorPointGravity : UParticleModuleAttractorBase {
	struct FVector Position; // 0x40(0x0c)
	float Radius; // 0x4c(0x04)
	struct UDistributionFloat* Strength; // 0x50(0x08)
	struct FRawDistributionFloat StrengthRaw; // 0x58(0x38)
};

// Class Engine.ParticleModuleBeamBase
// Size: 0x40 (Inherited: 0x40)
struct UParticleModuleBeamBase : UParticleModule {
};

// Class Engine.ParticleModuleBeamModifier
// Size: 0x130 (Inherited: 0x40)
struct UParticleModuleBeamModifier : UParticleModuleBeamBase {
	enum class BeamModifierType ModifierType; // 0x40(0x01)
	char pad_41[0x3]; // 0x41(0x03)
	struct FBeamModifierOptions PositionOptions; // 0x44(0x04)
	struct FRawDistributionVector Position; // 0x48(0x50)
	struct FBeamModifierOptions TangentOptions; // 0x98(0x04)
	char pad_9C[0x4]; // 0x9c(0x04)
	struct FRawDistributionVector Tangent; // 0xa0(0x50)
	char bAbsoluteTangent : 1; // 0xf0(0x01)
	char pad_F0_1 : 7; // 0xf0(0x01)
	char pad_F1[0x3]; // 0xf1(0x03)
	struct FBeamModifierOptions StrengthOptions; // 0xf4(0x04)
	struct FRawDistributionFloat Strength; // 0xf8(0x38)
};

// Class Engine.ParticleModuleBeamNoise
// Size: 0x1c8 (Inherited: 0x40)
struct UParticleModuleBeamNoise : UParticleModuleBeamBase {
	char bLowFreq_Enabled : 1; // 0x40(0x01)
	char pad_40_1 : 7; // 0x40(0x01)
	char pad_41[0x3]; // 0x41(0x03)
	int32 Frequency; // 0x44(0x04)
	int32 Frequency_LowRange; // 0x48(0x04)
	char pad_4C[0x4]; // 0x4c(0x04)
	struct FRawDistributionVector NoiseRange; // 0x50(0x50)
	struct FRawDistributionFloat NoiseRangeScale; // 0xa0(0x38)
	char bNRScaleEmitterTime : 1; // 0xd8(0x01)
	char pad_D8_1 : 7; // 0xd8(0x01)
	char pad_D9[0x7]; // 0xd9(0x07)
	struct FRawDistributionVector NoiseSpeed; // 0xe0(0x50)
	char bSmooth : 1; // 0x130(0x01)
	char pad_130_1 : 7; // 0x130(0x01)
	char pad_131[0x3]; // 0x131(0x03)
	float NoiseLockRadius; // 0x134(0x04)
	char bNoiseLock : 1; // 0x138(0x01)
	char bOscillate : 1; // 0x138(0x01)
	char pad_138_2 : 6; // 0x138(0x01)
	char pad_139[0x3]; // 0x139(0x03)
	float NoiseLockTime; // 0x13c(0x04)
	float NoiseTension; // 0x140(0x04)
	char bUseNoiseTangents : 1; // 0x144(0x01)
	char pad_144_1 : 7; // 0x144(0x01)
	char pad_145[0x3]; // 0x145(0x03)
	struct FRawDistributionFloat NoiseTangentStrength; // 0x148(0x38)
	int32 NoiseTessellation; // 0x180(0x04)
	char bTargetNoise : 1; // 0x184(0x01)
	char pad_184_1 : 7; // 0x184(0x01)
	char pad_185[0x3]; // 0x185(0x03)
	float FrequencyDistance; // 0x188(0x04)
	char bApplyNoiseScale : 1; // 0x18c(0x01)
	char pad_18C_1 : 7; // 0x18c(0x01)
	char pad_18D[0x3]; // 0x18d(0x03)
	struct FRawDistributionFloat NoiseScale; // 0x190(0x38)
};

// Class Engine.ParticleModuleBeamSource
// Size: 0x148 (Inherited: 0x40)
struct UParticleModuleBeamSource : UParticleModuleBeamBase {
	enum class Beam2SourceTargetMethod SourceMethod; // 0x40(0x01)
	char pad_41[0x7]; // 0x41(0x07)
	struct FName SourceName; // 0x48(0x08)
	char bSourceAbsolute : 1; // 0x50(0x01)
	char pad_50_1 : 7; // 0x50(0x01)
	char pad_51[0x7]; // 0x51(0x07)
	struct FRawDistributionVector Source; // 0x58(0x50)
	char bLockSource : 1; // 0xa8(0x01)
	char pad_A8_1 : 7; // 0xa8(0x01)
	char pad_A9[0x3]; // 0xa9(0x03)
	enum class Beam2SourceTargetTangentMethod SourceTangentMethod; // 0xac(0x01)
	char pad_AD[0x3]; // 0xad(0x03)
	struct FRawDistributionVector SourceTangent; // 0xb0(0x50)
	char bLockSourceTangent : 1; // 0x100(0x01)
	char pad_100_1 : 7; // 0x100(0x01)
	char pad_101[0x7]; // 0x101(0x07)
	struct FRawDistributionFloat SourceStrength; // 0x108(0x38)
	char bLockSourceStength : 1; // 0x140(0x01)
	char pad_140_1 : 7; // 0x140(0x01)
	char pad_141[0x7]; // 0x141(0x07)
};

// Class Engine.ParticleModuleBeamTarget
// Size: 0x148 (Inherited: 0x40)
struct UParticleModuleBeamTarget : UParticleModuleBeamBase {
	enum class Beam2SourceTargetMethod TargetMethod; // 0x40(0x01)
	char pad_41[0x7]; // 0x41(0x07)
	struct FName TargetName; // 0x48(0x08)
	struct FRawDistributionVector Target; // 0x50(0x50)
	char bTargetAbsolute : 1; // 0xa0(0x01)
	char bLockTarget : 1; // 0xa0(0x01)
	char pad_A0_2 : 6; // 0xa0(0x01)
	char pad_A1[0x3]; // 0xa1(0x03)
	enum class Beam2SourceTargetTangentMethod TargetTangentMethod; // 0xa4(0x01)
	char pad_A5[0x3]; // 0xa5(0x03)
	struct FRawDistributionVector TargetTangent; // 0xa8(0x50)
	char bLockTargetTangent : 1; // 0xf8(0x01)
	char pad_F8_1 : 7; // 0xf8(0x01)
	char pad_F9[0x7]; // 0xf9(0x07)
	struct FRawDistributionFloat TargetStrength; // 0x100(0x38)
	char bLockTargetStength : 1; // 0x138(0x01)
	char pad_138_1 : 7; // 0x138(0x01)
	char pad_139[0x3]; // 0x139(0x03)
	float LockRadius; // 0x13c(0x04)
	char pad_140[0x8]; // 0x140(0x08)
};

// Class Engine.ParticleModuleCameraBase
// Size: 0x40 (Inherited: 0x40)
struct UParticleModuleCameraBase : UParticleModule {
};

// Class Engine.ParticleModuleCameraOffset
// Size: 0x80 (Inherited: 0x40)
struct UParticleModuleCameraOffset : UParticleModuleCameraBase {
	struct FRawDistributionFloat CameraOffset; // 0x40(0x38)
	char bSpawnTimeOnly : 1; // 0x78(0x01)
	char pad_78_1 : 7; // 0x78(0x01)
	char pad_79[0x3]; // 0x79(0x03)
	enum class EParticleCameraOffsetUpdateMethod UpdateMethod; // 0x7c(0x01)
	char pad_7D[0x3]; // 0x7d(0x03)
};

// Class Engine.ParticleModuleCollisionBase
// Size: 0x40 (Inherited: 0x40)
struct UParticleModuleCollisionBase : UParticleModule {
};

// Class Engine.ParticleModuleCollision
// Size: 0x1c8 (Inherited: 0x40)
struct UParticleModuleCollision : UParticleModuleCollisionBase {
	struct FRawDistributionVector DampingFactor; // 0x40(0x50)
	struct FRawDistributionVector DampingFactorRotation; // 0x90(0x50)
	struct FRawDistributionFloat MaxCollisions; // 0xe0(0x38)
	enum class EParticleCollisionComplete CollisionCompletionOption; // 0x118(0x01)
	char pad_119[0x7]; // 0x119(0x07)
	struct TArray<enum class EObjectTypeQuery> CollisionTypes; // 0x120(0x10)
	char pad_130[0x8]; // 0x130(0x08)
	char bApplyPhysics : 1; // 0x138(0x01)
	char bIgnoreTriggerVolumes : 1; // 0x138(0x01)
	char pad_138_2 : 6; // 0x138(0x01)
	char pad_139[0x7]; // 0x139(0x07)
	struct FRawDistributionFloat ParticleMass; // 0x140(0x38)
	float DirScalar; // 0x178(0x04)
	char bPawnsDoNotDecrementCount : 1; // 0x17c(0x01)
	char bOnlyVerticalNormalsDecrementCount : 1; // 0x17c(0x01)
	char pad_17C_2 : 6; // 0x17c(0x01)
	char pad_17D[0x3]; // 0x17d(0x03)
	float VerticalFudgeFactor; // 0x180(0x04)
	char pad_184[0x4]; // 0x184(0x04)
	struct FRawDistributionFloat DelayAmount; // 0x188(0x38)
	char bDropDetail : 1; // 0x1c0(0x01)
	char bCollideOnlyIfVisible : 1; // 0x1c0(0x01)
	char bIgnoreSourceActor : 1; // 0x1c0(0x01)
	char pad_1C0_3 : 5; // 0x1c0(0x01)
	char pad_1C1[0x3]; // 0x1c1(0x03)
	float MaxCollisionDistance; // 0x1c4(0x04)
};

// Class Engine.ParticleModuleCollisionGPU
// Size: 0xc8 (Inherited: 0x40)
struct UParticleModuleCollisionGPU : UParticleModuleCollisionBase {
	struct FRawDistributionFloat Resilience; // 0x40(0x38)
	struct FRawDistributionFloat ResilienceScaleOverLife; // 0x78(0x38)
	float Friction; // 0xb0(0x04)
	float RandomSpread; // 0xb4(0x04)
	float RandomDistribution; // 0xb8(0x04)
	float RadiusScale; // 0xbc(0x04)
	float RadiusBias; // 0xc0(0x04)
	enum class EParticleCollisionResponse Response; // 0xc4(0x01)
	enum class EParticleCollisionMode CollisionMode; // 0xc5(0x01)
	char pad_C6[0x2]; // 0xc6(0x02)
};

// Class Engine.ParticleModuleColorBase
// Size: 0x40 (Inherited: 0x40)
struct UParticleModuleColorBase : UParticleModule {
};

// Class Engine.ParticleModuleColor
// Size: 0xd0 (Inherited: 0x40)
struct UParticleModuleColor : UParticleModuleColorBase {
	struct FRawDistributionVector StartColor; // 0x40(0x50)
	struct FRawDistributionFloat StartAlpha; // 0x90(0x38)
	char bClampAlpha : 1; // 0xc8(0x01)
	char pad_C8_1 : 7; // 0xc8(0x01)
	char pad_C9[0x7]; // 0xc9(0x07)
};

// Class Engine.ParticleModuleColor_Seeded
// Size: 0xf0 (Inherited: 0xd0)
struct UParticleModuleColor_Seeded : UParticleModuleColor {
	struct FParticleRandomSeedInfo RandomSeedInfo; // 0xd0(0x20)
};

// Class Engine.ParticleModuleColorOverLife
// Size: 0xd0 (Inherited: 0x40)
struct UParticleModuleColorOverLife : UParticleModuleColorBase {
	struct FRawDistributionVector ColorOverLife; // 0x40(0x50)
	struct FRawDistributionFloat AlphaOverLife; // 0x90(0x38)
	char bClampAlpha : 1; // 0xc8(0x01)
	char pad_C8_1 : 7; // 0xc8(0x01)
	char pad_C9[0x7]; // 0xc9(0x07)
};

// Class Engine.ParticleModuleColorScaleOverLife
// Size: 0xd0 (Inherited: 0x40)
struct UParticleModuleColorScaleOverLife : UParticleModuleColorBase {
	struct FRawDistributionVector ColorScaleOverLife; // 0x40(0x50)
	struct FRawDistributionFloat AlphaScaleOverLife; // 0x90(0x38)
	char bEmitterTime : 1; // 0xc8(0x01)
	char pad_C8_1 : 7; // 0xc8(0x01)
	char pad_C9[0x7]; // 0xc9(0x07)
};

// Class Engine.ParticleModuleEventBase
// Size: 0x40 (Inherited: 0x40)
struct UParticleModuleEventBase : UParticleModule {
};

// Class Engine.ParticleModuleEventGenerator
// Size: 0x50 (Inherited: 0x40)
struct UParticleModuleEventGenerator : UParticleModuleEventBase {
	struct TArray<struct FParticleEvent_GenerateInfo> Events; // 0x40(0x10)
};

// Class Engine.ParticleModuleEventReceiverBase
// Size: 0x50 (Inherited: 0x40)
struct UParticleModuleEventReceiverBase : UParticleModuleEventBase {
	enum class EParticleEventType EventGeneratorType; // 0x40(0x01)
	char pad_41[0x7]; // 0x41(0x07)
	struct FName EventName; // 0x48(0x08)
};

// Class Engine.ParticleModuleEventReceiverKillParticles
// Size: 0x58 (Inherited: 0x50)
struct UParticleModuleEventReceiverKillParticles : UParticleModuleEventReceiverBase {
	char bStopSpawning : 1; // 0x50(0x01)
	char pad_50_1 : 7; // 0x50(0x01)
	char pad_51[0x7]; // 0x51(0x07)
};

// Class Engine.ParticleModuleEventReceiverSpawn
// Size: 0xf8 (Inherited: 0x50)
struct UParticleModuleEventReceiverSpawn : UParticleModuleEventReceiverBase {
	struct FRawDistributionFloat SpawnCount; // 0x50(0x38)
	char bUseParticleTime : 1; // 0x88(0x01)
	char bUsePSysLocation : 1; // 0x88(0x01)
	char bInheritVelocity : 1; // 0x88(0x01)
	char pad_88_3 : 5; // 0x88(0x01)
	char pad_89[0x7]; // 0x89(0x07)
	struct FRawDistributionVector InheritVelocityScale; // 0x90(0x50)
	struct TArray<struct UPhysicalMaterial*> PhysicalMaterials; // 0xe0(0x10)
	char bBanPhysicalMaterials : 1; // 0xf0(0x01)
	char pad_F0_1 : 7; // 0xf0(0x01)
	char pad_F1[0x7]; // 0xf1(0x07)
};

// Class Engine.ParticleModuleKillBase
// Size: 0x40 (Inherited: 0x40)
struct UParticleModuleKillBase : UParticleModule {
};

// Class Engine.ParticleModuleKillBox
// Size: 0xe8 (Inherited: 0x40)
struct UParticleModuleKillBox : UParticleModuleKillBase {
	struct FRawDistributionVector LowerLeftCorner; // 0x40(0x50)
	struct FRawDistributionVector UpperRightCorner; // 0x90(0x50)
	char bAbsolute : 1; // 0xe0(0x01)
	char bKillInside : 1; // 0xe0(0x01)
	char bAxisAlignedAndFixedSize : 1; // 0xe0(0x01)
	char pad_E0_3 : 5; // 0xe0(0x01)
	char pad_E1[0x7]; // 0xe1(0x07)
};

// Class Engine.ParticleModuleKillHeight
// Size: 0x80 (Inherited: 0x40)
struct UParticleModuleKillHeight : UParticleModuleKillBase {
	struct FRawDistributionFloat Height; // 0x40(0x38)
	char bAbsolute : 1; // 0x78(0x01)
	char bFloor : 1; // 0x78(0x01)
	char bApplyPSysScale : 1; // 0x78(0x01)
	char pad_78_3 : 5; // 0x78(0x01)
	char pad_79[0x7]; // 0x79(0x07)
};

// Class Engine.ParticleModuleLifetimeBase
// Size: 0x40 (Inherited: 0x40)
struct UParticleModuleLifetimeBase : UParticleModule {
};

// Class Engine.ParticleModuleLifetime
// Size: 0x78 (Inherited: 0x40)
struct UParticleModuleLifetime : UParticleModuleLifetimeBase {
	struct FRawDistributionFloat LifeTime; // 0x40(0x38)
};

// Class Engine.ParticleModuleLifetime_Seeded
// Size: 0x98 (Inherited: 0x78)
struct UParticleModuleLifetime_Seeded : UParticleModuleLifetime {
	struct FParticleRandomSeedInfo RandomSeedInfo; // 0x78(0x20)
};

// Class Engine.ParticleModuleLightBase
// Size: 0x40 (Inherited: 0x40)
struct UParticleModuleLightBase : UParticleModule {
};

// Class Engine.ParticleModuleLight
// Size: 0x158 (Inherited: 0x40)
struct UParticleModuleLight : UParticleModuleLightBase {
	bool bUseInverseSquaredFalloff; // 0x40(0x01)
	bool bAffectsTranslucency; // 0x41(0x01)
	bool bPreviewLightRadius; // 0x42(0x01)
	char pad_43[0x1]; // 0x43(0x01)
	float SpawnFraction; // 0x44(0x04)
	struct FRawDistributionVector ColorScaleOverLife; // 0x48(0x50)
	struct FRawDistributionFloat BrightnessOverLife; // 0x98(0x38)
	struct FRawDistributionFloat RadiusScale; // 0xd0(0x38)
	struct FRawDistributionFloat LightExponent; // 0x108(0x38)
	struct FLightingChannels LightingChannels; // 0x140(0x03)
	char pad_143[0x1]; // 0x143(0x01)
	float VolumetricScatteringIntensity; // 0x144(0x04)
	bool bHighQualityLights; // 0x148(0x01)
	bool bShadowCastingLights; // 0x149(0x01)
	char pad_14A[0x6]; // 0x14a(0x06)
	struct UTextureLightProfile* IESTexture; // 0x150(0x08)
};

// Class Engine.ParticleModuleLight_Seeded
// Size: 0x178 (Inherited: 0x158)
struct UParticleModuleLight_Seeded : UParticleModuleLight {
	struct FParticleRandomSeedInfo RandomSeedInfo; // 0x158(0x20)
};

// Class Engine.ParticleModuleLocationBase
// Size: 0x40 (Inherited: 0x40)
struct UParticleModuleLocationBase : UParticleModule {
};

// Class Engine.ParticleModuleLocation
// Size: 0x98 (Inherited: 0x40)
struct UParticleModuleLocation : UParticleModuleLocationBase {
	struct FRawDistributionVector StartLocation; // 0x40(0x50)
	float DistributeOverNPoints; // 0x90(0x04)
	float DistributeThreshold; // 0x94(0x04)
};

// Class Engine.ParticleModuleLocation_Seeded
// Size: 0xb8 (Inherited: 0x98)
struct UParticleModuleLocation_Seeded : UParticleModuleLocation {
	struct FParticleRandomSeedInfo RandomSeedInfo; // 0x98(0x20)
};

// Class Engine.ParticleModuleLocationWorldOffset
// Size: 0x98 (Inherited: 0x98)
struct UParticleModuleLocationWorldOffset : UParticleModuleLocation {
};

// Class Engine.ParticleModuleLocationWorldOffset_Seeded
// Size: 0xb8 (Inherited: 0x98)
struct UParticleModuleLocationWorldOffset_Seeded : UParticleModuleLocationWorldOffset {
	struct FParticleRandomSeedInfo RandomSeedInfo; // 0x98(0x20)
};

// Class Engine.ParticleModuleLocationBoneSocket
// Size: 0x80 (Inherited: 0x40)
struct UParticleModuleLocationBoneSocket : UParticleModuleLocationBase {
	enum class ELocationBoneSocketSource SourceType; // 0x40(0x01)
	char pad_41[0x3]; // 0x41(0x03)
	struct FVector UniversalOffset; // 0x44(0x0c)
	struct TArray<struct FLocationBoneSocketInfo> SourceLocations; // 0x50(0x10)
	enum class ELocationBoneSocketSelectionMethod SelectionMethod; // 0x60(0x01)
	char pad_61[0x3]; // 0x61(0x03)
	char bUpdatePositionEachFrame : 1; // 0x64(0x01)
	char bOrientMeshEmitters : 1; // 0x64(0x01)
	char bInheritBoneVelocity : 1; // 0x64(0x01)
	char pad_64_3 : 5; // 0x64(0x01)
	char pad_65[0x3]; // 0x65(0x03)
	float InheritVelocityScale; // 0x68(0x04)
	char pad_6C[0x4]; // 0x6c(0x04)
	struct FName SkelMeshActorParamName; // 0x70(0x08)
	int32 NumPreSelectedIndices; // 0x78(0x04)
	char pad_7C[0x4]; // 0x7c(0x04)
};

// Class Engine.ParticleModuleLocationDirect
// Size: 0x180 (Inherited: 0x40)
struct UParticleModuleLocationDirect : UParticleModuleLocationBase {
	struct FRawDistributionVector Location; // 0x40(0x50)
	struct FRawDistributionVector LocationOffset; // 0x90(0x50)
	struct FRawDistributionVector ScaleFactor; // 0xe0(0x50)
	struct FRawDistributionVector Direction; // 0x130(0x50)
};

// Class Engine.ParticleModuleLocationEmitter
// Size: 0x60 (Inherited: 0x40)
struct UParticleModuleLocationEmitter : UParticleModuleLocationBase {
	struct FName EmitterName; // 0x40(0x08)
	enum class ELocationEmitterSelectionMethod SelectionMethod; // 0x48(0x01)
	char pad_49[0x3]; // 0x49(0x03)
	char InheritSourceVelocity : 1; // 0x4c(0x01)
	char pad_4C_1 : 7; // 0x4c(0x01)
	char pad_4D[0x3]; // 0x4d(0x03)
	float InheritSourceVelocityScale; // 0x50(0x04)
	char bInheritSourceRotation : 1; // 0x54(0x01)
	char pad_54_1 : 7; // 0x54(0x01)
	char pad_55[0x3]; // 0x55(0x03)
	float InheritSourceRotationScale; // 0x58(0x04)
	char pad_5C[0x4]; // 0x5c(0x04)
};

// Class Engine.ParticleModuleLocationEmitterDirect
// Size: 0x48 (Inherited: 0x40)
struct UParticleModuleLocationEmitterDirect : UParticleModuleLocationBase {
	struct FName EmitterName; // 0x40(0x08)
};

// Class Engine.ParticleModuleLocationPrimitiveBase
// Size: 0xd0 (Inherited: 0x40)
struct UParticleModuleLocationPrimitiveBase : UParticleModuleLocationBase {
	char Positive_X : 1; // 0x40(0x01)
	char Positive_Y : 1; // 0x40(0x01)
	char Positive_Z : 1; // 0x40(0x01)
	char Negative_X : 1; // 0x40(0x01)
	char Negative_Y : 1; // 0x40(0x01)
	char Negative_Z : 1; // 0x40(0x01)
	char SurfaceOnly : 1; // 0x40(0x01)
	char Velocity : 1; // 0x40(0x01)
	char pad_41[0x7]; // 0x41(0x07)
	struct FRawDistributionFloat VelocityScale; // 0x48(0x38)
	struct FRawDistributionVector StartLocation; // 0x80(0x50)
};

// Class Engine.ParticleModuleLocationPrimitiveCylinder
// Size: 0x150 (Inherited: 0xd0)
struct UParticleModuleLocationPrimitiveCylinder : UParticleModuleLocationPrimitiveBase {
	char RadialVelocity : 1; // 0xd0(0x01)
	char pad_D0_1 : 7; // 0xd0(0x01)
	char pad_D1[0x7]; // 0xd1(0x07)
	struct FRawDistributionFloat StartRadius; // 0xd8(0x38)
	struct FRawDistributionFloat StartHeight; // 0x110(0x38)
	enum class CylinderHeightAxis HeightAxis; // 0x148(0x01)
	char pad_149[0x7]; // 0x149(0x07)
};

// Class Engine.ParticleModuleLocationPrimitiveCylinder_Seeded
// Size: 0x170 (Inherited: 0x150)
struct UParticleModuleLocationPrimitiveCylinder_Seeded : UParticleModuleLocationPrimitiveCylinder {
	struct FParticleRandomSeedInfo RandomSeedInfo; // 0x150(0x20)
};

// Class Engine.ParticleModuleLocationPrimitiveSphere
// Size: 0x108 (Inherited: 0xd0)
struct UParticleModuleLocationPrimitiveSphere : UParticleModuleLocationPrimitiveBase {
	struct FRawDistributionFloat StartRadius; // 0xd0(0x38)
};

// Class Engine.ParticleModuleLocationPrimitiveSphere_Seeded
// Size: 0x128 (Inherited: 0x108)
struct UParticleModuleLocationPrimitiveSphere_Seeded : UParticleModuleLocationPrimitiveSphere {
	struct FParticleRandomSeedInfo RandomSeedInfo; // 0x108(0x20)
};

// Class Engine.ParticleModuleLocationPrimitiveTriangle
// Size: 0x138 (Inherited: 0x40)
struct UParticleModuleLocationPrimitiveTriangle : UParticleModuleLocationBase {
	struct FRawDistributionVector StartOffset; // 0x40(0x50)
	struct FRawDistributionFloat Height; // 0x90(0x38)
	struct FRawDistributionFloat Angle; // 0xc8(0x38)
	struct FRawDistributionFloat Thickness; // 0x100(0x38)
};

// Class Engine.ParticleModuleLocationSkelVertSurface
// Size: 0xa0 (Inherited: 0x40)
struct UParticleModuleLocationSkelVertSurface : UParticleModuleLocationBase {
	enum class ELocationSkelVertSurfaceSource SourceType; // 0x40(0x01)
	char pad_41[0x3]; // 0x41(0x03)
	struct FVector UniversalOffset; // 0x44(0x0c)
	char bUpdatePositionEachFrame : 1; // 0x50(0x01)
	char bOrientMeshEmitters : 1; // 0x50(0x01)
	char bInheritBoneVelocity : 1; // 0x50(0x01)
	char pad_50_3 : 5; // 0x50(0x01)
	char pad_51[0x3]; // 0x51(0x03)
	float InheritVelocityScale; // 0x54(0x04)
	struct FName SkelMeshActorParamName; // 0x58(0x08)
	struct TArray<struct FName> ValidAssociatedBones; // 0x60(0x10)
	char bEnforceNormalCheck : 1; // 0x70(0x01)
	char pad_70_1 : 7; // 0x70(0x01)
	char pad_71[0x3]; // 0x71(0x03)
	struct FVector NormalToCompare; // 0x74(0x0c)
	float NormalCheckToleranceDegrees; // 0x80(0x04)
	float NormalCheckTolerance; // 0x84(0x04)
	struct TArray<int32> ValidMaterialIndices; // 0x88(0x10)
	char bInheritVertexColor : 1; // 0x98(0x01)
	char bInheritUV : 1; // 0x98(0x01)
	char pad_98_2 : 6; // 0x98(0x01)
	char pad_99[0x3]; // 0x99(0x03)
	uint32 InheritUVChannel; // 0x9c(0x04)
};

// Class Engine.ParticleModulePivotOffset
// Size: 0x48 (Inherited: 0x40)
struct UParticleModulePivotOffset : UParticleModuleLocationBase {
	struct FVector2D PivotOffset; // 0x40(0x08)
};

// Class Engine.ParticleModuleSourceMovement
// Size: 0x90 (Inherited: 0x40)
struct UParticleModuleSourceMovement : UParticleModuleLocationBase {
	struct FRawDistributionVector SourceMovementScale; // 0x40(0x50)
};

// Class Engine.ParticleModuleMaterialBase
// Size: 0x40 (Inherited: 0x40)
struct UParticleModuleMaterialBase : UParticleModule {
};

// Class Engine.ParticleModuleMeshMaterial
// Size: 0x50 (Inherited: 0x40)
struct UParticleModuleMeshMaterial : UParticleModuleMaterialBase {
	struct TArray<struct UMaterialInterface*> MeshMaterials; // 0x40(0x10)
};

// Class Engine.ParticleModuleOrbitBase
// Size: 0x48 (Inherited: 0x40)
struct UParticleModuleOrbitBase : UParticleModule {
	char bUseEmitterTime : 1; // 0x40(0x01)
	char pad_40_1 : 7; // 0x40(0x01)
	char pad_41[0x7]; // 0x41(0x07)
};

// Class Engine.ParticleModuleOrbit
// Size: 0x158 (Inherited: 0x48)
struct UParticleModuleOrbit : UParticleModuleOrbitBase {
	enum class EOrbitChainMode ChainMode; // 0x48(0x01)
	char pad_49[0x7]; // 0x49(0x07)
	struct FRawDistributionVector OffsetAmount; // 0x50(0x50)
	struct FOrbitOptions OffsetOptions; // 0xa0(0x04)
	char pad_A4[0x4]; // 0xa4(0x04)
	struct FRawDistributionVector RotationAmount; // 0xa8(0x50)
	struct FOrbitOptions RotationOptions; // 0xf8(0x04)
	char pad_FC[0x4]; // 0xfc(0x04)
	struct FRawDistributionVector RotationRateAmount; // 0x100(0x50)
	struct FOrbitOptions RotationRateOptions; // 0x150(0x04)
	char pad_154[0x4]; // 0x154(0x04)
};

// Class Engine.ParticleModuleOrientationBase
// Size: 0x40 (Inherited: 0x40)
struct UParticleModuleOrientationBase : UParticleModule {
};

// Class Engine.ParticleModuleOrientationAxisLock
// Size: 0x48 (Inherited: 0x40)
struct UParticleModuleOrientationAxisLock : UParticleModuleOrientationBase {
	enum class EParticleAxisLock LockAxisFlags; // 0x40(0x01)
	char pad_41[0x7]; // 0x41(0x07)
};

// Class Engine.ParticleModuleParameterBase
// Size: 0x40 (Inherited: 0x40)
struct UParticleModuleParameterBase : UParticleModule {
};

// Class Engine.ParticleModuleParameterDynamic
// Size: 0x58 (Inherited: 0x40)
struct UParticleModuleParameterDynamic : UParticleModuleParameterBase {
	struct TArray<struct FEmitterDynamicParameter> DynamicParams; // 0x40(0x10)
	int32 UpdateFlags; // 0x50(0x04)
	char bUsesVelocity : 1; // 0x54(0x01)
	char pad_54_1 : 7; // 0x54(0x01)
	char pad_55[0x3]; // 0x55(0x03)
};

// Class Engine.ParticleModuleParameterDynamic_Seeded
// Size: 0x78 (Inherited: 0x58)
struct UParticleModuleParameterDynamic_Seeded : UParticleModuleParameterDynamic {
	struct FParticleRandomSeedInfo RandomSeedInfo; // 0x58(0x20)
};

// Class Engine.SubUVAnimation
// Size: 0x70 (Inherited: 0x38)
struct USubUVAnimation : UObject {
	struct UTexture2D* SubUVTexture; // 0x38(0x08)
	int32 SubImages_Horizontal; // 0x40(0x04)
	int32 SubImages_Vertical; // 0x44(0x04)
	enum class ESubUVBoundingVertexCount BoundingMode; // 0x48(0x01)
	enum class EOpacitySourceMode OpacitySourceMode; // 0x49(0x01)
	char pad_4A[0x2]; // 0x4a(0x02)
	float AlphaThreshold; // 0x4c(0x04)
	char pad_50[0x20]; // 0x50(0x20)
};

// Class Engine.ParticleModuleRequired
// Size: 0x1a0 (Inherited: 0x40)
struct UParticleModuleRequired : UParticleModule {
	struct UMaterialInterface* Material; // 0x40(0x08)
	struct UMaterialInterface* MaterialTiled; // 0x48(0x08)
	struct FVector4 TiledTranslucentMultipliers; // 0x50(0x10)
	struct FVector EmitterOrigin; // 0x60(0x0c)
	struct FRotator EmitterRotation; // 0x6c(0x0c)
	enum class EParticleScreenAlignment ScreenAlignment; // 0x78(0x01)
	char pad_79[0x3]; // 0x79(0x03)
	float MinFacingCameraBlendDistance; // 0x7c(0x04)
	float MaxFacingCameraBlendDistance; // 0x80(0x04)
	float MinimalScreenSize; // 0x84(0x04)
	char bUseLocalSpace : 1; // 0x88(0x01)
	char bKillOnDeactivate : 1; // 0x88(0x01)
	char bKillOnCompleted : 1; // 0x88(0x01)
	char pad_88_3 : 5; // 0x88(0x01)
	char pad_89[0x3]; // 0x89(0x03)
	enum class EParticleSortMode SortMode; // 0x8c(0x01)
	char pad_8D[0x3]; // 0x8d(0x03)
	char bUseLegacyEmitterTime : 1; // 0x90(0x01)
	char bRemoveHMDRoll : 1; // 0x90(0x01)
	char pad_90_2 : 6; // 0x90(0x01)
	char pad_91[0x3]; // 0x91(0x03)
	float EmitterDuration; // 0x94(0x04)
	float EmitterDurationLow; // 0x98(0x04)
	char bEmitterDurationUseRange : 1; // 0x9c(0x01)
	char bDurationRecalcEachLoop : 1; // 0x9c(0x01)
	char pad_9C_2 : 6; // 0x9c(0x01)
	char pad_9D[0x3]; // 0x9d(0x03)
	int32 EmitterLoops; // 0xa0(0x04)
	char pad_A4[0x4]; // 0xa4(0x04)
	struct FRawDistributionFloat SpawnRate; // 0xa8(0x38)
	enum class EParticleBurstMethod ParticleBurstMethod; // 0xe0(0x01)
	char pad_E1[0x7]; // 0xe1(0x07)
	struct TArray<struct FParticleBurst> BurstList; // 0xe8(0x10)
	float EmitterDelay; // 0xf8(0x04)
	float EmitterDelayLow; // 0xfc(0x04)
	char bEmitterDelayUseRange : 1; // 0x100(0x01)
	char bDelayFirstLoopOnly : 1; // 0x100(0x01)
	char pad_100_2 : 6; // 0x100(0x01)
	char pad_101[0x3]; // 0x101(0x03)
	enum class EParticleSubUVInterpMethod InterpolationMethod; // 0x104(0x01)
	char pad_105[0x3]; // 0x105(0x03)
	int32 SubImages_Horizontal; // 0x108(0x04)
	int32 SubImages_Vertical; // 0x10c(0x04)
	char bScaleUV : 1; // 0x110(0x01)
	char pad_110_1 : 7; // 0x110(0x01)
	char pad_111[0x3]; // 0x111(0x03)
	float RandomImageTime; // 0x114(0x04)
	int32 RandomImageChanges; // 0x118(0x04)
	char bOverrideSystemMacroUV : 1; // 0x11c(0x01)
	char pad_11C_1 : 7; // 0x11c(0x01)
	char pad_11D[0x3]; // 0x11d(0x03)
	struct FVector MacroUVPosition; // 0x120(0x0c)
	float MacroUVRadius; // 0x12c(0x04)
	char bUseMaxDrawCount : 1; // 0x130(0x01)
	char pad_130_1 : 7; // 0x130(0x01)
	char pad_131[0x3]; // 0x131(0x03)
	int32 MaxDrawCount; // 0x134(0x04)
	enum class EParticleUVFlipMode UVFlippingMode; // 0x138(0x01)
	char pad_139[0x7]; // 0x139(0x07)
	struct UTexture2D* CutoutTexture; // 0x140(0x08)
	enum class ESubUVBoundingVertexCount BoundingMode; // 0x148(0x01)
	enum class EOpacitySourceMode OpacitySourceMode; // 0x149(0x01)
	char pad_14A[0x2]; // 0x14a(0x02)
	float AlphaThreshold; // 0x14c(0x04)
	enum class EEmitterNormalsMode EmitterNormalsMode; // 0x150(0x01)
	char pad_151[0x3]; // 0x151(0x03)
	struct FVector NormalsSphereCenter; // 0x154(0x0c)
	struct FVector NormalsCylinderDirection; // 0x160(0x0c)
	char bOrbitModuleAffectsVelocityAlignment : 1; // 0x16c(0x01)
	char pad_16C_1 : 7; // 0x16c(0x01)
	char pad_16D[0x3]; // 0x16d(0x03)
	struct TArray<struct FName> NamedMaterialOverrides; // 0x170(0x10)
	char pad_180[0x20]; // 0x180(0x20)
};

// Class Engine.ParticleModuleRotationBase
// Size: 0x40 (Inherited: 0x40)
struct UParticleModuleRotationBase : UParticleModule {
};

// Class Engine.ParticleModuleMeshRotation
// Size: 0x98 (Inherited: 0x40)
struct UParticleModuleMeshRotation : UParticleModuleRotationBase {
	struct FRawDistributionVector StartRotation; // 0x40(0x50)
	char bInheritParent : 1; // 0x90(0x01)
	char pad_90_1 : 7; // 0x90(0x01)
	char pad_91[0x7]; // 0x91(0x07)
};

// Class Engine.ParticleModuleMeshRotation_Seeded
// Size: 0xb8 (Inherited: 0x98)
struct UParticleModuleMeshRotation_Seeded : UParticleModuleMeshRotation {
	struct FParticleRandomSeedInfo RandomSeedInfo; // 0x98(0x20)
};

// Class Engine.ParticleModuleRotation
// Size: 0x78 (Inherited: 0x40)
struct UParticleModuleRotation : UParticleModuleRotationBase {
	struct FRawDistributionFloat StartRotation; // 0x40(0x38)
};

// Class Engine.ParticleModuleRotation_Seeded
// Size: 0x98 (Inherited: 0x78)
struct UParticleModuleRotation_Seeded : UParticleModuleRotation {
	struct FParticleRandomSeedInfo RandomSeedInfo; // 0x78(0x20)
};

// Class Engine.ParticleModuleRotationOverLifetime
// Size: 0x80 (Inherited: 0x40)
struct UParticleModuleRotationOverLifetime : UParticleModuleRotationBase {
	struct FRawDistributionFloat RotationOverLife; // 0x40(0x38)
	char Scale : 1; // 0x78(0x01)
	char pad_78_1 : 7; // 0x78(0x01)
	char pad_79[0x7]; // 0x79(0x07)
};

// Class Engine.ParticleModuleRotationRateBase
// Size: 0x40 (Inherited: 0x40)
struct UParticleModuleRotationRateBase : UParticleModule {
};

// Class Engine.ParticleModuleMeshRotationRate
// Size: 0x90 (Inherited: 0x40)
struct UParticleModuleMeshRotationRate : UParticleModuleRotationRateBase {
	struct FRawDistributionVector StartRotationRate; // 0x40(0x50)
};

// Class Engine.ParticleModuleMeshRotationRate_Seeded
// Size: 0xb0 (Inherited: 0x90)
struct UParticleModuleMeshRotationRate_Seeded : UParticleModuleMeshRotationRate {
	struct FParticleRandomSeedInfo RandomSeedInfo; // 0x90(0x20)
};

// Class Engine.ParticleModuleMeshRotationRateMultiplyLife
// Size: 0x90 (Inherited: 0x40)
struct UParticleModuleMeshRotationRateMultiplyLife : UParticleModuleRotationRateBase {
	struct FRawDistributionVector LifeMultiplier; // 0x40(0x50)
};

// Class Engine.ParticleModuleMeshRotationRateOverLife
// Size: 0x98 (Inherited: 0x40)
struct UParticleModuleMeshRotationRateOverLife : UParticleModuleRotationRateBase {
	struct FRawDistributionVector RotRate; // 0x40(0x50)
	char bScaleRotRate : 1; // 0x90(0x01)
	char pad_90_1 : 7; // 0x90(0x01)
	char pad_91[0x7]; // 0x91(0x07)
};

// Class Engine.ParticleModuleRotationRate
// Size: 0x78 (Inherited: 0x40)
struct UParticleModuleRotationRate : UParticleModuleRotationRateBase {
	struct FRawDistributionFloat StartRotationRate; // 0x40(0x38)
};

// Class Engine.ParticleModuleRotationRate_Seeded
// Size: 0x98 (Inherited: 0x78)
struct UParticleModuleRotationRate_Seeded : UParticleModuleRotationRate {
	struct FParticleRandomSeedInfo RandomSeedInfo; // 0x78(0x20)
};

// Class Engine.ParticleModuleRotationRateMultiplyLife
// Size: 0x78 (Inherited: 0x40)
struct UParticleModuleRotationRateMultiplyLife : UParticleModuleRotationRateBase {
	struct FRawDistributionFloat LifeMultiplier; // 0x40(0x38)
};

// Class Engine.ParticleModuleSizeBase
// Size: 0x40 (Inherited: 0x40)
struct UParticleModuleSizeBase : UParticleModule {
};

// Class Engine.ParticleModuleSize
// Size: 0x90 (Inherited: 0x40)
struct UParticleModuleSize : UParticleModuleSizeBase {
	struct FRawDistributionVector StartSize; // 0x40(0x50)
};

// Class Engine.ParticleModuleSize_Seeded
// Size: 0xb0 (Inherited: 0x90)
struct UParticleModuleSize_Seeded : UParticleModuleSize {
	struct FParticleRandomSeedInfo RandomSeedInfo; // 0x90(0x20)
};

// Class Engine.ParticleModuleSizeMultiplyLife
// Size: 0x98 (Inherited: 0x40)
struct UParticleModuleSizeMultiplyLife : UParticleModuleSizeBase {
	struct FRawDistributionVector LifeMultiplier; // 0x40(0x50)
	char MultiplyX : 1; // 0x90(0x01)
	char MultiplyY : 1; // 0x90(0x01)
	char MultiplyZ : 1; // 0x90(0x01)
	char pad_90_3 : 5; // 0x90(0x01)
	char pad_91[0x7]; // 0x91(0x07)
};

// Class Engine.ParticleModuleSizeScale
// Size: 0x98 (Inherited: 0x40)
struct UParticleModuleSizeScale : UParticleModuleSizeBase {
	struct FRawDistributionVector SizeScale; // 0x40(0x50)
	char EnableX : 1; // 0x90(0x01)
	char EnableY : 1; // 0x90(0x01)
	char EnableZ : 1; // 0x90(0x01)
	char pad_90_3 : 5; // 0x90(0x01)
	char pad_91[0x7]; // 0x91(0x07)
};

// Class Engine.ParticleModuleSizeScaleBySpeed
// Size: 0x50 (Inherited: 0x40)
struct UParticleModuleSizeScaleBySpeed : UParticleModuleSizeBase {
	struct FVector2D SpeedScale; // 0x40(0x08)
	struct FVector2D MaxScale; // 0x48(0x08)
};

// Class Engine.ParticleModuleSpawnBase
// Size: 0x48 (Inherited: 0x40)
struct UParticleModuleSpawnBase : UParticleModule {
	char bProcessSpawnRate : 1; // 0x40(0x01)
	char bProcessBurstList : 1; // 0x40(0x01)
	char pad_40_2 : 6; // 0x40(0x01)
	char pad_41[0x7]; // 0x41(0x07)
};

// Class Engine.ParticleModuleSpawn
// Size: 0x110 (Inherited: 0x48)
struct UParticleModuleSpawn : UParticleModuleSpawnBase {
	struct FRawDistributionFloat Rate; // 0x48(0x38)
	struct FRawDistributionFloat RateScale; // 0x80(0x38)
	enum class EParticleBurstMethod ParticleBurstMethod; // 0xb8(0x01)
	char pad_B9[0x7]; // 0xb9(0x07)
	struct TArray<struct FParticleBurst> BurstList; // 0xc0(0x10)
	struct FRawDistributionFloat BurstScale; // 0xd0(0x38)
	char bApplyGlobalSpawnRateScale : 1; // 0x108(0x01)
	char pad_108_1 : 7; // 0x108(0x01)
	char pad_109[0x7]; // 0x109(0x07)
};

// Class Engine.ParticleModuleSpawnPerUnit
// Size: 0x98 (Inherited: 0x48)
struct UParticleModuleSpawnPerUnit : UParticleModuleSpawnBase {
	float UnitScalar; // 0x48(0x04)
	char pad_4C[0x4]; // 0x4c(0x04)
	struct FRawDistributionFloat SpawnPerUnit; // 0x50(0x38)
	char bIgnoreSpawnRateWhenMoving : 1; // 0x88(0x01)
	char pad_88_1 : 7; // 0x88(0x01)
	char pad_89[0x3]; // 0x89(0x03)
	float MovementTolerance; // 0x8c(0x04)
	float MaxFrameDistance; // 0x90(0x04)
	char bIgnoreMovementAlongX : 1; // 0x94(0x01)
	char bIgnoreMovementAlongY : 1; // 0x94(0x01)
	char bIgnoreMovementAlongZ : 1; // 0x94(0x01)
	char pad_94_3 : 5; // 0x94(0x01)
	char pad_95[0x3]; // 0x95(0x03)
};

// Class Engine.ParticleModuleSubUVBase
// Size: 0x40 (Inherited: 0x40)
struct UParticleModuleSubUVBase : UParticleModule {
};

// Class Engine.ParticleModuleSubUV
// Size: 0x88 (Inherited: 0x40)
struct UParticleModuleSubUV : UParticleModuleSubUVBase {
	struct USubUVAnimation* Animation; // 0x40(0x08)
	struct FRawDistributionFloat SubImageIndex; // 0x48(0x38)
	char bUseRealTime : 1; // 0x80(0x01)
	char pad_80_1 : 7; // 0x80(0x01)
	char pad_81[0x7]; // 0x81(0x07)
};

// Class Engine.ParticleModuleSubUVMovie
// Size: 0xd0 (Inherited: 0x88)
struct UParticleModuleSubUVMovie : UParticleModuleSubUV {
	char bUseEmitterTime : 1; // 0x88(0x01)
	char pad_88_1 : 7; // 0x88(0x01)
	char pad_89[0x7]; // 0x89(0x07)
	struct FRawDistributionFloat FrameRate; // 0x90(0x38)
	int32 StartingFrame; // 0xc8(0x04)
	char pad_CC[0x4]; // 0xcc(0x04)
};

// Class Engine.ParticleModuleTrailBase
// Size: 0x40 (Inherited: 0x40)
struct UParticleModuleTrailBase : UParticleModule {
};

// Class Engine.ParticleModuleTrailSource
// Size: 0xa8 (Inherited: 0x40)
struct UParticleModuleTrailSource : UParticleModuleTrailBase {
	enum class ETrail2SourceMethod SourceMethod; // 0x40(0x01)
	char pad_41[0x7]; // 0x41(0x07)
	struct FName SourceName; // 0x48(0x08)
	struct FRawDistributionFloat SourceStrength; // 0x50(0x38)
	char bLockSourceStength : 1; // 0x88(0x01)
	char pad_88_1 : 7; // 0x88(0x01)
	char pad_89[0x3]; // 0x89(0x03)
	int32 SourceOffsetCount; // 0x8c(0x04)
	struct TArray<struct FVector> SourceOffsetDefaults; // 0x90(0x10)
	enum class EParticleSourceSelectionMethod SelectionMethod; // 0xa0(0x01)
	char pad_A1[0x3]; // 0xa1(0x03)
	char bInheritRotation : 1; // 0xa4(0x01)
	char pad_A4_1 : 7; // 0xa4(0x01)
	char pad_A5[0x3]; // 0xa5(0x03)
};

// Class Engine.ParticleModuleTypeDataBase
// Size: 0x40 (Inherited: 0x40)
struct UParticleModuleTypeDataBase : UParticleModule {
};

// Class Engine.ParticleModuleTypeDataAnimTrail
// Size: 0x58 (Inherited: 0x40)
struct UParticleModuleTypeDataAnimTrail : UParticleModuleTypeDataBase {
	char bDeadTrailsOnDeactivate : 1; // 0x40(0x01)
	char bEnablePreviousTangentRecalculation : 1; // 0x40(0x01)
	char bTangentRecalculationEveryFrame : 1; // 0x40(0x01)
	char pad_40_3 : 5; // 0x40(0x01)
	char pad_41[0x3]; // 0x41(0x03)
	float TilingDistance; // 0x44(0x04)
	float DistanceTessellationStepSize; // 0x48(0x04)
	float TangentTessellationStepSize; // 0x4c(0x04)
	float WidthTessellationStepSize; // 0x50(0x04)
	char pad_54[0x4]; // 0x54(0x04)
};

// Class Engine.ParticleModuleTypeDataBeam2
// Size: 0x178 (Inherited: 0x40)
struct UParticleModuleTypeDataBeam2 : UParticleModuleTypeDataBase {
	enum class EBeam2Method BeamMethod; // 0x40(0x01)
	char pad_41[0x3]; // 0x41(0x03)
	int32 TextureTile; // 0x44(0x04)
	float TextureTileDistance; // 0x48(0x04)
	int32 Sheets; // 0x4c(0x04)
	int32 MaxBeamCount; // 0x50(0x04)
	float Speed; // 0x54(0x04)
	int32 InterpolationPoints; // 0x58(0x04)
	char bAlwaysOn : 1; // 0x5c(0x01)
	char pad_5C_1 : 7; // 0x5c(0x01)
	char pad_5D[0x3]; // 0x5d(0x03)
	int32 UpVectorStepSize; // 0x60(0x04)
	char pad_64[0x4]; // 0x64(0x04)
	struct FName BranchParentName; // 0x68(0x08)
	struct FRawDistributionFloat Distance; // 0x70(0x38)
	enum class EBeamTaperMethod TaperMethod; // 0xa8(0x01)
	char pad_A9[0x7]; // 0xa9(0x07)
	struct FRawDistributionFloat TaperFactor; // 0xb0(0x38)
	struct FRawDistributionFloat TaperScale; // 0xe8(0x38)
	char RenderGeometry : 1; // 0x120(0x01)
	char RenderDirectLine : 1; // 0x120(0x01)
	char RenderLines : 1; // 0x120(0x01)
	char RenderTessellation : 1; // 0x120(0x01)
	char pad_120_4 : 4; // 0x120(0x01)
	char pad_121[0x57]; // 0x121(0x57)
};

// Class Engine.ParticleModuleTypeDataGpu
// Size: 0x470 (Inherited: 0x40)
struct UParticleModuleTypeDataGpu : UParticleModuleTypeDataBase {
	struct FGPUSpriteEmitterInfo EmitterInfo; // 0x40(0x2c0)
	struct FGPUSpriteResourceData ResourceData; // 0x300(0x160)
	float CameraMotionBlurAmount; // 0x460(0x04)
	char bClearExistingParticlesOnInit : 1; // 0x464(0x01)
	char pad_464_1 : 7; // 0x464(0x01)
	char pad_465[0xb]; // 0x465(0x0b)
};

// Class Engine.ParticleModuleTypeDataMesh
// Size: 0xc8 (Inherited: 0x40)
struct UParticleModuleTypeDataMesh : UParticleModuleTypeDataBase {
	struct UStaticMesh* Mesh; // 0x40(0x08)
	char CastShadows : 1; // 0x48(0x01)
	char DoCollisions : 1; // 0x48(0x01)
	char pad_48_2 : 6; // 0x48(0x01)
	char pad_49[0x3]; // 0x49(0x03)
	enum class EMeshScreenAlignment MeshAlignment; // 0x4c(0x01)
	char pad_4D[0x3]; // 0x4d(0x03)
	char bOverrideMaterial : 1; // 0x50(0x01)
	char bOverrideDefaultMotionBlurSettings : 1; // 0x50(0x01)
	char bEnableMotionBlur : 1; // 0x50(0x01)
	char pad_50_3 : 5; // 0x50(0x01)
	char pad_51[0x3]; // 0x51(0x03)
	float Pitch; // 0x54(0x04)
	float Roll; // 0x58(0x04)
	float Yaw; // 0x5c(0x04)
	struct FRawDistributionVector RollPitchYawRange; // 0x60(0x50)
	char pad_B0[0x8]; // 0xb0(0x08)
	enum class EParticleAxisLock AxisLockOption; // 0xb8(0x01)
	char pad_B9[0x3]; // 0xb9(0x03)
	char bCameraFacing : 1; // 0xbc(0x01)
	char pad_BC_1 : 7; // 0xbc(0x01)
	char pad_BD[0x3]; // 0xbd(0x03)
	enum class EMeshCameraFacingUpAxis CameraFacingUpAxisOption; // 0xc0(0x01)
	enum class EMeshCameraFacingOptions CameraFacingOption; // 0xc1(0x01)
	char pad_C2[0x2]; // 0xc2(0x02)
	char bApplyParticleRotationAsSpin : 1; // 0xc4(0x01)
	char bFaceCameraDirectionRatherThanPosition : 1; // 0xc4(0x01)
	char bCollisionsConsiderPartilceSize : 1; // 0xc4(0x01)
	char pad_C4_3 : 5; // 0xc4(0x01)
	char pad_C5[0x3]; // 0xc5(0x03)
};

// Class Engine.ParticleModuleTypeDataRibbon
// Size: 0x70 (Inherited: 0x40)
struct UParticleModuleTypeDataRibbon : UParticleModuleTypeDataBase {
	int32 MaxTessellationBetweenParticles; // 0x40(0x04)
	int32 SheetsPerTrail; // 0x44(0x04)
	int32 MaxTrailCount; // 0x48(0x04)
	int32 MaxParticleInTrailCount; // 0x4c(0x04)
	char bDeadTrailsOnDeactivate : 1; // 0x50(0x01)
	char bDeadTrailsOnSourceLoss : 1; // 0x50(0x01)
	char bClipSourceSegement : 1; // 0x50(0x01)
	char bEnablePreviousTangentRecalculation : 1; // 0x50(0x01)
	char bTangentRecalculationEveryFrame : 1; // 0x50(0x01)
	char bSpawnInitialParticle : 1; // 0x50(0x01)
	char pad_50_6 : 2; // 0x50(0x01)
	char pad_51[0x3]; // 0x51(0x03)
	enum class ETrailsRenderAxisOption RenderAxis; // 0x54(0x01)
	char pad_55[0x3]; // 0x55(0x03)
	float TangentSpawningScalar; // 0x58(0x04)
	char bRenderGeometry : 1; // 0x5c(0x01)
	char bRenderSpawnPoints : 1; // 0x5c(0x01)
	char bRenderTangents : 1; // 0x5c(0x01)
	char bRenderTessellation : 1; // 0x5c(0x01)
	char pad_5C_4 : 4; // 0x5c(0x01)
	char pad_5D[0x3]; // 0x5d(0x03)
	float TilingDistance; // 0x60(0x04)
	float DistanceTessellationStepSize; // 0x64(0x04)
	char bEnableTangentDiffInterpScale : 1; // 0x68(0x01)
	char pad_68_1 : 7; // 0x68(0x01)
	char pad_69[0x3]; // 0x69(0x03)
	float TangentTessellationScalar; // 0x6c(0x04)
};

// Class Engine.ParticleModuleVectorFieldBase
// Size: 0x40 (Inherited: 0x40)
struct UParticleModuleVectorFieldBase : UParticleModule {
};

// Class Engine.ParticleModuleVectorFieldGlobal
// Size: 0x50 (Inherited: 0x40)
struct UParticleModuleVectorFieldGlobal : UParticleModuleVectorFieldBase {
	char bOverrideGlobalVectorFieldTightness : 1; // 0x40(0x01)
	char pad_40_1 : 7; // 0x40(0x01)
	char pad_41[0x3]; // 0x41(0x03)
	float GlobalVectorFieldScale; // 0x44(0x04)
	float GlobalVectorFieldTightness; // 0x48(0x04)
	char pad_4C[0x4]; // 0x4c(0x04)
};

// Class Engine.ParticleModuleVectorFieldLocal
// Size: 0x78 (Inherited: 0x40)
struct UParticleModuleVectorFieldLocal : UParticleModuleVectorFieldBase {
	struct UVectorField* VectorField; // 0x40(0x08)
	struct FVector RelativeTranslation; // 0x48(0x0c)
	struct FRotator RelativeRotation; // 0x54(0x0c)
	struct FVector RelativeScale3D; // 0x60(0x0c)
	float Intensity; // 0x6c(0x04)
	float Tightness; // 0x70(0x04)
	char bIgnoreComponentTransform : 1; // 0x74(0x01)
	char bTileX : 1; // 0x74(0x01)
	char bTileY : 1; // 0x74(0x01)
	char bTileZ : 1; // 0x74(0x01)
	char bUseFixDT : 1; // 0x74(0x01)
	char pad_74_5 : 3; // 0x74(0x01)
	char pad_75[0x3]; // 0x75(0x03)
};

// Class Engine.ParticleModuleVectorFieldRotation
// Size: 0x58 (Inherited: 0x40)
struct UParticleModuleVectorFieldRotation : UParticleModuleVectorFieldBase {
	struct FVector MinInitialRotation; // 0x40(0x0c)
	struct FVector MaxInitialRotation; // 0x4c(0x0c)
};

// Class Engine.ParticleModuleVectorFieldRotationRate
// Size: 0x50 (Inherited: 0x40)
struct UParticleModuleVectorFieldRotationRate : UParticleModuleVectorFieldBase {
	struct FVector RotationRate; // 0x40(0x0c)
	char pad_4C[0x4]; // 0x4c(0x04)
};

// Class Engine.ParticleModuleVectorFieldScale
// Size: 0x80 (Inherited: 0x40)
struct UParticleModuleVectorFieldScale : UParticleModuleVectorFieldBase {
	struct UDistributionFloat* VectorFieldScale; // 0x40(0x08)
	struct FRawDistributionFloat VectorFieldScaleRaw; // 0x48(0x38)
};

// Class Engine.ParticleModuleVectorFieldScaleOverLife
// Size: 0x80 (Inherited: 0x40)
struct UParticleModuleVectorFieldScaleOverLife : UParticleModuleVectorFieldBase {
	struct UDistributionFloat* VectorFieldScaleOverLife; // 0x40(0x08)
	struct FRawDistributionFloat VectorFieldScaleOverLifeRaw; // 0x48(0x38)
};

// Class Engine.ParticleModuleVelocityBase
// Size: 0x48 (Inherited: 0x40)
struct UParticleModuleVelocityBase : UParticleModule {
	char bInWorldSpace : 1; // 0x40(0x01)
	char bApplyOwnerScale : 1; // 0x40(0x01)
	char pad_40_2 : 6; // 0x40(0x01)
	char pad_41[0x7]; // 0x41(0x07)
};

// Class Engine.ParticleModuleVelocity
// Size: 0xd0 (Inherited: 0x48)
struct UParticleModuleVelocity : UParticleModuleVelocityBase {
	struct FRawDistributionVector StartVelocity; // 0x48(0x50)
	struct FRawDistributionFloat StartVelocityRadial; // 0x98(0x38)
};

// Class Engine.ParticleModuleVelocity_Seeded
// Size: 0xf0 (Inherited: 0xd0)
struct UParticleModuleVelocity_Seeded : UParticleModuleVelocity {
	struct FParticleRandomSeedInfo RandomSeedInfo; // 0xd0(0x20)
};

// Class Engine.ParticleModuleVelocityCone
// Size: 0xc8 (Inherited: 0x48)
struct UParticleModuleVelocityCone : UParticleModuleVelocityBase {
	struct FRawDistributionFloat Angle; // 0x48(0x38)
	struct FRawDistributionFloat Velocity; // 0x80(0x38)
	struct FVector Direction; // 0xb8(0x0c)
	char pad_C4[0x4]; // 0xc4(0x04)
};

// Class Engine.ParticleModuleVelocityInheritParent
// Size: 0x98 (Inherited: 0x48)
struct UParticleModuleVelocityInheritParent : UParticleModuleVelocityBase {
	struct FRawDistributionVector Scale; // 0x48(0x50)
};

// Class Engine.ParticleModuleVelocityOverLifetime
// Size: 0xa0 (Inherited: 0x48)
struct UParticleModuleVelocityOverLifetime : UParticleModuleVelocityBase {
	struct FRawDistributionVector VelOverLife; // 0x48(0x50)
	char Absolute : 1; // 0x98(0x01)
	char pad_98_1 : 7; // 0x98(0x01)
	char pad_99[0x7]; // 0x99(0x07)
};

// Class Engine.ParticleSystemReplay
// Size: 0x50 (Inherited: 0x38)
struct UParticleSystemReplay : UObject {
	int32 ClipIDNumber; // 0x38(0x04)
	char pad_3C[0x14]; // 0x3c(0x14)
};

// Class Engine.DemoPendingNetGame
// Size: 0xd8 (Inherited: 0xd8)
struct UDemoPendingNetGame : UPendingNetGame {
};

// Class Engine.PhysicalMaterial
// Size: 0x90 (Inherited: 0x38)
struct UPhysicalMaterial : UObject {
	float Friction; // 0x38(0x04)
	enum class EFrictionCombineMode FrictionCombineMode; // 0x3c(0x01)
	bool bOverrideFrictionCombineMode; // 0x3d(0x01)
	char pad_3E[0x2]; // 0x3e(0x02)
	float Restitution; // 0x40(0x04)
	enum class EFrictionCombineMode RestitutionCombineMode; // 0x44(0x01)
	bool bOverrideRestitutionCombineMode; // 0x45(0x01)
	char pad_46[0x2]; // 0x46(0x02)
	float Density; // 0x48(0x04)
	float RaiseMassToPower; // 0x4c(0x04)
	float DestructibleDamageThresholdScale; // 0x50(0x04)
	char pad_54[0x4]; // 0x54(0x04)
	struct UPhysicalMaterialPropertyBase* PhysicalMaterialProperty; // 0x58(0x08)
	enum class EPhysicalSurface SurfaceType; // 0x60(0x01)
	char pad_61[0x3]; // 0x61(0x03)
	float TireFrictionScale; // 0x64(0x04)
	struct TArray<struct FTireFrictionScalePair> TireFrictionScales; // 0x68(0x10)
	char pad_78[0x18]; // 0x78(0x18)
};

// Class Engine.PhysicalMaterialPropertyBase
// Size: 0x38 (Inherited: 0x38)
struct UPhysicalMaterialPropertyBase : UObject {
};

// Class Engine.PhysicsCollisionHandler
// Size: 0x50 (Inherited: 0x38)
struct UPhysicsCollisionHandler : UObject {
	float ImpactThreshold; // 0x38(0x04)
	float ImpactReFireDelay; // 0x3c(0x04)
	struct USoundBase* DefaultImpactSound; // 0x40(0x08)
	float LastImpactSoundTime; // 0x48(0x04)
	char pad_4C[0x4]; // 0x4c(0x04)
};

// Class Engine.PhysicsConstraintTemplate
// Size: 0x350 (Inherited: 0x38)
struct UPhysicsConstraintTemplate : UObject {
	char pad_38[0x8]; // 0x38(0x08)
	struct FConstraintInstance DefaultInstance; // 0x40(0x1f0)
	struct TArray<struct FPhysicsConstraintProfileHandle> ProfileHandles; // 0x230(0x10)
	struct FConstraintProfileProperties DefaultProfile; // 0x240(0x104)
	char pad_344[0xc]; // 0x344(0x0c)
};

// Class Engine.PhysicsSerializer
// Size: 0xe0 (Inherited: 0x38)
struct UPhysicsSerializer : UObject {
	char pad_38[0xa8]; // 0x38(0xa8)
};

// Class Engine.PlatformInterfaceBase
// Size: 0x48 (Inherited: 0x38)
struct UPlatformInterfaceBase : UObject {
	struct TArray<struct FDelegateArray> AllDelegates; // 0x38(0x10)
};

// Class Engine.CloudStorageBase
// Size: 0x60 (Inherited: 0x48)
struct UCloudStorageBase : UPlatformInterfaceBase {
	struct TArray<struct FString> LocalCloudFiles; // 0x48(0x10)
	char bSuppressDelegateCalls : 1; // 0x58(0x01)
	char pad_58_1 : 7; // 0x58(0x01)
	char pad_59[0x7]; // 0x59(0x07)
};

// Class Engine.InGameAdManager
// Size: 0x70 (Inherited: 0x48)
struct UInGameAdManager : UPlatformInterfaceBase {
	char bShouldPauseWhileAdOpen : 1; // 0x48(0x01)
	char pad_48_1 : 7; // 0x48(0x01)
	char pad_49[0x7]; // 0x49(0x07)
	struct TArray<DelegateProperty> ClickedBannerDelegates; // 0x50(0x10)
	struct TArray<DelegateProperty> ClosedAdDelegates; // 0x60(0x10)
};

// Class Engine.MicroTransactionBase
// Size: 0x78 (Inherited: 0x48)
struct UMicroTransactionBase : UPlatformInterfaceBase {
	struct TArray<struct FPurchaseInfo> AvailableProducts; // 0x48(0x10)
	struct FString LastError; // 0x58(0x10)
	struct FString LastErrorSolution; // 0x68(0x10)
};

// Class Engine.TwitterIntegrationBase
// Size: 0x48 (Inherited: 0x48)
struct UTwitterIntegrationBase : UPlatformInterfaceBase {

	bool TwitterRequest(struct FString URL, struct TArray<struct FString> ParamKeysAndValues, enum class ETwitterRequestMethod RequestMethod, int32 AccountIndex); // Function Engine.TwitterIntegrationBase.TwitterRequest // Native|Public|HasOutParms // @ game+0x5b77bb8
	bool ShowTweetUI(struct FString InitialMessage, struct FString URL, struct FString Picture); // Function Engine.TwitterIntegrationBase.ShowTweetUI // Native|Public // @ game+0x5b75d78
	void Init(); // Function Engine.TwitterIntegrationBase.Init // Native|Public // @ game+0xc64df0
	int32 GetNumAccounts(); // Function Engine.TwitterIntegrationBase.GetNumAccounts // Native|Public // @ game+0x5b6d228
	struct FString GetAccountName(int32 AccountIndex); // Function Engine.TwitterIntegrationBase.GetAccountName // Native|Public // @ game+0x5b6bd0c
	bool CanShowTweetUI(); // Function Engine.TwitterIntegrationBase.CanShowTweetUI // Native|Public // @ game+0x5b67954
	bool AuthorizeAccounts(); // Function Engine.TwitterIntegrationBase.AuthorizeAccounts // Native|Public // @ game+0x5af1fe8
};

// Class Engine.PlatformInterfaceWebResponse
// Size: 0xc0 (Inherited: 0x38)
struct UPlatformInterfaceWebResponse : UObject {
	struct FString OriginalURL; // 0x38(0x10)
	int32 ResponseCode; // 0x48(0x04)
	int32 Tag; // 0x4c(0x04)
	struct FString StringResponse; // 0x50(0x10)
	struct TArray<bool> BinaryResponse; // 0x60(0x10)
	char pad_70[0x50]; // 0x70(0x50)

	int32 GetNumHeaders(); // Function Engine.PlatformInterfaceWebResponse.GetNumHeaders // Native|Public // @ game+0x5b6d250
	struct FString GetHeaderValue(struct FString HeaderName); // Function Engine.PlatformInterfaceWebResponse.GetHeaderValue // Native|Public // @ game+0x5b6cb70
	void GetHeader(int32 HeaderIndex, struct FString Header, struct FString Value); // Function Engine.PlatformInterfaceWebResponse.GetHeader // Native|Public|HasOutParms // @ game+0x5b6c9c8
};

// Class Engine.ChildConnection
// Size: 0x65850 (Inherited: 0x65848)
struct UChildConnection : UNetConnection {
	struct UNetConnection* Parent; // 0x65848(0x08)
};

// Class Engine.Polys
// Size: 0x48 (Inherited: 0x38)
struct UPolys : UObject {
	char pad_38[0x10]; // 0x38(0x10)
};

// Class Engine.ReporterBase
// Size: 0x40 (Inherited: 0x38)
struct UReporterBase : UObject {
	char pad_38[0x8]; // 0x38(0x08)
};

// Class Engine.ReporterGraph
// Size: 0xb8 (Inherited: 0x40)
struct UReporterGraph : UReporterBase {
	char pad_40[0x78]; // 0x40(0x78)
};

// Class Engine.ReverbEffect
// Size: 0x68 (Inherited: 0x38)
struct UReverbEffect : UObject {
	float Density; // 0x38(0x04)
	float Diffusion; // 0x3c(0x04)
	float Gain; // 0x40(0x04)
	float GainHF; // 0x44(0x04)
	float DecayTime; // 0x48(0x04)
	float DecayHFRatio; // 0x4c(0x04)
	float ReflectionsGain; // 0x50(0x04)
	float ReflectionsDelay; // 0x54(0x04)
	float LateGain; // 0x58(0x04)
	float LateDelay; // 0x5c(0x04)
	float AirAbsorptionGainHF; // 0x60(0x04)
	float RoomRolloffFactor; // 0x64(0x04)
};

// Class Engine.Rig
// Size: 0x58 (Inherited: 0x38)
struct URig : UObject {
	struct TArray<struct FTransformBase> TransformBases; // 0x38(0x10)
	struct TArray<struct FNode> Nodes; // 0x48(0x10)
};

// Class Engine.SimpleConstructionScript
// Size: 0xc8 (Inherited: 0x38)
struct USimpleConstructionScript : UObject {
	struct TArray<struct USCS_Node*> RootNodes; // 0x38(0x10)
	struct TArray<struct USCS_Node*> AllNodes; // 0x48(0x10)
	struct USCS_Node* DefaultSceneRootNode; // 0x58(0x08)
	struct USCS_Node* RootNode; // 0x60(0x08)
	struct TArray<struct USCS_Node*> ActorComponentNodes; // 0x68(0x10)
	char pad_78[0x50]; // 0x78(0x50)
};

// Class Engine.SCS_Node
// Size: 0x160 (Inherited: 0x38)
struct USCS_Node : UObject {
	struct UClass* ComponentClass; // 0x38(0x08)
	struct UActorComponent* ComponentTemplate; // 0x40(0x08)
	struct FBlueprintCookedComponentInstancingData CookedComponentInstancingData; // 0x48(0x50)
	struct FName VariableName; // 0x98(0x08)
	struct FName AttachToName; // 0xa0(0x08)
	struct FName ParentComponentOrVariableName; // 0xa8(0x08)
	struct FName ParentComponentOwnerClassName; // 0xb0(0x08)
	bool bIsParentComponentNative; // 0xb8(0x01)
	char pad_B9[0x7]; // 0xb9(0x07)
	struct TArray<struct USCS_Node*> ChildNodes; // 0xc0(0x10)
	struct USCS_Node* LODParentNode; // 0xd0(0x08)
	struct TArray<struct FBPVariableMetaDataEntry> MetaDataArray; // 0xd8(0x10)
	struct FGuid VariableGuid; // 0xe8(0x10)
	bool bIsFalseRoot; // 0xf8(0x01)
	bool bIsNative; // 0xf9(0x01)
	char pad_FA[0x6]; // 0xfa(0x06)
	struct FName NativeComponentName; // 0x100(0x08)
	bool bVariableNameAutoGenerated; // 0x108(0x01)
	char pad_109[0x7]; // 0x109(0x07)
	struct FName InternalVariableName; // 0x110(0x08)
	char pad_118[0x48]; // 0x118(0x48)
};

// Class Engine.Selection
// Size: 0xa0 (Inherited: 0x38)
struct USelection : UObject {
	char pad_38[0x68]; // 0x38(0x68)
};

// Class Engine.DestructibleMesh
// Size: 0x3a8 (Inherited: 0x300)
struct UDestructibleMesh : USkeletalMesh {
	struct FDestructibleParameters DefaultDestructibleParameters; // 0x300(0x88)
	struct TArray<struct FFractureEffect> FractureEffects; // 0x388(0x10)
	char pad_398[0x10]; // 0x398(0x10)
};

// Class Engine.SkeletalMeshReductionSettings
// Size: 0x50 (Inherited: 0x38)
struct USkeletalMeshReductionSettings : UObject {
	struct TArray<struct FSkeletalMeshLODGroupSettings> Settings; // 0x38(0x10)
	char pad_48[0x8]; // 0x48(0x08)
};

// Class Engine.SkeletalMeshSocket
// Size: 0x70 (Inherited: 0x38)
struct USkeletalMeshSocket : UObject {
	struct FName SocketName; // 0x38(0x08)
	struct FName BoneName; // 0x40(0x08)
	struct FVector RelativeLocation; // 0x48(0x0c)
	struct FRotator RelativeRotation; // 0x54(0x0c)
	struct FVector RelativeScale; // 0x60(0x0c)
	bool bForceAlwaysAnimated; // 0x6c(0x01)
	char pad_6D[0x3]; // 0x6d(0x03)

	void InitializeSocketFromLocation(struct USkeletalMeshComponent* SkelComp, struct FVector WorldLocation, struct FVector WorldNormal); // Function Engine.SkeletalMeshSocket.InitializeSocketFromLocation // Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable // @ game+0x5b6f024
	struct FVector GetSocketLocation(struct USkeletalMeshComponent* SkelComp); // Function Engine.SkeletalMeshSocket.GetSocketLocation // Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const // @ game+0x5b6e350
};

// Class Engine.SlateBrushAsset
// Size: 0xc8 (Inherited: 0x38)
struct USlateBrushAsset : UObject {
	struct FSlateBrush Brush; // 0x38(0x90)
};

// Class Engine.SlateTextureAtlasInterface
// Size: 0x38 (Inherited: 0x38)
struct USlateTextureAtlasInterface : UInterface {
};

// Class Engine.SoundConcurrency
// Size: 0x48 (Inherited: 0x38)
struct USoundConcurrency : UObject {
	struct FSoundConcurrencySettings Concurrency; // 0x38(0x10)
};

// Class Engine.SoundEffectPreset
// Size: 0x50 (Inherited: 0x38)
struct USoundEffectPreset : UObject {
	char pad_38[0x18]; // 0x38(0x18)
};

// Class Engine.SoundEffectSubmixPreset
// Size: 0x50 (Inherited: 0x50)
struct USoundEffectSubmixPreset : USoundEffectPreset {
};

// Class Engine.SoundSubmix
// Size: 0x60 (Inherited: 0x38)
struct USoundSubmix : UObject {
	struct TArray<struct USoundSubmix*> ChildSubmixes; // 0x38(0x10)
	struct USoundSubmix* ParentSubmix; // 0x48(0x08)
	struct TArray<struct USoundEffectSubmixPreset*> SubmixEffectChain; // 0x50(0x10)
};

// Class Engine.SoundBase
// Size: 0xb0 (Inherited: 0x38)
struct USoundBase : UObject {
	struct USoundClass* SoundClassObject; // 0x38(0x08)
	char bDebug : 1; // 0x40(0x01)
	char bOverrideConcurrency : 1; // 0x40(0x01)
	char bIgnoreFocus : 1; // 0x40(0x01)
	char pad_40_3 : 5; // 0x40(0x01)
	char pad_41[0x7]; // 0x41(0x07)
	struct USoundConcurrency* SoundConcurrencySettings; // 0x48(0x08)
	struct FSoundConcurrencySettings ConcurrencyOverrides; // 0x50(0x10)
	enum class EMaxConcurrentResolutionRule MaxConcurrentResolutionRule; // 0x60(0x01)
	char pad_61[0x3]; // 0x61(0x03)
	int32 MaxConcurrentPlayCount; // 0x64(0x04)
	float Duration; // 0x68(0x04)
	char pad_6C[0x4]; // 0x6c(0x04)
	struct USoundAttenuation* AttenuationSettings; // 0x70(0x08)
	float Priority; // 0x78(0x04)
	char pad_7C[0x4]; // 0x7c(0x04)
	struct USoundSubmix* SoundSubmixObject; // 0x80(0x08)
	struct TArray<struct FSoundSubmixSendInfo> SoundSubmixSends; // 0x88(0x10)
	float DefaultMasterReverbSendAmount; // 0x98(0x04)
	char pad_9C[0x4]; // 0x9c(0x04)
	struct USoundEffectSourcePresetChain* SourceEffectChain; // 0xa0(0x08)
	char pad_A8[0x8]; // 0xa8(0x08)
};

// Class Engine.DialogueSoundWaveProxy
// Size: 0xd0 (Inherited: 0xb0)
struct UDialogueSoundWaveProxy : USoundBase {
	char pad_B0[0x20]; // 0xb0(0x20)
};

// Class Engine.SoundNode
// Size: 0x48 (Inherited: 0x38)
struct USoundNode : UObject {
	struct TArray<struct USoundNode*> ChildNodes; // 0x38(0x10)
};

// Class Engine.SoundCue
// Size: 0x208 (Inherited: 0xb0)
struct USoundCue : USoundBase {
	char bOverrideAttenuation : 1; // 0xb0(0x01)
	char pad_B0_1 : 7; // 0xb0(0x01)
	char pad_B1[0x7]; // 0xb1(0x07)
	struct USoundNode* FirstNode; // 0xb8(0x08)
	float VolumeMultiplier; // 0xc0(0x04)
	float PitchMultiplier; // 0xc4(0x04)
	struct FSoundAttenuationSettings AttenuationOverrides; // 0xc8(0x130)
	char pad_1F8[0x10]; // 0x1f8(0x10)
};

// Class Engine.SoundGroups
// Size: 0x98 (Inherited: 0x38)
struct USoundGroups : UObject {
	struct TArray<struct FSoundGroup> SoundGroupProfiles; // 0x38(0x10)
	char pad_48[0x50]; // 0x48(0x50)
};

// Class Engine.SoundWave
// Size: 0x298 (Inherited: 0xb0)
struct USoundWave : USoundBase {
	int32 CompressionQuality; // 0xb0(0x04)
	char bLooping : 1; // 0xb4(0x01)
	char bStreaming : 1; // 0xb4(0x01)
	char pad_B4_2 : 6; // 0xb4(0x01)
	char pad_B5[0x3]; // 0xb5(0x03)
	int32 StreamingPriority; // 0xb8(0x04)
	char pad_BC_0 : 3; // 0xbc(0x01)
	char bMature : 1; // 0xbc(0x01)
	char bManualWordWrap : 1; // 0xbc(0x01)
	char bSingleLine : 1; // 0xbc(0x01)
	char bVirtualizeWhenSilent : 1; // 0xbc(0x01)
	char pad_BC_7 : 1; // 0xbc(0x01)
	char pad_BD[0x3]; // 0xbd(0x03)
	enum class ESoundGroup SoundGroup; // 0xc0(0x01)
	char pad_C1[0x7]; // 0xc1(0x07)
	struct FString SpokenText; // 0xc8(0x10)
	float SubtitlePriority; // 0xd8(0x04)
	float Volume; // 0xdc(0x04)
	float Pitch; // 0xe0(0x04)
	int32 NumChannels; // 0xe4(0x04)
	int32 SampleRate; // 0xe8(0x04)
	int32 RawPCMDataSize; // 0xec(0x04)
	struct TArray<struct FSubtitleCue> Subtitles; // 0xf0(0x10)
	struct TArray<struct FLocalizedSubtitle> LocalizedSubtitles; // 0x100(0x10)
	struct UCurveTable* Curves; // 0x110(0x08)
	struct UCurveTable* InternalCurves; // 0x118(0x08)
	char pad_120[0x178]; // 0x120(0x178)
};

// Class Engine.SoundWaveProcedural
// Size: 0x320 (Inherited: 0x298)
struct USoundWaveProcedural : USoundWave {
	char pad_298[0x88]; // 0x298(0x88)
};

// Class Engine.SoundClass
// Size: 0x90 (Inherited: 0x38)
struct USoundClass : UObject {
	struct FSoundClassProperties Properties; // 0x38(0x2c)
	char pad_64[0x4]; // 0x64(0x04)
	struct TArray<struct USoundClass*> ChildClasses; // 0x68(0x10)
	struct TArray<struct FPassiveSoundMixModifier> PassiveSoundMixModifiers; // 0x78(0x10)
	struct USoundClass* ParentClass; // 0x88(0x08)
};

// Class Engine.SoundEffectSourcePreset
// Size: 0x50 (Inherited: 0x50)
struct USoundEffectSourcePreset : USoundEffectPreset {
};

// Class Engine.SoundEffectSourcePresetChain
// Size: 0x50 (Inherited: 0x38)
struct USoundEffectSourcePresetChain : UObject {
	struct TArray<struct FSourceEffectChainEntry> Chain; // 0x38(0x10)
	char bPlayEffectChainTails : 1; // 0x48(0x01)
	char pad_48_1 : 7; // 0x48(0x01)
	char pad_49[0x7]; // 0x49(0x07)
};

// Class Engine.SoundMix
// Size: 0x98 (Inherited: 0x38)
struct USoundMix : UObject {
	char bApplyEQ : 1; // 0x38(0x01)
	char pad_38_1 : 7; // 0x38(0x01)
	char pad_39[0x3]; // 0x39(0x03)
	float EQPriority; // 0x3c(0x04)
	struct FAudioEQEffect EQSettings; // 0x40(0x38)
	struct TArray<struct FSoundClassAdjuster> SoundClassEffects; // 0x78(0x10)
	float InitialDelay; // 0x88(0x04)
	float FadeInTime; // 0x8c(0x04)
	float Duration; // 0x90(0x04)
	float FadeOutTime; // 0x94(0x04)
};

// Class Engine.SoundNodeAssetReferencer
// Size: 0x48 (Inherited: 0x48)
struct USoundNodeAssetReferencer : USoundNode {
};

// Class Engine.SoundNodeWavePlayer
// Size: 0x78 (Inherited: 0x48)
struct USoundNodeWavePlayer : USoundNodeAssetReferencer {
	struct USoundWave* SoundWaveAssetPtr; // 0x48(0x20)
	struct USoundWave* SoundWave; // 0x68(0x08)
	char pad_70_0 : 1; // 0x70(0x01)
	char bLooping : 1; // 0x70(0x01)
	char pad_70_2 : 6; // 0x70(0x01)
	char pad_71[0x7]; // 0x71(0x07)
};

// Class Engine.SoundNodeAttenuation
// Size: 0x188 (Inherited: 0x48)
struct USoundNodeAttenuation : USoundNode {
	struct USoundAttenuation* AttenuationSettings; // 0x48(0x08)
	struct FSoundAttenuationSettings AttenuationOverrides; // 0x50(0x130)
	char bOverrideAttenuation : 1; // 0x180(0x01)
	char pad_180_1 : 7; // 0x180(0x01)
	char pad_181[0x7]; // 0x181(0x07)
};

// Class Engine.SoundNodeBranch
// Size: 0x50 (Inherited: 0x48)
struct USoundNodeBranch : USoundNode {
	struct FName BoolParameterName; // 0x48(0x08)
};

// Class Engine.SoundNodeConcatenator
// Size: 0x58 (Inherited: 0x48)
struct USoundNodeConcatenator : USoundNode {
	struct TArray<float> InputVolume; // 0x48(0x10)
};

// Class Engine.SoundNodeDelay
// Size: 0x50 (Inherited: 0x48)
struct USoundNodeDelay : USoundNode {
	float DelayMin; // 0x48(0x04)
	float DelayMax; // 0x4c(0x04)
};

// Class Engine.SoundNodeDialoguePlayer
// Size: 0x70 (Inherited: 0x48)
struct USoundNodeDialoguePlayer : USoundNode {
	struct FDialogueWaveParameter DialogueWaveParameter; // 0x48(0x20)
	char bLooping : 1; // 0x68(0x01)
	char pad_68_1 : 7; // 0x68(0x01)
	char pad_69[0x7]; // 0x69(0x07)
};

// Class Engine.SoundNodeDistanceCrossFade
// Size: 0x58 (Inherited: 0x48)
struct USoundNodeDistanceCrossFade : USoundNode {
	struct TArray<struct FDistanceDatum> CrossFadeInput; // 0x48(0x10)
};

// Class Engine.SoundNodeParamCrossFade
// Size: 0x60 (Inherited: 0x58)
struct USoundNodeParamCrossFade : USoundNodeDistanceCrossFade {
	struct FName ParamName; // 0x58(0x08)
};

// Class Engine.SoundNodeDoppler
// Size: 0x50 (Inherited: 0x48)
struct USoundNodeDoppler : USoundNode {
	float DopplerIntensity; // 0x48(0x04)
	char pad_4C[0x4]; // 0x4c(0x04)
};

// Class Engine.SoundNodeEnveloper
// Size: 0x170 (Inherited: 0x48)
struct USoundNodeEnveloper : USoundNode {
	float LoopStart; // 0x48(0x04)
	float LoopEnd; // 0x4c(0x04)
	float DurationAfterLoop; // 0x50(0x04)
	int32 LoopCount; // 0x54(0x04)
	char bLoopIndefinitely : 1; // 0x58(0x01)
	char bLoop : 1; // 0x58(0x01)
	char pad_58_2 : 6; // 0x58(0x01)
	char pad_59[0x7]; // 0x59(0x07)
	struct UDistributionFloatConstantCurve* VolumeInterpCurve; // 0x60(0x08)
	struct UDistributionFloatConstantCurve* PitchInterpCurve; // 0x68(0x08)
	struct FRuntimeFloatCurve VolumeCurve; // 0x70(0x78)
	struct FRuntimeFloatCurve PitchCurve; // 0xe8(0x78)
	float PitchMin; // 0x160(0x04)
	float PitchMax; // 0x164(0x04)
	float VolumeMin; // 0x168(0x04)
	float VolumeMax; // 0x16c(0x04)
};

// Class Engine.SoundNodeGroupControl
// Size: 0x58 (Inherited: 0x48)
struct USoundNodeGroupControl : USoundNode {
	struct TArray<int32> GroupSizes; // 0x48(0x10)
};

// Class Engine.SoundNodeLooping
// Size: 0x50 (Inherited: 0x48)
struct USoundNodeLooping : USoundNode {
	int32 LoopCount; // 0x48(0x04)
	char bLoopIndefinitely : 1; // 0x4c(0x01)
	char pad_4C_1 : 7; // 0x4c(0x01)
	char pad_4D[0x3]; // 0x4d(0x03)
};

// Class Engine.SoundNodeMature
// Size: 0x48 (Inherited: 0x48)
struct USoundNodeMature : USoundNode {
};

// Class Engine.SoundNodeMixer
// Size: 0x58 (Inherited: 0x48)
struct USoundNodeMixer : USoundNode {
	struct TArray<float> InputVolume; // 0x48(0x10)
};

// Class Engine.SoundNodeModulator
// Size: 0x58 (Inherited: 0x48)
struct USoundNodeModulator : USoundNode {
	float PitchMin; // 0x48(0x04)
	float PitchMax; // 0x4c(0x04)
	float VolumeMin; // 0x50(0x04)
	float VolumeMax; // 0x54(0x04)
};

// Class Engine.SoundNodeModulatorContinuous
// Size: 0x88 (Inherited: 0x48)
struct USoundNodeModulatorContinuous : USoundNode {
	struct FModulatorContinuousParams PitchModulationParams; // 0x48(0x20)
	struct FModulatorContinuousParams VolumeModulationParams; // 0x68(0x20)
};

// Class Engine.SoundNodeOscillator
// Size: 0x70 (Inherited: 0x48)
struct USoundNodeOscillator : USoundNode {
	char bModulateVolume : 1; // 0x48(0x01)
	char bModulatePitch : 1; // 0x48(0x01)
	char pad_48_2 : 6; // 0x48(0x01)
	char pad_49[0x3]; // 0x49(0x03)
	float AmplitudeMin; // 0x4c(0x04)
	float AmplitudeMax; // 0x50(0x04)
	float FrequencyMin; // 0x54(0x04)
	float FrequencyMax; // 0x58(0x04)
	float OffsetMin; // 0x5c(0x04)
	float OffsetMax; // 0x60(0x04)
	float CenterMin; // 0x64(0x04)
	float CenterMax; // 0x68(0x04)
	char pad_6C[0x4]; // 0x6c(0x04)
};

// Class Engine.SoundNodeQualityLevel
// Size: 0x48 (Inherited: 0x48)
struct USoundNodeQualityLevel : USoundNode {
};

// Class Engine.SoundNodeRandom
// Size: 0x78 (Inherited: 0x48)
struct USoundNodeRandom : USoundNode {
	struct TArray<float> Weights; // 0x48(0x10)
	int32 PreselectAtLevelLoad; // 0x58(0x04)
	char bRandomizeWithoutReplacement : 1; // 0x5c(0x01)
	char pad_5C_1 : 7; // 0x5c(0x01)
	char pad_5D[0x3]; // 0x5d(0x03)
	struct TArray<bool> HasBeenUsed; // 0x60(0x10)
	int32 NumRandomUsed; // 0x70(0x04)
	char pad_74[0x4]; // 0x74(0x04)
};

// Class Engine.SoundNodeSoundClass
// Size: 0x50 (Inherited: 0x48)
struct USoundNodeSoundClass : USoundNode {
	struct USoundClass* SoundClassOverride; // 0x48(0x08)
};

// Class Engine.SoundNodeSwitch
// Size: 0x50 (Inherited: 0x48)
struct USoundNodeSwitch : USoundNode {
	struct FName IntParameterName; // 0x48(0x08)
};

// Class Engine.SoundNodeWaveParam
// Size: 0x50 (Inherited: 0x48)
struct USoundNodeWaveParam : USoundNode {
	struct FName WaveParameterName; // 0x48(0x08)
};

// Class Engine.StaticMeshSocket
// Size: 0x78 (Inherited: 0x38)
struct UStaticMeshSocket : UObject {
	struct FName SocketName; // 0x38(0x08)
	struct FVector RelativeLocation; // 0x40(0x0c)
	struct FRotator RelativeRotation; // 0x4c(0x0c)
	struct FVector RelativeScale; // 0x58(0x0c)
	char pad_64[0x4]; // 0x64(0x04)
	struct FString Tag; // 0x68(0x10)
};

// Class Engine.StringTable
// Size: 0x50 (Inherited: 0x38)
struct UStringTable : UObject {
	char pad_38[0x18]; // 0x38(0x18)
};

// Class Engine.SubsurfaceProfile
// Size: 0x60 (Inherited: 0x38)
struct USubsurfaceProfile : UObject {
	struct FSubsurfaceProfileStruct Settings; // 0x38(0x24)
	char pad_5C[0x4]; // 0x5c(0x04)
};

// Class Engine.TextPropertyTestObject
// Size: 0x80 (Inherited: 0x38)
struct UTextPropertyTestObject : UObject {
	struct FText DefaultedText; // 0x38(0x18)
	struct FText UndefaultedText; // 0x50(0x18)
	struct FText TransientText; // 0x68(0x18)
};

// Class Engine.LightMapTexture2D
// Size: 0x110 (Inherited: 0x108)
struct ULightMapTexture2D : UTexture2D {
	char pad_108[0x8]; // 0x108(0x08)
};

// Class Engine.ShadowMapTexture2D
// Size: 0x110 (Inherited: 0x108)
struct UShadowMapTexture2D : UTexture2D {
	enum class EShadowMapFlags ShadowmapFlags; // 0x108(0x01)
	char pad_109[0x7]; // 0x109(0x07)
};

// Class Engine.Texture2DArray
// Size: 0x108 (Inherited: 0x108)
struct UTexture2DArray : UTexture2D {
};

// Class Engine.TextureLightProfile
// Size: 0x110 (Inherited: 0x108)
struct UTextureLightProfile : UTexture2D {
	float Brightness; // 0x108(0x04)
	float TextureMultiplier; // 0x10c(0x04)
};

// Class Engine.Texture2DDynamic
// Size: 0xe0 (Inherited: 0xc8)
struct UTexture2DDynamic : UTexture {
	char pad_C8[0x8]; // 0xc8(0x08)
	enum class EPixelFormat Format; // 0xd0(0x01)
	char pad_D1[0xf]; // 0xd1(0x0f)
};

// Class Engine.CanvasRenderTarget2D
// Size: 0x118 (Inherited: 0xf8)
struct UCanvasRenderTarget2D : UTextureRenderTarget2D {
	struct FMulticastDelegate OnCanvasRenderTargetUpdate; // 0xf8(0x10)
	struct UWorld* World; // 0x108(0x08)
	bool bShouldClearRenderTargetOnReceiveUpdate; // 0x110(0x01)
	char pad_111[0x7]; // 0x111(0x07)

	void UpdateResource(); // Function Engine.CanvasRenderTarget2D.UpdateResource // Native|Public|BlueprintCallable // @ game+0x4d80fd4
	void ReceiveUpdate(struct UCanvas* Canvas, int32 Width, int32 Height); // Function Engine.CanvasRenderTarget2D.ReceiveUpdate // Event|Public|BlueprintEvent // @ game+0x33e45c
	void GetSize(int32 Width, int32 Height); // Function Engine.CanvasRenderTarget2D.GetSize // Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure // @ game+0x5b6e234
	struct UCanvasRenderTarget2D* CreateCanvasRenderTarget2D(struct UObject* WorldContextObject, struct UClass* CanvasRenderTarget2DClass, int32 Width, int32 Height); // Function Engine.CanvasRenderTarget2D.CreateCanvasRenderTarget2D // Final|Native|Static|Public|BlueprintCallable // @ game+0x5b69bb8
};

// Class Engine.TextureRenderTargetCube
// Size: 0xf0 (Inherited: 0xd0)
struct UTextureRenderTargetCube : UTextureRenderTarget {
	int32 SizeX; // 0xd0(0x04)
	struct FLinearColor ClearColor; // 0xd4(0x10)
	enum class EPixelFormat OverrideFormat; // 0xe4(0x01)
	char pad_E5[0x3]; // 0xe5(0x03)
	char bHDR : 1; // 0xe8(0x01)
	char bForceLinearGamma : 1; // 0xe8(0x01)
	char pad_E8_2 : 6; // 0xe8(0x01)
	char pad_E9[0x7]; // 0xe9(0x07)
};

// Class Engine.TextureLODSettings
// Size: 0x48 (Inherited: 0x38)
struct UTextureLODSettings : UObject {
	struct TArray<struct FTextureLODGroup> TextureLODGroups; // 0x38(0x10)
};

// Class Engine.DeviceProfile
// Size: 0xe0 (Inherited: 0x48)
struct UDeviceProfile : UTextureLODSettings {
	struct FString DeviceType; // 0x48(0x10)
	struct FString BaseProfileName; // 0x58(0x10)
	struct UObject* Parent; // 0x68(0x08)
	char pad_70[0x18]; // 0x70(0x18)
	struct TArray<struct FString> CVars; // 0x88(0x10)
	char pad_98[0x48]; // 0x98(0x48)
};

// Class Engine.ThumbnailInfo
// Size: 0x38 (Inherited: 0x38)
struct UThumbnailInfo : UObject {
};

// Class Engine.TimelineTemplate
// Size: 0xa8 (Inherited: 0x38)
struct UTimelineTemplate : UObject {
	float TimelineLength; // 0x38(0x04)
	enum class ETimelineLengthMode LengthMode; // 0x3c(0x01)
	char pad_3D[0x3]; // 0x3d(0x03)
	char bAutoPlay : 1; // 0x40(0x01)
	char bLoop : 1; // 0x40(0x01)
	char bReplicated : 1; // 0x40(0x01)
	char bValidatedAsWired : 1; // 0x40(0x01)
	char bIgnoreTimeDilation : 1; // 0x40(0x01)
	char pad_40_5 : 3; // 0x40(0x01)
	char pad_41[0x7]; // 0x41(0x07)
	struct TArray<struct FTTEventTrack> EventTracks; // 0x48(0x10)
	struct TArray<struct FTTFloatTrack> FloatTracks; // 0x58(0x10)
	struct TArray<struct FTTVectorTrack> VectorTracks; // 0x68(0x10)
	struct TArray<struct FTTLinearColorTrack> LinearColorTracks; // 0x78(0x10)
	struct TArray<struct FBPVariableMetaDataEntry> MetaDataArray; // 0x88(0x10)
	struct FGuid TimelineGuid; // 0x98(0x10)
};

// Class Engine.TouchInterface
// Size: 0x68 (Inherited: 0x38)
struct UTouchInterface : UObject {
	struct TArray<struct FTouchInputControl> Controls; // 0x38(0x10)
	float ActiveOpacity; // 0x48(0x04)
	float InactiveOpacity; // 0x4c(0x04)
	float TimeUntilDeactive; // 0x50(0x04)
	float TimeUntilReset; // 0x54(0x04)
	float ActivationDelay; // 0x58(0x04)
	bool bPreventRecenter; // 0x5c(0x01)
	char pad_5D[0x3]; // 0x5d(0x03)
	float StartupDelay; // 0x60(0x04)
	char pad_64[0x4]; // 0x64(0x04)
};

// Class Engine.UserDefinedEnum
// Size: 0xd0 (Inherited: 0x80)
struct UUserDefinedEnum : UEnum {
	struct TMap<struct FName, struct FText> DisplayNameMap; // 0x80(0x50)
};

// Class Engine.VectorField
// Size: 0x58 (Inherited: 0x38)
struct UVectorField : UObject {
	struct FBox Bounds; // 0x38(0x1c)
	float Intensity; // 0x54(0x04)
};

// Class Engine.VectorFieldAnimated
// Size: 0x98 (Inherited: 0x58)
struct UVectorFieldAnimated : UVectorField {
	struct UTexture2D* Texture; // 0x58(0x08)
	enum class EVectorFieldConstructionOp ConstructionOp; // 0x60(0x01)
	char pad_61[0x3]; // 0x61(0x03)
	int32 VolumeSizeX; // 0x64(0x04)
	int32 VolumeSizeY; // 0x68(0x04)
	int32 VolumeSizeZ; // 0x6c(0x04)
	int32 SubImagesX; // 0x70(0x04)
	int32 SubImagesY; // 0x74(0x04)
	int32 FrameCount; // 0x78(0x04)
	float FramesPerSecond; // 0x7c(0x04)
	char bLoop : 1; // 0x80(0x01)
	char pad_80_1 : 7; // 0x80(0x01)
	char pad_81[0x7]; // 0x81(0x07)
	struct UVectorFieldStatic* NoiseField; // 0x88(0x08)
	float NoiseScale; // 0x90(0x04)
	float NoiseMax; // 0x94(0x04)
};

// Class Engine.VectorFieldStatic
// Size: 0xf0 (Inherited: 0x58)
struct UVectorFieldStatic : UVectorField {
	int32 SizeX; // 0x58(0x04)
	int32 SizeY; // 0x5c(0x04)
	int32 SizeZ; // 0x60(0x04)
	char pad_64[0x8c]; // 0x64(0x8c)
};

// Class Engine.VisualLoggerAutomationTests
// Size: 0x38 (Inherited: 0x38)
struct UVisualLoggerAutomationTests : UObject {
};

// Class Engine.VisualLoggerDebugSnapshotInterface
// Size: 0x38 (Inherited: 0x38)
struct UVisualLoggerDebugSnapshotInterface : UInterface {
};

// Class Engine.WorldComposition
// Size: 0xa0 (Inherited: 0x38)
struct UWorldComposition : UObject {
	char pad_38[0x38]; // 0x38(0x38)
	struct TArray<struct ULevelStreaming*> TilesStreaming; // 0x70(0x10)
	double TilesStreamingTimeThreshold; // 0x80(0x08)
	bool bLoadAllTilesDuringCinematic; // 0x88(0x01)
	bool bRebaseOriginIn3DSpace; // 0x89(0x01)
	char pad_8A[0x2]; // 0x8a(0x02)
	float RebaseOriginDistance; // 0x8c(0x04)
	struct TArray<struct FString> IgnoreStreamingPrefix; // 0x90(0x10)
};

