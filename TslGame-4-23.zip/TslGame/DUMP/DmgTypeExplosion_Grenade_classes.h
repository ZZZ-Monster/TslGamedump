// BlueprintGeneratedClass DmgTypeExplosion_Grenade.DmgTypeExplosion_Grenade_C
// Size: 0x100 (Inherited: 0x100)
struct UDmgTypeExplosion_Grenade_C : UTslDamageType {
};

